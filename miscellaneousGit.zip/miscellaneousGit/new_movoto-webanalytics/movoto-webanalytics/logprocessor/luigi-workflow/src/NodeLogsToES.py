# Python libraries
import logging
import os
import subprocess
import datetime
import json
# Internal libraries
import movotolib.luigi_properties
from movotolib.movoto_task import MovotoTask
from movotolib.movoto_task import MovotoEsTarget
# Third-party libraries
import luigi
from luigi.contrib.hdfs.hadoopcli_clients import HdfsClient
from luigi.contrib.hdfs.target import HdfsTarget
from luigi.contrib.hive import *
from luigi.s3 import *
from luigi.hive import HiveTableTarget, run_hive_cmd
from luigi import notifications
from luigi.contrib.spark import *

import boto
import boto.s3.connection
from boto.s3.key import Key

from urllib2 import *
from movotolib.S3GenericLuigi import S3GenericLuigi


def formatDateS3(run_date):
    spdate = str(run_date).split("-")
    firstpart, secondpart = spdate[0][:len(spdate[0]) / 2], spdate[0][len(spdate[0]) / 2:]
    S3FileDate = spdate[1] + spdate[2] + secondpart
    return S3FileDate


def createDirectory(date):
    luigi_config = luigi.configuration.get_config()
    fs = os.path.exists(luigi_config.get('movoto', 'home-dir')+luigi_config.get('S3', 'outputDirectory') + date)
    if (fs):
        logger.debug('Path already created')
    else:
        os.makedirs(luigi_config.get('movoto', 'home-dir')+luigi_config.get('S3', 'outputDirectory') + date)


def ConnectionS3(self):
    access_key = self.luigi_config.get('S3', 'access_key')
    access_secret = self.luigi_config.get('S3', 'access_secret')
    client = S3GenericLuigi(access_key, access_secret)
    return client


class S3DataPull(MovotoTask):
    job_name = luigi.Parameter()
    run_date = luigi.DateParameter(default=datetime.date.today())
    luigi_config = luigi.configuration.get_config()
    get_all = luigi.Parameter(default=False)

    @staticmethod
    def S3Connection(date):
        pass

    def output(self):
        luigi_config = luigi.configuration.get_config()
        return MovotoEsTarget(self.job_name, self.__class__.__name__, self.run_date)

    def requires(self):
        client = ConnectionS3(self)
        S3date = formatDateS3(self.run_date)
        fileExist = client.exists(str(self.luigi_config.get('S3', 's3DirectoryPath')) + S3date)
        if (fileExist):
            pass
        else:
            logger.debug('Node logs not uploaded for the day %s' % self.run_date)
            sys.exit()

    def run_task(self):
        S3date = formatDateS3(self.run_date)
	luigi_config = luigi.configuration.get_config()
        createDirectory(S3date)
        access_key = self.luigi_config.get('S3', 'access_key')
        access_secret = self.luigi_config.get('S3', 'access_secret')
        # Creating a connection

        client = S3GenericLuigi(access_key, access_secret)
        listdir = client.listdir(str(self.luigi_config.get('S3', 's3DirectoryPath')) + S3date + "/")
        for key, value in enumerate(listdir):
            commands = []

            fileName = str(value).split("/")[-1]
            print(fileName)
            commands.append('gunzip')
            commands.append(str(luigi_config.get('movoto', 'home-dir')+self.luigi_config.get('S3', 'outputDirectory')) + S3date + "/" + fileName)

            client.get(value,luigi_config.get('movoto', 'home-dir')+self.luigi_config.get('S3', 'outputDirectory') + S3date + "/" + fileName)
            logger.debug('Extratcing the gz file.....:%s' % fileName)

            output = subprocess.check_output(commands)


class moveNodeLogsToHdfs(MovotoTask):
    job_name = luigi.Parameter()
    run_date = luigi.DateParameter(default=datetime.date.today())
    get_all = luigi.Parameter(default=False)
    luigi_config = luigi.configuration.get_config()

    def output(self):
        luigi_config = luigi.configuration.get_config()
        return MovotoEsTarget(self.job_name, self.__class__.__name__, self.run_date)

    def run_task(self):
        hdfs_client = HdfsClient()
        S3date = formatDateS3(self.run_date)
        hdfs_client.put(str(self.luigi_config.get('movoto', 'home-dir')+self.luigi_config.get('S3', 'outputDirectory') + S3date),
                        str(self.luigi_config.get('NodeLogsToHdfs', 'outputHDFSDirectory')))

    def requires(self):
        return S3DataPull(job_name=self.job_name, run_date=self.run_date)
        #pass


class ParseData(MovotoTask, SparkSubmitTask):
    job_name = luigi.Parameter()
    run_date = luigi.DateParameter(default=datetime.date.today())
    get_all = luigi.Parameter(default=False)
    luigi_config = luigi.configuration.get_config()

    def output(self):
        luigi_config = luigi.configuration.get_config()
        return MovotoEsTarget(self.job_name, self.__class__.__name__, self.run_date)

    def app_options(self):
        S3date = formatDateS3(self.run_date)
        inputPath = str(self.luigi_config.get('spark', 'directoryPath') + S3date + "/access*")
        outputPath = str(self.luigi_config.get('spark', 'destinationPath') + S3date)
	date_of_run = str(self.run_date)
	geonew_filePath = str(self.luigi_config.get('spark', 'geonewpath'))
	patternsPath = str(self.luigi_config.get('movoto', 'home-dir')+self.luigi_config.get('spark', 'patternsPath'))
        self.params = [inputPath, outputPath, date_of_run, geonew_filePath, patternsPath]
        return self.params

    def requires(self):
        return moveNodeLogsToHdfs(job_name=self.job_name, run_date=self.run_date)
        # pass

    def run_task(self):
        spark = ParseData(self.job_name, self.run_date, self.get_all)
        spark.app = self.luigi_config.get('movoto', 'home-dir')+self.luigi_config.get('spark', 'app')
        spark.entry_class = self.luigi_config.get('spark', 'entry_class')
        spark.name = self.luigi_config.get('spark', 'name')
        self.app_options()
        sparkcommand = SparkSubmitTask.run(spark)


class LoadHiveAccessLogs(MovotoTask):
    job_name = luigi.Parameter()
    run_date = luigi.DateParameter(default=datetime.date.today())
    get_all = luigi.Parameter(default=False)
    luigi_config = luigi.configuration.get_config()
    priority=luigi.Parameter(default=0)

    def output(self):
        return MovotoEsTarget(self.job_name, self.__class__.__name__, self.run_date)

    def requires(self):
        return ParseData(job_name=self.job_name, run_date=self.run_date)
        #pass

    def run_task(self):
        table_name = self.luigi_config.get('LoadHiveAccessLogs', 'hivetable')
        database_name = self.luigi_config.get('LoadHiveAccessLogs', 'database')
        logger.debug('Checking for the Table {0} existence in Hive database {1}'.format(table_name, database_name))
        S3date = formatDateS3(self.run_date)
        currentDay = self.run_date
        previousDay = currentDay - datetime.timedelta(days=1)

        target = HiveTableTarget(table=table_name, database=database_name).exists()
        logger.debug('Table exists:%s.' % (target))

        if target:
            daylist = [currentDay, previousDay]
            stdout = map(lambda s: run_hive_cmd(
                'LOAD DATA INPATH \'{0}\' INTO TABLE {2}.{1} PARTITION(accesstimedate=\"{3}\");'.format(
                    str(self.luigi_config.get('spark', 'destinationPath')) + S3date + "/" + str(s) + "/*gz.parquet",
                    table_name, database_name, s)), daylist)
            logger.debug('Ran Load Successfully...')
        else:
            logger.debug('Table {0} in Database {1} Does not exist..'.format(table_name, database_name))
            raise TaskException(
                    'Task %s Failed, as Table does not exist in the Database...' % (self.__class__.__name__))


class TaskException(Exception):
    pass


if __name__ == "__main__":
    luigi.run()
