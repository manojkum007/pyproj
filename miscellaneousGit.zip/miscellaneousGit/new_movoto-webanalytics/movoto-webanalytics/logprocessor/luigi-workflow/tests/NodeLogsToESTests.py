import unittest
from NodeLogsToES import S3DataPull, ConnectionS3, formatDateS3,\
    moveNodeLogsToHdfs, ParseData, LoadHiveAccessLogs

class LogProcessorTaskTests(unittest.TestCase):
    def testS3DataPull(self):
        s3dp =  S3DataPull(job_name="DailyAccessLogs1")
        print( s3dp.get_all, s3dp.run_date, s3dp.job_name, s3dp.luigi_config)
        s3conn = ConnectionS3(s3dp)        
        print(s3dp.run_date)        
        print(formatDateS3(s3dp.run_date))
        self.assertIsNotNone(s3conn, "S3 Connection not available")
        
    def testMoveNodeLogsToHdfs(self):
        mnlth = moveNodeLogsToHdfs(job_name="DailyAccessLogs2") 
        self.assertIsNotNone(mnlth, "Move to hdfs not successful")\
    
    def testParseData(self):
        pd = ParseData(job_name="DailyAccessLogs3")
        print( pd.luigi_config.get('spark', 'app') )
        self.assertIsNotNone(pd, "Parsedata job is not successful")
        
    def testLoadHiveAccessLogs(self):
        lhal= LoadHiveAccessLogs(job_name="DailyAccessLogs4")
        self.assertIsNotNone(lhal, "LoadHiveAccessLogs job is not successful")
    
        
        
        
                