#!/bin/bash

cd /opt/workflows/logprocessor/src

source /home/huser/.profile

python NodeLogsToES.py LoadHiveAccessLogs --job-name DailyAccessLogs

#remove data files older than 7 days
export seventhday=$(date +%m%d%y -d "7 day ago")

echo "Removing processed log files at - /opt/workflows/logprocessor/nodelogs/$seventhday"
rm -rf "/opt/workflows/logprocessor/nodelogs/$seventhday"

echo "Removing processed log files at - /tmp/nodelogs/$seventhday"
hdfs dfs -rm -r -f "/tmp/nodelogs/$seventhday"

