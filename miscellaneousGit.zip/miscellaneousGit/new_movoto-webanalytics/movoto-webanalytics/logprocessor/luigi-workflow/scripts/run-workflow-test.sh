#!/bin/bash

cd /opt/workflows/logprocessor/src

python NodeLogsToES.py LoadHiveAccessLogs --job-name DailyAccessLogs --run-date "2017-05-09"
