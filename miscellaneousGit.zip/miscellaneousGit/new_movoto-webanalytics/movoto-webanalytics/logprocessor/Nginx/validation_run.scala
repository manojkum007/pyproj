
val dfold = spark.read.parquet("/bigdata/data/tranformed_nodelogs/051017/2017-05-09");

val dfnew = spark.read.parquet("/bigdata/data/tranformed_nodelogs/051017_new/2017-05-09");


dfold.createTempView("dfold")
dfnew.createTempView("dfnew")

spark.sql("select sum(hash(clientIpAddress)), sum(hash(rfc1413ClientIdentity)), sum(hash(remote_user)), sum(hash(dateTime)), sum(hash(request)), sum(hash(httpStatusCode)), sum(hash(bytesSent)), sum(hash(referrer)), sum(hash(referrer_pageid)), sum(hash(device)), sum(hash(OS_family)), sum(hash(OS_major)), sum(hash(OS_minor)), sum(hash(OS_patch)), sum(hash( userAgent_family)), sum(hash(userAgent_major)), sum(hash(userAgent_minor)), sum(hash(userAgent_patch)), sum(hash(raw_record)), sum(hash(accessTime)), sum(hash(userAgent)), sum(hash(page_id)), sum(hash(listing_url)), sum(hash(upstreamSep)), sum(hash(requestTime)), sum(hash(upstreamHeaderTime)), sum(hash(upstreamResponseTime)), sum(hash(HTTPverb)), sum(hash(first)), sum(hash(second)), sum(hash(third)), sum(hash(fourth)), sum(hash(urllisting)), sum(hash(state)), sum(hash(city)), sum(hash(nhood)), sum(hash(zipcode)), sum(hash(geotype)) from dfold")


spark.sql("select sum(hash(clientIpAddress)), sum(hash(rfc1413ClientIdentity)), sum(hash(remote_user)), sum(hash(dateTime)), sum(hash(request)), sum(hash(httpStatusCode)), sum(hash(bytesSent)), sum(hash(referrer)), sum(hash(referrer_pageid)), sum(hash(device)), sum(hash(OS_family)), sum(hash(OS_major)), sum(hash(OS_minor)), sum(hash(OS_patch)), sum(hash( userAgent_family)), sum(hash(userAgent_major)), sum(hash(userAgent_minor)), sum(hash(userAgent_patch)), sum(hash(raw_record)), sum(hash(accessTime)), sum(hash(userAgent)), sum(hash(page_id)), sum(hash(listing_url)), sum(hash(upstreamSep)), sum(hash(requestTime)), sum(hash(upstreamHeaderTime)), sum(hash(upstreamResponseTime)), sum(hash(HTTPverb)), sum(hash(first)), sum(hash(second)), sum(hash(third)), sum(hash(fourth)), sum(hash(urllisting)), sum(hash(state)), sum(hash(city)), sum(hash(nhood)), sum(hash(zipcode)), sum(hash(geotype)) from dfnew")




|             3723932890846|                 163108918794501|       163108918794501|      2536944532891|     4703511568087|          -17061933268333|       5190358399283|    104989233737350|          -150113862986186|   58698361273843|    -129663178580883|     12415535580519|     -1586050650514|     23637037046752|            -81660413459402|            63087490892649|            57461317857691|             8497022212977|         930940645135|       -4519315844928|     -85893189611497|   -79063584914987|        -7417925217495|       162363804130233|         7719983834653|               12581684278369|                 12847673563586|   -118279483961954|     76899125193|      13477823785|    -21593073592|      -3147490948|       -7501216452122|-149892667666866|-150061937365620|         4199958|        1124715857|       49927552800|



|             3723932890846|                 163108918794501|       163108918794501|      2536944532891|     4703511568087|          -17061933268333|       5190358399283|    104989233737350|          -150113862986186|   58698361273843|    -129663178580883|     12415535580519|     -1586050650514|     23637037046752|            -81660413459402|            63087490892649|            57461317857691|             8497022212977|         930940645135|       -4519315844928|     -85893189611497|   -79063584914987|        -7417925217495|       162363804130233|         7719983834653|               12581684278369|                 12847673563586|   -118279483961954|     76899125193|      13477823785|    -21593073592|      -3147490948|       -7501216452122|-149892667666866|-150061937365620|         4199958|        1124715857|       49927552800|

spark.sql("select sum(hash(clientIpAddress, rfc1413ClientIdentity, remote_user, dateTime, request, httpStatusCode, bytesSent, referrer, referrer_pageid, device, OS_family, OS_major, OS_minor, OS_patch,  userAgent_family, userAgent_major, userAgent_minor, userAgent_patch, raw_record, accessTime, userAgent, page_id, listing_url, upstreamSep, requestTime, upstreamHeaderTime, upstreamResponseTime, HTTPverb, first, second, third, fourth, urllisting, state, city, nhood, zipcode, geotype)) from dfold").show

spark.sql("select sum(hash(clientIpAddress, rfc1413ClientIdentity, remote_user, dateTime, request, httpStatusCode, bytesSent, referrer, referrer_pageid, device, OS_family, OS_major, OS_minor, OS_patch,  userAgent_family, userAgent_major, userAgent_minor, userAgent_patch, raw_record, accessTime, userAgent, page_id, listing_url, upstreamSep, requestTime, upstreamHeaderTime, upstreamResponseTime, HTTPverb, first, second, third, fourth, urllisting, state, city, nhood, zipcode, geotype)) from dfnew").show

-204767037216
-204767037216