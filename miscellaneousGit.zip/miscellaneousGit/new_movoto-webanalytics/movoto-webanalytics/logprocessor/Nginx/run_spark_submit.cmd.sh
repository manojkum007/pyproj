#!/bin/bash

spark-submit --name NginxTransform --class com.movoto.NginxTransform.NginxTransform --conf spark.yarn.executor.memoryOverhead=7500 \
 /media/jignesh/New Volume/userdata/Company/Movoto/workspace_lp/Nginx/NginxParser/target/NginxParser-1.0-SNAPSHOT-jar-with-dependencies.jar \
 /bigdata/data/nodelogs/access* \
 /bigdata/data/tranformed_nodelogs \
 2017-05-10 \
 /bigdata/data/geonew/*parquet \
 /bigdata/data/nodelogsConf/patterns.txt
 
 
  /opt/spark/bin/spark-submit 
--master yarn 
--name NginxTransform 
--class com.movoto.NginxTransform.NginxTransform 
--conf spark.yarn.executor.memoryOverhead=7500 
--driver-memory 10G --executor-memory 8G --driver-cores 1 --executor-cores 1 --num-executors 100 
/opt/NginNodeLogsParser/scala/Nginx/NginxParser/target/NginxParser-1.0-SNAPSHOT-jar-with-dependencies.jar 
hdfs://rhino.igenhome.local:9000/tmp/nodelogs/060917/access* 
hdfs://rhino.igenhome.local:9000/tmp/node_logs_parquet/060917 
2017-06-09 
/user/hive/warehouse/mls.db/geonew/*parquet 
/opt/NginNodeLogsParser/conf/patterns.txt
 
 
spark-submit --master yarn --queue default --num-executors 100 --executor-memory 1g --driver-memory 10g --executor-cores 1 --conf spark.yarn.executor.memoryOverhead=2500 --name NginxTransform911 
--class com.movoto.logprocessor.LogProcessorRunner \
 /home/jprajapati/workspace/NginNodeLogsParser/scala1/Nginx/NginxParser/target/NginxParser-1.0-SNAPSHOT-jar-with-dependencies.jar \
 /data/webanalytics/nodelogs/051017/access* \
 /data/webanalytics/transformed_nodelogs/051017 \
 2017-05-10 \
 /data/webanalytics/geonew/*parquet \
 /home/jprajapati/workspace/NginNodeLogsParser/scala1/patterns.txt





