#!/bin/bash

export tablepath="/user/hive/warehouse/access_logs.db/crawledpercent_stats/"
export destpath="none"
export dateofrun="2017-09-05"
export currentdate=$dateofrun
export sevendaydate=$(date -d "$currentdate 6 days ago" +"%Y-%m-%d")
export index="accesslogs"
export indextype="percentage_crawl"
export query="SELECT ((SUM(crawledon_counts)*100)/SUM(total_counts)) AS percentCrawl,CONCAT(CONCAT(SPLIT(CAST(from_unixtime((unix_timestamp(CAST(CAST(crawledon AS timestamp) AS string))+ (3600 * 12)), 'yyyy-MM-dd HH:mm:SS') AS string) ,\" \")[0],'T',SPLIT(CAST(from_unixtime((unix_timestamp(CAST(CAST(crawledon AS timestamp) AS string))+(3600 * 12)), 'yyyy-MM-dd HH:mm:SS') AS string),\" \")[1]),'.000Z') AS \`@timestamp\` FROM data WHERE fromdate='$currentdate' GROUP BY fromdate,crawledon"
export configpath="/opt/NginNodeLogsParser/conf/Es.config"
export partitioncol="day"

curl -XGET "192.168.120.136:9200/$index/$indextype/_search?pretty" \
 -H "Content-Type: application/json" \
 -d "{\"query\" : {\"query_string\" : { \"query\": \"@timestamp: $currentdate\" }}}"

echo -e "Parameters: \n $tablepath \n $destpath \n $dateofrun \n $index \n $indextype \n $query \n $configpath \n $partitioncol \n"

#echo "Wish to proceed[y/n]?"
#read proceedyn
#if [ "$proceedyn" != "y" ]; then
#    echo "Exiting."
#    exit -1
#fi

curl -XPOST "192.168.120.136:9200/$index/$indextype/_delete_by_query" \
 -H "Content-Type: application/json" \
 -d "{\"query\" : {\"query_string\" : { \"query\": \"@timestamp: $currentdate\" }}}"

spark-submit --name EsDataPercentageCrawl --class com.movoto.chimpanzeeES \
 --master yarn \
 --num-executors 20 \
 --executor-memory 4g \
 --executor-cores 1 \
 --driver-memory 7g \
 --driver-cores 4 \
 --queue low \
 /opt/NginNodeLogsParser/scala/Nginx/AccLogsESPush/target/AccLogsESPush-1.0-SNAPSHOT-jar-with-dependencies.jar \
 "$tablepath" \
 "$destpath" \
 "$dateofrun" \
 "$index" \
 "$indextype" \
 "$query" \
 "$configpath" \
 "$partitioncol" 


echo "Done."
 
 