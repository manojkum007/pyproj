#!/bin/bash

cd /opt/workflows/mls_accesslogs

source /home/huser/.profile

export inputpath="/user/hive/warehouse/access_logs.db/loadbalancer_accesslogs/"
export partitionCol="accesstimedate"
export rundate="2017-10-29"
export temp_table="access_count"
export query="select httpStatusCode as responsecode, page_id as  pagetype, userAgent as user_agent, count(listing_url) as count from $temp_table WHERE httpStatusCode in ('301','302','200') group by httpStatusCode, page_id, userAgent"  
export esnodes="192.168.120.135:9200,192.168.120.136:9200"
export indexname="mls_accesslogs"
export doctype="accesslog_counts"
export result="./result.txt" 
export errorFile= "./error.txt"
export sendMail="true"

curl -XGET "192.168.120.136:9200/$indexname/$doctype/_search?pretty" \
 -H "Content-Type: application/json" \
 -d "{\"query\" : {\"query_string\" : { \"query\": \"@timestamp: $rundate\" }}}"
  
echo -e "Parameters: \n $inputpath \n $rundate \n $indexname \n $doctype \n $query \n $partitioncol \n"
#echo "Wish to proceed[y/n]?"
#read proceedyn
#if [ "$proceedyn" != "y" ]; then
#    echo "Exiting."
#    exit -1 
#fi 

curl -XPOST "192.168.120.136:9200/$indexname/$doctype/_delete_by_query" \
 -H "Content-Type: application/json" \
 -d "{\"query\" : {\"query_string\" : { \"query\": \"@timestamp: $rundate\" }}}"

/opt/spark/bin/spark-submit --name AccessCountsESPush --class com.movoto.HiveToESPush \
--master yarn \
--num-executors 10 \
--executor-memory 4g \
--driver-memory 8g \
--executor-cores 1 \
--jars "/opt/workflows/mls_accesslogs/lib/elasticsearch-spark-13_2.10-5.3.0.jar" \
--queue low \
/opt/workflows/mls_accesslogs/mls_accesslogs-1.0.jar \
"$inputpath" \
"$partitionCol" \
"$rundate" \
"$temp_table" \
"$query" \
"$esnodes" \
"$indexname" \
"$doctype" \
"$result" \
"$errorFile"

if [ “$sendMail” == “true” ]
then
	cat ${result} | mail -aFrom:accesslog_uploader -s "Access log ES upload status"  gkarampudi@movoto.com
if	

echo "Done."
