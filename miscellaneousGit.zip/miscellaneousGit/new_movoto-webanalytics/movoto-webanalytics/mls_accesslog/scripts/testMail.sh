#!/bin/bash

cd /opt/workflows/mls_accesslogs

export result="./result.txt" 
export sendMail="true"

if [ “$sendMail” = “true” ]
then
cat ${result} | mail -aFrom:accesslog_uploader -s "Access log ES upload status"  gkarampudi@movoto.com
fi

echo "Done."