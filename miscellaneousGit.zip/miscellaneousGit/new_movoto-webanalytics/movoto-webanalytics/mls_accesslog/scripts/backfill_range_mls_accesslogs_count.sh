#!/bin/bash

export inputpath="/user/hive/warehouse/access_logs.db/loadbalancer_accesslogs/"
export partitionCol="accesstimedate"
export fromdate="2017-10-24" 
export todate="2017-10-26"
export temp_table="access_count"
export query="select httpStatusCode as responsecode, page_id as  pagetype, userAgent as user_agent, count(listing_url) as count from  $temp_table WHERE httpStatusCode in ('301','302','200') group by httpStatusCode, page_id, userAgent"  
export esnodes="192.168.120.135:9200,192.168.120.136:9200"
export indexname="mls_accesslogs"
export doctype="accesslog_counts"
export reportfile="./backfillOutput.txt"


spark-submit --name AccessCountsESPush --class com.movoto.BackFillHiveToESPush \
--master yarn \
--num-executors 10 \
--executor-memory 4g \
--driver-memory 8g \
--executor-cores 1 \
--jars "./elasticsearch-spark-13_2.10-5.3.0.jar" \
--queue low \
./accesscount-1.0.jar \
"$inputpath" \
"$partitionCol" \
"$fromdate" \
"$todate" \
"$query" \
"$temp_table" \
"$esnodes" \
"$indexname" \
"$doctype" \
"$reportfile" 


cat ${reportfile} | mail -aFrom:accesslog_uploader -s "Access log ES upload report"  gkarampudi@movoto.com

 echo "Done."