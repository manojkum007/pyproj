#!/bin/bash

cd /opt/workflows/mls_accesslogs

source /home/huser/.profile

export inputpath="/user/hive/warehouse/access_logs.db/loadbalancer_accesslogs/"
export partitionCol="accesstimedate"
export rundate=$(date +'%Y-%m-%d' -d "yesterday")
export temp_table="access_count"
export query="select httpStatusCode as responsecode, page_id as  pagetype, userAgent as user_agent, count(listing_url) as count from $temp_table WHERE httpStatusCode in ('301','302','200') group by httpStatusCode, page_id, userAgent"  
export esnodes="192.168.120.135:9200,192.168.120.136:9200"
export indexname="mls_accesslogs"
export doctype="accesslog_counts"
export result="./result.txt" 
export errorFile="./error.txt"
export sendMail="true"


/opt/spark/bin/spark-submit --name AccessCountsESPush --class com.movoto.HiveToESPush \
--master yarn \
--num-executors 10 \
--executor-memory 4g \
--driver-memory 8g \
--executor-cores 1 \
--jars "/opt/workflows/mls_accesslogs/lib/elasticsearch-spark-13_2.10-5.3.0.jar" \
--queue low \
/opt/workflows/mls_accesslogs/mls_accesslogs-1.0.jar \
"$inputpath" \
"$partitionCol" \
"$rundate" \
"$temp_table" \
"$query" \
"$esnodes" \
"$indexname" \
"$doctype" \
"$result" \
"$errorFile"

if [ “$sendMail” = “true” ]
then
	cat ${result} | mail -aFrom:accesslog_uploader -s "MLS Access log ES upload status"  gkarampudi@movoto.com
fi	

if [-f “$errorFile”]
then
	cat ${errorFile} | mail -aFrom:accesslog_uploader -s "[ERROR] MLS Access log ES upload broken"  gkarampudi@movoto.com,jprajapati@movoto.com,upidathala@movoto.com,adesai@movoto.com
fi	

echo "Done...."
