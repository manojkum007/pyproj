# -*- coding: utf-8 -*-
"""
Created on Mon Oct 30 17:01:13 2017

@author: manoj
"""

#Python libraries
import logging
import os
import subprocess
import datetime
import json
import time
#import thrift

#Internal libraries
#import luigi_properties

#Third-party libraries
import luigi
from luigi.contrib.hdfs.hadoopcli_clients import HdfsClient
from luigi.contrib.hdfs.target import HdfsTarget
from luigi.contrib.hive import *
from luigi.hive import HiveTableTarget, run_hive_cmd
from luigi import notifications
import pymssql
import sys
import datetime
import re

try:
    sys.path.append('../config/')
    sys.path.append('../lib/')
except Exception as e:
    print "folder does't exist"

from config_params import * 
import luigi
import mlsrefreshlogger
from luigi.contrib.spark import *
from movoto_task import MovotoTask
from movoto_task import MovotoEsTarget


import sys
mlsutilspath="/opt/mlsutils"

sys.path.append(mlsutilspath)
from  PantherCheck import DataCheck


LOGNAME="mlsrefresh_spark_daily"

def property_file_reader(pfile, section):
    f=open(pfile ,'r')
    obj=None
    for line in f:
        match_pattern="{0}\s?=\s?({1})".format(section ,'\S+\s+.*')
        obj=re.match(match_pattern, line)
        if obj:
            return obj.group(1)
            
            
          
            
            
            

class PantherDataImport( MovotoTask ,SparkSubmitTask):
    job_name = luigi.Parameter()
    run_date = luigi.DateParameter(default = datetime.date.today()-datetime.timedelta(days=1))
    get_all = luigi.Parameter(default=False)
    logger= luigi.Parameter()
    luigi_config = luigi.configuration.get_config()

    def __init__(self, *args, **kwargs):
        luigi.configuration.LuigiConfigParser.add_config_path(os.environ['LUIGI_CONFIG_PATH'])
        super(PantherDataImport, self).__init__(*args, **kwargs)
       #log_name='%s_%s.log'
        #self.logger = mlsrefreshlogger.get_logger(log_path, log_name%(LOGNAME, self.run_date.strftime('%Y-%m-%d')), HOST, FROM_ADDRESS, TO_ADDRESS, SUBJECT)	
        
    def requires(self):
        #currentpath=os.getcwd()
        #os.chdir(mlsutilspath)
        #cuurentluigi_path=os.environ['LUIGI_CONFIG_PATH']
        #os.environ["LUIGI_CONFIG_PATH"] = mlsutilspath+"/"+"client.cfg"
        #logger.info("%s previous client "%os.environ["LUIGI_CONFIG_PATH"] )
        
        if (re.search('mls_listing' ,self.job_name)!=None):
            yield DataCheck(job_name="mls_listing", run_date=self.run_date, get_all=self.get_all)
        elif (re.search('mls_public_record_association' ,self.job_name)!=None):
            yield DataCheck(job_name="mls_public_record_association", run_date=self.run_date, get_all=self.get_all)
        elif (re.search('mls_address' ,self.job_name)!=None):
            yield DataCheck(job_name="mls_address", run_date=self.run_date, get_all=self.get_all)
        elif (re.search('mls_image_downloader' ,self.job_name)!=None):
            yield DataCheck(job_name="mls_image_downloader_status_history", run_date=self.run_date, get_all=self.get_all)
        elif (re.search('mls_attribute' ,self.job_name)!=None):
            yield DataCheck(job_name="mls_attribute_history", run_date=self.run_date, get_all=self.get_all)
        else:pass
    
    
        #os.chdir(currentpath)
        #os.environ["LUIGI_CONFIG_PATH"] = cuurentluigi_path
        
        
        
    @property
    def spark_version(self):
        return "spark"    

    @property
    def spark_submit(self):
        return configuration.get_config().get('spark', 'spark-submit', 'spark-submit')

    @property
    def master(self):
        return configuration.get_config().get("spark", "master", None)


    @property
    def executor_memory(self):
        return configuration.get_config().get("spark", "executor-memory", None)

    @property
    def driver_cores(self):
        return configuration.get_config().get("spark", "driver-cores", None)

    @property
    def total_executor_cores(self):
        return configuration.get_config().get("spark", "total-executor-cores", None)

    @property
    def driver_memory(self):
        return configuration.get_config().get("spark", "driver-memory", None)
    
    @property
    def num_executors(self):
        return configuration.get_config().get("spark", "num-executors", None)
    
    @property
    def jars(self):
        return self._list_config(configuration.get_config().get("spark", "jars", None))
    
    @property
    def py_files(self):
        return self._list_config(configuration.get_config().get(
            self.spark_version, "py-files", None))
    
    @property
    def queue(self):
        return configuration.get_config().get("spark", "queue", None)

    
    def app_options(self):
        jdbc_property_file = str(self.luigi_config.get('spark', 'jdbc_property_file'))
        job_property_file = str(self.luigi_config.get('spark', 'job_property_file'))
        job_property_file=job_property_file%(self.job_name)
        run_date = str(self.run_date.strftime('%Y-%m-%d'))    
        self.params = [jdbc_property_file, job_property_file, run_date]
        return self.params

       

    def run_task(self):
        spark = PantherDataImport(self.job_name, self.run_date ,self.get_all ,self.logger)
        
        spark.app = self.luigi_config.get('spark', 'app')
        spark.entry_class = self.luigi_config.get('spark', 'entry_class')
        spark.name = self.luigi_config.get('spark', 'name')
        self.app_options()
        
        try:  
            delta_table_partition_column=property_file_reader(self.params[1] ,'mls.delta.partition.column').strip()
            delta_table=property_file_reader(self.params[1] ,'mls.delta.table')
            delete_partition_query="alter table [database_table] DROP PARTITION(`[partition_date]` = '[Date]')"
            delete_partition_query=delete_partition_query.replace('[database_table]',delta_table).replace('[partition_date]', delta_table_partition_column).replace('[Date]',self.run_date.strftime('%Y-%m-%d'))
            
            partition_check="show partitions %s PARTITION(%s='%s');"%(delta_table, delta_table_partition_column, self.run_date.strftime('%Y-%m-%d'))
            res=run_hive_cmd(partition_check)
            if res.strip()!='':
                self.logger.info("removing partitions from deltapartition  table %s"%delete_partition_query)
                run_hive_cmd(delete_partition_query) 
                self.logger.info("deleted partition")
        except Exception as e:
            self.logger.critical("Problem in deleting partition %s "%e)
            sys.exit(0)
            


        try:
            sparkcommand = SparkSubmitTask.run(self)
            self.logger.info("result of job %s"%sparkcommand)
            
#            delta_data_cnt="""select count(*)  from [database_table] where [partition_date]="[Date]";"""
#            delta_data_cnt=delta_data_cnt.replace('[database_table]',delta_table).replace('[partition_date]', delta_table_partition_column).replace('[Date]',self.run_date.strftime('%Y-%m-%d'))
#            cnt_result=run_hive_cmd(delta_data_cnt).split("\n")[0].strip()          
#            if int(cnt_result) <=0:
#                self.logger.critical("Data imported has count less than 1")
#                raise ValueError
                
            self.logger.info("Data imported has count >0")
        except Exception as e:
            self.logger.critical("Error while running spark submit %s "%e)
            sys.exit(0)



    def output(self):
        return MovotoEsTarget(self.job_name, self.__class__.__name__, self.run_date, 'daily')



class RefreshFinalParquet( MovotoTask ,SparkSubmitTask):
    job_name = luigi.Parameter()
    run_date = luigi.DateParameter(default = datetime.date.today()-datetime.timedelta(days=1))
    get_all = luigi.Parameter(default=False)
    luigi_config = luigi.configuration.get_config()

    def __init__(self, *args, **kwargs):
        luigi.configuration.LuigiConfigParser.add_config_path(os.environ['LUIGI_CONFIG_PATH'])
        super(RefreshFinalParquet, self).__init__(*args, **kwargs)
        log_name='%s_%s.log'
        self.logger = mlsrefreshlogger.get_logger(log_path, log_name%(LOGNAME, self.run_date.strftime('%Y-%m-%d')), HOST, FROM_ADDRESS, TO_ADDRESS, SUBJECT)	
        
    def requires(self):
        yield PantherDataImport(self.job_name, self.run_date,  self.get_all, self.logger)
        
    @property
    def spark_version(self):
        return "spark"    

    @property
    def spark_submit(self):
        return configuration.get_config().get('sparkfinal', 'spark-submit', 'spark-submit')

    @property
    def master(self):
        return configuration.get_config().get("sparkfinal", "master", None)


    @property
    def executor_memory(self):
        return configuration.get_config().get("sparkfinal", "executor-memory", None)

    @property
    def driver_cores(self):
        return configuration.get_config().get("sparkfinal", "driver-cores", None)

    @property
    def total_executor_cores(self):
        return configuration.get_config().get("sparkfinal", "total-executor-cores", None)

    @property
    def driver_memory(self):
        return configuration.get_config().get("sparkfinal", "driver-memory", None)
    
    @property
    def num_executors(self):
        return configuration.get_config().get("sparkfinal", "num-executors", None)
    
    @property
    def jars(self):
        return self._list_config(configuration.get_config().get("sparkfinal", "jars", None))
    
    @property
    def py_files(self):
        return self._list_config(configuration.get_config().get(
            self.spark_version, "py-files", None))
    
    @property
    def queue(self):
        return configuration.get_config().get("sparkfinal", "queue", None)

    
    def app_options(self):
        job_property_file = str(self.luigi_config.get('sparkfinal', 'job_property_file'))
        job_property_file=job_property_file%(self.job_name)
        run_date = str(self.run_date.strftime('%Y-%m-%d'))    
        self.params = [ job_property_file, run_date]
        return self.params

       

    def run_task(self):
        spark = RefreshFinalParquet(self.job_name, self.run_date ,self.get_all)
        
        spark.app = self.luigi_config.get('sparkfinal', 'app')
        
        spark.entry_class = self.luigi_config.get('sparkfinal', 'entry_class')
        spark.name = self.luigi_config.get('sparkfinal', 'name')
        self.app_options()

        
        ##checking for parquet table in hive###
        try:
            parquet_final_comb=property_file_reader(self.params[0] ,'mls.refresh.final.table')
            print "parquet_final_table" ,parquet_final_comb
            parquet_final_database=parquet_final_comb.split(".")[0]
            parquet_final_table=parquet_final_comb.split(".")[1]
            
            
            target = HiveTableTarget(table=parquet_final_table,database=parquet_final_database).exists()
            if target!=True:
                create_query="CREATE TABLE {0}.{1} ( ".format(parquet_final_database, parquet_final_table)
                create_query+= property_file_reader(self.params[0] ,'mls.refresh.schema.value')
                create_query+=") STORED AS PARQUET;"
                self.logger.info("creating parquet table %s"%create_query)
                run_hive_cmd(create_query) 
            else:
                run_hive_cmd("truncate table %s"%parquet_final_comb)
                self.logger.info("%s  table truncated"%parquet_final_comb)
                
        except Exception as e:
            self.logger.critical("Unable to create table %s "%e)
            sys.exit(0)
            
    
        ########running spark jobs to update final paruet table############
    
        try:
            if (re.search('mls_attribute' ,self.job_name)!=None):
                parquet_column_list=property_file_reader(self.params[0] ,'mls.refresh.column.list')
                delta_table=property_file_reader(self.params[0] ,'mls.delta.table')
                delta_table_partition_column=property_file_reader(self.params[0] ,'mls.delta.partition.column').strip()
                
                load_full_dataset="""insert overwrite table [parquet_table]
                                    select  [column_list] from [delta_table] where [partition_date]="[Date]" ;"""
                
                load_full_dataset=load_full_dataset.replace('[parquet_table]', parquet_final_comb).replace('[column_list]', parquet_column_list).replace('[delta_table]',delta_table).replace('[partition_date]', delta_table_partition_column).replace('[Date]',self.run_date.strftime('%Y-%m-%d'))
  
                
                run_hive_cmd(load_full_dataset)
                self.logger.info("Attribute full data loading is successfull")
                                    
            else:
                sparkcommand = SparkSubmitTask.run(self)
                self.logger.info("result of job %s"%sparkcommand)
              
            parq_data_cnt="""select count(*)  from [database_table];"""
            parq_data_cnt=parq_data_cnt.replace('[database_table]',parquet_final_comb)
            cnt_res=run_hive_cmd(parq_data_cnt).split("\n")[0].strip()      
            #self.logger.critical("table count of job %s is  %s"%(self.job_name, cnt_res))
            assert(int(cnt_res) >0)
            self.logger.info("Data imported to parquet has count >0")
        except Exception as e:
            self.logger.critical("Exception in spark submit job  %s "%e)
            sys.exit(0)
            
        
        ########################deleting backup table , renaming orc_load table to orc backup and rename parquet table to orc_load########
        

        try:  
            backuptable_database=property_file_reader(self.params[0] ,'mls.refresh.final.bkptable')
            
            print "backuptable_database" ,backuptable_database
            backup_database=backuptable_database.split(".")[0]
            backuptable=backuptable_database.split(".")[1]
            backuptarget = HiveTableTarget(table=backuptable,database=backup_database).exists()
            if backuptarget==True:
                self.logger.info("Dropping backup table %s"%backuptable)
                run_hive_cmd("drop  table %s.%s"%(backup_database, backuptable)) 
                self.logger.info("table dropped")
            
            ##Rename orc to bkp##########
            
            
            orcloadtable_database=property_file_reader(self.params[0] ,'mls.old.main.table')
            orcload_database=orcloadtable_database.split(".")[0]
            orcloadtable=orcloadtable_database.split(".")[1]
            orctarget = HiveTableTarget(table=orcloadtable,database=orcload_database).exists()
            if orctarget==True:
                self.logger.info("Renaming orcload table %s"%orcloadtable)
                run_hive_cmd("alter table %s rename to %s"%(orcloadtable_database,backuptable_database) ) 
                self.logger.info("table reanmed")
            
            
            #########Renaming to parquet to orc load table #############333
            
            parquet_final_comb=property_file_reader(self.params[0] ,'mls.refresh.final.table')
            parquet_final_database=parquet_final_comb.split(".")[0]
            parquet_final_table=parquet_final_comb.split(".")[1]
            parquetarget = HiveTableTarget(table=parquet_final_table,database=parquet_final_database).exists()
            if parquetarget==True:
                self.logger.info("Renaming parquet final table %s"%orcloadtable)
                run_hive_cmd("alter table %s rename to %s"%(parquet_final_comb, orcloadtable_database) ) 
                self.logger.info("table reanmed")
            
        except Exception as e:
            self.logger.critical("Problem in doing Hive Operation %s "%e)
            sys.exit(0)
            
            



    def output(self):
        return MovotoEsTarget(self.job_name, self.__class__.__name__, self.run_date, 'daily')



if __name__ == "__main__":
    luigi.run()


