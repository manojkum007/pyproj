#!/bin/bash

#source ~/.bashrc

source /home/huser/.profile

cd  /opt/workflows/mlsrefresh/python/refreshjobs

export PYTHONPATH="/opt/workflows/mlsrefresh/python/refreshjobs"

python -m luigi --module mls_refresh_spark RefreshFinalParquet  --job-name mls_listing_refresh 

python -m luigi --module mls_refresh_spark RefreshFinalParquet  --job-name mls_public_record_association_refresh

python -m luigi --module mls_refresh_spark RefreshFinalParquet  --job-name mls_address_refresh 

python -m luigi --module mls_refresh_spark RefreshFinalParquet  --job-name mls_image_downloader_status_refresh

python -m luigi --module mls_refresh_spark RefreshFinalParquet  --job-name mls_attribute_refresh 


cd  /opt/mlsstat/
export PYTHONPATH="/opt/mlsstat"

python -m luigi --module mls_lisstat_stat_spark MlsRowCountCheck --tables-list  spark_refreshtables

