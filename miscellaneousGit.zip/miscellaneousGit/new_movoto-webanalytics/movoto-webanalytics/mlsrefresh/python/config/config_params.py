# -*- coding: utf-8 -*-
"""
Created on Mon Aug 14 19:01:18 2017

@author: manoj
"""
import os
import sys
HOST = 'localhost'
FROM_ADDRESS = 'rhino_mlsrefresh@movoto.com'
# TO_ADDRESS = ['yraskin@movoto.com', 'UPidathala@movoto.com', 'ZPeirce@movoto.com']
TO_ADDRESS = ['mkumar@movoto.com',]
SUBJECT = 'Spark MlsRefresh Error'


root_dir='/opt/workflows/mlsrefresh/python'
log_path="{0}/{1}".format(root_dir ,'logs')
sys.path.append('%s/config/'%root_dir)

if not os.environ.get('LUIGI_CONFIG_PATH'):
    os.environ['LUIGI_CONFIG_PATH']='%s/config/client.cfg'%root_dir



if not os.path.exists('%s/logs/'%root_dir):
    os.makedirs('%s/logs/'%root_dir)


