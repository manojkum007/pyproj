# Python libraries
import logging
import os
import subprocess
import datetime
import json

# Internal libraries
import luigi_properties

# Third-party libraries
import luigi
from elasticsearch import Elasticsearch

logger = logging.getLogger('luigi-interface')

RANGE_MAP = {
    'daily': '||+1d',
    'weekly': '||-1w',
    'monthly': '||-1m'
}


class MovotoEsTarget(luigi.Target):
    def __init__(self, job_name, luigi_task_name, run_date=datetime.datetime.today(), run_interval='daily'):
        self.job_name = job_name
        self.run_date = run_date
        self.run_interval = run_interval
        self.luigi_task_name = luigi_task_name

        pass

    def exists(self):
        # Query Elasticsearch for the given task name
        luigi_config = luigi.configuration.get_config()
        es_host = luigi_config.get('movoto', 'es-host')
        es_port = int(luigi_config.get('movoto', 'es-port'))
        job_status_index = luigi_config.get('movoto', 'job-status-index')

        logger.debug(
            'MovotoEsTarget::exists(): Checking ES index %s to see if Luigi task "%s" for Job "%s" has been run...' % (
            job_status_index, self.luigi_task_name, self.job_name))

        es = Elasticsearch([{'host': es_host, 'port': es_port}])

        query_body = self.__get_jobstats_query()

        # For dev purposes. This gives Elasticsearch time to process a job completion data entry, on which this exists() method depends.
        import time
        time.sleep(5)

        # print json.dumps(query_body, indent=2)

        response = es.search(index=job_status_index, body=query_body)

        if len(response['hits']['hits']) == 0:
            logger.debug('MovotoEsTarget::exists(): Luigi task "%s" for Job "%s" has not yet been run.' % (
            self.luigi_task_name, self.job_name))
            return False
        else:
            logger.debug('MovotoEsTarget::exists(): Luigi task "%s" for Job "%s" has already been run.' % (
            self.luigi_task_name, self.job_name))
            return True

        pass

    def __get_jobstats_query(self):

        query = {
            "query": {
                "bool": {
                    "must": [
                        {
                            "match": {
                                "all_params.job_name": self.job_name
                            }
                        },
                        {
                            "range": {
                                "all_params.run_date": {
                                    "gte": self.run_date.strftime('%Y-%m-%d'),
                                    "lt": self.run_date.strftime('%Y-%m-%d') + RANGE_MAP[self.run_interval]
                                }
                            }
                        },
                        {
                            "match": {
                                "luigi_task_name": self.luigi_task_name
                            }
                        },
                        {
                            "match": {
                                "successful": 1
                            }
                        }
                    ]
                }
            }
        }

        return query


class MovotoTask(luigi.Task):
    def run_task(self):
        raise NotImplementedError('run_task() function must be implemented')

    def run(self):
        task_successful = False
        task_name = self.__class__.__name__

        start_time = datetime.datetime.now()

        error_message = None
        error = None
        try:
            self.run_task()
            logger.debug('MovotoTask::run(): Task %s succeeded.' % (task_name))
            task_successful = True
        except Exception as e:
            task_successful = False
            logger.error('MovotoTask::run(): Task %s failed: %s' % (task_name, e.message))
            import sys
            error_message = str(e)
            error = sys.exc_info()

        end_time = datetime.datetime.now()

        logger.debug('MovotoTask::run(): Pushing into Elasticsearch results for Luigi Task = %s' % (task_name))
        try:
            self.__job_status_to_es(start_time, end_time, task_successful, error_message, task_name)
        except Exception as exc:
            logger.error('Failed to put job results into Elasticsearch: %s' % exc.message)

        if error:
            raise error[1], None, error[2]

    def __job_status_to_es(self, start_time, end_time, task_successful, error_message, task_name):
        # Get Elasticsearch configuration from /etc/luigi/client.cfg
        config = luigi.configuration.get_config()
        es_host = config.get('movoto', 'es-host')
        es_port = int(config.get('movoto', 'es-port'))
        jobstatus_index = config.get('movoto', 'job-status-index')

        params = self.to_str_params()

        es = Elasticsearch([{'host': es_host, 'port': es_port}])

        es_doc = dict()
        es_doc['start_time'] = start_time.strftime('%Y-%m-%dT%H:%M:%S.000Z')
        es_doc['end_time'] = end_time.strftime('%Y-%m-%dT%H:%M:%S.000Z')
        es_doc['@timestamp'] = start_time.strftime('%Y-%m-%dT%H:%M:%S.000Z')
        es_doc['year'] = start_time.year
        es_doc['month'] = start_time.month
        es_doc['monthname'] = start_time.strftime('%b')
        es_doc['day'] = start_time.day

        es_doc['runtime'] = (end_time - start_time).seconds
        es_doc['successful'] = 1 if task_successful else 0
        es_doc['error_message'] = error_message
        es_doc['luigi_task_name'] = task_name

        # If the job parameter is not supplied then use the name of the Luigi Task
        es_doc['job_name'] = params.get('job_name')
        es_doc['get_all'] = params['get_all']
        es_doc['all_params'] = params

        es.index(index=jobstatus_index, doc_type=task_name, body=json.dumps(es_doc), timestamp=es_doc['@timestamp'])


if __name__ == "__main__":
    luigi.run()
