#Python libraries

#Internal librarires

#Third-party libraries

DRIVERS = {
  'sql_server': {
     'driver_class': 'com.microsoft.sqlserver.jdbc.SQLServerDriver',
     'jdbc_driver': 'sqlserver',
     'connection_string': 'jdbc:{0}://{1}:{2};databaseName={3}'
  },
  'postgres_sql':{
     'driver_class': 'com.amazon.redshift.jdbc41.Driver',
     'jdbc_driver': 'postgresql',
     'connection_string': 'jdbc:{0}://{1}:{2}/{3}'
  },
  'mysql':{
      'driver_class': 'com.mysql.jdbc.Driver',
      'jdbc_driver': 'mysql',
      'connection_string': 'jdbc:{0}://{1}:{2}/{3}'
  }
}

FILE_TYPES = {
  'avro' : '--as-avrodatafile',
  'parquet' : '--as-parquetfile'
}

DATABASES = {
    'DB_IGEN56_User': {
      'driver': 'sql_server',
      'host': 'production-55.svcolo.movoto.net',
      'name': 'igen56_User',
      'port': 1433,
      'username': 'Cheetah',
      'password': 'd3pY5aun'
    },
    'DB_IGEN56_User_NEW': {
      'driver': 'sql_server',
      'host': 'liger.san-mateo.movoto.net',
      'name': 'iGen56_User_NEW',
      'port': 1433,
      'username': 'sa',
      'password': 'igen'
    },
    'DB_IGEN56_Log' : {
      'driver': 'sql_server',
      'host': 'production-49.svcolo.movoto.net',
      'name': 'igen56_Log',
      'port': 1433,
      'username': 'Cheetah',
      'password': 'd3pY5aun'
    },
    'events': {
     'driver': 'postgres_sql',
     'host': 'movotonova-qxk54a.redshift.segment.com',
     'name': 'events',
     'port': '5439',
     'username': 'admin',
     'password': 'a240e66d12c74372a59fe22ec646e3afA' 
    },
    'LOG_SMARTMOVOTO': {
     'driver': 'mysql',
     'host': 'production-73.svcolo.movoto.net',
     'name': 'LOG_SMARTMOVOTO',
     'port': '3306',
     'username': 'cheetah',
     'password': 'd3pY5aun' 
    },
    'SMARTMOVOTO': {
     'driver': 'mysql',
     'host': 'production-73.svcolo.movoto.net',
     'name': 'LOG_SMARTMOVOTO',
     'port': '3306',
     'username': 'cheetah',
     'password': 'd3pY5aun' 
    },
    'RELATEDHOMES': {
     'driver': 'mysql',
     'host': 'production-18.svcolo.movoto.net',
     'name': 'RELATEDHOMES',
     'port': '3306',
     'username': 'cheetah',
     'password': 'pGqcaxQD' 
    },
    'igen60_web_slv0': {
     'driver': 'sql_server',
     'host': 'production-55.svcolo.movoto.net',
     'name': 'igen60_web_slv0',
     'port': '1433',
     'username': 'cheetah',
     'password': 'd3pY5aun'
     },
    'DB_MovotoDictionary' :{
     'driver': 'sql_server',
     'host': 'cheetah',
     'name': 'MovotoDictionary',
     'port': '1433',
     'username': 'ro-user',
     'password': 'movoto'
    },
    'DB_movotodw' :{
     'driver': 'sql_server',
     'host': 'cheetah',
     'name': 'movotodw',
     'port': '1433',
     'username': 'ro-user',
     'password': 'movoto'
    },
     'DB_sessionLog' :{
     'driver': 'sql_server',
     'host': '172.24.0.38',
     'name': 'iGen56_Log',
     'port': '1433',
     'username': 'sa',
     'password': 'igen'
    },
     'MLS_movotodb': {
     'driver': 'mysql',
     'host': 'movotodb-slave-04.v2.ng.movoto.net',
     'name': 'movoto',
     'port': '3306',
     'username': 'upidathala',
     'password': 'hEq8tacE'
    },
     'MLS_movotodb_local': {
     'driver': 'mysql',
     'host': 'tiger',
     'name': 'movoto',
     'port': '3306',
     'username': 'sa',
     'password': 'igen'
    },
    'Panther_MLS' :{
     'driver': 'sql_server',
     'host': 'panther.san-mateo.movoto.net',
     'name': 'mls_raw',
     'port': '1433',
     'username': 'sa',
     'password': 'igen'
    },
    'DB_user_mart' :{
     'driver': 'sql_server',
     'host': 'puma',
     'name': 'user_mart',
     'port': '1433',
     'username': 'sa',
     'password': 'igen'
    },
    'Panther_GEO' :{
     'driver': 'sql_server',
     'host': 'panther.san-mateo.movoto.net',
     'name': 'geo',
     'port': '1433',
     'username': 'sa',
     'password': 'igen'
    },
    'MLS_movotodb_production': {
     'driver': 'mysql',
     'host': 'movotodb-slave-04.v2.ng.movoto.net',
     'name': 'movoto',
     'port': '3306',
     'username': 'analytics-ro',
     'password': 'AX89nc!#GCfmplcul80'
    }
}
