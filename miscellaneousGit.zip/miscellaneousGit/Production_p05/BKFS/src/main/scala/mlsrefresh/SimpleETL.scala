package mlsrefresh

trait SimpleETL extends java.io.Serializable {
  
}