package mlsrefresh

class MLSListingETL extends SimpleETL {
  val srcRDBTable: String = "";
  val destTable: String = "";
  val deltaTable: String = "";
  
  def loadAndStoreDelta(deltaSQL: String): Unit = {
    
  }
  
  
  
}