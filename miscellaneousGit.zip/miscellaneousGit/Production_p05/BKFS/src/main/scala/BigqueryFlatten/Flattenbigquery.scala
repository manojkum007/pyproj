package BigqueryFlatten;

import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

import scala.collection.mutable.ListBuffer;


object Flattenbigquery {
  val warehouseLocation = "file:///tmp/ware"

  val spark = SparkSession
    .builder()
    .appName("mlsdeltarefreshJob")
    .config("spark.sql.warehouse.dir", warehouseLocation)
    .config("spark.master", "local")
    .enableHiveSupport()
    .getOrCreate()
  val helper = FlatteningHelper;
  var totals: Seq[StructField] = null;



  def main(args: Array[String]) = {
    var errorCode: Int = 0;


    println("spark engine started")
//

    val bqdf=spark.read.parquet("src/main/resources/bigquery_data/2017-04-07_071416-m-00004.snappy.parquet")
    bqdf.createOrReplaceTempView("nova")
    val newdf=spark.sql("select  hits.`array`.customDimensions.`array` from  nova limit 10")
    /*
    root
 |-- customDimensions: array (nullable = true)
 |    |-- element: struct (containsNull = true)
 |    |    |-- array: array (nullable = true)
 |    |    |    |-- element: struct (containsNull = true)
 |    |    |    |    |-- index: long (nullable = true)
 |    |    |    |    |-- value: binary (nullable = true)

     */ println(newdf.show())

/*
    import org.apache.spark.sql.DataFrame
    import org.apache.spark.sql.types._


    case class Bar(x: Int, y: String)
    case class Foo(bar: Bar)

    val df = sc.parallelize(Seq(Foo(Bar(1, "first")), Foo(Bar(2, "second")))).toDF

    df.printSchema

    def children(colname: String, df: DataFrame) = {
      val parent = df.schema.fields.filter(_.name == colname).head
      val fields = parent.dataType match {
        case x: StructType => x.fields
        case _ => Array.empty[StructField]
      }
      fields.map(x => col(s"$colname.${x.name}"))
    }


    df.select(children("bar", df): _*).printSchema


    scala> tt.asInstanceOf[StructType].fields.foreach(r=>ss+=StructField(prefix+ "."+r.name,r.dataType,true))

    import org.apache.spark.sql.types.StructType

    val nested_fields = df.schema
      .filter(c => c.name == "b2")
      .flatMap(_.dataType.asInstanceOf[StructType].fields)
      .map(_.name)

*/
    val bqrdd=bqdf.rdd
    //var totals=null
    schemaForTotals(bqdf);

    println("totals: "+ totals)
    var outRows=null;

/*
    bqrdd.map(rw=>{
      val recBuff = ListBuffer.empty[Any]
      recBuff+=rw.getAs[Row]("totals")
      explodeTotals(rw, recBuff)
      val dateValue = helper.getAsByteString(rw, "date")
      recBuff+=dateValue
      //outRows += Row(recBuff: _*)
    })*/

   // println("recBuff "+ recBuff)



  }

  def explodeTotals(rw: Row, recBuff: ListBuffer[Any]): Unit = {
    addRecordsByType(totals, rw.getAs[Row]("totals"), recBuff);
  }


  def addRecordsByType(fields: Seq[StructField], rw: Row, recBuff: ListBuffer[Any]): Unit = {
    fields.foreach(sf => sf.dataType match {
      case _: LongType => if(rw==null) recBuff += null.asInstanceOf[Long] else recBuff += rw.getAs[Long](sf.metadata.getString(helper.CONST_COMMENT))
      case _: StringType => if(rw==null) recBuff += null.asInstanceOf[String] else recBuff += helper.getAsByteString(rw, sf.metadata.getString(helper.CONST_COMMENT))
      case _: BooleanType => if(rw==null) recBuff += null.asInstanceOf[Boolean] else recBuff += rw.getAs[Boolean](sf.metadata.getString(helper.CONST_COMMENT))
      case _ => println("Error: Data type of column not recognized- " + sf.metadata.getString(helper.CONST_COMMENT))
    })
  }

  def schemaForTotals(df : DataFrame) : Unit = {
    val colNamePrefix = "total_";
    totals =
      (for(columnName <-
           List("visits",
             "hits",
             "pageviews",
             "timeOnSite",
             "bounces",
             "transactions",
             "transactionRevenue",
             "newVisits",
             "screenviews",
             "uniqueScreenviews",
             "timeOnScreen",
             "totalTransactionRevenue"
           ) )
        yield { val sf = df.schema("totals").dataType.asInstanceOf[StructType](columnName)
          helper.newStructField(sf, colNamePrefix)
        })
  }

}
