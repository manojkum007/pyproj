/**
  * Created by manoj on 20/9/18.
  */

/**
  * Created by manoj on 15/9/18.
  */


package DuplicateId

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.types.{StructType, _}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

import scala.collection.mutable.ListBuffer


object Duplicatebymapreduce {
  def main(args: Array[String]) {
    //Create Spark Context
    val warehouseLocation = "file:///tmp/warehouse"

    val spark = SparkSession
      .builder()
      .appName("Mlsduplicateremoval")
      //      .config("spark.sql.warehouse.dir", warehouseLocation)
      //      .config("spark.master", "local")
      .enableHiveSupport()
      .getOrCreate()


    val production_path: String = "hdfs://192.168.120.131:9000"

    var mls_maintable: String = ""
    var mls_deltatable: String = ""
    var primary_id: String = ""
    var partitioned_col: String = ""
    var panthercount: String = "";
    var last_col_index: String = "";
    var outputpath: String = "";

    if (args.length > 1) {
      mls_maintable = args(0).toString
      mls_deltatable = args(1).toString
      primary_id = args(2).toString
      partitioned_col = args(3).toString
      panthercount = args(4).toString
      outputpath = args(5).toString
      last_col_index = args(6).toString
    } else {
      println(" sorry  in correct no of parameter passed")
      System.exit(-1)
    }

    if (mls_maintable.toString.length > 0 && mls_deltatable.toString.length > 0) {

      try {

        val maindf = spark.read.parquet(mls_maintable)

        val dropdelatdf = spark.read.parquet(mls_deltatable)
        val deltadf = dropdelatdf.drop(dropdelatdf.col(partitioned_col))

        val mergedDF: DataFrame = DeduplicationForData(maindf, deltadf, spark, primary_id, maindf.count() / panthercount.toDouble ,last_col_index.toInt)

        println("saving File in hadoop")
        mergedDF.toDF(maindf.schema.fieldNames: _*).write.mode("overwrite").parquet(outputpath)

        val savedparquetdf=spark.read.parquet(outputpath)

        val cntpar=savedparquetdf.count
        println( "count comparison" +panthercount.toLong + cntpar )

        if(panthercount.toLong != cntpar.toLong) {
          val config = new Configuration()
          config.set("fs.defaultFS", production_path)
          val fs= FileSystem.get(config)
          if ( fs.exists(new Path(outputpath.toString))) {
            fs.delete(new Path(outputpath.toString) ,true)
          }
          println("raising exception")
          throw  new Exception

        }

      } catch {
        case e: Exception => println("some exception"+ e.printStackTrace)
          println("due to some error closing Session")
          System.exit(-1)
      }
      finally {
        println("closing spark")
        spark.stop()
        System.exit(0)
      }

    }


  }





  def DatatypeMapping( attdf :DataFrame) :ListBuffer[String] ={
     var schemaLis= ListBuffer[String]()
    val tt =attdf.schema.fields.foreach( rw=>
      {
        rw.dataType match {
          case IntegerType => schemaLis+="rw.getAs[Integer]"+"(\""+rw.name+"\")"
          case LongType =>    schemaLis+="r.getAs[Long]"+"(\""+rw.name+"\")"
          case DoubleType =>  schemaLis+="r.getAs[Double]"+"(\""+rw.name+"\")"
          case StringType =>   schemaLis+="r.getAs[String]"+"(\""+rw.name+"\")"
          case x  if ( x.isInstanceOf[DecimalType]  )=>  schemaLis+="r.getAs[Double]"+"(\""+rw.name+"\")"
          //case _ =>  schemaLis+="Some other"+ rw.dataType
        }

      }
    )
    schemaLis
  }

  def DeduplicationForData(maindf :DataFrame , delatadf :DataFrame ,sc:SparkSession ,primarycol:String , ratio:Double , colIndex:Int): DataFrame ={

    var comdf=maindf
    if (ratio<1.0) {
      comdf=maindf.union(delatadf)
    }

    val mappeddf= comdf.rdd.map(r=>(r.getAs[String](primarycol),r.toSeq.toList))

    val aggdf=mappeddf.reduceByKey((agg,x)=>(if (agg(agg.length-1-colIndex).asInstanceOf[Long] > x(x.length-1-colIndex).asInstanceOf[Long] ) agg else x))

    val svdf=aggdf.map(r=>Row(r._2:_*))

    val final_attdf=sc.createDataFrame(svdf,  StructType(comdf.schema.fields))
    // println("totalcount" +final_attdf.count)
    final_attdf
  }



}


