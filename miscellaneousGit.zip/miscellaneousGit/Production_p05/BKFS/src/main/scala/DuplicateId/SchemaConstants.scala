/**
  * Created by manoj on 20/9/18.
  */

object SchemaConstants {



}