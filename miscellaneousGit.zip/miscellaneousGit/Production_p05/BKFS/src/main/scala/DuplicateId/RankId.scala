/**
  * Created by manoj on 15/9/18.
  */


package DuplicateId

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.SparkSession

object RankId {
  def main(args: Array[String]) {
    //Create Spark Context
    val warehouseLocation = "file:///tmp/warehouse"

    val spark = SparkSession
      .builder()
      .appName("Mlsduplicateremoval")
      .config("spark.sql.warehouse.dir", warehouseLocation)
      .enableHiveSupport()
      .getOrCreate()

    val production_path :String="hdfs://192.168.120.131:9000"

    var mls_table:String=""
    var primary_id:String=""
    var updated_col:String=""
    var panthercount:String="";
    var outputpath:String="";

    if (args.length > 1) {
      mls_table =  args(0).toString
      primary_id =  args(1).toString
      updated_col =  args(2).toString
      panthercount=  args(3).toString
      outputpath =  args(4).toString
    } else {
      println(" sorry no parameter passed")
      System.exit(-1)
    }
    import org.apache.spark.sql.expressions.Window
    import org.apache.spark.sql.functions.row_number


    if (mls_table.toString.length>0) {
      val parqfile=spark.table(mls_table)


      val config = new Configuration()
      config.set("fs.defaultFS", production_path)
      val fs= FileSystem.get(config)
      if ( fs.exists(new Path(outputpath.toString))) {
        fs.delete(new Path(outputpath.toString))
      }


      val newparq=parqfile.withColumn("rank", row_number().over(Window.partitionBy(primary_id).orderBy(parqfile.col(updated_col).desc)))
        val distdf=newparq.where(newparq.col("rank")===1).drop(newparq.col("rank"))

      val distinctcnt=distdf.count
      println("distdf.count"+distinctcnt)
      assert(distinctcnt==panthercount.toLong)


      val lis=List("000008ae-d629-11e3-81d4-063cdff9b714","00001ff2-711e-11e4-bcee-063cdff9b714","00006128-26fe-4eed-8edf-6789a6bee6fe","00007cae-b099-11e3-9e2e-063cdff9b714","0000df2e-387e-11e4-a9ba-063cdff9b714","0000f572-2a0a-11e4-851f-063cdff9b714","00011878-1a02-46a1-b29c-516f4b8cf706","000158ea-c453-11e3-944b-063cdff9b714","0001c992-282d-4a87-b6b9-f4084185d4a0","0001d0d9-e2b2-4d5e-9fdd-2aa39a3bfbd7")

      val testdf=parqfile.filter(!(parqfile.col("id").isin(lis:_*)))


      // spark.setConf("hive.exec.dynamic.partition", "true")
     // hiveContext.setConf("hive.exec.dynamic.partition.mode", "nonstrict")

      distdf.write.mode("overwrite").parquet(outputpath)


    }

    }
}


