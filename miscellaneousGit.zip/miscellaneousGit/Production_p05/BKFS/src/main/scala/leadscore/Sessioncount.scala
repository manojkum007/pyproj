package leadscore;

import org.apache.spark.sql.SparkSession

/**
  * Created by manoj on 29/12/17.
  */

object Sessioncount  {

  def JustTesting(): Unit = {

    println(" Hi Testing Something");

  }

  /*
  def main(args: Array[String]): Unit = {

    val warehouseLocation = "file:///tmp/ware"

    val spark = SparkSession
      .builder()
      .appName("SessionCount")
      .config("spark.sql.warehouse.dir", warehouseLocation)
      .config("spark.master", "local")
      .enableHiveSupport()
      .getOrCreate()


    import spark.implicits._

    JustTesting();
  }
*/

}