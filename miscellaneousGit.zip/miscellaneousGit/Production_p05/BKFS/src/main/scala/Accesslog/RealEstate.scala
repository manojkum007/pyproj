package Accesslog

import org.apache.spark.sql.SparkSession


object RealEstate {

  def main(args: Array[String]): Unit = {

     /* if (args.length != 1) {
       println("Usage: SparkSessionSimpleExample <path_to_json_file")
       System.exit(1)
     }
     */



    val warehouseLocation = "file:///tmp/ware"

    val spark = SparkSession
      .builder()
      .appName("RealEstateExample")
      .config("spark.sql.warehouse.dir", warehouseLocation)
      .enableHiveSupport()
      .getOrCreate()
//.config("spark.master", "master")

    import spark.implicits._

    // for dev rhino

    /*
    val listingtable="/user/hive/warehouse/mls.db/mls_listing_snapshot_orc_load"

    val addresstable="/user/hive/warehouse/mls.db/mls_address_snapshot_orc_load"

    val attributetable="/user/hive/warehouse/mls.db/mls_attribute_orc_load"

    */

    val listingtable="/user/hive/warehouse/mls.db/mls_listing"

    val addresstable="/user/hive/warehouse/mls.db/address"

    val attributetable="/user/hive/warehouse/mls.db/attribute"

    val zipcode_uspstable="/user/hive/warehouse/mls.db/zipcode_usps"


    val listparqdf=spark.read.parquet(listingtable)
    val addressdf=spark.read.parquet(addresstable)
    val attributeparqdf=spark.read.parquet(attributetable)

    val zipcodeupsparqdf=spark.read.parquet(zipcode_uspstable)


    val listprimarydf=  listparqdf.select("mls_address_id")
    val addressprimarydf =addressdf.select("id")

    val commondf =listprimarydf.join(addressprimarydf , (listprimarydf.col("mls_address_id") === addressprimarydf.col("id")) , "inner")

    //println( "left join id of listing and its   count" +commondf.count)

    val filteredaddressdf=addressdf.join(commondf , (addressdf.col("id") === commondf.col("id")) , "inner").drop(commondf.col("id"))


    val list_address_df =listparqdf.join(filteredaddressdf, (listparqdf.col("mls_address_id") === filteredaddressdf.col("id")) ,"left").drop(filteredaddressdf.col("id")).drop(filteredaddressdf.col("created_at")).drop(filteredaddressdf.col("updated_at"))

    println(list_address_df.printSchema())
    //70497915

    val list_address_att_status_df=list_address_df.join(attributeparqdf , (list_address_df.col("standard_status") === attributeparqdf.col("id")) , "left").withColumn("s_name" ,attributeparqdf.col("name")).drop(attributeparqdf.col("id")).drop(attributeparqdf.col("name")).drop(attributeparqdf.col("created_at")).drop(attributeparqdf.col("updated_at")).drop(attributeparqdf.col("attribute_type_id")).drop(attributeparqdf.col("display_name")).drop(attributeparqdf.col("spanish_display_name")).drop(attributeparqdf.col("listing_status_map_id"))

    val list_address_att_status_att_proptype_df=list_address_att_status_df.join(attributeparqdf , (list_address_att_status_df.col("property_type") === attributeparqdf.col("id")) , "left").withColumn("p_name" ,attributeparqdf.col("name")).drop(attributeparqdf.col("id")).drop(attributeparqdf.col("name")).drop(attributeparqdf.col("created_at")).drop(attributeparqdf.col("updated_at"))

    list_address_att_status_att_proptype_df.printSchema()

    list_address_att_status_att_proptype_df.createOrReplaceTempView("list_add_att_temp")

    val sql_query=
      """select
          mls_id,
        COALESCE(Lower(s_name), 'unknown')             AS            property_status,
          COALESCE(Lower(p_name), 'unknown')             AS            property_type,
            state,
              zip_code,
              CASE
                 WHEN  Datediff('2017-12-01', To_date(Cast(created_at AS TIMESTAMP)))<= 1 THEN 1
                  ELSE 0
              END    AS     new_listing,
              CASE
                  WHEN Datediff('2017-12-01', To_date(Cast(created_at AS TIMESTAMP)))<= 7 THEN 1
                   ELSE 0
              END    AS     listed_l7d,
              1  AS  listings from list_add_att_temp"""

    /*
    CASE       WHEN  Datediff('2017-12-01', To_date(Cast(created_at AS TIMESTAMP)))<= 1 THEN 1       ELSE 0     END    AS     new_listing,
    CASE       WHEN Datediff('2017-12-01', To_date(Cast(created_at AS TIMESTAMP)))<= 7 THEN 1       ELSE 0     END    AS     listed_l7d,
    */


    /*
    ,
               CONVERT(BIGINT, CASE
                                 WHEN created_at >= list_date THEN
                                 Datediff("2017-12-01", To_date(Cast(created_at AS TIMESTAMP)))
                                 ELSE NULL
                               END)                                     AS
                      create_delay_days,
               CONVERT(BIGINT, Datediff("2017-12-01", To_date(Cast(created_at AS TIMESTAMP)))) AS
                      days_on_movoto,
               CONVERT(BIGINT, Datediff("2017-12-01", To_date(Cast(created_at AS TIMESTAMP))))  AS
                      listing_freshness
                      */


    /*

    SELECT Q1.mls_id,
       COALESCE(Q1.state, z.state)     AS state,
       COALESCE(z.dma_code, -1)        AS dma_code,
       COALESCE(z.dma_name, 'unknown') AS dma,
       Q1.property_status,
       Q1.property_type,
       Q1.new_listing,
       Q1.listed_l7d,
       Sum(Q1.listings)                AS listings,
       CASE
         WHEN Sum(Q1.listings) = 0 THEN NULL
         ELSE Sum(Q1.create_delay_days) / Sum(Q1.listings)
       END                             AS avg_create_delay_days,
       CASE
         WHEN Sum(Q1.listings) = 0 THEN NULL
         ELSE Sum(Q1.days_on_movoto) / Sum(Q1.listings)
       END                             AS avg_days_on_movoto,
       CASE
         WHEN Sum(Q1.listings) = 0 THEN NULL
         ELSE Sum(Q1.listing_freshness) / Sum(Q1.listings)
       END                             AS avg_listing_freshness
FROM   (SELECT l.mls_id,
               COALESCE(Lower(s.NAME), 'unknown')                       AS
                      property_status,
               COALESCE(Lower(p.NAME), 'unknown')                       AS
                      property_type,
               a.state,
               a.zip_code,
               CASE
                 WHEN Datediff(day, l.created_at, @StartDate) <= 1 THEN 1
                 ELSE 0
               END                                                      AS
               new_listing,
               CASE
                 WHEN Datediff(day, l.created_at, @StartDate) <= 7 THEN 1
                 ELSE 0
               END                                                      AS
               listed_l7d,
               1                                                        AS
               listings,
               CONVERT(BIGINT, CASE
                                 WHEN l.created_at >= l.list_date THEN
                                 Datediff(day, l.list_date, l.created_at)
                                 ELSE NULL
                               END)                                     AS
                      create_delay_days,
               CONVERT(BIGINT, Datediff(day, l.created_at, @StartDate)) AS
                      days_on_movoto,
               CONVERT(BIGINT, Datediff(day, l.list_date, @StartDate))  AS
                      listing_freshness
        FROM   mls_listing l
               LEFT JOIN address a
                      ON l.mls_address_id = a.id
               LEFT JOIN attribute s
                      ON l.standard_status = s.id
               LEFT JOIN attribute p
                      ON l.property_type = p.id
        WHERE  l.created_at <= @StartDate) Q1
       LEFT JOIN zipcode_usps z
              ON Q1.zip_code = z.zipcode
GROUP  BY Q1.mls_id,
          COALESCE(Q1.state, z.state),
          Q1.property_status,
          Q1.property_type,
          Q1.new_listing,
          Q1.listed_l7d,
          COALESCE(z.dma_code, -1),
          COALESCE(z.dma_name, 'unknown')



          CREATE TABLE `zipcode_usps`(
  `zipcode` string,
  `city_name` string,
  `county_name` string,
  `ast_region` string,
  `state` string,
  `dma_name` string,
  `dma_code` int,
  `tier` int,
  `igen_county_code` string,
  `center_lat` string,
  `center_lng` string,
  `timezone` string,
  `pst_offset` int)


     */
    val finaldf=spark.sql(sql_query)


    val newzipcodeupsparqdf =zipcodeupsparqdf.withColumn("newzipcode", 'zipcode.cast("string")).withColumn("newstate", 'State.cast("string")).drop(zipcodeupsparqdf.col("zipcode")).drop(zipcodeupsparqdf.col("State"))


    val full_final_df=finaldf.join(newzipcodeupsparqdf , (finaldf.col("zip_code") === newzipcodeupsparqdf.col("newzipcode")) , "left")


    full_final_df.createOrReplaceTempView("full_final_list_table")

    val fsql_query=""" SELECT
                   mls_id,
                   COALESCE(state, newstate)     AS state,
                   COALESCE(dma_code, -1)        AS dma_code,
                   COALESCE(cast(dma_name as  string) , 'unknown') AS dma,
                   property_status,
                   property_type,
                   new_listing,
                   listed_l7d,
                   Sum(listings)         AS listings
                   from full_final_list_table
                     GROUP  BY mls_id,
                     COALESCE(state, newstate),
                     property_status,
                     property_type,
                     new_listing,
                     listed_l7d,
                     COALESCE(dma_code, -1),
                     COALESCE(cast(dma_name as  string), 'unknown')"""


    val mls_agg=spark.sql(fsql_query)

    println("mls_agg count" + mls_agg.count)
       //mls_agg.count   26080

    //70521305


  }
}
