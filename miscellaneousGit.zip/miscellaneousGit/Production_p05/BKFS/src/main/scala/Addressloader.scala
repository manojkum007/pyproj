
/**
  * Created by manoj on 23/11/17.
  */


//package bkfsaddress;
//import bkfsaddress.AddressConstants;




import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.Path
//import org.apache.spark.rdd._
//import org.apache.spark.sql
import java.text.SimpleDateFormat


//import org.apache.spark.sql.SparkSession
//import org.apache.avro.generic.GenericData.StringType
import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.Row
import org.apache.spark.sql.types._
import org.apache.spark.sql.types.StructField
import org.joda.time.DateTime
import org.apache.spark.sql.hive.HiveContext

import scala.collection.mutable.WrappedArray







object Addressloader {


  def main(args: Array[String]): Unit = {

    //AddressConstants.call()

    //println(AddressConstants.hashMap2("GD"))

    //val conf = new SparkConf
    //conf.setMaster(args(0))
   // val sc = new SparkContext(conf)
   // val inputRDD = sc.textFile(args(1))

    //Create Spark Context
    //import org.apache.spark._
    //import sqlContext.implicits._
    val conf = new SparkConf().setAppName("BkfSAddress")
      //.setMaster("yarn-cluster")
    val sc = new SparkContext(conf)

    /*
    val warehouseLocation = "file:${system:user.dir}/spark-warehouse"
    val spark = SparkSession
      .builder()
      .appName("SparkSessionZipsExample")
      .config("spark.sql.warehouse.dir", warehouseLocation)
      .enableHiveSupport()
      .getOrCreate()
    */

    val production_path :String="hdfs://192.168.120.131:9000"
    //val rhino_path :String="hdfs://localhost:54310"
    var addressdeltatable:String=""
    var addressmaintable :String=""
    var run_date :String=""




    if (args.length > 2) {
      addressdeltatable =  args(0).toString
      addressmaintable = args(1).toString
      run_date=args(2)
    } else {
      println(" sorry no parameter passed")
      System.exit(-1)
    }


    val config = new Configuration()
    config.set("fs.defaultFS", production_path)
    val fs= FileSystem.get(config)


    //val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)

    val sqlContext = new org.apache.spark.sql.SQLContext(sc)
    val hiveContext = new HiveContext(sc)


    import sqlContext.implicits._


    //val pone="hdfs://localhost:54310/user/hive/warehouse/mls.db/mls_address_snapshot_delta"
    //val mainaddresstablepath="hdfs://localhost:54310/user/hive/warehouse/mls.db/bkfs_address"

   // val pone="/user/hive/warehouse/mls_history.db/mls_address_history/updated_date=2017-11-25"
    //val mainaddresstablepath="/user/hive/warehouse/bkfs.db/address"


    //val mainaddresstablepath="/tmp/first.txt"


    if (addressdeltatable.length>0 ) {
      val parqfile=sqlContext.read.parquet(addressdeltatable)

      val newparqfile=parqfile.withColumn(AddressConstants.tablecolumns("addr_s_f"), lit(null))
        .withColumn(AddressConstants.tablecolumns("unittype"), lit(null).cast(StringType))
        .withColumn(AddressConstants.tablecolumns("unitnum"), lit(null).cast(StringType))
        .withColumn(AddressConstants.tablecolumns("addr_c_r"), lit(null).cast(StringType))
        .withColumn(AddressConstants.tablecolumns("addr_c_t"), lit(null).cast(StringType))
        .withColumn(AddressConstants.tablecolumns("dataver"), lit(null).cast(StringType))

      val controlflag=1.toChar

      val newenddate =DateTime.parse(run_date).plusDays(1).getMillis

      println("get second"+ newenddate)
      //new org.joda.time.DateTime(1510333448000L).toLocalDate

      //d1.plusDays(1).toLocalDate

      //var enddate=DateTime.parse(sdate).getMillis


      //val filtered_df=newparqfile.filter( parqfile("updated_at") >= DateTime.parse(sdate).getMillis && parqfile("updated_at")<= newenddate)


      //filtered_df.map(r=>r.mkString(controlflag.toString)).write.format("text").save(deltaoutputpath)

      val idlist= newparqfile.select(newparqfile(AddressConstants.tablecolumns("id")).cast("string")).collect()
     // idlist.foreach(e=>println(e(0)))


      //newparqfile.createTempView("deltatbl")
/*
      val newparqfile_new= sqlContext.sql(" select Cast("+ AddressConstants.tablecolumns("id")+" as VARCHAR(36))," +
        "Cast( "+ AddressConstants.tablecolumns("subpremise")+ " as VARCHAR(32))," +
        "Cast("+ AddressConstants.tablecolumns("strtnum")+" as VARCHAR(32))," +
        "Cast( "+ AddressConstants.tablecolumns("strtdir")+"   as VARCHAR(16))," +
        "Cast( "+ AddressConstants.tablecolumns("strtname")+  " as VARCHAR(128))," +
        "Cast("+ AddressConstants.tablecolumns("st_dir_suff")+  "  as VARCHAR(16))," +
        "Cast( "+ AddressConstants.tablecolumns("strtdesg")+  " as VARCHAR(16))," +
        "Cast( "+ AddressConstants.tablecolumns("city")+  "  as VARCHAR(64))," +
        "Cast( "+ AddressConstants.tablecolumns("state")+  "  as VARCHAR(32))," +
        "Cast( "+ AddressConstants.tablecolumns("county")+  "  as VARCHAR(128))," +
        "Cast(  "+ AddressConstants.tablecolumns("ngr_r")+  "   as VARCHAR(255))," +
        "Cast( "+ AddressConstants.tablecolumns("ngr_m")+  "    as VARCHAR(255))," +
        "Cast(  "+ AddressConstants.tablecolumns("ngr_n")+  "    as VARCHAR(255))," +
        "Cast(  "+ AddressConstants.tablecolumns("ngr_s")+  "  as VARCHAR(255))," +
        "Cast( "+ AddressConstants.tablecolumns("ngrh")+  "  as VARCHAR(500))," +
        "Cast( "+ AddressConstants.tablecolumns("addr")+  "  as VARCHAR(255))," +
        "Cast( "+ AddressConstants.tablecolumns("zip")+  "   as VARCHAR(5))," +
        "Cast( "+ AddressConstants.tablecolumns("zip4")+  "  as VARCHAR(4))," +
        "Cast (Cast( "+ AddressConstants.tablecolumns("lat")+  "  as string)  as float)," +
        "Cast (Cast( "+ AddressConstants.tablecolumns("lng")+  "  as string)  as float)," +
        "Cast( "+ AddressConstants.tablecolumns("type")+  "  as VARCHAR(20))," +
        "Cast( "+ AddressConstants.tablecolumns("srctype")+  "  as VARCHAR(20))," +
        "county_geo_id,city_geo_id,neighborhood_r_geo_id,neighborhood_m_geo_id," +
        "neighborhood_n_geo_id,neighborhood_s_geo_id," +
        "CAST(  "+ AddressConstants.tablecolumns("crt_at")+  "   AS timestamp)," +
        "CAST(  "+ AddressConstants.tablecolumns("upd_at")+  "    AS timestamp)," +
        AddressConstants.tablecolumns("addr_s_f")+"," +
        AddressConstants.tablecolumns("unittype")+"," +
        AddressConstants.tablecolumns("unitnum")+"," +
        AddressConstants.tablecolumns("addr_c_r")+"," +
        AddressConstants.tablecolumns("addr_c_t")+"," +
        AddressConstants.tablecolumns("dataver") + " from  deltatbl")*/


      //println("total ids in mlsaddress"+idlist)
      val broadcastList = sc.broadcast(idlist.map(r=>r(0).toString))

      //println("broadcast variable ="+broadcastList.value.foreach(e=>println(e(0))))

      //val  mainaddressdf=sc.textFile(mainaddresstablepath)

     // val bkfsaddressdf =mainaddressdf.map(row=>row.split(controlflag)).toDF()


     //bkfsaddressdf.take(1).foreach(r=>println(r(0)))

      //bkfsaddressdf.filter(!broadcastList.value.contains(bkfsaddressdf(AddressConstants.tablecolumns("id"))))
     // val checkId = udf((id: Long) => broadcastList.value.contains(id))

      //val finalDataFrame = bkfsaddressdf.where(checkId(bkfsaddressdf(AddressConstants.tablecolumns("id"))))
      //println(bkfsaddressdf.printSchema())
      //val finalDataFrame = bkfsaddressdf.filter(bkfsaddressdf(AddressConstants.tablecolumns("id")).isin(broadcastList.value: _*))

      //finalDataFrame.take(1).foreach(r=>println(r(0)))

      //testdf.filter(rw => rw.getAs[WrappedArray[String]](0)(0).contains(brdcast.value)).count

     // val newdf=bkfsaddressdf.filter(rw => !broadcastList.value.contains(rw.getAs[WrappedArray[String]](0)(0)))
     // val datatest=dd.map(r=>r.getAs[WrappedArray[String]](0).toArray.mkString(newt.toString))

     // val saveddf =newdf.map(r=>r.getAs[WrappedArray[String]](0).toArray.mkString(controlflag.toString))

     // saveddf.write.format("text").save(outputpath)
       //println("saved completed")
        //.collect.foreach(r=>println(r.getAs[WrappedArray[String]](0)(0)))



      // val df = bkfsaddressdf.filter(rw => { !broadcastList.value.contains(rw   .getAs[String](AddressConstants.tablecolumns("id")).trim) })

      //filtercnt
        //parqfile.withColumn("addr_source_flag", parqfile("id"))

     // println("total filter count"+ newparqfile.printSchema())


      //val  mainaddressdf=sc.read.option("delimiter","?").schema(customSchema).csv(mainaddresstablepath)


      //val bkfsaddressdf =mainaddressdf.map(row=>row.split(controlflag)).map(rr=>Row(rr(0),rr(1),rr(2),rr(3),rr(4),rr(5),rr(6),rr(7),rr(8),rr(9),rr(10),rr(11),rr(12),rr(13),rr(14),rr(15),rr(16),rr(17).trim.toFloat,rr(18).trim.toFloat,rr(19),rr(20),rr(21).toInt,rr(22).toInt,rr(23).toInt,rr(24).toInt,rr(25).toInt,rr(26).toInt,rr(27).toInt,rr(28).toLong,rr(29).toLong,rr(30),rr(31),rr(32),rr(33),rr(34),rr(35)))
    // val df =hiveContext.table("bkfs.address")


      val df =hiveContext.table(addressmaintable)
      val newdf=df.filter(not(col(AddressConstants.tablecolumns("id")).isin(broadcastList.value : _*)))

      //val maindf=newdf.union(newparqfile_new)
      newdf.write.option("spark.io.encryption.enabled", "false").mode("overwrite").insertInto("default.addrtemp_new")

      println("saved completed")



    }


    sc.stop();
  }

}