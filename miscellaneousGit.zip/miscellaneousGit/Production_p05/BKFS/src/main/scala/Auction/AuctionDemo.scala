/**
  * Created by manoj on 11/5/18.
  */

/**
  * Created by manoj on 7/11/17.
  */


import org.apache.spark.sql.{DataFrame, SparkSession}


case class SimpsonCharacter(name: String, actor: String, episodeDebut: String)
case class Auction(auctionid: String, bid: Float, bidtime: Float, bidder: String, bidderrate: Integer, openbid: Float, price: Float, item: String, daystolive: Integer)


object AuctionDemo {

  def main(args: Array[String]): Unit = {


    val warehouseLocation = "file:///tmp/ware"

    val spark = SparkSession
      .builder()
      .appName("RealEstateExample")
      .config("spark.sql.warehouse.dir", warehouseLocation)
      .config("spark.master", "local")
      .enableHiveSupport()
      .getOrCreate()
    //.config("spark.master", "master")

    import spark.implicits._


    /* val auctionRDD  =ebaydf.map(row=>row.split(",")).map(newdf=>Auction(
       newdf(0),newdf(1).toFloat,newdf(2).toFloat,newdf(3),newdf(4).toInt,newdf(5).toFloat,newdf(6).toFloat,newdf(7),newdf(8).toInt))
 */
    val auctionRDD = spark.read.textFile("/home/manoj/miscellaneousGit/sparkdataframeexample/ebay.csv")
      .map(_.split(","))
      .map(p =>Auction(p(0),p(1).toFloat,p(2).toFloat,p(3),p(4).toInt,p(5).toFloat,p(6).toFloat,p(7),p(8).toInt ))

      val auctiondf=auctionRDD.toDF()


    val apair = auctionRDD.map(auc=>((auc.auctionid,auc.item), (auc.bid, 1)))

    val atotalcount = apair.rdd.reduceByKey((x,y) => (x._1 + y._1, x._2 + y._2))
    val avgitem=atotalcount.mapValues{case(total,y) =>(total/y) }
    //val sorteddf=avgitem.toDF().sort("auctionid")
    val sorteddf=avgitem.sortByKey()

    sorteddf.take(10).foreach(println)



    auctiondf.createOrReplaceTempView("auctiontable")
    val newdf=auctiondf.rdd.map(r=>((r.getAs[String]("swu_template_id"), r.getAs[String]("event_type")),(1) ))


    val sqlauctiondf=spark.sql("select auctionid , item , min (bid) ,avg(bid) ,max(bid) from  auctiontable group by auctionid , item order by auctionid  limit 10")

    sqlauctiondf.take(10).foreach(println)
    //optbay.toDF().select("auctionid").distinct.count
    /* println(for (elem <- optbay.take(3)) {println(elem)})

     val nebaydf= optbay.toDF()

     println(nebaydf.select($"auctionid").distinct.count)

     */

    spark.stop()

  }
  /*
    def avgByItem(autionrdd :RDD[Auction]): Unit =  {

         (autionrdd groupBy("auctionid", "item")).count

    }*/

  def pushtoElasticSearch(df :DataFrame): Unit ={
    println("pushing started")
    /*

 optbay.toDF().write.format("org.elasticsearch.spark.sql")
   .option("es.nodes" , "192.168.120.135:9200,192.168.120.136:9200")
   .option("es.port","9200")
   .mode("Append")
   .save("megacorp/ebaymultiple")
 */
    /*
        aggsparkdf.toDF().write.format("org.elasticsearch.spark.sql")
          .option("es.nodes" , "192.168.120.21")
          .option("es.port","9200")
          .mode("Append")
          .save("/sparkpost_test/metric_agg")*/



    df.toDF().write.format("org.elasticsearch.spark.sql")
      .option("es.nodes" , "192.168.120.21")
      .option("es.port","9200")
      .mode("Append")
      .save("megacorp/ebaynew")


    println("pushing completed")

  }



}
