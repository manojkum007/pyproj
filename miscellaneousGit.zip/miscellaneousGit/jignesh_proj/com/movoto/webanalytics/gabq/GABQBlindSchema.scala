package com.movoto.webanalytics.gabq

import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.BinaryType
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.ArrayType
import org.apache.spark.sql.types.MetadataBuilder
import org.apache.spark.sql.types.Metadata

class GABQBlindSchema extends SimpleFlattener {
  
  var measures: Seq[StructField] = null;
  var totals: Seq[StructField] = null;
  
  var trafficSource: Seq[StructField] = null;
  var trafficSource_adwordsClickInfo: Seq[StructField] = null;
  var trafficSource_adwordsClickInfo_targetingCriteria: Seq[StructField] = null;
  
  var device: Seq[StructField] = null;
  
  var geoNetwork: Seq[StructField] = null;
  
  var customDimensions: Seq[StructField] = null;
  
  var singleHit: Seq[StructField] = null;
  var hitPage: Seq[StructField] = null;
  var hitEventInfo: Seq[StructField] = null;
  var hitCustomDimensions: Seq[StructField] = null;
  var hitSourcePropertyInfo: Seq[StructField] = null;
  var hitContentGroup: Seq[StructField] = null;
  
  var partitionDate: StructField = null;
  var df: DataFrame = null
  
  val helper = FlatteningHelper;
  
  def buildSchema: StructType = {

    //schemaForSingleHit
    schemaForMeasures
    schemaForTotals
    schemaForTrafficSource
    schemaForDevice
    schemaForGeoNetwork
    schemaForCustDims
    schemaForSingleHit
    schemaForHitPage
    schemaForHitEventInfo
    schemaForHitCustomDimensions
    schemaForHitSourcePropertyInfo
    schemaForHitContentGroup

    //println( "schemafor singlelist " +df.collect)

    
    val schema =    measures
    /*measures ++
    totals ++
    trafficSource ++
    trafficSource_adwordsClickInfo ++
    trafficSource_adwordsClickInfo_targetingCriteria ++
    device ++
    geoNetwork ++
    customDimensions ++
    singleHit ++
    hitPage ++ 
    hitEventInfo ++
    hitCustomDimensions ++
    hitSourcePropertyInfo ++
    hitContentGroup ++ 
    Seq( partitionDate )     // <- date should go to end for partitioning
*/

    StructType( schema )
  }
  
  /**
   *   
       |-- fullVisitorId: binary (nullable = true)
       |-- userId: binary (nullable = true)
       |-- channelGrouping: binary (nullable = true)
       |-- socialEngagementType: binary (nullable = true)
       |-- visitNumber: long (nullable = true)
       |-- visitId: long (nullable = true)
       |-- visitStartTime: long (nullable = true)
END it--->       |-- date: binary (nullable = true)
   */
  def schemaForMeasures: Unit = {
    measures = 
      (for(columnName <-
        List("fullVisitorId", 
             "userId", 
             "channelGrouping", 
             "socialEngagementType", 
             "visitNumber", 
             "visitId", 
             "visitStartTime") ) 
        yield {
          helper.newStructField(df.schema(columnName))
        })   
    
    partitionDate = helper.newStructField(df.schema("date"))      
  }
  
  /**0
   * 
 |-- totals: struct (nullable = true)
 |    |-- visits: long (nullable = true)
 |    |-- hits: long (nullable = true)
 |    |-- pageviews: long (nullable = true)
 |    |-- timeOnSite: long (nullable = true)
 |    |-- bounces: long (nullable = true)
 |    |-- transactions: long (nullable = true)
 |    |-- transactionRevenue: long (nullable = true)
 |    |-- newVisits: long (nullable = true)
 |    |-- screenviews: long (nullable = true)
 |    |-- uniqueScreenviews: long (nullable = true)
 |    |-- timeOnScreen: long (nullable = true)
 |    |-- totalTransactionRevenue: long (nullable = true)
   * 
   */
  def schemaForTotals: Unit = {
    val colNamePrefix = "total_";
    totals = 
      (for(columnName <-
        List("visits", 
             "hits",
             "pageviews",
             "timeOnSite",
             "bounces",
             "transactions",
             "transactionRevenue",
             "newVisits",
             "screenviews",
             "uniqueScreenviews",
             "timeOnScreen",
             "totalTransactionRevenue"
             ) ) 
        yield { val sf = df.schema("totals").dataType.asInstanceOf[StructType](columnName)        
        helper.newStructField(sf, colNamePrefix)
      })   
  }
  
  /**
   * 
 |-- trafficSource: struct (nullable = true) 
 |    |-- referralPath: binary (nullable = true)
 |    |-- campaign: binary (nullable = true)
 |    |-- source: binary (nullable = true)
 |    |-- medium: binary (nullable = true)
 |    |-- keyword: binary (nullable = true)
 |    |-- adContent: binary (nullable = true)
 |    |-- isTrueDirect: boolean (nullable = true)
 |    |-- campaignCode: binary (nullable = true)
 |    |-- adwordsClickInfo: struct (nullable = true)
 |    |    |-- campaignId: long (nullable = true)
 |    |    |-- adGroupId: long (nullable = true)
 |    |    |-- creativeId: long (nullable = true)
 |    |    |-- criteriaId: long (nullable = true)
 |    |    |-- page: long (nullable = true)
 |    |    |-- slot: binary (nullable = true)
 |    |    |-- criteriaParameters: binary (nullable = true)
 |    |    |-- gclId: binary (nullable = true)
 |    |    |-- customerId: long (nullable = true)
 |    |    |-- adNetworkType: binary (nullable = true)
 |    |    |-- isVideoAd: boolean (nullable = true)
 |    |    |-- targetingCriteria: struct (nullable = true)
 |    |    |    |-- boomUserlistId: long (nullable = true) 
   */
  def schemaForTrafficSource: Unit = {
    var colNamePrefix = "trafficSource_";
    trafficSource = 
      (for(columnName <-
        List("referralPath",
             "campaign",
             "source",
             "medium",
             "keyword",
             "adContent",
             "isTrueDirect",
             "campaignCode"
             ) ) 
        yield { val sf = df.schema("trafficSource").dataType.asInstanceOf[StructType](columnName)
         helper.newStructField(sf, colNamePrefix)  
      })   
      
     colNamePrefix = "trafficSource_adwordsClickInfo_";
     trafficSource_adwordsClickInfo = 
      (for(columnName <-
        List("campaignId",
             "adGroupId",
             "creativeId",
             "criteriaId",
             "page",
             "slot",
             "criteriaParameters",
             "gclId",
             "customerId",
             "adNetworkType",
             "isVideoAd"
             ) ) 
        yield { val sf = df.schema("trafficSource").dataType.asInstanceOf[StructType]("adwordsClickInfo").dataType.asInstanceOf[StructType](columnName)
        helper.newStructField(sf, colNamePrefix)  
      })
      
     colNamePrefix = "trafficSource_adwordsClickInfo_targetingCriteria_";
     trafficSource_adwordsClickInfo_targetingCriteria = 
      (for(columnName <-
        List("boomUserlistId"
             ) ) 
        yield { val sf = df.schema("trafficSource").dataType.asInstanceOf[StructType]("adwordsClickInfo").dataType.asInstanceOf[StructType]("targetingCriteria").dataType.asInstanceOf[StructType](columnName)
        helper.newStructField(sf, colNamePrefix)  
      })
  }
  
  /** 
 |-- device: struct (nullable = true)
 |    |-- browser: binary (nullable = true)
 |    |-- browserVersion: binary (nullable = true)
 |    |-- browserSize: binary (nullable = true)
 |    |-- operatingSystem: binary (nullable = true)
 |    |-- operatingSystemVersion: binary (nullable = true)
 |    |-- isMobile: boolean (nullable = true)
 |    |-- mobileDeviceBranding: binary (nullable = true)
 |    |-- mobileDeviceModel: binary (nullable = true)
 |    |-- mobileInputSelector: binary (nullable = true)
 |    |-- mobileDeviceInfo: binary (nullable = true)
 |    |-- mobileDeviceMarketingName: binary (nullable = true)
 |    |-- flashVersion: binary (nullable = true)
 |    |-- javaEnabled: boolean (nullable = true)
 |    |-- language: binary (nullable = true)
 |    |-- screenColors: binary (nullable = true)
 |    |-- screenResolution: binary (nullable = true)
 |    |-- deviceCategory: binary (nullable = true)
   */
  def schemaForDevice: Unit = {
    val colNamePrefix = "device_";
    device = 
      (for(columnName <-
        List("browser",
             "browserVersion",
             "browserSize",
             "operatingSystem",
             "operatingSystemVersion",
             "isMobile",
             "mobileDeviceBranding",
             "mobileDeviceModel",
             "mobileInputSelector",
             "mobileDeviceInfo",
             "mobileDeviceMarketingName",
             "flashVersion",
             "javaEnabled",
             "language",
             "screenColors",
             "screenResolution",
             "deviceCategory"
             ) ) 
        yield { val sf = df.schema("device").dataType.asInstanceOf[StructType](columnName)
        helper.newStructField(sf, colNamePrefix)  
      }) 
  }
  
  /**
 |-- geoNetwork: struct (nullable = true)
 |    |-- continent: binary (nullable = true)
 |    |-- subContinent: binary (nullable = true)
 |    |-- country: binary (nullable = true)
 |    |-- region: binary (nullable = true)
 |    |-- metro: binary (nullable = true)
 |    |-- city: binary (nullable = true)
 |    |-- cityId: binary (nullable = true)
 |    |-- networkDomain: binary (nullable = true)
 |    |-- latitude: binary (nullable = true)
 |    |-- longitude: binary (nullable = true)
 |    |-- networkLocation: binary (nullable = true)
   */
  def schemaForGeoNetwork: Unit = {
    val colNamePrefix = "geoNetwork_";
    geoNetwork = 
      (for(columnName <-
        List("continent",
             "subContinent",
             "country",
             "region",
             "metro",
             "city",
             "cityId",
             "networkDomain",
             "latitude",
             "longitude",
             "networkLocation"
             ) ) 
        yield { val sf = df.schema("geoNetwork").dataType.asInstanceOf[StructType](columnName)
        helper.newStructField(sf, colNamePrefix)  
      }) 
  } 
  
  /**
   * 6, 61, 65, 66, 71, 72, 73, 74, 75, 76, 77, 79, 80, 81, 83, 84, 85, 87, 88
   * 
   * NewList -> 6, 61, 65, 66, 71, 72, 73, 74, 75, 76, 77, 79, 80, 81, 83, 84, 85 
   * 
   * 78 (gclid)
   * 
 |-- customDimensions: struct (nullable = true)
 |    |-- array: array (nullable = true)
 |    |    |-- element: struct (containsNull = true)
 |    |    |    |-- index: long (nullable = true)
 |    |    |    |-- value: binary (nullable = true)
   */
  def schemaForCustDims: Unit = {
    val colNamePrefix = "customDimensions_index_";
    customDimensions =
      (for(columnName <-
      List(6, 61, 65, 66, 71, 72, 73, 74, 75, 76, 77, 79, 80, 81, 83, 84, 85) ) 
      yield {
        StructField((colNamePrefix.concat(columnName.toString)), StringType, true, helper.getCommentMetadata(columnName.toString) )
        //.withComment(columnName.toString)        
      })
  }

  
  /**
   * 
 hits: struct (containsNull = true)
 |    |    |    |-- hitNumber: long (nullable = true)
 |    |    |    |-- time: long (nullable = true)
 |    |    |    |-- hour: long (nullable = true)
 |    |    |    |-- minute: long (nullable = true)
 |    |    |    |-- isSecure: boolean (nullable = true)
 |    |    |    |-- isInteraction: boolean (nullable = true)
 |    |    |    |-- isEntrance: boolean (nullable = true)
 |    |    |    |-- isExit: boolean (nullable = true)
 |    |    |    |-- referer: binary (nullable = true)
 |    |    |    |-- type: binary (nullable = true) 
   * 
   */
  def schemaForSingleHit: Unit = {
    val colNamePrefix = "hits_";
    singleHit = 
      (for(columnName <-
        List("hitNumber", 
             "time", 
             "hour", 
             "minute", 
             "isSecure", 
             "isInteraction", 
             "isEntrance", 
             "isExit", 
             "referer", 
             "type"  
             ) ) 
        yield { val sf = df.schema("hits").dataType.asInstanceOf[StructType]("array").dataType.asInstanceOf[ArrayType].elementType.asInstanceOf[StructType](columnName)
        helper.newStructField(sf, colNamePrefix)  
      }) 
  }
  
  /** 
		|-- page: struct (nullable = true)
 		|    |-- pagePath: binary (nullable = true)
 		|    |-- hostname: binary (nullable = true)
 		|    |-- pageTitle: binary (nullable = true)
 		|    |-- searchKeyword: binary (nullable = true)
 		|    |-- searchCategory: binary (nullable = true)
  	|    |-- pagePathLevel1: binary (nullable = true)
  	|    |-- pagePathLevel2: binary (nullable = true)
  	|    |-- pagePathLevel3: binary (nullable = true)
   	|    |-- pagePathLevel4: binary (nullable = true)
   */
  def schemaForHitPage: Unit = {
    val colNamePrefix = "hits_page_";
    hitPage = 
      (for(columnName <-
        List("pagePath",
           	 "hostname",
           	 "pageTitle",
           	 "searchKeyword",
           	 "searchCategory",
           	 "pagePathLevel1",
           	 "pagePathLevel2",
           	 "pagePathLevel3",
           	 "pagePathLevel4" 
             ) ) 
        yield { val sf = df.schema("hits").dataType.asInstanceOf[StructType]("array").dataType.asInstanceOf[ArrayType].elementType.asInstanceOf[StructType]("page").dataType.asInstanceOf[StructType](columnName)
        helper.newStructField(sf, colNamePrefix)  
      })
  }
  
  /**
   |-- eventInfo: struct (nullable = true)
	 |    |-- eventCategory: binary (nullable = true)
	 |    |-- eventAction: binary (nullable = true)
	 |    |-- eventLabel: binary (nullable = true)
	 |    |-- eventValue: long (nullable = true)
   */
  def schemaForHitEventInfo: Unit = {
    val colNamePrefix = "hits_eventInfo_";
    hitEventInfo = 
      (for(columnName <-
        List("eventCategory", 
             "eventAction", 
             "eventLabel", 
             "eventValue"
             ) ) 
        yield { val sf = df.schema("hits").dataType.asInstanceOf[StructType]("array").dataType.asInstanceOf[ArrayType].elementType.asInstanceOf[StructType]("eventInfo").dataType.asInstanceOf[StructType](columnName)
        helper.newStructField(sf, colNamePrefix)  
      })    
  }
  
  /**
   * 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 79, 80, 81, 82, 83, 84, 85, 86
   * 
   * NewDims-> 1, 2, 3, 4, 5, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 62, 63, 64, 67, 68, 69, 70, 78, 82, 86, 87, 88 
   * 
   * 37 (soc_shr_type)
   * 
   * customDimensions: struct (nullable = true)
			|-- array: array (nullable = true)
			|    |-- element: struct (containsNull = true)
			|    |-- index: long (nullable = true)
			|    |-- value: binary (nullable = true)
   */
  def schemaForHitCustomDimensions: Unit = {
    val colNamePrefix = "hits_customDimensions_index_";
    hitCustomDimensions =
      (for(columnName <-
      List(1, 2, 3, 4, 5, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 62, 63, 64, 67, 68, 69, 70, 78, 82, 86, 87, 88) ) 
      yield {
        StructField((colNamePrefix.concat(columnName.toString)), StringType, true, helper.getCommentMetadata(columnName.toString))      
      })
  }

  
  /**
   |-- sourcePropertyInfo: struct (nullable = true)
	 |    |-- sourcePropertyDisplayName: binary (nullable = true)
	 |    |-- sourcePropertyTrackingId: binary (nullable = true)
   */
  def schemaForHitSourcePropertyInfo: Unit = {
    val colNamePrefix = "hits_sourcePropertyInfo_";
    hitSourcePropertyInfo = 
      (for(columnName <-
        List("sourcePropertyDisplayName", 
             "sourcePropertyTrackingId"
             ) ) 
        yield { val sf = df.schema("hits").dataType.asInstanceOf[StructType]("array").dataType.asInstanceOf[ArrayType].elementType.asInstanceOf[StructType]("sourcePropertyInfo").dataType.asInstanceOf[StructType](columnName)
        helper.newStructField(sf, colNamePrefix)  
      }) 
  }
  
  /**
	 |-- contentGroup: struct (nullable = true)
 	 |    |-- contentGroup1: binary (nullable = true)
 	 |    |-- contentGroup2: binary (nullable = true)
 	 |    |-- contentGroup3: binary (nullable = true)
 	 |    |-- contentGroup4: binary (nullable = true)
 	 |    |-- contentGroup5: binary (nullable = true)
 	 |    |-- contentGroupUniqueViews1: long (nullable = true)
 	 |    |-- contentGroupUniqueViews2: long (nullable = true)
 	 |    |-- contentGroupUniqueViews3: long (nullable = true)
 	 |    |-- contentGroupUniqueViews4: long (nullable = true)
 	 |    |-- contentGroupUniqueViews5: long (nullable = true)
   */
  def schemaForHitContentGroup: Unit = {
    val colNamePrefix = "hits_contentGroup_";
    hitContentGroup = 
      (for(columnName <-
        List("contentGroup1", 
 	           "contentGroup2", 
 	           "contentGroup3", 
 	           "contentGroup4", 
 	           "contentGroup5", 
 	           "contentGroupUniqueViews1", 
 	           "contentGroupUniqueViews2", 
 	           "contentGroupUniqueViews3", 
 	           "contentGroupUniqueViews4", 
 	           "contentGroupUniqueViews5"
             ) ) 
        yield { val sf = df.schema("hits").dataType.asInstanceOf[StructType]("array").dataType.asInstanceOf[ArrayType].elementType.asInstanceOf[StructType]("contentGroup").dataType.asInstanceOf[StructType](columnName)
        helper.newStructField(sf, colNamePrefix)  
      }) 
  }




}







































