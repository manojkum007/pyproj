package com.movoto.webanalytics.gabq

trait SimpleFlattener extends java.io.Serializable {
  
}