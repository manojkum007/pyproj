package com.movoto.webanalytics.gabq

import org.apache.spark.sql.DataFrame;
import scala.collection.mutable.ListBuffer
import org.apache.spark.sql.Row
import scala.collection.mutable.WrappedArray
import org.apache.spark.sql.catalyst.encoders.RowEncoder
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.LongType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.BinaryType
import org.apache.spark.sql.types.BooleanType
import org.apache.spark.sql.types.StringType
import org.apache.spark.rdd.RDD
import util.control.Breaks._



class GABQBlindFlattener extends GABQBlindSchema {
  /**
   * Flattens daily export records into given schema.
   */
  def flattenDailyExport(dailyDF: DataFrame): RDD[Row] = {
    //build the schema first from given dataframe

    println ("running inside GABQBlindFlattener ")
    this.df = dailyDF
    val schema = this.buildSchema
    
    dailyDF.flatMap(rw => {
      val recBuff = ListBuffer.empty[Any]
      explodeMeasures(rw, recBuff)
     /* explodeTotals(rw, recBuff)
      explodeTrafficeSource(rw, recBuff)
      explodeDevice(rw, recBuff)
      explodeGeoNetwork(rw, recBuff)
      explodeCustomDimensions(rw, recBuff)*/
      
      val dateValue = helper.getAsByteString(rw, "date") // partitioned column
      
      val hitsRW = rw.getAs[Row]("hits").getAs[WrappedArray[Row]]("array")      
      var hitBuff:ListBuffer[Any] = null




      val outRows = for(hit <- hitsRW) yield {
        hitBuff = null
        val rwBuff = ListBuffer.empty[Any];

        //explode every hit
        hitBuff = explodeSingleHit(hit);
        println("hitBuff +" +hitBuff)
        rwBuff ++= recBuff
        rwBuff ++= hitBuff
        rwBuff += dateValue //partitioned column
        Row(rwBuff: _*)

      }
      
      //generate a row for each of the measures other than hits
      recBuff ++= (for(i <- 1 to hitBuff.size) yield { null })
      recBuff += dateValue // partitioned column
      
      outRows :+ Row(recBuff: _*)      
    })
  }
  
  
  def explodeMeasures(rw: Row, recBuff: ListBuffer[Any]): Unit = {
    addRecordsByType(measures, rw, recBuff);
  }
  
  def explodeTotals(rw: Row, recBuff: ListBuffer[Any]): Unit = {
    addRecordsByType(totals, rw.getAs[Row]("totals"), recBuff);
  }
  
  def explodeTrafficeSource(rw: Row, recBuff: ListBuffer[Any]): Unit = {
    addRecordsByType(trafficSource, rw.getAs[Row]("trafficSource"), recBuff);
    addRecordsByType(trafficSource_adwordsClickInfo, rw.getAs[Row]("trafficSource").getAs[Row]("adwordsClickInfo"), recBuff);
    addRecordsByType(trafficSource_adwordsClickInfo_targetingCriteria, rw.getAs[Row]("trafficSource").getAs[Row]("adwordsClickInfo").getAs[Row]("targetingCriteria"), recBuff);
  }
  
  def explodeDevice(rw: Row, recBuff: ListBuffer[Any]): Unit = {
    addRecordsByType(device, rw.getAs[Row]("device"), recBuff);
  }
  
  def explodeGeoNetwork(rw: Row, recBuff: ListBuffer[Any]): Unit = {
    addRecordsByType(geoNetwork, rw.getAs[Row]("geoNetwork"), recBuff);
  }
  
  def explodeCustomDimensions(rw: Row, recBuff: ListBuffer[Any]): Unit = {
    addCustomDimensionFields(customDimensions, rw.getAs[Row]("customDimensions").getAs[WrappedArray[Row]]("array"), recBuff)
  }
  
  def explodeSingleHit(rw: Row): ListBuffer[Any] = {
    val recBuff = ListBuffer.empty[Any]
    addRecordsByType(singleHit, rw, recBuff);    
    addRecordsByType(hitPage, rw.getAs[Row]("page"), recBuff)
    addRecordsByType(hitEventInfo, rw.getAs[Row]("eventInfo"), recBuff)
    addCustomDimensionFields(hitCustomDimensions, rw.getAs[Row]("customDimensions").getAs[WrappedArray[Row]]("array"), recBuff)
    addRecordsByType(hitSourcePropertyInfo, rw.getAs[Row]("sourcePropertyInfo"), recBuff)
    addRecordsByType(hitContentGroup, rw.getAs[Row]("contentGroup"), recBuff)
    
    recBuff
  }
  
  def addCustomDimensionFields(fields: Seq[StructField], rwArr: WrappedArray[Row], recBuff: ListBuffer[Any]): Unit = {
    fields.foreach(sf => {
      recBuff += null.asInstanceOf[String] // insert value as null by default
      rwArr.foreach(rw => {
        val indexValue = rw.getAs[Long]("index")        
        if(indexValue == sf.metadata.getString(helper.CONST_COMMENT).toLong) {
          recBuff( (recBuff.size - 1) ) = helper.getAsByteString(rw, "value")          
        }
      })
    })
  }
  
  def addRecordsByType(fields: Seq[StructField], rw: Row, recBuff: ListBuffer[Any]): Unit = {
    fields.foreach(sf => sf.dataType match {
      case _: LongType => if(rw==null) recBuff += null.asInstanceOf[Long] else recBuff += rw.getAs[Long](sf.metadata.getString(helper.CONST_COMMENT))
      case _: StringType => if(rw==null) recBuff += null.asInstanceOf[String] else recBuff += helper.getAsByteString(rw, sf.metadata.getString(helper.CONST_COMMENT))
      case _: BooleanType => if(rw==null) recBuff += null.asInstanceOf[Boolean] else recBuff += rw.getAs[Boolean](sf.metadata.getString(helper.CONST_COMMENT))
      case _ => println("Error: Data type of column not recognized- " + sf.metadata.getString(helper.CONST_COMMENT))
    })
  }
  
  
  
}








