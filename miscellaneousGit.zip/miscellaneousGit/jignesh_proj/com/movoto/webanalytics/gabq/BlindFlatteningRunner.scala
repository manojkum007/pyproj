package com.movoto.webanalytics.gabq

import java.io.File
import org.apache.spark.sql.DataFrame
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.Path
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.hive.HiveContext

object BlindFlatteningRunner {
  
  val HISTORIC_BQ_TABLE_FLAG = "spark.movoto.gabq.isHistoric";
  
  def main(args: Array[String]) {

    val master = args.length match {
      case x: Int if x > 0 => args(0)
      case _ => "local"
    }
   /* if(! (args.length <= 3) ) {
      System.out.println(args.mkString(", "))
      println("Usage: " + usage)
      System.exit(-1);
    }*/
    
   /* val inpath = args(0).trim
    val outpath = args(1).trim
    var filterPartitions:String =  if(args.length > 2) args(2).trim else null*/

    val inpath="/home/manoj/spark_helper/bigquery_par"
    val outpath="/home/manoj/spark_helper/newflattened"
    var filterPartitions=null

    var sc:SparkContext = null
    
    try {      
      sc = new SparkContext(new SparkConf().setAppName("bigqueryflatening").setMaster("local[2]"))
      val sqlContext = new SQLContext(sc)
      val hiveContext = new HiveContext(sc)
    
      val flattener = new GABQBlindFlattener;
      val hadoopFS = FileSystem.get(new Configuration)
      
      runFlattening(inpath, outpath, filterPartitions, sc, hiveContext, flattener, hadoopFS);
      
    } catch {
      case e:Exception => {
        println("*************** Error: " + e.getLocalizedMessage);
        e.printStackTrace()
        System.exit(-1)
      }
    } finally {
      if(sc != null) sc.stop()
    }
    
  }
  
  def runFlattening(inpath: String, outpath: String, filterPartitions: String, sc: SparkContext, hiveContext: HiveContext, flattener: GABQBlindFlattener, hadoopFS: FileSystem) = {
    import hiveContext.implicits._
    import hiveContext.sql
    
    var allpartitions = hadoopFS.listStatus(new Path(inpath));
    var allpartsavailable = true;
    if(filterPartitions != null) {      
      allpartitions = allpartitions.filter(partfile => (partfile.isDirectory && filterPartitions.contains(partfile.getPath.getName)) )
      if( filterPartitions.split(",").length != allpartitions.length ) {
        throw new Exception("Missing source partition(s). " + allpartitions.mkString(",") + s" does not match $filterPartitions." )
      }
    }       
    
    for(infile <- allpartitions) {
      val infileName = infile.getPath.getName
      val inpartition = buildInPath( infileName, inpath )
      println(s"Processing $inpartition")      
      
      val rowRDD = flattener.flattenDailyExport( hiveContext.read.parquet(inpartition) )
      println("rowRDD " )

      rowRDD.foreach(println)


      //val df = hiveContext.createDataFrame(rowRDD, flattener.buildSchema)


      hiveContext.setConf("hive.exec.dynamic.partition", "true")
      hiveContext.setConf("hive.exec.dynamic.partition.mode", "nonstrict")
    	/*val reccount =
    	  df.write.mode("append")
    	  .partitionBy("date")
    	  .insertInto(outpath);*/
          	
    //	println(s"$reccount rows written for input $infileName to $outpath")
    }
  }
  
  def buildInPath(infileName: String, indir: String): String = {
    if(indir.endsWith("/")) indir.concat(infileName) 
    else indir.concat("/").concat(infileName)
  }
  
  val usage = """spark-submit app ... <input directory> <output tablename> [<filter directory name1>,<filter directory name2>,...]
    FOR OLD GA BQ SCHEMA USE --conf spark.movoto.gabq.isHistoric=true """
}