package com.movoto.webanalytics.gabq

import org.apache.spark.sql.Row
import scala.collection.mutable.WrappedArray
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.BinaryType
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.Metadata
import org.apache.spark.sql.types.MetadataBuilder

object FlatteningHelper extends java.io.Serializable {
  
  val CONST_COMMENT = "comment";
  
  def getAsByteString(rw: Row, colName: String) : String = {
    rw.getAs[Array[Byte]](colName) match {
      case a: Array[Byte] => new String(a, "utf-8")
      case _ => null.asInstanceOf[String]
    }
  }
  
  def getAsDimensionArray(rwArr: WrappedArray[Row], indexMap: Map[Long, Int]): Array[String] = {
    val dimArr: Array[String] = Array.ofDim[String](indexMap.size)
    
    rwArr.foreach(dim => dim.getAs[Long]("index") match {
      case (x: Long) if(x != null && indexMap.contains(x)) => dimArr( indexMap(x) ) = FlatteningHelper.getAsByteString(dim, "value")
      case _ =>
    })
    
    dimArr
  }
  
  def newStructField(sf: StructField, colNamePrefix: String = "") : StructField = {
    sf.dataType match {
      case _: BinaryType => StructField((colNamePrefix.concat(sf.name)), StringType, sf.nullable, getCommentMetadata(sf.name))
      case _ => StructField((colNamePrefix.concat(sf.name)), sf.dataType, sf.nullable, getCommentMetadata(sf.name))
    }
  }
  
      
  /**
   * Return metadata instance for comments.
   */
  def getCommentMetadata(comnt: String): Metadata = {
    (new MetadataBuilder).putString("comment", comnt).build()
  }
  
}