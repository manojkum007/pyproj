package com.movoto.webanalytics.utils

import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types._
import com.movoto.webanalytics.gabq.FlatteningHelper
import scala.collection.mutable.ArrayBuffer

object SchemaUtils extends java.io.Serializable {
  
  def toSparkSchemaFromSQL(sqlSchema: String) = {
    val schemaFields = for(colRec <- sqlSchema.split(',').map(_.trim)) yield {
      val colInfo = colRec.split("\\s+")
      assert(colInfo.size >= 2, "SQL schema string should contain at least 2 arguments (column_name | data_type)")
      StructField(colInfo(0).trim.replaceAll("`", ""), getTypeByName(colInfo(1).trim))
    }
    
    StructType(schemaFields)
  }
    
  def toSparkSchema(hiveSchema: String): StructType = {    
    
    val schemaFields = for( colRec <- hiveSchema.split('\n') ) yield { 
      val colInfo = colRec.split('|')
      assert(colInfo.size >= 2, "Hive schema string should contain at least 2 arguments (column_name | data_type)")
      
      colInfo.toList match {
        case List(colName, colType, isNullable, comments) => StructField(colName.trim, getTypeByName(colType.trim), isNullable.contains("true"), (new MetadataBuilder).putString("comment", comments).build())
        case List(colName, colType, isNullable) => StructField(colName.trim, getTypeByName(colType.trim), isNullable.contains("true"))
        case List(colName, colType) => StructField(colName.trim, getTypeByName(colType.trim), true)
        case _ => null
      }
    }

    StructType(schemaFields)
  }
  
  def getTypeByName(typeName: String) : DataType = {
    typeName.toLowerCase() match {
      case "string" => StringType
      case "int" => IntegerType
      case "bigint" => LongType
      case "double" => DoubleType
      case "boolean" => BooleanType
      case "binary" => BinaryType      
      case _ => null
    }
  }
  
  def toSQLSchema(sparkSchema: StructType): String = {    
    sparkSchema.fields.map(e => {
      "`" + e.name + "` " + e.dataType.simpleString
    }).mkString(", ")        
  }
}