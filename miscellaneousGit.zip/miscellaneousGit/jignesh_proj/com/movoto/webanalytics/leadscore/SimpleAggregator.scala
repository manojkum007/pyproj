package com.movoto.webanalytics.leadscore

trait SimpleAggregator extends java.io.Serializable {
  
}