package com.movoto.webanalytics.leadscore

import scala.collection.mutable.ArrayBuffer
import org.joda.time._

object LeadScoreAggUtils extends java.io.Serializable {

  def toVisitTSMillis(visitstarttime: Any, hittime: Any): Long = {
    ((visitstarttime.asInstanceOf[Long] * 1000L) + hittime.asInstanceOf[Long])
  }

  def a4b4SessionsCounts(a4: Seq[Array[Any]], b4: Seq[Array[Any]]): ArrayBuffer[Any] = {
    import LeadScoreConstants.gagrouped._;

    val aggval = ArrayBuffer[Any](
      // -- number of sessions after first lead
      a4.map(_(visitnumber).asInstanceOf[Long]).distinct.size,
      //  -- number of sessions before first lead   
      b4.map(_(visitnumber).asInstanceOf[Long]).distinct.size,
      // -- number of saved searches after first lead
      a4.filter(_(label) == "save-search").map(_(visitnumber)).distinct.size,
      // -- number of saved searches before first lead
      b4.filter(_(label) == "save-search").map(_(visitnumber)).distinct.size,
      // -- number of favorited homes after first lead
      a4.filter(_(label) == "favorite-home").map(_(visitnumber)).distinct.size,
      // -- number of favorited homes before first lead
      b4.filter(_(label) == "favorite-home").map(_(visitnumber)).distinct.size)

    aggval
  }

  def a4b4Properties(a4s: Seq[Array[Any]], b4s: Seq[Array[Any]], a4: Seq[Array[Any]], b4: Seq[Array[Any]]): ArrayBuffer[Any] = {
    import LeadScoreConstants.gagrouped._;

    val aggval = ArrayBuffer[Any](
      // -- number of properties viewed after first lead
      a4.filter(e =>
        (e(hittype) != null && e(hittype).asInstanceOf[String].toLowerCase == "page"
          && e(dpp) != null && e(pgpath) != null && e(pgpath).asInstanceOf[String].trim.toLowerCase == "/Property Detail".toLowerCase))
        .filter(e => (e(pview) != null && !e(pview).asInstanceOf[String].trim.isEmpty)).size,

      // -- number of properties viewed before first lead
      b4.filter(e =>
        (e(hittype) != null && e(hittype).asInstanceOf[String].toLowerCase == "page"
          && e(dpp) != null && e(pgpath) != null && e(pgpath).asInstanceOf[String].trim.toLowerCase == "/Property Detail".toLowerCase))
        .filter(e => (e(pview) != null && !e(pview).asInstanceOf[String].trim.isEmpty)).size,

      // -- number of distinct days visiting the site after first lead  nodd_ahtld
      a4s.map(_(strvdate)).distinct.size,
      // -- number of distinct days visiting the site before first lead  nodd_bhtld
      b4s.map(_(strvdate)).distinct.size,
      // -- number of pages seen while logged in after first lead  nopvw_ahtld
      a4.map(e => (e(pview).asInstanceOf[String], e(hittype).asInstanceOf[String]))
        .filter(e => (e._1 != null && !e._1.trim.isEmpty && e._2 != null && e._2.toLowerCase == "page")).size,
      // -- number of pages seen while logged in before first lead  nopvw_bhtld
      b4.map(e => (e(pview).asInstanceOf[String], e(hittype).asInstanceOf[String]))
        .filter(e => (e._1 != null && !e._1.trim.isEmpty && e._2 != null && e._2.toLowerCase == "page")).size,
      // -- number of photo pages seen after first lead
      a4.map(e => (e(pgpath).asInstanceOf[String], e(hittype).asInstanceOf[String]))
        .filter(e => (e._1 != null && !e._1.trim.isEmpty && e._1.trim.toLowerCase == "/Property Detail - AllPhotos".toLowerCase && e._2 != null && e._2.toLowerCase == "page")).size,
      // -- number of photo pages viewed before first lead
      b4.map(e => (e(pgpath).asInstanceOf[String], e(hittype).asInstanceOf[String]))
        .filter(e => (e._1 != null && !e._1.trim.isEmpty && e._1.trim.toLowerCase == "/Property Detail - AllPhotos".toLowerCase && e._2 != null && e._2.toLowerCase == "page")).size)

    val a4pview = a4.map(e => (e(plstatus).asInstanceOf[String], e(hittype).asInstanceOf[String]))
    val b4pview = b4.map(e => (e(plstatus).asInstanceOf[String], e(hittype).asInstanceOf[String]))

    // -- number of sold properties viewed after first lead
    aggval += a4pview.filter(e => (e._1 != null && !e._1.trim.isEmpty && e._1.trim.toLowerCase == "sold" && e._2 != null && e._2.toLowerCase == "page")).size
    // -- number of sold properties viewed before first lead
    aggval += b4pview.filter(e => (e._1 != null && !e._1.trim.isEmpty && e._1.trim.toLowerCase == "sold" && e._2 != null && e._2.toLowerCase == "page")).size
    // -- number of active properties viewed after first lead
    aggval += a4pview.filter(e => (e._1 != null && !e._1.trim.isEmpty && e._1.trim.toLowerCase == "active" && e._2 != null && e._2.toLowerCase == "page")).size
    // -- number of active properties viewed before first lead
    aggval += b4pview.filter(e => (e._1 != null && !e._1.trim.isEmpty && e._1.trim.toLowerCase == "active" && e._2 != null && e._2.toLowerCase == "page")).size

    aggval
  }

  def daysAndLeads(firstleadtime: Long, leadrowssorted: Seq[Array[Any]]): ArrayBuffer[Any] = {
    import LeadScoreConstants.gagrouped._;

    val aggval = ArrayBuffer.empty[Any]

    // -- number of days since the last session  nod_lst_sess
    aggval += Days.daysBetween(new DateTime(leadrowssorted.map(_(visitstarttime).asInstanceOf[Long]).max.toLong * 1000L), new DateTime(System.currentTimeMillis)).getDays

    // -- number of days since the last property viewed  nod_lst_pv
    val dpprecs =
      leadrowssorted.filter(e => (e(dpp) != null && e(dpp) == "detail-property-page" && e(hittype) != null && e(hittype).asInstanceOf[String].toLowerCase == "page")).sortBy(_(visitstarttime).asInstanceOf[Long])

    if (dpprecs.size > 0) {
      aggval += Days.daysBetween(new DateTime(dpprecs.map(_(visitstarttime).asInstanceOf[Long]).max.toLong * 1000L), new DateTime(System.currentTimeMillis)).getDays
    } else {
      aggval += null.asInstanceOf[Int]
    }

    // -- number of days since the last active property viewed  nod_lst_apv
    val dppplrecs = dpprecs.filter(e => (e(plstatus) != null && e(plstatus).asInstanceOf[String].toLowerCase == "active"))
    if (dppplrecs.size > 0) {
      aggval += Days.daysBetween(new DateTime(dppplrecs.map(_(visitstarttime).asInstanceOf[Long]).max.toLong * 1000L), new DateTime(System.currentTimeMillis)).getDays
    } else {
      aggval += null.asInstanceOf[Int]
    }

    // -- number of days since the last page view  nod_lst_pgv
    val pgvwcountrecs = leadrowssorted.filter(e => (e(pgvwcount) != null && e(pgvwcount).asInstanceOf[Long] > 0))
    if (pgvwcountrecs.size > 0) {
      aggval += Days.daysBetween(new DateTime(pgvwcountrecs.map(_(visitstarttime).asInstanceOf[Long]).max.toLong * 1000L), new DateTime(System.currentTimeMillis)).getDays
    } else {
      aggval += null.asInstanceOf[Int]
    }

    // -- number of days between first hit on the site and first lead  noh_bhtld
    aggval += Days.daysBetween(new DateTime(leadrowssorted.map(_(visitstarttime).asInstanceOf[Long]).min.toLong * 1000L), new DateTime(firstleadtime.toLong)).getDays

    aggval
  }

  def aggDaysBetweenPropViews(leadrowssorted: Seq[Array[Any]]): ArrayBuffer[Any] = {
    import LeadScoreConstants.gagrouped._;

    val aggval = ArrayBuffer.empty[Any]

    val dpprecs = leadrowssorted
      .filter(e => (e(hittype) != null && e(hittype).asInstanceOf[String].toLowerCase == "page" && e(pgpath) != null && e(pgpath).asInstanceOf[String].trim.toLowerCase == "/Property Detail".toLowerCase))
      .map(e => toVisitTSMillis(e(visitstarttime), e(hittime))).sorted.distinct

    if (dpprecs.size > 1) {
      val numdays = dpprecs.sliding(2).map(e => Days.daysBetween(new DateTime((e(0).toLong)), new DateTime((e(1).toLong))).getDays).toSeq.sorted
      // -- minimum number of days between viewing properties	prop_timelag_day 	
      aggval += numdays.min
      // -- median number of days between property views	prop_timelag_med 	
      aggval += numdays.drop((numdays.size / 2)).head
      // -- mean number of days between property views		prop_timelag_mean
      val meandays = (numdays.sum * 1.0 / numdays.size)
      aggval += meandays
      // -- variance of the number of days between property views	prop_timelag_var
      val variancedays = (numdays.map(e => math.pow((e - meandays), 2)).sum * 1.0 / numdays.size)
      aggval += variancedays
      val stdevdays = math.sqrt(variancedays)

      // -- kurtosis of the number of days between property views	prop_timelag_kurt
      var ktssdays = null.asInstanceOf[Double]
      if (stdevdays != 0) {
        ktssdays = ((numdays.map(e => math.pow((e - meandays), 4)).sum / numdays.size) / math.pow(stdevdays, 4))
      }
      aggval += ktssdays

      // -- skew of the number of days between property views	prop_timelag_skew      
      var skewdays = null.asInstanceOf[Double]
      if (stdevdays != 0) {
        skewdays = ((numdays.map(e => math.pow((e - meandays), 3)).sum / numdays.size) / math.pow(stdevdays, 3))
      }
      aggval += skewdays

    } else {
      aggval += null.asInstanceOf[Int]
      aggval += null.asInstanceOf[Int]
      aggval += null.asInstanceOf[Double]
      aggval += null.asInstanceOf[Double]
      aggval += null.asInstanceOf[Double]
      aggval += null.asInstanceOf[Double]
    }
  }

  def aggLeadPropertyDetails(leadrowssorted: Seq[Array[Any]]): ArrayBuffer[Any] = {
    import LeadScoreConstants.gagrouped._;
    val aggval = ArrayBuffer.empty[Any]

    // -- Property Id of the house of the last hot lead (HL)
    // -- MLS Id of the house of the last hot lead (HL)
    // -- Listing Id of the house of the last hot lead (HL)
    // -- sqft of the house of the last hot lead (HL)
    // -- number of photos on the MLS for the property of the most recent HL
    // -- number of bathrooms for the most recent HL
    // -- number of bedrooms of the most recent HL
    // -- price of the most recent HL
    var lrrecs = leadrowssorted.filter(e => (e(label) != null && e(label).asInstanceOf[String].toLowerCase == "lead-received" && (e(lsid) != null || e(propid) != null)))
    if (lrrecs.isEmpty) {
      lrrecs = leadrowssorted.filter(e => (e(category) != null && e(category).asInstanceOf[String].toLowerCase == "lead"))
    }

    if (lrrecs.size > 0) {
      val maxlrrec = lrrecs.maxBy(e => (toVisitTSMillis(e(visitstarttime), e(hittime))))
      aggval += maxlrrec(propid)
      aggval += maxlrrec(mlsid)
      aggval += maxlrrec(lsid)
      aggval += maxlrrec(sqft_of_house)
      aggval += maxlrrec(no_of_photos)
      aggval += maxlrrec(no_of_bathrooms)
      aggval += maxlrrec(no_of_bedrooms)
      aggval += maxlrrec(listingprice)
    } else {
      aggval += null.asInstanceOf[String]
      aggval += null.asInstanceOf[String]
      aggval += null.asInstanceOf[String]
      aggval += null.asInstanceOf[String]
      aggval += null.asInstanceOf[String]
      aggval += null.asInstanceOf[String]
      aggval += null.asInstanceOf[String]
      aggval += null.asInstanceOf[String]
    }
    aggval
  }

  def divideFirstHL(a4: Seq[Array[Any]], b4: Seq[Array[Any]]): ArrayBuffer[Any] = {
    import LeadScoreConstants.gagrouped._;

    val aggval = ArrayBuffer.empty[Any]

    // -- number of pages viewed while logged after first HL divided by the number of pages viewed while logged off after first HL
    a4.filter(e => (e(loggedin) != null && e(loggedin).asInstanceOf[String].trim.toLowerCase == "true")).map(_(pgvwcount).asInstanceOf[Long]) match {
      case ls1 if (!ls1.isEmpty) => {
        a4.filter(e => (e(loggedin) != null && e(loggedin).asInstanceOf[String].trim.toLowerCase == "false")).map(_(pgvwcount).asInstanceOf[Long]) match {
          case ls2 if (!ls2.isEmpty && ls2.sum > 0) => aggval += (ls1.sum * 1.0 / ls2.sum)
          case _                                    => aggval += null.asInstanceOf[Double]
        }
      }
      case _ => aggval += null.asInstanceOf[Double]
    }

    // -- number of pages viewed while logged on before first HL divided by number of pages viewed while logged off before first HL
    b4.filter(e => (e(loggedin) != null && e(loggedin).asInstanceOf[String].trim.toLowerCase == "true")).map(_(pgvwcount).asInstanceOf[Long]) match {
      case ls1 if (!ls1.isEmpty) => {
        b4.filter(e => (e(loggedin) != null && e(loggedin).asInstanceOf[String].trim.toLowerCase == "false")).map(_(pgvwcount).asInstanceOf[Long]) match {
          case ls2 if (!ls2.isEmpty && ls2.sum > 0) => aggval += (ls1.sum * 1.0 / ls2.sum)
          case _                                    => aggval += null.asInstanceOf[Double]
        }
      }
      case _ => aggval += null.asInstanceOf[Double]
    }

    // -- number of sold properties viewed after first HL divided by number of active properties viewed after first HL
    a4.filter(e => (e(plstatus) != null && e(plstatus).asInstanceOf[String].trim.toLowerCase == "active")).size match {
      case x if (x > 0) => aggval += (a4.filter(e => (e(plstatus) != null && e(plstatus).asInstanceOf[String].trim.toLowerCase == "sold")).size * 1.0 / x)
      case _            => aggval += null.asInstanceOf[Double]
    }

    //-- number of sold properties viewed before first HL divided by the number of active properties viewed before first HL
    b4.filter(e => (e(plstatus) != null && e(plstatus).asInstanceOf[String].trim.toLowerCase == "active")).size match {
      case x if (x > 0) => aggval += (b4.filter(e => (e(plstatus) != null && e(plstatus).asInstanceOf[String].trim.toLowerCase == "sold")).size * 1.0 / x)
      case _            => aggval += null.asInstanceOf[Double]
    }

    aggval
  }
  
  def aggLastVisitDetails(leadrowssorted: Seq[Array[Any]]): ArrayBuffer[Any] = {
    import LeadScoreConstants.gagrouped._;

    val aggval = ArrayBuffer.empty[Any]
    aggval += new java.sql.Timestamp( (leadrowssorted.map(_(visitstarttime).asInstanceOf[Long]).max * 1000l) )
    aggval
  }
}