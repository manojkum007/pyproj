package com.movoto.webanalytics.leadscore

import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.hive.HiveContext

object LeadScoreRunner {
  
  var sc: SparkContext = null
  var sqlContext: SQLContext = null
  var hiveContext: HiveContext = null
    
  
  def runLeadScore(partlist: String, ngmaptable: String, srctable: String, desttable: String) = {
    sc = new SparkContext(new SparkConf)
    sqlContext = new SQLContext(sc)
    hiveContext = new HiveContext(sc)
    
    val leadscoreagg = new LeadScoreAggregator
    val srcdf = hiveContext.sql( leadscoreagg.getLeadScoreAggQuery(partlist, srctable) )
    val ngmapdf = hiveContext.sql( leadscoreagg.getNovaIdGAIdMapQuery(ngmaptable) )
    val ngmap = sc.broadcast( leadscoreagg.mapGAToNovaId(ngmapdf) )
    val aggrdd = leadscoreagg.aggLeadScores( srcdf, ngmap )
    val aggdf =  hiveContext.createDataFrame(aggrdd, leadscoreagg.buildSchema)
    
    hiveContext.setConf("hive.exec.dynamic.partition", "true")
    hiveContext.setConf("hive.exec.dynamic.partition.mode", "nonstrict")
    
    val reccount = 
      aggdf.write.mode("append")
    	  .insertInto(desttable);
          	
    println(s"$reccount rows written for input partitions ($partlist) from $srctable into $desttable .")
    
    
  }
  
  
  def main(args: Array[String]) {
    args.toList match {
      case partlist :: ngmaptable :: srctable :: desttable :: others => {
        try {
          runLeadScore(partlist, ngmaptable, srctable, desttable)
        } catch {
          case e: Exception => println("************** Error processing."); e.printStackTrace(); 
        } finally {
          if(sc != null) sc.stop()
        }
      }
      case _ => { 
        println("Invalid use of arguments. Usage: spark-submit ... <comma_separted_list_of_partitions> <db.table_name>"); 
        System.exit(-1);
      }
     }
  }
}