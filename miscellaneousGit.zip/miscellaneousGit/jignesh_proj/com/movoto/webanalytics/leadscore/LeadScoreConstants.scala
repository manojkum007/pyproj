package com.movoto.webanalytics.leadscore

object LeadScoreConstants {
  
 
  object gagrouped extends java.io.Serializable {
    val visitnumber = 0 
    val visitstarttime = 1 
    val strvdate = 2
    val pgvwcount = 3 
    val hittype = 4 
    val hittime = 5 
    val action = 6 
    val label = 7 
    val category = 8
    val pgpath = 9 
    val dpp = 10 
    val loggedin = 11 
    val mlsid = 12
    val lsid = 13
    val listingprice = 14 
    val no_of_photos = 15 
    val no_of_bedrooms = 16 
    val no_of_bathrooms = 17 
    val sqft_of_house = 18
    val plstatus = 19
    val pview = 20
    val propid = 21;
  }
  
  object gaselect extends java.io.Serializable {  
    val gaid = 0
    val visitnumber = 1
    val visitstarttime = 2
    val strvdate = 3
    val pgvwcount = 4
    val hittype = 5
    val hittime = 6
    val action = 7
    val label = 8
    val category = 9 
    val pgpath = 10   
    val dpp = 11
    val loggedin = 12
    val mlsid = 13
    val lsid = 14
    val listingprice = 15
    val no_of_photos = 16
    val no_of_bedrooms = 17
    val no_of_bathrooms = 18
    val sqft_of_house = 19
    val plstatus = 20
    val pview = 21
    val propid = 22
  }
  
  val selectList = List(
    ("gaid", 0, "customdimensions_index_6"),
    ("visitnumber", 1, "visitnumber"),
    ("visitstarttime", 2, "visitstarttime"),
    ("strvdate", 3, "cast(cast(from_unixtime(visitstarttime) as date) as string)"),
    ("pgvwcount", 4, "total_pageviews"),
    ("hittype", 5, "hits_type"),
    ("hittime", 6, "hits_time"),
    ("action", 7, "hits_eventinfo_eventaction"),
    ("label", 8, "hits_eventinfo_eventlabel"),
    ("category", 9, "hits_eventinfo_eventcategory"), 
    ("pgpath", 10, "hits_page_pagepath"),   
    ("dpp", 11, "hits_customdimensions_index_2"),
    ("loggedin", 12, "hits_customdimensions_index_7"),
    ("mlsid", 13, "hits_customdimensions_index_14"),
    ("lsid", 14, "hits_customdimensions_index_15"),
    ("listingprice", 15, "hits_customdimensions_index_16"),
    ("no_of_photos", 16, "hits_customdimensions_index_17"),
    ("no_of_bedrooms", 17, "hits_customdimensions_index_18"),
    ("no_of_bathrooms", 18, "hits_customdimensions_index_19"),
    ("sqft_of_house", 19, "hits_customdimensions_index_20"),
    ("plstatus", 20, "hits_customdimensions_index_23"),
    ("pview", 21, "hits_customdimensions_index_64"),
    ("propid", 22, "hits_customdimensions_index_82")
  )
  
}