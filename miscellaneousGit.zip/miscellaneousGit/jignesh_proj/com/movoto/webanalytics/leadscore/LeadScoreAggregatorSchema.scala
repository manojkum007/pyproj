package com.movoto.webanalytics.leadscore

import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.types.DoubleType
import org.apache.spark.sql.types.LongType
import org.apache.spark.sql.types.TimestampType

class LeadScoreAggregatorSchema extends SimpleAggregator {
  
  def buildSchema(): StructType = {
    StructType(Seq(
        StructField("nova_id", StringType, true),
        StructField("nos_ahtld", IntegerType, true),
        StructField("nos_bhtld", IntegerType, true),
        StructField("noss_ahtld", IntegerType, true),
        StructField("noss_bhtld", IntegerType, true),
        StructField("nofh_ahtld", IntegerType, true),
        StructField("nofh_bhtld", IntegerType, true),
        StructField("nopv_ahtld", IntegerType, true),
        StructField("nopv_bhtld", IntegerType, true),
        StructField("nodd_ahtld", IntegerType, true),
        StructField("nodd_bhtld", IntegerType, true),
        StructField("nopvw_ahtld", IntegerType, true),
        StructField("nopvw_bhtld", IntegerType, true),
        StructField("nopgv_ahtld", IntegerType, true),
        StructField("nopgv_bhtld", IntegerType, true),
        StructField("noslpv_ahtld", IntegerType, true),
        StructField("noslpv_bhtld", IntegerType, true),
        StructField("noapv_ahtld", IntegerType, true),
        StructField("noapv_bhtld", IntegerType, true),
        StructField("nod_lst_sess", IntegerType, true),
        StructField("nod_lst_pv", IntegerType, true),
        StructField("nod_lst_apv", IntegerType, true),
        StructField("nod_lst_pgv", IntegerType, true),
        StructField("noh_bhtld", IntegerType, true),
        StructField("prop_timelag_day", IntegerType, true),
        StructField("prop_timelag_med", IntegerType, true),
        StructField("prop_timelag_mean", DoubleType, true),
        StructField("prop_timelag_var", DoubleType, true),
        StructField("prop_timelag_kurt", DoubleType, true),
        StructField("prop_timelag_skew", DoubleType, true),
        StructField("propid_lst_htld", StringType, true),
        StructField("mlsid_lst_htld", StringType, true),
        StructField("lsid_lst_htld", StringType, true),
        StructField("sqft_lst_htld", StringType, true),
        StructField("nophts_lst_htld", StringType, true),
        StructField("noba_lst_htld", StringType, true),
        StructField("nobe_lst_htld", StringType, true),
        StructField("listpx_lst_htld", StringType, true),
        StructField("lipgv_per_lopgv_ahtld", DoubleType, true),
        StructField("lipgv_per_lopgv__bhtld", DoubleType, true),
        StructField("noslpv_ahtld_per_noapv_afhtld", DoubleType, true),
        StructField("noslpv_bhtld_per_noapv_bfhtld", DoubleType, true),        
        StructField("last_visit_datetime", TimestampType, true)
        ))    
  }
  
  def getLeadScoreAggQuery(dtRange: String, tableName: String): String = {
    require((dtRange != null && !dtRange.trim.isEmpty()), "Date range must be specified in format \"(20170710, 20170711)\" or specify \"all\" for whole table")
    var dtpart = s" `date` in ($dtRange) and "
    if(dtRange == "all") dtpart = ""
    val selectColumns = LeadScoreConstants.selectList.map(e=>(e._3 + " as " + e._1)).mkString(", ")
    
    s"""select distinct $selectColumns   
       from $tableName
       where $dtpart
       hits_hitnumber is not null and customdimensions_index_6 is not null"""
  }
  
  def getNovaIdGAIdMapQuery(tableName: String): String = {
    s"""select nova_id, ga_id from $tableName"""
  }
  
}