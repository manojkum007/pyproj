# scala-grok
### scala-grok was converted for scala language style from [java-grok](https://github.com/thekrakken/java-grok).

### Simple API that allows you to easily parse logs and other files http://grok.nflabs.com/  
