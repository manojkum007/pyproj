package movoto.NginxTransform

import scala.util.{Failure, Success, Try}

/**
  * Created by satyajit on 11/4/16.
  */
object MapSearchLandingPage extends App {

  def MapsearchParser(Listing_url:Option[String]):Try[mapsearchParts] = {
    try {
      val x = Listing_url.get.split("/")
      x match {
        case Array(a) => Success(mapsearchParts(Some(a), None, None, None, x.mkString("/"), a match {
          case a if a.toString.length == 2 => a
          case a: String if a.toString.contains("-") && a.toString.split("-").size>0 && a.toString.split("-")(a.toString.split("-").size - 1).size == 2 => a.toString.split("-").filter(_.size == 2)(0)
          case a if a.toString.length != 2 => "None"
        },
          a match { case tup: String if tup.toString.contains("-") && tup.toString.split("-").size > 0 && tup.toString.split("-")(tup.toString.split("-").size - 1).size == 2 => tup.toString.split("-").dropRight(1).mkString("-")
          case _ => "None"
          }
        ))
        case Array(a, b) => Success(mapsearchParts(Some(a), Some(b), None, None, x.mkString("/"), (a, b) match {
          case tup: (_, _) if tup._1.toString.length == 2 => tup._1
          case tup: (_, _) if tup._2.toString.length == 2 => tup._2
          case tup: (_, _) if tup._1.toString.contains("-") && tup._1.toString.split("-").size>0 && tup._1.toString.split("-")(tup._1.toString.split("-").size - 1).size == 2 => tup._1.toString.split("-")(tup._1.toString.split("-").size - 1).toLowerCase
          //case tup: (_, _) if tup._1.toString.length != 2 && tup._2.toString.length != 2 => "None"
          case _ => "None"
        },
          (a, b) match {
            case tup: (_, _) if tup._1.toString.contains("-") && tup._1.toString.split("-").size > 0 && tup._1.toString.split("-")(tup._1.toString.split("-").size - 1).size == 2 => tup._1.toString.split("-").dropRight(1).mkString("-")
            case _ => "None"
          }
        ))
        case Array(a, b, c) => Success(mapsearchParts(Some(a), Some(b), Some(c), None, x.mkString("/"), (a, b, c) match {
          case tup: (_, _, _) if tup._1.toString.length == 2 => tup._1
          case tup: (_, _, _) if tup._2.toString.length == 2 => tup._2
          case tup: (_, _, _) if tup._1.toString.contains("-") && tup._1.toString.split("-").size>0 && tup._1.toString.split("-")(tup._1.toString.split("-").size - 1).size == 2 => tup._1.toString.split("-")(tup._1.toString.split("-").size - 1).toLowerCase
          //case tup: (_, _, _) if tup._1.toString.length != 2 && tup._2.toString.length != 2 => "None"
          case _ => "None"
        },
          (a, b, c) match { case tup: (_, _, _) if tup._1.toString.contains("-") && tup._1.toString.split("-").size > 0 && tup._1.toString.split("-")(tup._1.toString.split("-").size - 1).size == 2 => tup._1.toString.split("-").dropRight(1).mkString("-")
          case _ => "None"
          }))
        case Array(a, b, c, d) => Success(mapsearchParts(Some(a), Some(b), Some(c), Some(d), x.mkString("/"), (a, b, c, d) match {
          case tup: (_, _, _, _) if tup._1.toString.length == 2 => tup._1
          case tup: (_, _, _, _) if tup._2.toString.length == 2 => tup._2
          case tup: (_, _, _, _) if tup._1.toString.contains("-") && tup._1.toString.split("-").size>0 && tup._1.toString.split("-")(tup._1.toString.split("-").size - 1).size == 2 => tup._1.toString.split("-")(tup._1.toString.split("-").size - 1).toLowerCase
          //case tup: (_, _, _, _) if tup._1.toString.length != 2 && tup._2.toString.length != 2 => "None"
          case _ => "None"
        },
          (a, b, c, d) match { case tup: (_, _, _, _) if tup._1.toString.contains("-") && tup._1.toString.split("-").size > 0 && tup._1.toString.split("-")(tup._1.toString.split("-").size - 1).size == 2 => tup._1.toString.split("-").dropRight(1).mkString("-")
          case _ => "None"
          }))
        case arr: Array[String] if arr.length > 4 => Success(mapsearchParts(Some(arr(0)), Some(arr(1)), Some(arr(2)), Some(arr(3)), x.mkString("/"), (arr(0), arr(1), arr(2)) match {
          case tup: (_, _, _) if tup._1.toString.length == 2 => tup._1
          case tup: (_, _, _) if tup._2.toString.length == 2 => tup._2
          case tup: (_, _, _) if tup._1.toString.contains("-") && tup._1.toString.split("-").size>0 && tup._1.toString.split("-")(tup._1.toString.split("-").size - 1).size == 2 => tup._1.toString.split("-")(tup._1.toString.split("-").size - 1).toLowerCase
          //case tup: (_, _, _) if tup._1.toString.length != 2 && tup._2.toString.length != 2 => "None"
          case _ => "None"
        },
          (arr(0), arr(1), arr(2)) match { case tup: (_, _, _) if tup._1.toString.contains("-")  && tup._1.toString.split("-").size > 0 && tup._1.toString.split("-")(tup._1.toString.split("-").size - 1).size == 2 => tup._1.toString.split("-").dropRight(1).mkString("-")
          case _ => "None"
          }))
        case _ => Success(mapsearchParts(None, None, None, None, x.mkString("/"), "None", "None"))
      }
    }
    catch {
      case e:Exception => Failure(e)
    }
  }



  def siteMapParser(Listing_url:Option[String]):Try[mapsearchParts] = {
    try {
      val x = Listing_url.get.split("/")
      x match {
        case Array(a) => Success(mapsearchParts(Some(a), None, None, None, x.mkString("/"), a match {
          case a if a.toString.length == 2 => a
          case a if a.toString.length != 2 => "None"
        }, "None"))
        case Array(a, b) => Success(mapsearchParts(Some(a), Some(b), None, None, x.mkString("/"), (a, b) match {
          case tup: (_, _) if tup._1.toString.length == 2 => tup._1
          case tup: (_, _) if tup._2.toString.length == 2 => tup._2
          case tup: (_, _) if tup._2.toString.contains("-") => tup._2.toString.split("-")(tup._2.toString.split("-").size - 1)
          case tup: (_, _) if tup._1.toString.length != 2 && tup._2.toString.length != 2 => "None"
        },
          (a, b) match {
            case tup: (_, _) if tup._2.toString.contains("-") => tup._2.toString.split("-").dropRight(1).mkString("-")
            case _ => "None"
          }
        ))
        case Array(a, b, c) => Success(mapsearchParts(Some(a), Some(b), Some(c), None, x.mkString("/"), (a, b, c) match {
          case tup: (_, _, _) if tup._1.toString.length == 2 => tup._1
          case tup: (_, _, _) if tup._2.toString.length == 2 => tup._2
          case tup: (_, _, _) if tup._3.toString.contains("-") => tup._3.toString.split("-")(tup._3.toString.split("-").size - 1)
          case tup: (_, _, _) if tup._1.toString.length != 2 && tup._2.toString.length != 2 => "None"
        },
          (a, b, c) match { case tup: (_, _, _) if tup._3.toString.contains("-") => tup._3.toString.split("-").dropRight(1).mkString("-")
          case _ => "None"
          }))
        case Array(a, b, c, d) => Success(mapsearchParts(Some(a), Some(b), Some(c), Some(d), x.mkString("/"), (a, b, c, d) match {
          case tup: (_, _, _, _) if tup._1.toString.length == 2 => tup._1
          case tup: (_, _, _, _) if tup._2.toString.length == 2 => tup._2
          case tup: (_, _, _, _) if tup._3.toString.contains("-") => tup._3.toString.split("-")(tup._3.toString.split("-").size - 1)
          case tup: (_, _, _, _) if tup._1.toString.length != 2 && tup._2.toString.length != 2 => "None"
        },
          (a, b, c, d) match { case tup: (_, _, _, _) if tup._3.toString.contains("-") => tup._3.toString.split("-").dropRight(1).mkString("-")
          case _ => "None"
          }))
        case arr: Array[String] if arr.length > 4 => Success(mapsearchParts(Some(arr(0)), Some(arr(1)), Some(arr(2)), Some(arr(3)), x.mkString("/"), (arr(0), arr(1), arr(2)) match {
          case tup: (_, _, _) if tup._1.toString.length == 2 => tup._1
          case tup: (_, _, _) if tup._2.toString.length == 2 => tup._2
          case tup: (_, _, _) if tup._3.toString.contains("-") => tup._3.toString.split("-")(tup._3.toString.split("-").size - 1)
          case tup: (_, _, _) if tup._1.toString.length != 2 && tup._2.toString.length != 2 => "None"
        },
          (arr(0), arr(1), arr(2)) match { case tup: (_, _, _) if tup._3.toString.contains("-") => tup._3.toString.split("-").dropRight(1).mkString("-")
          case _ => "None"
          }))
        case _ => Success(mapsearchParts(None, None, None, None, x.mkString("/"), "None", "None"))
      }
    }
    catch{
      case e:Exception => Failure(e)
    }
  }


  /*

  Possible sitemaps types

  1. /sitemap/home-values/city-state/zipcode
  2. /sitemap/state/......
  3. /property-search


   */

}


case class mapsearchParts(first1: Option[String], second1: Option[String], third1: Option[String], Fourth1: Option[String], listing_url: String, state: String, city: String)
