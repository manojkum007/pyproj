package movoto.NginxTransform

import java.sql.Timestamp
import java.text.SimpleDateFormat
import java.util.Calendar

import com.movoto.Grok.GrokParseRegex
import com.movoto.NginxAccesLogParser.{AccessLogParser, AccessLogRecord, AccessLogUpstreamRecord, NodeLogRecord}
import com.movoto.ua.parser.{Parser, UserAgent}
import org.apache.spark.sql.types.{StringType, StructField, StructType, TimestampType}
import org.apache.spark.sql.{Row, SQLContext}
import org.apache.spark.storage.StorageLevel
import org.apache.spark.{SparkConf, SparkContext}

import scala.util.Success



/**
  * Created by satyajit on 4/11/16.
  */
object NginxTransform {

  def main(args: Array[String]): Unit = {
    args.toList match {
      case directoryPath :: destinationPath :: run_date :: pathToGeoNew :: pathToGrokPatterns :: extraArgs =>

        val sparkConf = new SparkConf().
          setAppName("NginxTransform")
          //.setMaster("local[5]")

        sparkConf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
        sparkConf.registerKryoClasses(Array(classOf[AccessLogParser], classOf[AccessLogRecord] ,classOf[AccessLogUpstreamRecord],classOf[NodeLogRecord],classOf[Parser],classOf[UserAgent]))

        val sc = new SparkContext(sparkConf)
        val sqlContext = new SQLContext(sc)

        sqlContext.setConf("spark.sql.parquet.binaryAsString", "true")

        val NginxFileRead = sc.textFile(directoryPath)//.repartition(sc.defaultParallelism * 6)
        val parser = new AccessLogParser
        val Movoto = "Movoto"
        val Others = "Others"

        def cleanData(data: Any): Option[String] = data match {
          case data: String => Some(data)
          case data: Option[String] => data
          case _ => Some("None")
        }

        def createTimestamp(DateFormat: String): Timestamp = {
          val cleanDate = DateFormat.replaceAll("\\[", "").replaceAll("\\]", "")
          val format = new SimpleDateFormat("dd/MMM/yyyy:HH:mm:ss +SSSS")
          val parsedDate: java.util.Date = format.parse(cleanDate)
          val timeStamp = new Timestamp(parsedDate.getTime)
          return timeStamp
        }


        def parseReferrerPageid(urlLink: Option[String]): Any = {
          if (urlLink == None) {
            None
          } else {
            val url = urlLink.get
            if (url startsWith "http") {
              val domain = if (url.split("/").size >= 3) {
                url.split("/")(2)
              }
              else {
                try {
                  url.split("/")(1)
                }
                catch {
                  case i: Exception => url.split("/")(0)
                }
              }
              if (domain contains "www.movoto.com") {
                val homeOrMovoto = url.split(domain).size
                if (homeOrMovoto > 1) {
                  GrokParseRegex.getMatchpage_id(if (url.split("m.movoto.com").length>1) url.split("m.movoto.com")(1) else "None", Movoto, pathToGrokPatterns)
                } else {
                  GrokParseRegex.getMatchpage_id(domain, Others, pathToGrokPatterns)
                }
              }
              else {
                GrokParseRegex.getMatchpage_id(domain, Others, pathToGrokPatterns)
              }
            }
            else {
              if (url contains "m.movoto") {
                GrokParseRegex.getMatchpage_id(url.split("m.movoto.com")(1), Movoto, pathToGrokPatterns)
              } else {
                GrokParseRegex.getMatchpage_id(url, Others, pathToGrokPatterns)
              }
            }
          }
        }

        val nginxUpstreamSchemaString = "clientIpAddress,rfc1413ClientIdentity,remote_user,dateTime,request,httpStatusCode,bytesSent,referrer,referrer_pageid,device,OS_family,OS_major,OS_minor,OS_patch,userAgent_family,userAgent_major,userAgent_minor,userAgent_patch,raw_record,accessTime,userAgent,page_id,listing_url,upstreamSep,requestTime,upstreamHeaderTime,upstreamResponseTime,HTTPverb,first,second,third,fourth,urllisting,state,city,nhood,zipcode,geotype"

        val schema =
          StructType(
            nginxUpstreamSchemaString.split(",").map(fieldName => {
              if (fieldName == "accessTime") {
                StructField(fieldName, TimestampType, true)
              } else {
                StructField(fieldName, StringType, true)
              }
            }))




        val format = new java.text.SimpleDateFormat("yyyy-MM-dd")
        val currentDayDate = format.parse(run_date)
        val currentDay = format.format(currentDayDate)
        val cal = Calendar.getInstance();
        cal.setTime(currentDayDate)
        cal.add(Calendar.DATE, -1)
        val yesterDay = format.format(cal.getTime())


        val invalidRecord = NginxFileRead.filter(line => {
          (parser.parseUpstreamRecord(line.toString) == None)
        })
        invalidRecord.saveAsTextFile(destinationPath + "/" + "invalidRecord-" + currentDay)
        invalidRecord.unpersist()

        val validRecord = NginxFileRead.filter(line => {
          (parser.parseUpstreamRecord(line.toString) != None)
        }).repartition(100).persist(StorageLevel.MEMORY_AND_DISK_SER)

        val geonew = sc.broadcast(sqlContext.read.parquet(pathToGeoNew).select("type","nameforurl").filter("type in ('N_NEIGHBORHOOD','S_NEIGHBORHOOD','M_NEIGHBORHOOD','R_NEIGHBORHOOD')").collect().map(x => geonew_case(x(0).toString,x(1).toString)))
        val geonew_zipcode = sc.broadcast(sqlContext.read.parquet(pathToGeoNew).select("type","nameforurl").filter("type in ('POSTAL_CODE')").collect().map(x => zipcode_case(x(0).toString,x(1).toString)))

        def processmapSearch(ListingUrl:String,pageId:String)= {

          val mapSearchLanding:mapsearchParts = (ListingUrl,pageId) match {
            case tup: (String, String) if tup._2 == "sitemap" => MapSearchLandingPage.siteMapParser(Some(tup._1)).get
            case tup: (String, String) if (tup._2.toString.startsWith("mapsearch") || tup._2.toString=="None") => MapSearchLandingPage.MapsearchParser(Some(tup._1)).get
            case _ => Success(mapsearchParts(None, None, None, None, ListingUrl.toString, "None", "None")).get
          }


          val geonewNeighbor:Option[String] = geonew.value exists(x => x.nameforurl== (if (mapSearchLanding.second1==None) "None" else mapSearchLanding.second1.get)) match {
            case bool:Boolean if bool==true =>  mapSearchLanding.second1
            case bool:Boolean if bool==false => None
            case _ => None
          }


          val geonewZip:Option[String] = geonew_zipcode.value exists(x => x.nameforurl==(if (mapSearchLanding.second1==None) "None" else mapSearchLanding.second1.get)) match {
            case bool:Boolean if bool==true =>  mapSearchLanding.second1
            case bool:Boolean if bool==false => None
            case _ => None
          }


          val geoType:Option[String] = (geonewNeighbor,mapSearchLanding.city,mapSearchLanding.state,geonewZip) match {
            case tup if (tup._4!=None && tup._4!="None") => Some("zipcode")
            case tup if (tup._1!=None && tup._1!="None")=> Some("nhood")
            case tup if (tup._2!=None && tup._2!="None") && (tup._1==None || tup._1=="None") && (tup._4==None || tup._4=="None")=> Some("city")
            case tup if (tup._3!=None && tup._3!="None") && List("ak","al","ar","az","ca","co","ct","dc","de","fl","ga","hi","ia","id","il","in","ks",
              "ky","la","ma","md","me","mi","mn","mo","ms","mt","nc","nd","ne","nh","nj","nm","nv",
              "ny","oh","ok","or","pa","ri","sc","sd","tn","tx","ut","va","vt","wa","wi","wv","wy").contains(tup._3)
              && (mapSearchLanding.city==None || mapSearchLanding.city=="None") && (geonewZip==None || geonewZip=="None")
              && (geonewNeighbor==None || geonewNeighbor=="None") => Some("state")
            case _ => None
          }
          (mapSearchLanding.first1,mapSearchLanding.second1,mapSearchLanding.third1,mapSearchLanding.Fourth1,mapSearchLanding.listing_url,mapSearchLanding.state,mapSearchLanding.city,geonewNeighbor,geonewZip,geoType)
        }

        val dataRDD =
          validRecord.map(row => {
            val accessLogRecord = parser.parseUpstreamRecord(row.toString)
            val userAg = accessLogRecord.map(r => r.userAgent)
            val ua = userAg.get
            val client = Parser.get.parse(ua.toString)
            val url_listing = cleanData(if (accessLogRecord.map(row => row.request).toString.isEmpty) {
              "None"
            } else if (accessLogRecord.map(row => row.request).toString contains " ") {
              accessLogRecord.map(row => row.request).toString.split(" ")(1).replaceFirst("/", "")
            } else {
              "None"
            })
            val pageId = cleanData(GrokParseRegex.getMatchpage_id(if (accessLogRecord.map(row => row.request).toString.isEmpty || accessLogRecord.map(row => row.request) == None) {
              "None"
            } else if (accessLogRecord.map(row => row.request).toString.trim contains " ") {
              accessLogRecord.map(row => row.request).toString.trim.split(" ")(1)
            } else {
              "None"
            }, Movoto, pathToGrokPatterns))

            val (first,second,third,fourth,urlisting,state,city,nhood,zipcode,geoType) = processmapSearch(url_listing.get.toString,pageId.get.toString)
            Row(cleanData(accessLogRecord.map(row => row.clientIpAddress)),
              cleanData(accessLogRecord.map(row => row.rfc1413ClientIdentity)),
              cleanData(accessLogRecord.map(row => row.remoteUser)),
              cleanData(accessLogRecord.map(row => row.dateTime)),
              cleanData(accessLogRecord.map(row => row.request)),
              cleanData(accessLogRecord.map(row => row.httpStatusCode)),
              cleanData(accessLogRecord.map(row => row.bytesSent)),
              cleanData(accessLogRecord.map(row => row.referer)),
              cleanData(parseReferrerPageid(accessLogRecord.map(row => row.referer))),
              cleanData(client.device.family),
              cleanData(client.os.family),
              cleanData(client.os.major),
              cleanData(client.os.minor),
              cleanData(client.os.patch),
              cleanData(client.userAgent.family),
              cleanData(client.userAgent.major),
              cleanData(client.userAgent.minor),
              cleanData(client.userAgent.patch),
              cleanData(row.toString),
              createTimestamp(accessLogRecord.map(row => row.dateTime).get.toString),
              cleanData(if (row.toString.toLowerCase.contains("GoogleBot".toLowerCase) && accessLogRecord.map(row => row.clientIpAddress).get.toString.startsWith("66.")) {
                "googlebotip"
              }
              else if (row.toString.toLowerCase.contains("GoogleBot".toLowerCase)) {
                "googlebot"
              } else {
                cleanData(client.userAgent.family)
              }),
              pageId,
              url_listing
              , cleanData(accessLogRecord.map(row => row.upstreamSep)),
              cleanData(accessLogRecord.map(row => row.requesttime)),
              cleanData(accessLogRecord.map(row => row.upstreamHeaderTime)),
              cleanData(accessLogRecord.map(row => row.upstreamReponseTime)),
              cleanData(accessLogRecord.map(row => if (row.request.toString contains " ") row.request.toString.split(" ")(0) else "None")),
              cleanData(first),
              cleanData(second),
              cleanData(third),
              cleanData(fourth),
              cleanData(urlisting),
              cleanData(state),
              cleanData(city),
              cleanData(nhood),
              cleanData(zipcode),
              cleanData(geoType)
            )
          }).persist(StorageLevel.MEMORY_AND_DISK_SER)


        val NginxDF = sqlContext.createDataFrame(dataRDD, schema)


        val dataYest = NginxDF.filter(NginxDF("accessTime").lt(currentDay))
        val dataToday = NginxDF.filter(NginxDF("accessTime").geq(currentDay))

        //NginxDF.write.parquet(destinationPath + "/" + "ParquetOutput/")

        dataYest.write.parquet(destinationPath + "/" + yesterDay.toString)
        dataToday.write.parquet(destinationPath + "/" + currentDay.toString)

      case _ =>
        System.err.println("Usage:NginxTranform  <directoryPath> <destinationPath>")
        System.exit(-1)
    }

  }


}

case class geonew_case(`type`:String,nameforurl:String)
case class zipcode_case(`type`:String,nameforurl:String)
