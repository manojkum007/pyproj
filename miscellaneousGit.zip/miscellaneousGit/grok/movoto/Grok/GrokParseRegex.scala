package movoto.Grok

import oi.thekraken.grok.api.Grok

/**
  * Created by satyajit on 4/19/16.
  */
object GrokParseRegex extends App{

  def getMatchpage_id(req:String,urlType:String,pathToGrokPattern:String):Any= {
    print(pathToGrokPattern)
    if (req == "/") {
      return "home"
    }
    else {
      val grok: Grok = Grok.create(pathToGrokPattern);
      //val grok: Grok = Grok.create("/home/satyajit/avm/Nginx/src/main/resources/patterns.txt");
      val list = if (urlType == "Movoto") List( "TOOLS" , "SCHOOLS" , "SELL"  ,"AGENT" , "AGENTMOBILE" , "MORTGAGES" , "CITYHUB" , "BLOG" , "TEMPLATE" , "API" , "WEBSERVICES" , "ACTIVATION"  , "NO_RESULT_PAGE"  , "MY_NOTES"  , "SEARCH"  , "LIST_VIEW"  , "IMAGE_VIEW"  , "FAVORITES"  , "SAVED_SEARCHES"  , "FORGOT_PASSWORD"  , "SIGNUP"  , "LOGOUT"  , "LOGIN"  , "HL_FORM" , "EMAIL_TO_FRIEND", "DPP_MAP", "TERMS_N_CONDITIONS", "AWESOME_HOMES", "NEARBY_SCHOOLS", "THANK_YOU", "ALL_PHOTOS", "DSP", "ABOUT", "DPP", "HTMLNONE","SITEMAP","SCHOOLDISTRICT","SEARCHNONE", "HOMEVALUES" , "PROPERTYNONE", "MAPSEARCHOPENHOUSE" ,"MAPSEARCHFORECLOSED" ,"MAPSEARCHCONDOS" ,"MAPSEARCHMULTIFAMILY" ,"MAPSEARCHSINGLEFAMILY" ,"MAPSEARCHREDUCED30" ,"MAPSEARCHLUXURYHOMES","MAPSEARCHNEW7" ,"MAPSEARCHSOLD" ,"MAPSEARCHPRICE", "MAPSEARCHBED", "MAPSEARCHSTATUS"  ,"MAPSEARCHSQFT" ,"MARKETTRENDS" , "DEMOGRAPHICS","ESPANOL","MAPSEARCH" ) else List("HOME","ANDROID","GOOGLE","BING","YAHOO","BAIDU","FACEBOOK","PINTEREST","REDDIT")
      val data = list.map(x => {
        grok.compile("%{" + x + "}")
        val gm: Match = grok.`match`(req)
        gm.captures();
        val page_id = gm.toMap.keySet()
        page_id
      })
      val value = data.filter(x => !(x.isEmpty))
      val ret = if (value.isEmpty) "None" else
      {
        if (value(0).toString isEmpty) None else value(0).toString.replace("[", "").dropRight(1).toLowerCase
      }
      ret
    }
  }
}
