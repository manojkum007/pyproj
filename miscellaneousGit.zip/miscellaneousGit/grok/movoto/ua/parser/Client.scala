package movoto.ua.parser

case class Client(userAgent: UserAgent, os: OS, device: Device)
