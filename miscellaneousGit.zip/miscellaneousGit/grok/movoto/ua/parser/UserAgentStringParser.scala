package movoto.ua.parser

trait UserAgentStringParser {
  def parse(agent: String): Client
}
