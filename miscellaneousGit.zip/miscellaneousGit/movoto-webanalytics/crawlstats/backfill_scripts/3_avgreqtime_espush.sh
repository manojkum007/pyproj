#!/bin/bash

export tablepath="/user/hive/warehouse/access_logs.db/avgreqtime_crawlstats/"
export destpath="none"
export dateofrun="2017-09-03"
export currentdate=$dateofrun
export sevendaydate=$(date -d "$currentdate 7 days ago" +"%Y-%m-%d")
export index="accesslogs"
export indextype="avgreqtime"
export query="SELECT CASE WHEN pagetype=\"dpp\" THEN CONCAT(UPPER(pagetype),\"_\",status) WHEN pagetype LIKE '%mapsearch%' THEN \"MAPSEARCH\"  WHEN pagetype=\"home\" THEN UPPER(pagetype) END AS pagetype,  mls_id,state,(requesttime*1000) AS requesttime,dom_range,CASE WHEN (raw_record LIKE '%Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)%' OR raw_record LIKE '%Googlebot/2.1 (+http://www.google.com/bot.html)%') THEN \"DESKTOP\" WHEN raw_record LIKE '%Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.96 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)%' THEN \"MOBILE\" ELSE \"OTHERS\" END AS google_user_agent,CONCAT(CONCAT(SPLIT(CAST(from_unixtime((unix_timestamp(CAST(CAST(crawledon AS timestamp) AS string))+ (3600 * 8)), 'yyyy-MM-dd HH:mm:SS') AS string) ,\" \")[0],'T',SPLIT(CAST(from_unixtime((unix_timestamp(CAST(CAST(crawledon AS timestamp) AS string)) + (3600 * 8)), 'yyyy-MM-dd HH:mm:SS') AS string),\" \")[1]),'.000Z') AS \`@timestamp\` FROM data"
export configpath="/opt/NginNodeLogsParser/conf/Es.config"
export partitioncol="day"

curl -XGET "192.168.120.136:9200/$index/$indextype/_search?pretty" \
 -H "Content-Type: application/json" \
 -d "{\"query\" : {\"query_string\" : { \"query\": \"@timestamp: $currentdate\" }}}"

echo -e "Parameters: \n $tablepath \n $destpath \n $dateofrun \n $index \n $indextype \n $query \n $configpath \n $partitioncol \n"

#echo "Wish to proceed[y/n]?"
#read proceedyn
#if [ "$proceedyn" != "y" ]; then
#    echo "Exiting."
#    exit -1
#fi

curl -XPOST "192.168.120.136:9200/$index/$indextype/_delete_by_query" \
 -H "Content-Type: application/json" \
 -d "{\"query\" : {\"query_string\" : { \"query\": \"@timestamp: $currentdate\" }}}"

spark-submit --name EsDataPushAvgReqTime --class com.movoto.chimpanzeeES \
 --master yarn \
 --num-executors 20 \
 --executor-memory 4g \
 --executor-cores 1 \
 --driver-memory 7g \
 --driver-cores 4 \
  --queue low \
 /opt/NginNodeLogsParser/scala/Nginx/AccLogsESPush/target/AccLogsESPush-1.0-SNAPSHOT-jar-with-dependencies.jar \
 "$tablepath" \
 "$destpath" \
 "$dateofrun" \
 "$index" \
 "$indextype" \
 "$query" \
 "$configpath" \
 "$partitioncol" 
 
 echo "Done."
 