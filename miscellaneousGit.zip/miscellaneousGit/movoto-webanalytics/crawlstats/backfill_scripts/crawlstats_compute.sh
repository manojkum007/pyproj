#!/bin/bash

export access_logs="access_logs_tmp"
export mls="access_logs_tmp"
export rundate="2017-09-05"
export sevendaydate=$(date -d "$rundate 6 days ago" +"%Y-%m-%d")

echo -e "Parameters: $access_logs \n $mls \n $rundate \n $sevendaydate \n"

#spark-sql --master yarn \
# --num-executors 63 \
# --executor-memory 5g \
# --driver-memory 6g \
# --hivevar access_logs=$access_logs \
# --hivevar mls=$mls \
# --hivevar rundate=$rundate \
# --hivevar sevendaydate=$sevendaydate \
# -f ./crawlstats_compute.hql

hive --hivevar access_logs=$access_logs --hivevar mls=$mls --hivevar rundate=$rundate --hivevar sevendaydate=$sevendaydate -f ./crawlstats_compute.hql

echo "Done."
