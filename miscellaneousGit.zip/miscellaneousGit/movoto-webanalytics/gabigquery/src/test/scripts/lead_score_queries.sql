
-- number of sessions after first lead
select  t1.customdimensions_index_6 ,count(distinct t1.visitnumber) 
from 
 webanalytics.sessions_hits_newschema t1
 join 
 (select customdimensions_index_6, visitstarttime 
  from 
   webanalytics.sessions_hits_newschema 
  where 
    `date` ='20170710' AND hits_eventInfo_eventAction='first_hotlead' and customdimensions_index_6 is not null  group by customdimensions_index_6, visitstarttime
 ) t2
where 
 t1.visitstarttime > t2.visitstarttime 
 and t1.customdimensions_index_6=t2.customdimensions_index_6 and  t1.customdimensions_index_6 is not null 
group by t1.customdimensions_index_6;

-- number of sessions before first lead
select  t1.customdimensions_index_6 ,count(distinct t1.visitnumber) 
from 
 webanalytics.sessions_hits_newschema t1
 join 
 (select customdimensions_index_6, visitstarttime 
  from 
   webanalytics.sessions_hits_newschema 
  where 
   `date` ='20170710' and hits_eventInfo_eventAction='first_hotlead' and customdimensions_index_6 is not NULL
  group by customdimensions_index_6, visitstarttime
 ) t2
where 
 t1.visitstarttime  < t2.visitstarttime and `date` ='20170710' and t1.customdimensions_index_6=t2.customdimensions_index_6 and  t1.customdimensions_index_6 is not null 
group by t1.customdimensions_index_6;

-- number of saved searches after first lead
select t1.customdimensions_index_6 ,count(distinct t1.visitnumber) 
from 
 webanalytics.sessions_hits_newschema t1
 join 
 (select customdimensions_index_6, visitstarttime 
  from 
   webanalytics.sessions_hits_newschema 
  where 
   `date` ='20170710' and hits_eventInfo_eventAction='first_hotlead' and customdimensions_index_6 is not null 
  group by customdimensions_index_6, visitstarttime
 ) t2
where 
 t1.visitstarttime  >t2.visitstarttime and  `date` ='20170710' and t1.customdimensions_index_6=t2.customdimensions_index_6 
 and t1.customdimensions_index_6 is not null  
 and  hits_eventInfo_eventLabel = 'save-search' 
group by t1.customdimensions_index_6;

-- number of saved searches before first lead
select  t1.customdimensions_index_6 ,count(distinct t1.visitnumber) 
from 
 webanalytics.sessions_hits_newschema t1
 join 
 (select customdimensions_index_6, visitstarttime 
  from 
   webanalytics.sessions_hits_newschema 
  where 
   `date` ='20170710' and hits_eventInfo_eventAction='first_hotlead' and customdimensions_index_6 is not null 
  group by customdimensions_index_6, visitstarttime
 ) t2
where 
 t1.visitstarttime < t2.visitstarttime and `date` ='20170710'  and t1.customdimensions_index_6=t2.customdimensions_index_6 
 and  t1.customdimensions_index_6 is not null 
 and  hits_eventInfo_eventLabel = 'save-search'
group by t1.customdimensions_index_6;

-- number of favorited homes after first lead
select  t1.customdimensions_index_6 ,count(distinct t1.visitnumber) 
from 
 webanalytics.sessions_hits_newschema t1
 join 
 (select customdimensions_index_6, visitstarttime 
 from 
  webanalytics.sessions_hits_newschema 
 where 
  `date` ='20170710' and hits_eventInfo_eventAction='first_hotlead' and customdimensions_index_6 is not null 
 group by customdimensions_index_6, visitstarttime
 ) t2
where 
 t1.visitstarttime  >t2.visitstarttime and `date` ='20170710' and t1.customdimensions_index_6=t2.customdimensions_index_6 
 and t1.customdimensions_index_6 is not null  
 and  hits_eventInfo_eventLabel = 'favorite-home'
group by t1.customdimensions_index_6;

-- number of favorited homes before first lead
select  t1.customdimensions_index_6 ,count(distinct t1.visitnumber) 
from 
 webanalytics.sessions_hits_newschema t1
 join 
 (select customdimensions_index_6, visitstarttime 
  from 
   webanalytics.sessions_hits_newschema 
  where 
   `date` ='20170710' and hits_eventInfo_eventAction='first_hotlead' and customdimensions_index_6 is not NULL 
  group by customdimensions_index_6, visitstarttime
 ) t2
where 
 t1.visitstarttime  <t2.visitstarttime and `date` ='20170710'  and t1.customdimensions_index_6=t2.customdimensions_index_6 
 and  t1.customdimensions_index_6 is not null 
 and  hits_eventInfo_eventLabel = 'favorite-home' 
group by t1.customdimensions_index_6;

-- number of properties viewed after first lead
select  t1.customdimensions_index_6 , count(t1.hits_customdimensions_index_64) from webanalytics.sessions_hits_newschema t1
join 
(select customdimensions_index_6, visitstarttime from webanalytics.sessions_hits_newschema 
 where `date` ='20170710' and hits_eventInfo_eventAction='first_hotlead' and customdimensions_index_6 is not null 
 group by customdimensions_index_6, visitstarttime
) t2
where t1.visitstarttime  >t2.visitstarttime  and t1.customdimensions_index_6=t2.customdimensions_index_6 AND
hits_customdimensions_index_2='detail-property-page' group by t1.customdimensions_index_6;

-- number of properties viewed before first lead
select t1.customdimensions_index_6 , count(t1.hits_customdimensions_index_64) from webanalytics.sessions_hits_newschema t1
join 
(select customdimensions_index_6, visitstarttime from webanalytics.sessions_hits_newschema 
 where `date` ='20170710' and hits_eventInfo_eventAction='first_hotlead' and customdimensions_index_6 is not null 
 group by customdimensions_index_6, visitstarttime
) t2
where t1.visitstarttime  <t2.visitstarttime  and t1.customdimensions_index_6=t2.customdimensions_index_6 
 and hits_customdimensions_index_2='detail-property-page' group by t1.customdimensions_index_6;

 
 -- number of distinct days visiting the site after first lead
select t1.customdimensions_index_6 , count(DISTINCT t1.`date`)  from webanalytics.sessions_hits_newschema t1
join (select customdimensions_index_6, visitstarttime from webanalytics.sessions_hits_newschema 
 where `date` ='20170710' and hits_eventInfo_eventAction='first_hotlead' and customdimensions_index_6 is not null 
 group by customdimensions_index_6, visitstarttime
) t2
where `date` ='20170710' and t1.customdimensions_index_6=t2.customdimensions_index_6 and t1.visitstarttime  > t2.visitstarttime  
group  by t1.customdimensions_index_6 ,t1.`date`;

-- number of distinct days visiting the site before first lead
select  t1.customdimensions_index_6 , count(DISTINCT t1.`date`)  from webanalytics.sessions_hits_newschema t1
join (select customdimensions_index_6, visitstarttime from webanalytics.sessions_hits_newschema 
 where `date` ='20170710' and hits_eventInfo_eventAction='first_hotlead' and customdimensions_index_6 is not null 
 group by customdimensions_index_6, visitstarttime
) t2
where  t1.customdimensions_index_6=t2.customdimensions_index_6  and t1.visitstarttime  < t2.visitstarttime 
 group  by t1.customdimensions_index_6 ,t1.`date`;
 
-- number of pages seen while logged in after first lead 
select t1.customdimensions_index_6 , count(t1.hits_customdimensions_index_64) from webanalytics.sessions_hits_newschema t1
join (select customdimensions_index_6, visitstarttime , hits_time from webanalytics.sessions_hits_newschema
where `date` ='20170710' and hits_eventInfo_eventAction='first_hotlead' and customdimensions_index_6 is not null group by customdimensions_index_6, visitstarttime,hits_time
) t2
where t1.visitstarttime =t2.visitstarttime and t1.customdimensions_index_6=t2.customdimensions_index_6 and t1.hits_customdimensions_index_64 is not NULL
and t1.hits_time>t2.hits_time and hits_customdimensions_index_7='true' group by t1.customdimensions_index_6 ;

-- number of pages seen while logged in before first lead
select  t1.customdimensions_index_6 , count(t1.hits_customdimensions_index_64) from webanalytics.sessions_hits_newschema t1
join (select customdimensions_index_6, visitstarttime , hits_time from webanalytics.sessions_hits_newschema 
where `date` ='20170710' and hits_eventInfo_eventAction='first_hotlead' and customdimensions_index_6 is not null  group by customdimensions_index_6, visitstarttime,hits_time
) t2
where t1.visitstarttime  =t2.visitstarttime and t1.customdimensions_index_6=t2.customdimensions_index_6 and t1.hits_customdimensions_index_64 is not null 
and t1.hits_time<t2.hits_time and hits_customdimensions_index_7='true'  group  by t1.customdimensions_index_6;

-- number of photo pages seen after first lead
select  t1.customdimensions_index_6 ,t1.hits_customdimensions_index_17 from webanalytics.sessions_hits_newschema t1
join (select customdimensions_index_6, visitstarttime from webanalytics.sessions_hits_newschema 
where `date` ='20170604' and hits_eventInfo_eventAction='first_hotlead' and customdimensions_index_6 is not null  group by customdimensions_index_6, visitstarttime
) t2
where t1.visitstarttime  >t2.visitstarttime and  `date` ='20170604'  and t1.customdimensions_index_6=t2.customdimensions_index_6 
and  t1.hits_page_pagepath=/Property Detail - AllPhotos  
group by t1.customdimensions_index_6 ,t1.hits_customdimensions_index_17

-- number of photo pages viewed before first lead
select  t1.customdimensions_index_6 ,t1.hits_customdimensions_index_17 from webanalytics.sessions_hits_newschema t1
join (select customdimensions_index_6, visitstarttime from webanalytics.sessions_hits_newschema 
where `date` ='20170604' and hits_eventInfo_eventAction='first_hotlead' and customdimensions_index_6 is not null  group by customdimensions_index_6, visitstarttime
) t2
where t1.visitstarttime  <t2.visitstarttime and  `date` ='20170604'  and t1.customdimensions_index_6=t2.customdimensions_index_6 and 
t1.hits_page_pagepath=/Property Detail - AllPhotos 
group by t1.customdimensions_index_6 ,t1.hits_customdimensions_index_17

-- number of sold properties viewed after first lead
select  t1.customdimensions_index_6 ,count(t1.hits_customdimensions_index_23) from webanalytics.sessions_hits_newschema t1
join (select customdimensions_index_6, visitstarttime from webanalytics.sessions_hits_newschema 
 where `date` ='20170710' and hits_eventInfo_eventAction='first_hotlead' and customdimensions_index_6 is not null  group by customdimensions_index_6, visitstarttime
) t2
where 
t1.visitstarttime  >t2.visitstarttime and  `date` ='20170710'  and t1.customdimensions_index_6=t2.customdimensions_index_6 
and t1.hits_customdimensions_index_23='SOLD'   group by t1.customdimensions_index_6; 

-- number of sold properties viewed before first lead
select  t1.customdimensions_index_6 ,count(t1.hits_customdimensions_index_23) from webanalytics.sessions_hits_newschema t1
join (select customdimensions_index_6, visitstarttime from webanalytics.sessions_hits_newschema 
where `date` ='20170710' and hits_eventInfo_eventAction='first_hotlead' and customdimensions_index_6 is not null  group by customdimensions_index_6, visitstarttime
) t2
where t1.visitstarttime  <t2.visitstarttime and  `date` ='20170710'  and t1.customdimensions_index_6=t2.customdimensions_index_6 
and  t1.hits_customdimensions_index_23='SOLD' group by t1.customdimensions_index_6;

-- number of active properties viewed after first lead
select distinct  t1.customdimensions_index_6 ,t1.hits_customdimensions_index_23  from webanalytics.sessions_hits_newschema t1
join (select customdimensions_index_6, visitstarttime from webanalytics.sessions_hits_newschema 
where `date` ='20170604' and hits_eventInfo_eventAction='first_hotlead' and customdimensions_index_6 is not null  group by customdimensions_index_6, visitstarttime
) t2
where t1.visitstarttime  >t2.visitstarttime and  `date` ='20170604'  and t1.customdimensions_index_6=t2.customdimensions_index_6 
AND t1.hits_customdimensions_index_23='ACTIVE';

-- number of active properties viewed before first lead
select  distinct t1.customdimensions_index_6 , t1.hits_customdimensions_index_23  from webanalytics.sessions_hits_newschema t1
join (select customdimensions_index_6, visitstarttime from webanalytics.sessions_hits_newschema 
where `date` ='20170604' and hits_eventInfo_eventAction='first_hotlead' and customdimensions_index_6 is not null  group by customdimensions_index_6, visitstarttime
) t2
where t1.visitstarttime  <t2.visitstarttime and `date` ='20170710' and t1.customdimensions_index_6=t2.customdimensions_index_6 
 and t1.hits_customdimensions_index_23='ACTIVE';
 
-- number of days since the last session
select customdimensions_index_6, DATEDIFF(current_timestamp(),cast(from_unixtime( max(visitstarttime) ) as timestamp)) 
from webanalytics.sessions_hits_newschema 
where `date` ='20170710' AND customdimensions_index_6 is not null 
group by customdimensions_index_6;

-- number of days since the last property viewed
select  customdimensions_index_6, DATEDIFF(cast(current_date() as timestamp), from_unixtime(unix_timestamp(max(`date`))))  from 
webanalytics.sessions_hits_newschema 
where customdimensions_index_6 is not null  and  hits_customdimensions_index_2='detail-property-page'  group by customdimensions_index_6;

-- number of days since the last active property viewed
select  customdimensions_index_6, DATEDIFF(cast(current_date() as timestamp), from_unixtime(unix_timestamp(max(`date`) ,'yyyyMMdd'), 'yyyy-MM-dd'))  from 
webanalytics.sessions_hits_newschema 
where customdimensions_index_6 is not null  and  hits_customdimensions_index_2='detail-property-page' and  hits_customdimensions_index_23='ACTIVE'   group by customdimensions_index_6 limit 20;

-- number of days since the last page view
select  customdimensions_index_6, DATEDIFF(cast(current_date() as timestamp), from_unixtime(unix_timestamp(max(`date`) ,'yyyyMMdd'), 'yyyy-MM-dd'))  from 
webanalytics.sessions_hits_newschema 
where customdimensions_index_6 is not null and total_pageviews is not null group by customdimensions_index_6;

-- number of days between first hit on the site and first lead
select  t1.customdimensions_index_6 ,DATEDIFF(cast(t2.visitstarttime*1000 as timestamp),cast(min(t1.visitstarttime)*1000 as timestamp)) from webanalytics.sessions_hits_newschema t1
join (select customdimensions_index_6, visitstarttime from webanalytics.sessions_hits_newschema 
where `date` ='20170604' and hits_eventInfo_eventAction='first_hotlead' and customdimensions_index_6 is not null  group by customdimensions_index_6, visitstarttime
) t2
where t1.customdimensions_index_6=t2.customdimensions_index_6  group by t1.customdimensions_index_6,t2.visitstarttime ;

-- minimum number of days between viewing properties
select t1.customdimensions_index_6 ,min(t1.`date` - t2.`date`) from webanalytics.sessions_hits_newschema t1
join (select customdimensions_index_6, `date` from webanalytics.sessions_hits_newschema
where  customdimensions_index_6 is not null and   hits_customdimensions_index_2='detail-property-page' group by customdimensions_index_6  ,`date`  order by `date`
) t2
where t1.customdimensions_index_6=t2.customdimensions_index_6 and t1.`date`>t2.`date` group by t1.customdimensions_index_6,t1.`date`,t2.`date`;

-- sqft of the house of the last hot lead (HL)
select  customdimensions_index_6 as ga_id , hits_customdimensions_index_20 as sqft_of_house , hits_customdimensions_index_15 as listing_id, 
hits_customdimensions_index_83 as nova_userid, max(visitid+(hits_time/1000)) as hit_time 
from  webanalytics.sessions_hits_newschema 
where hits_eventInfo_eventLabel ='lead-received'  
and  `date` ='20170604' and hits_customdimensions_index_15 is not null 
group by   customdimensions_index_6 ,visitid, hits_time ,hits_customdimensions_index_15, hits_customdimensions_index_20 ,hits_customdimensions_index_83   limit  20;

-- number of photos on the MLS for the property of the most recent HL
select  customdimensions_index_6 as ga_id , hits_customdimensions_index_17 as no_of_photos , hits_customdimensions_index_15 as listing_id, 
 hits_customdimensions_index_83 as nova_userid,  max(visitid+(hits_time/1000)) as hit_time 
from  webanalytics.sessions_hits_newschema where hits_eventInfo_eventLabel ='lead-received'  and  `date` ='20170604' 
and hits_customdimensions_index_15 is not null  
group by   customdimensions_index_6 ,visitid, hits_time ,hits_customdimensions_index_15, hits_customdimensions_index_17 ,hits_customdimensions_index_83 ;  

-- number of bathrooms for the most recent HL
select  customdimensions_index_6 as ga_id , hits_customdimensions_index_19 as no_of_bathrooms, hits_customdimensions_index_15 as listing_id, 
 hits_customdimensions_index_83 as nova_userid,  max(visitid+(hits_time/1000)) as hit_time  
from webanalytics.sessions_hits_newschema 
where hits_eventInfo_eventLabel ='lead-received'  and  `date` ='20170604' 
and hits_customdimensions_index_15 is not null 
group by   customdimensions_index_6 ,visitid, hits_time ,hits_customdimensions_index_15, hits_customdimensions_index_19 ,hits_customdimensions_index_83   ;

-- number of bedrooms of the most recent HL
select  customdimensions_index_6 as ga_id , hits_customdimensions_index_18 as no_of_bedrooms , hits_customdimensions_index_15 as listing_id, 
 hits_customdimensions_index_83 as nova_userid,  max(visitid+(hits_time/1000)) as hit_time 
from  webanalytics.sessions_hits_newschema 
where hits_eventInfo_eventLabel ='lead-received'  and `date` ='20170604' and hits_customdimensions_index_15 is not null  
group by customdimensions_index_6 ,visitid, hits_time ,hits_customdimensions_index_15, hits_customdimensions_index_18 ,hits_customdimensions_index_83;

-- price of the most recent HL
select  customdimensions_index_6 as ga_id , hits_customdimensions_index_16 as listingprice , hits_customdimensions_index_15 as listing_id, 
 hits_customdimensions_index_83 as nova_userid,  max(visitid+(hits_time/1000)) as hit_time 
 from  webanalytics.sessions_hits_newschema 
where hits_eventInfo_eventLabel ='lead-received'  and `date` ='20170604' and hits_customdimensions_index_15 is not null 
group by   customdimensions_index_6 ,visitid, hits_time ,hits_customdimensions_index_15, hits_customdimensions_index_16 ,hits_customdimensions_index_83  ;

-- number of pages viewed while logged after first HL divided by the number of pages viewed while logged off after first HL
select page_login.customdimensions_index_6, page_login.no_pg_login/ page_logoff.no_pg_logoff  from 
(select  t1.customdimensions_index_6 , count(t1.total_pageviews)  as no_pg_login  from webanalytics.sessions_hits_newschema t1
join (select customdimensions_index_6, visitstarttime , hits_time from webanalytics.sessions_hits_newschema 
where `date` ='20170604' and hits_eventInfo_eventAction='first_hotlead' and customdimensions_index_6 is not null  
group by customdimensions_index_6, visitstarttime,hits_time
) t2
where t1.visitstarttime  =t2.visitstarttime and t1.customdimensions_index_6=t2.customdimensions_index_6 and
 t1.hits_customdimensions_index_64 is not null and t1.hits_time>t2.hits_time  and hits_customdimensions_index_7='true' 
  group  by t1.customdimensions_index_6  
) page_login
join 
(
select  t1.customdimensions_index_6 , count(t1.total_pageviews)  as no_pg_logoff from webanalytics.sessions_hits_newschema t1
join (select customdimensions_index_6, visitstarttime , hits_time from webanalytics.sessions_hits_newschema 
where `date` ='20170604' and hits_eventInfo_eventAction='first_hotlead' and customdimensions_index_6 is not null  
group by customdimensions_index_6, visitstarttime,hits_time
) t2
where t1.visitstarttime  =t2.visitstarttime and t1.customdimensions_index_6=t2.customdimensions_index_6 and
 t1.hits_customdimensions_index_64 is not null and t1.hits_time>t2.hits_time  and hits_customdimensions_index_7='false' 
  group  by t1.customdimensions_index_6  
) page_logoff where page_login.customdimensions_index_6=page_logoff.customdimensions_index_6  limit 200;

-- number of pages viewed while logged on before first HL divided by number of pages viewed while logged off before first HL
select page_login.customdimensions_index_6, page_login.no_pg_login/ page_logoff.no_pg_logoff  from 
(select  t1.customdimensions_index_6 , count(t1.total_pageviews)  as no_pg_login  from webanalytics.sessions_hits_newschema t1
join (select customdimensions_index_6, visitstarttime , hits_time from webanalytics.sessions_hits_newschema 
where `date` ='20170604' and hits_eventInfo_eventAction='first_hotlead' and customdimensions_index_6 is not null  
group by customdimensions_index_6, visitstarttime,hits_time
) t2
where t1.visitstarttime  =t2.visitstarttime and t1.customdimensions_index_6=t2.customdimensions_index_6 and
 t1.hits_customdimensions_index_64 is not null and t1.hits_time<t2.hits_time  and hits_customdimensions_index_7='true' 
  group  by t1.customdimensions_index_6  
) page_login
join 
(
select  t1.customdimensions_index_6 , count(t1.total_pageviews)  as no_pg_logoff from webanalytics.sessions_hits_newschema t1
join (select customdimensions_index_6, visitstarttime , hits_time from webanalytics.sessions_hits_newschema 
where `date` ='20170604' and hits_eventInfo_eventAction='first_hotlead' and customdimensions_index_6 is not null  
group by customdimensions_index_6, visitstarttime,hits_time
) t2
where t1.visitstarttime  =t2.visitstarttime and t1.customdimensions_index_6=t2.customdimensions_index_6 and
 t1.hits_customdimensions_index_64 is not null and t1.hits_time>t2.hits_time  and hits_customdimensions_index_7='false' 
  group  by t1.customdimensions_index_6  
) page_logoff where page_login.customdimensions_index_6=page_logoff.customdimensions_index_6  limit 200;

-- number of sold properties viewed after first HL divided by number of active properties viewed after first HL
select ap.customdimensions_index_6 ,ap.active_pr/sp.sold_pr from
(select t1.customdimensions_index_6 ,count(t1.hits_customdimensions_index_23) as active_pr from webanalytics.sessions_hits_newschema t1
join (select customdimensions_index_6, visitstarttime from webanalytics.sessions_hits_newschema
where `date` ='20170604' and hits_eventInfo_eventAction='first_hotlead' and customdimensions_index_6 is not null group by customdimensions_index_6, visitstarttime
) t2
where t1.visitstarttime <t2.visitstarttime and `date` ='20170604' and t1.customdimensions_index_6=t2.customdimensions_index_6 
and t1.hits_customdimensions_index_23='ACTIVE' group by t1.customdimensions_index_6
) ap

join
(select t1.customdimensions_index_6 ,count(t1.hits_customdimensions_index_23) as sold_pr from webanalytics.sessions_hits_newschema t1
join (select customdimensions_index_6, visitstarttime from webanalytics.sessions_hits_newschema
where `date` ='20170604' and hits_eventInfo_eventAction='first_hotlead' and customdimensions_index_6 is not null group by customdimensions_index_6, visitstarttime
) t2
where t1.visitstarttime >t2.visitstarttime and `date` ='20170604' and t1.customdimensions_index_6=t2.customdimensions_index_6 
and t1.hits_customdimensions_index_23='SOLD' group by t1.customdimensions_index_6) sp where ap.customdimensions_index_6==sp.customdimensions_index_6 limit 200;

-- number of sold properties viewed before first HL divided by the number of active properties viewed before first HL
select ap.customdimensions_index_6 ,ap.active_pr/sp.sold_pr  from 
(select  t1.customdimensions_index_6 ,count(t1.hits_customdimensions_index_23) as active_pr from webanalytics.sessions_hits_newschema t1
join (select customdimensions_index_6, visitstarttime from webanalytics.sessions_hits_newschema 
where `date` ='20170604' and hits_eventInfo_eventAction='first_hotlead' and customdimensions_index_6 is not null  group by customdimensions_index_6, visitstarttime
) t2
where t1.visitstarttime  >t2.visitstarttime and  `date` ='20170604'  and t1.customdimensions_index_6=t2.customdimensions_index_6 and  t1.hits_customdimensions_index_23='ACTIVE'   group by t1.customdimensions_index_6 
) ap

join 
(select  t1.customdimensions_index_6 ,count(t1.hits_customdimensions_index_23) as sold_pr  from webanalytics.sessions_hits_newschema t1
join (select customdimensions_index_6, visitstarttime from webanalytics.sessions_hits_newschema 
where `date` ='20170604' and hits_eventInfo_eventAction='first_hotlead' and customdimensions_index_6 is not null  group by customdimensions_index_6, visitstarttime
) t2
where t1.visitstarttime  >t2.visitstarttime and  `date` ='20170604'  and t1.customdimensions_index_6=t2.customdimensions_index_6 and  t1.hits_customdimensions_index_23='SOLD'   group by t1.customdimensions_index_6) sp  where ap.customdimensions_index_6==sp.customdimensions_index_6 limit 200;





































































































