import org.apache.spark.sql.SparkSession
import java.io.File
import org.apache.spark.sql.DataFrame
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.Path


val inpath = "/data/webanalytics/sessions_hits_parquet_newschema"
val hadoopFS = FileSystem.get(new Configuration)
var allpartitions = hadoopFS.listStatus(new Path(inpath));

var allIndexes = List[Long]()
var campCodeCount:Long = 0
var propNameCount:Long = 0
var propIdCount:Long = 0
var contentViewCount:Long = 0
for(infile <- allpartitions) {
 val infilepath = inpath.concat("/").concat(infile.getPath.getName)
 
 spark.read.parquet(infilepath).createTempView("sessions");
 spark.sql("select allhits from sessions LATERAL VIEW explode(hits.array) hitstable as allhits").createTempView("allhits") 
 spark.sql("select custdim from allhits LATERAL VIEW explode(allhits.customDimensions.array) custdimtab as custdim").createTempView("hitsdims")
// spark.sql("select custmet from allhits LATERAL VIEW explode(allhits.customMetrics.array) custmettab as custmet").createTempView("hitsmets")
 // spark.sql("select distinct custmet.index as indx from hitsmets").show(1000) <- nothing in metrics :)
 
 campCodeCount += spark.sql("select count(trafficSource.campaignCode) as cnt from sessions").map(rw=>rw.getAs[Long]("cnt")).collect()(0)
 val propCounts =
     spark.sql("select count(allhits.sourcePropertyInfo.sourcePropertyDisplayName) as cnt_name, count(allhits.sourcePropertyInfo.sourcePropertyTrackingId) as cnt_ids from allhits")
     .map(rw=>(rw.getAs[Long]("cnt_name"), rw.getAs[Long]("cnt_ids")) ).collect()
 propNameCount += propCounts(0)._1
 propIdCount += propCounts(0)._2
 
 contentViewCount += spark.sql("select (count(allhits.contentGroup.contentGroupUniqueViews1) + count(allhits.contentGroup.contentGroupUniqueViews2) + count(allhits.contentGroup.contentGroupUniqueViews3) + count(allhits.contentGroup.contentGroupUniqueViews4) + count(allhits.contentGroup.contentGroupUniqueViews5)) as cnt from allhits").map(rw=>rw.getAs[Long]("cnt")).collect()(0)
 
 allIndexes = allIndexes.union( spark.sql("select distinct custdim.index as all_indx from hitsdims").map(rw=>rw.getAs[Long]("all_indx")).collect ).distinct

 spark.catalog.dropTempView("sessions");
 spark.catalog.dropTempView("allhits");
 spark.catalog.dropTempView("hitsdims");
 spark.catalog.dropTempView("hitsmets");
 
 println("################### Custom dimension indexes");
 println(allIndexes.sorted.mkString(", "));
 println("################### --------------------------");

 println("################### Not null campaingCode count");
 println(campCodeCount);
 println("################### --------------------------");

 println("################### Not null sourcePropertyDisplayName count");
 println(propNameCount);
 println("################### --------------------------");

 println("################### Not null sourcePropertyTrackingId count");
 println(propIdCount);
 println("################### --------------------------");

 println("################### Not null contentGroupUniqueViewsX count");
 println(contentViewCount);
 println("################### --------------------------");
}

println("################### Custom dimension indexes");
println(allIndexes.sorted.mkString(", "));
println("################### --------------------------");

println("################### Not null campaingCode count");
println(campCodeCount);
println("################### --------------------------");

println("################### Not null sourcePropertyDisplayName count");
println(propNameCount);
println("################### --------------------------");

println("################### Not null sourcePropertyTrackingId count");
println(propIdCount);
println("################### --------------------------");

println("################### Not null contentGroupUniqueViewsX count");
println(contentViewCount);
println("################### --------------------------");


