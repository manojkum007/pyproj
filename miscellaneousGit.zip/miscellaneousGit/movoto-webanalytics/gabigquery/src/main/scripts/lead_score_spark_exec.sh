#!/bin/bash

cd /opt/workflows/gabigquery

source /home/huser/.profile

export yestday=$(date +%Y%m%d -d "yesterday")
export seventhday=$(date +%Y%m%d -d "8 day ago")


/opt/apache-hive-1.2.0-bin/bin/hive --hivevar bkptabdate=$yestday --hivevar droptabdate=$seventhday -f lead_scores.hql


/opt/spark/bin/spark-submit --num-executors 61 --executor-memory 5g --executor-cores 1 --driver-memory 6g \
 --master yarn --class com.movoto.webanalytics.leadscore.LeadScoreRunner \
 /home/jprajapati/workspace/webanalytics/gabigquery-1.0.jar \
 all \
 default.novaid_gaid_mapping \
 webanalytics.sessions_hits_newschema \
 webanalytics.lead_scores


