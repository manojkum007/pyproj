#!/bin/bash
spark-submit --num-executors 5 --executor-memory 6g --executor-cores 4 --driver-memory 8g \
 --master yarn --class com.movoto.webanalytics.gabq.FlatteningRunner \
 /home/jprajapati/workspace/webanalytics-1.0.jar \
 /data/webanalytics/sessions_hits_parquet_new/updated_date=2017-04-10 \
 webanalytics.gabq_sessions_hits_parquet_new 
 
 
spark-submit --num-executors 10 --executor-memory 7g --executor-cores 4 --driver-memory 8g \
 --master yarn --class com.movoto.webanalytics.gabq.BlindFlatteningRunner \
 /home/jprajapati/workspace/webanalytics/webanalytics-1.0.jar \
 /data/webanalytics/sessions_hits_parquet_newschema \
 webanalytics.sessions_hits_newschema 
 
