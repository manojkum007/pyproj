package com.movoto.scala

import org.apache.spark
import org.apache.spark.SparkContext._
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.sql.types._
import org.apache.spark.sql.SaveMode


object Tempcreator {
  def main(args: Array[String]){
    val conf = new SparkConf().setAppName("Test").setMaster("local[2]")
    val sc = new SparkContext(conf)
    val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)
    import sqlContext.implicits._

    val leftparttable = sqlContext.read.parquet("hdfs://localhost:54310/user/hive/warehouse/temp.db/mls_address_history")
    //val parqfile = sqlContext.read.parquet(main_table_path)
    println(leftparttable.printSchema)
    leftparttable.registerTempTable("left_parq")

    val rightparttable = sqlContext.read.parquet("hdfs://localhost:54310/user/hive/warehouse/temp.db/mls_address_parq")

    //val parqtemp = sqlContext.read.parquet(delta_table_path)
    println(rightparttable.count)

    rightparttable.registerTempTable("right_parq")

    //val primary_col :String=table_dict(tablename)

    val testdf= leftparttable.withColumn("new_id", $"id".cast(StringType)).drop($"id")

    val  stagingdf=sqlContext.sql("select * from right_parq where id not in (select id from left_parq limit 1)")

    println(" id not in left parq"+stagingdf.printSchema())
  val afterdropdf= leftparttable.drop(leftparttable.col("updated_date"))

    println(afterdropdf.printSchema)
    val uniondf=afterdropdf.union(stagingdf)
    println(" resultant df"+uniondf.count)

    /*val testdf= parqtemp.withColumn(newcolumn, parqtemp.col(primary_col).cast(StringType)).drop(parqtemp.col(primary_col))



    val subdf=parqfile.select(parqfile.col(primary_col).cast(StringType)).except(testdf.select(testdf.col(newcolumn).cast(StringType)))


   val newsubdf= subdf.withColumn(newcolumn, subdf.col(primary_col).cast(StringType)).drop(subdf.col(primary_col))
    println(newsubdf.printSchema)
    println(newsubdf.count)*/

   // val new_df = parqfile.join(newsubdf, parqfile(primary_col) === newsubdf(newcolumn),"leftouter")


    //val latest= new_df.filter(new_df.col(newcolumn).isNotNull)

    //val newlatest=latest.drop(latest.col(newcolumn))

    //newlatest.write.mode(SaveMode.Overwrite).parquet("/tmp/attribute_newdataset")

    //df.write.mode('overwrite').saveAsTable('temp.attribute_test')
    //newlatest.write.mode("overwrite").insertInto(final_table)



}

}