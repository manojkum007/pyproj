package com.movoto.scala

import org.apache.spark.SparkContext._
import org.apache.spark.{SparkConf,SparkContext}
import org.apache.spark.sql.types._
import org.apache.spark.sql.SaveMode


object Test {
  def main(args: Array[String]){
    val conf = new SparkConf().setAppName("Test").setMaster("local[2]")
    val sc = new SparkContext(conf)
   // val spark = SparkSession.builder().getOrCreate()
    //import spark.implicits._

    //import org.apache.spark.implicits._
    /*if(args.length != 3) {
      println("please enter table path and table name")
      System.exit(0);
    }*/

   // val main_table_path = args(0).trim
    //val delta_table_path = args(1).trim
    //var tablename:String =  args(2).trim
    var newcolumn :String="new_id"
    //var final_table: String="temp.attribute_test"
    var final_table: String="hdfs://localhost:54310/user/hive/warehouse/temp.db/attribute_test"

    var tablename :String ="mls_attribute"

    val table_dict=Map("mls_address"->"id","mls_listing"->"id","mls_public_record_association"->"id","mls_image_downloader"->"mls_listing_id","mls_attribute"->"id")

    val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)
    import sqlContext.implicits._


    val parqfile = sqlContext.read.parquet("hdfs://localhost:54310/user/hive/warehouse/temp.db/attribute_parq")
    //val parqfile = sqlContext.read.parquet(main_table_path)
    println(parqfile.printSchema)

    val parqtemp = sqlContext.read.parquet("hdfs://localhost:54310/user/hive/warehouse/temp.db/attribute_temp")

    //val parqtemp = sqlContext.read.parquet(delta_table_path)
    println(parqtemp.printSchema)

    val primary_col :String=table_dict(tablename)
    //val testdf= parqtemp.withColumn("new_id", $"id".cast(StringType)).drop($"id")

    val testdf= parqtemp.withColumn(newcolumn, parqtemp.col(primary_col).cast(StringType)).drop(parqtemp.col(primary_col))



    val subdf=parqfile.select(parqfile.col(primary_col).cast(StringType)).except(testdf.select(testdf.col(newcolumn).cast(StringType)))


    val newsubdf= subdf.withColumn(newcolumn, subdf.col(primary_col).cast(StringType)).drop(subdf.col(primary_col))
    println(newsubdf.printSchema)
    println(newsubdf.count)

    val new_df = parqfile.join(newsubdf, parqfile(primary_col) === newsubdf(newcolumn),"leftouter")


    val latest= new_df.filter(new_df.col(newcolumn).isNotNull)

    val newlatest=latest.drop(latest.col(newcolumn))

    //newlatest.write.mode(SaveMode.Overwrite).parquet("/tmp/attribute_newdataset")

    //df.write.mode('overwrite').saveAsTable('temp.attribute_test')
    newlatest.write.mode("overwrite").insertInto(final_table)

    /*
      val parqfile = sqlContext.read.parquet("hdfs://localhost:54310/user/hive/warehouse/bq_nova_desktop.db/sessions_hits_avro")

      parqfile.createTempView("nova");
      parqfile.show */
    /*  sc.textFile(args(0))
        .map(_.split(","))
        .map(rec => ((rec(0).split("-"))(0).toInt, rec(1).toFloat))
        .reduceByKey((a,b) => Math.max(a,b))
        .saveAsTextFile(args(1))*/


/*
  import scala.collection.mutable.ListBuffer

  def explodeTotals(rw: Row, recBuff: ListBuffer[Any] ): Unit = {
    val totals = rw.getAs[Row]("totals")
    var visits = totals.getAs[Long]("visits")
    val pageviews = totals.getAs[Long]("pageviews")
    val bounces = totals.getAs[Long]("bounces")
    recBuff += visits
    recBuff += pageviews
    recBuff += bounces
    recBuff += totals.getAs[Long]("newVisits")
    recBuff += totals.getAs[Long]("timeOnSite")
  }


  totaldf.flatMap(rw => {
    val recBuff = ListBuffer.empty[Any]
    explodeTotals(rw, recBuff)
  }

  def newStructField(sf: StructField, colNamePrefix: String = "") : StructField = {
    sf.dataType match {
      case _: BinaryType => StructField((colNamePrefix.concat(sf.name)), StringType, sf.nullable).withComment(sf.name)
      case _ => StructField((colNamePrefix.concat(sf.name)), sf.dataType, sf.nullable).withComment(sf.name)
    }
  }*/

}

}