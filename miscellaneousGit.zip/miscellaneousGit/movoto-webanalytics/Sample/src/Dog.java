/**
 * Created by manoj on 30/10/17.
 */
public class Dog {
     String name;
     String breed;
     String color;
     Integer age;


    public Dog( String name  , String breed ,String color ,Integer age){
        this.name =name;
        this.breed =breed;
        this.color =color;
        this.age =age;
    }

    public void getDetails() {
        System.out.print("\nName of dog is "+ this.name);
        System.out.print("\nBreed of dog is "+ this.breed);
        System.out.print("\ncolor of dog is "+ this.color);
        System.out.print("\nage of dog is "+ this.age);
    }


    public static void  main(String args[]){
        Dog d=new Dog("Tommy" ,"European", "brownish white", 6);
        d.getDetails();

    }
}
