/**
 * Created by manoj on 19/10/17.
 */

package classapackage;

public class ClassA {
    public void display()
    {

      System.out.println("Class A");
    }
}
