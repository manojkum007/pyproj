/**
 * Created by manoj on 18/10/17.
 */

/*
public class Sample {

    public static void  main(String args[]){
        int count=0;
        if ( args.length>0 ){
            while (count<args.length) {
                System.out.println(args[count]);
                count+=1;}
        }


    }
}
*/



/*
import javax.xml.crypto.Data;
import java.io.DataInputStream;
import java.io.SyncFailedException;

public class Sample {

    public static void main(String args[]) {
        DataInputStream  inreader= new DataInputStream(System.in);
        int intreader=0;
        float floatreader= 0.0f;
        try {
            System.out.println("Enter a integer ");
            intreader = Integer.parseInt(inreader.readLine());
            System.out.println("enetered number is "+intreader);
            System.out.println("Enter a Float number ");
            floatreader = Float.parseFloat(inreader.readLine());
            System.out.println("enetered number is "+floatreader);
        } catch (Exception e) {
            System.out.println("Exception occurred" +e);
        }

    }
}

*/

/*

class Rectangle {

    int width , height;
    Rectangle ( int x , int y) {
        width=x;
        height=y;
    }
    int ShowArea(){
        return width*height;
    }

    void display()
    {
        System.out.println("length  is " +width + " and breath "+ height) ;
    }
}

class Cuboid extends Rectangle{

    int zheight;
    Cuboid( int  x, int y , int z) {
        super(x,y);
        zheight=z;
    }
     long volume (){
         return super.ShowArea()*zheight;
     }

    void display()
    {
        System.out.println("length  is " +width + " and breath "+ height  +" height is " + zheight) ;
    }
}

public class Sample {

    public static void main(String args[]) {
       // Rectangle rr=  new Rectangle(4,6);

       // System.out.print("Area "+ rr.ShowArea());

         Cuboid cc= new Cuboid(4,5,6);
        cc.display();
        System.out.print("Voulume is "+ cc.volume());


    }
    }*/


/*

########################


*/

import classapackage.ClassA;
import classbpackage.*;

public class Sample {

    public static void  main(String args[]){
ClassA a=new ClassA();
        ClassB b=new ClassB();

        a.display();
        b.displayB();

    }
}



