/**
 * Created by manoj on 19/10/17.
 */

package classbpackage;

public class ClassB {
    protected int m=12;
    public void displayB(){
        System.out.println("In class B");
        System.out.println(" m ="+ m);
    }

}
