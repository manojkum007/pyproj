SELECT
	visitorId AS users,
	totals.visits AS sess,
	totals.pageViews AS views,
	totals.bounces AS sgl_sess,
	(
		totals.bounces / totals.visits
	) AS bounce_rt,
	totals.timeOnSite AS avg_time_site,
	(
		totals.pageviews / totals.visits
	) AS views_sess,
	hitsf.eventInfo.eventLabel AS event_label,
	hitsf.eventInfo.eventAction AS event_action,
	totals.newVisits AS new_sess,
	hitsf.contentGroup.contentGroupUniqueViews1 AS cont_grp_uniq_views,
	CASE
		WHEN hits_dimensions.index = 71 THEN hits_dimensions.value
	END AS exp_id,
	CASE
		WHEN hits_dimensions.index = 72 THEN hits_dimensions.value
	END AS exp_name,
	CASE
		WHEN hits_dimensions.INDEX = 74 THEN hits_dimensions.value
	END AS tst_sl_1,
	CASE
		WHEN hits_dimensions.index = 75 THEN hits_dimensions.value
	END AS tst_sl_2,
	CASE
		WHEN hits_dimensions.index = 76 THEN hits_dimensions.value
	END AS tst_sl_3,
	CASE
		WHEN hits_dimensions.INDEX = 77 THEN hits_dimensions.value
	END AS tst_sl_4,
	hitsf.referer AS REF,
	trafficSource.source AS src,
	trafficSource.medium AS med,
	trafficSource.keyword AS kywrd,
	trafficSource.adContent AS ad_cont,
	trafficSource.isTrueDirect AS dir_traffic,
	socialEngagementType AS soc_engd,
	trafficSource.campaign AS cmpg,
	trafficSource.campaignCode AS cmpg_code,
	trafficSource.adwordsClickInfo.adGroupId AS ad_grp,
	trafficSource.adwordsClickInfo.slot AS ad_sl,
	trafficSource.adwordsClickInfo.adNetworkType AS ad_dist_ntwrk,
	trafficSource.adwordsClickInfo.customerId AS adwords_cust_id,
	trafficSource.adwordsClickInfo.campaignId AS adwords_cmpg_id,
	trafficSource.adwordsClickInfo.adGroupId AS adwords_ad_grp_id,
	trafficSource.adwordsClickInfo.creativeId AS adwords_creat_id,
	trafficSource.adwordsClickInfo.criteriaId AS adwords_crit_id,
	trafficSource.adwordsClickInfo.isVideoAd AS vid_ad_flg,
	CASE
		WHEN cust_dim.index = 78 THEN cust_dim.value
	END AS gclid,
	visitNumber AS sess_num,
	hitsf.page.pagePath AS pg_name,
	CASE
		WHEN hits_dimensions.index = 1 THEN hits_dimensions.value
	END AS ch,
	CASE
		WHEN hits_dimensions.index = 2 THEN hits_dimensions.value
	END AS pg_type,
	CASE
		WHEN hits_dimensions.index = 3 THEN hits_dimensions.value
	END AS site_sec,
	CASE
		WHEN hits_dimensions.INDEX = 5 THEN hits_dimensions.value
	END AS xp,
	CASE
		WHEN hits_dimensions.index = 29 THEN hits_dimensions.value
	END AS lk_name,
	CASE
		WHEN hits_dimensions.index = 30 THEN hits_dimensions.value
	END AS lk_mod_name,
	CASE
		WHEN hits_dimensions.index = 31 THEN hits_dimensions.value
	END AS lk_type,
	CASE
		WHEN hits_dimensions.index = 37 THEN hits_dimensions.value
	END AS soc_shr_type,
	CASE
		WHEN hits_dimensions.index = 70 THEN hits_dimensions.value
	END AS sell_site_type,
	hitsf.page.hostname AS pg_hstnm,
	hitsf.page.pageTitle AS pt,
	hitsf.contentGroup.previousContentGroup1 AS cont_grp_mpsrch,
	CASE
		WHEN hits_dimensions.index = 14 THEN hits_dimensions.value
	END AS mls_id,
	CASE
		WHEN hits_dimensions.index = 15 THEN hits_dimensions.value
	END AS list_id,
	CASE
		WHEN hits_dimensions.index = 16 THEN hits_dimensions.value
	END AS list_price,
	CASE
		WHEN hits_dimensions.index = 17 THEN hits_dimensions.value
	END AS pht_nt,
	CASE
		WHEN hits_dimensions.index = 18 THEN hits_dimensions.value
	END AS bed_cnt,
	CASE
		WHEN hits_dimensions.index = 19 THEN hits_dimensions.value
	END AS bath_cnt,
	CASE
		WHEN hits_dimensions.index = 20 THEN hits_dimensions.value
	END AS sqft,
	CASE
		hits_dimensions.index
		WHEN 21 THEN hits_dimensions.value
	END AS dom,
	CASE
		hits_dimensions.index
		WHEN 22 THEN hits_dimensions.value
	END AS prop_type,
	CASE
		hits_dimensions.index
		WHEN 23 THEN hits_dimensions.value
	END AS list_stat,
	CASE
		hits_dimensions.index
		WHEN 24 THEN hits_dimensions.value
	END AS opn_house,
	CASE
		hits_dimensions.index
		WHEN 25 THEN hits_dimensions.value
	END AS city,
	CASE
		hits_dimensions.index
		WHEN 26 THEN hits_dimensions.value
	END AS state,
	CASE
		hits_dimensions.index
		WHEN 27 THEN hits_dimensions.value
	END AS zip,
	CASE
		hits_dimensions.index
		WHEN 28 THEN hits_dimensions.value
	END AS nbrhd,
	hitsf.eventInfo.eventCategory AS evnt_cat,
	hitsf.eventInfo.eventAction AS evnt_act,
	hitsf.eventInfo.eventLabel AS evnt_lbl,
	hitsf.eventInfo.eventValue AS evt_val,
	userId AS nova_id,
	hitsf.sourcePropertyInfo.SourcePropertyDisplayName AS ga_prop_nm,
	hitsf.sourcePropertyInfo.sourcePropertyDisplayName AS ga_prop_info,
	hitsf.sourcePropertyInfo.sourcePropertyTrackingID AS ga_trk_id,
	geoNetwork.continent AS continent,
	geoNetwork.subContinent AS sub_conttinent,
	geoNetwork.country AS ctry,
	geoNetwork.region AS rgn,
	geoNetwork.metro AS metro,
	geoNetwork.city AS geocity,
	geoNetwork.latitude AS lat,
	geoNetwork.longitude AS long,
	geoNetwork.networkDomain AS ntwrk_domain,
	geoNetwork.networkLocation AS ntwk_loc,
	geoNetwork.cityId AS city_id,
	CASE
		WHEN hits_dimensions.index = 32 THEN hits_dimensions.value
	END AS ld_id,
	CASE
		WHEN hits_dimensions.index = 33 THEN hits_dimensions.value
	END AS ld_form_loc,
	CASE
		WHEN hits_dimensions.index = 34 THEN hits_dimensions.value
	END AS ld_form_msg,
	CASE
		WHEN hits_dimensions.index = 35 THEN hits_dimensions.value
	END AS ld_state,
	CASE
		WHEN hits_dimensions.index = 36 THEN hits_dimensions.value
	END AS ld_type,
	CASE
		WHEN hits_dimensions.index = 69 THEN hits_dimensions.value
	END AS ld_dma,
	CASE
		WHEN hits_dimensions.index = 8 THEN hits_dimensions.value
	END AS mpsrch_view,
	CASE
		WHEN hits_dimensions.index = 9 THEN hits_dimensions.value
	END AS mpsrch_rslt_num,
	CASE
		WHEN hits_dimensions.index = 10 THEN hits_dimensions.value
	END AS mpsrch_term,
	CASE
		WHEN hits_dimensions.index = 11 THEN hits_dimensions.value
	END AS mpsrch_type,
	CASE
		WHEN hits_dimensions.index = 12 THEN hits_dimensions.value
	END AS mpsrch_pg_num,
	CASE
		WHEN hits_dimensions.index = 13 THEN hits_dimensions.value
	END AS mpsrch_sort_type,
	CASE
		WHEN hits_dimensions.index = 38 THEN hits_dimensions.value
	END AS fltr_sqft_min,
	CASE
		WHEN hits_dimensions.index = 39 THEN hits_dimensions.value
	END AS fltr_sqft_max,
	CASE
		WHEN hits_dimensions.index = 40 THEN hits_dimensions.value
	END AS fltr_bed_num,
	CASE
		WHEN hits_dimensions.index = 41 THEN hits_dimensions.value
	END AS fltr_bath_num,
	CASE
		WHEN hits_dimensions.index = 42 THEN hits_dimensions.value
	END AS fltr_dom_max,
	CASE
		WHEN hits_dimensions.index = 43 THEN hits_dimensions.value
	END AS fltr_dom_min,
	CASE
		WHEN hits_dimensions.index = 44 THEN hits_dimensions.value
	END AS fltr_has_pool,
	CASE
		WHEN hits_dimensions.index = 45 THEN hits_dimensions.value
	END AS fltr_is_fixup,
	CASE
		WHEN hits_dimensions.index = 46 THEN hits_dimensions.value
	END AS fltr_sgl_fam,
	CASE
		WHEN hits_dimensions.index = 47 THEN hits_dimensions.value
	END AS fltr_contn_hm,
	CASE
		WHEN hits_dimensions.index = 48 THEN hits_dimensions.value
	END AS fltr_mutifam_hm,
	CASE
		WHEN hits_dimensions.index = 49 THEN hits_dimensions.value
	END AS fltr_lotland,
	CASE
		WHEN hits_dimensions.index = 50 THEN hits_dimensions.value
	END AS fltr_mob_hm,
	CASE
		WHEN hits_dimensions.index = 51 THEN hits_dimensions.value
	END AS fltr_type_othr,
	CASE
		WHEN hits_dimensions.index = 52 THEN hits_dimensions.value
	END AS fltr_prop_stat,
	CASE
		WHEN hits_dimensions.index = 53 THEN hits_dimensions.value
	END AS fltr_fcl,
	CASE
		WHEN hits_dimensions.index = 54 THEN hits_dimensions.value
	END AS fltr_new_wk,
	CASE
		WHEN hits_dimensions.index = 55 THEN hits_dimensions.value
	END AS fltr_opn_house,
	CASE
		WHEN hits_dimensions.index = 56 THEN hits_dimensions.value
	END AS fltr_px_red,
	CASE
		WHEN hits_dimensions.index = 57 THEN hits_dimensions.value
	END AS fltr_hd_pend,
	CASE
		WHEN hits_dimensions.index = 58 THEN hits_dimensions.value
	END AS fltr_hd_no_phts,
	CASE
		WHEN hits_dimensions.index = 59 THEN hits_dimensions.value
	END AS fltr_yr_blt_min,
	CASE
		WHEN hits_dimensions.index = 60 THEN hits_dimensions.value
	END AS fltr_yr_blt_max,
	CASE
		WHEN cust_dim.index = 61 THEN cust_dim.value
	END AS anon_id,
	CASE
		WHEN hits_dimensions.index = 62 THEN hits_dimensions.value
	END AS tmsmp,
	CASE
		WHEN hits_dimensions.index = 63 THEN hits_dimensions.value
	END AS evnt_type,
	CASE
		WHEN hits_dimensions.index = 64 THEN hits_dimensions.value
	END AS pg_url,
	CASE
		WHEN cust_dim.index = 65 THEN cust_dim.value
	END AS user_agent,
	CASE
		WHEN cust_dim.index = 66 THEN cust_dim.value
	END AS vari_name,
	CASE
		WHEN hits_dimensions.index = 67 THEN hits_dimensions.value
	END AS prop_req_login,
	CASE
		WHEN hits_dimensions.index = 68 THEN hits_dimensions.value
	END AS mpsrch_rslt_type,
	device.browser AS brwsr,
	device.browserSize AS brwsr_size,
	device.browserVersion AS brwsr_ver,
	device.operatingSystem AS op_sys,
	device.operatingSystemVersion AS op_sys_ver,
	device.mobileDeviceBranding AS mob_dev_brand,
	device.mobileDeviceModel AS mob_dev_mod,
	device.mobileDeviceInfo AS mob_dev_info,
	device.mobileDeviceMarketingName AS mob_dev_mkt_nm,
	device.deviceCategory AS dev_cat,
	device.flashVersion AS flash_ver,
	device.javaEnabled AS java_en,
	device.language AS lang,
	device.screenColors AS screen_cl,
	device.screenResolution AS screen_res,
	CASE
		WHEN hits_dimensions.index = 4 THEN hits_dimensions.value
	END AS LOCAL,
	CASE
		WHEN cust_dim.index = 73 THEN cust_dim.value
	END AS ip,
	hitsf.minute AS MIN,
	hitsf.hour AS hr,
	CASE
		WHEN hits_dimensions.index = 6 THEN hits_dimensions.value
	END AS gaid,
	CASE
		WHEN hits_dimensions.index = 7 THEN hits_dimensions.value
	END AS loggedin,
	DATE
FROM
	bq_nova LATERAL VIEW explode(customDimensions.array) tblCustDim AS cust_dim LATERAL VIEW explode(hits.array) tblHits AS hitsf LATERAL VIEW explode(hitsf.customDimensions.array) tblHitsDimensions AS hits_dimensions;
