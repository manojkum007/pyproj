# Movoto Webanalytics
This repository contains codes for google analytics bigquery and related analysis using hadoop. Followings are the projects it hosts.  

1) webanalytics  
 a. google bigquery export flattening for bq_nova, desktop_bq_nova, mobile_bq_nova  

