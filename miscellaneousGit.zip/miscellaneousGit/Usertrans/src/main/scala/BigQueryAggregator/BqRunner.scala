package BigQueryAggregator


import java.text.SimpleDateFormat

import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.{SparkConf, SparkContext}
import org.joda.time.DateTime
import org.apache.hadoop.fs.{FileSystem, Path}

import scala.collection.mutable.ListBuffer

object BqRunner {

  def main(args: Array[String]) {

    var bqrawtable:String=""
    var outputpath :String=""
    var outputtable :String=""
    var start_date :String=""
    var end_date :String=""
    var get_all:String=""
    val rhino_path :String="hdfs://192.168.120.140:9000"
    var bqdates = ListBuffer[String]()
    val inputFormat = new SimpleDateFormat("yyyy-MM-dd")
    val outputFormat = new SimpleDateFormat("yyyyMMdd")


    if (args.length > 4) {
      bqrawtable =  args(0).trim.toString
      outputpath = args(1).trim.toString
      outputtable = args(2).trim.toString
      start_date=args(3).trim
      end_date=args(4).trim
    } else {
      println(" sorry no parameter passed")
      System.exit(-1)
    }

    val sc = new SparkContext(new SparkConf().setAppName("Aggregatorbigquery"))

    //val conf = new SparkConf().setAppName("Aggregatorbigquery")
    //val sc = new SparkContext(conf)

    //sc = new SparkContext(new SparkConf().setAppName("Aggregatorbigquery")
    val sqlContext = new SQLContext(sc)
    val hiveContext = new HiveContext(sc)
    import org.apache.hadoop.conf.Configuration
    val config = new Configuration()

    config.set("fs.defaultFS", rhino_path)




    bqdates=partitiongenerator(start_date ,end_date).map( e=>bqrawtable+"/date="+outputFormat.format(inputFormat.parse(e)))

    //val srctable = Array("/user/hive/warehouse/webanalytics.db/sessions_hits_newschema/date=20180501")
    //val rhino_path :String="hdfs://192.168.120.140:9000"
    //val outputpath="/tmp/bqagg"

    config.set("fs.defaultFS", rhino_path)


    try {

      bqdates.foreach(name => {
        println("looping for "+ name)
        val fs= FileSystem.get(config)
        if ( fs.exists(new Path(outputpath.toString))) {
          fs.delete(new Path(outputpath.toString))
        }
        val bqdf=sqlContext.read.parquet(name)
        var datecol=name.split("=")(1)
        val newbqdf=bqdf.withColumn("created_date", org.apache.spark.sql.functions.lit(datecol))
        val tobj = new BqAggregator
        tobj.aggDailyMetrics(newbqdf ,sqlContext , outputpath ,datecol ,hiveContext)
        val outputdf=hiveContext.read.parquet(outputpath)
        hiveContext.setConf("hive.exec.dynamic.partition", "true")
        hiveContext.setConf("hive.exec.dynamic.partition.mode", "nonstrict")
        outputdf.write.mode("append").partitionBy("created_date").insertInto(outputtable);
    })

    }
    catch {
      case e: Exception => println("************** Error processing."); e.printStackTrace();
        System.exit( -1 );
    }


      println("sucessfull compeleted")
      if(sc != null) sc.stop()
      System.exit(0);

  }



  def partitiongenerator( sdate:String,  edate:String) :ListBuffer[String]= {
    val buf = new ListBuffer[String]
    var t1=DateTime.parse(sdate).getDayOfYear
    var t2=DateTime.parse(edate).getDayOfYear
    if (DateTime.parse(edate).getYear<=DateTime.parse(sdate).getYear) {
      for (i <- 0 to t2-t1) {
        val d = DateTime.parse(sdate).plusDays(i).toString("YYYY-MM-dd")
        buf+=d
      }

    } else
    {
      var datediff :Int=0;
      if (DateTime.parse(sdate).getYearOfEra%4==0){datediff=(366-t1)+t2 }
      else { datediff=(365-t1)+t2}
      for (i <- 0 to datediff) {
        val d = DateTime.parse(sdate).plusDays(i).toString("YYYY-MM-dd")
        buf+=d
      }
    }
    buf
  }


}