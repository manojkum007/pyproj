package BigQueryAggregator

trait SimpleAggregator extends java.io.Serializable {
  
}