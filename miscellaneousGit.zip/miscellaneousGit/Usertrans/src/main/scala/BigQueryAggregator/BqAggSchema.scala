package BigQueryAggregator

import org.apache.spark.sql.types._

class BqAggSchema extends SimpleAggregator {


  def DimensionbuildSchema(): StructType = {
    StructType(Seq(
      StructField("metric_id", IntegerType, true),
      StructField("metric_value", LongType, true),
      StructField("platform", StringType, true),
      StructField("browser_name", StringType, true),
      StructField("browser_version", StringType, true),
      StructField("os_name", StringType, true),
      StructField("os_version", StringType, true),
      StructField("channel_grouping", StringType, true),
      StructField("trafficsource_source", StringType, true),
      StructField("trafficsource_medium", StringType, true),
      StructField("landing_page_path", StringType, true),
      StructField("year", IntegerType, true),
      StructField("week", IntegerType, true),
      StructField("dayofweek", StringType, true),
      StructField("numdayofweek", StringType, true),
      StructField("month", IntegerType, true),
      StructField("day", IntegerType, true),
      StructField("created_date", StringType, true)
    ))
  }
  
  def MetricsbuildSchema(): StructType = {
    StructType(Seq(
        StructField("Metricstype", IntegerType, true),
        StructField("Metrics_agg_name", StringType, true)
        ))    
  }

  /*
  def getLeadScoreAggQuery(dtRange: String, tableName: String): String = {


    /*
    require((dtRange != null && !dtRange.trim.isEmpty()), "Date range must be specified in format \"(20170710, 20170711)\" or specify \"all\" for whole table")
    var dtpart = s" `date` in ($dtRange) and "
    if(dtRange == "all") dtpart = ""
    val selectColumns = BqAggConstants.selectList.map(e=>(e._3 + " as " + e._1)).mkString(", ")

    //println("printing " +selectColumns)
    s"""select distinct $selectColumns   
       from $tableName
       where $dtpart
       hits_hitnumber is not null and customdimensions_index_6 is not null"""
       */
  }

  */
  
  def getNovaIdGAIdMapQuery(tableName: String): String = {
    s"""select nova_id, ga_id from $tableName"""
  }
  
}