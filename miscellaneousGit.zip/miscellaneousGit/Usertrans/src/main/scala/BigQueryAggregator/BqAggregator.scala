package BigQueryAggregator


import BigQueryAggregator.BqAggConstants._
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.{DataFrame, Row, SQLContext}

import scala.collection.mutable.ListBuffer

class BqAggregator extends BqAggSchema {

  def aggDailyMetrics(bqdf: DataFrame ,sc:SQLContext ,outputpath:String,  datecol: String ,hc:HiveContext): Unit = {
    /*
    val session_bqrows=sc.sql("select  1 as Metricstype,sum(total_visits) as Metricsaggno, device_browser  as device_brow, device_browserversion  as device_brwvrsn,  device_operatingsystem as device_os,   device_operatingsystemversion   as device_osvrsn,    channelgrouping  ,    trafficsource_source,    trafficsource_medium,     hits_page_pagepath as landing_page_path,      YEAR(FROM_UNIXTIME((unix_timestamp(dateval ,'yyyyMMdd'))))  as year ,      weekofyear(FROM_UNIXTIME((unix_timestamp(dateval ,'yyyyMMdd')))) as week ,       FROM_UNIXTIME((unix_timestamp(dateval ,'yyyyMMdd')) ,'u') as dayofweek,       Month(FROM_UNIXTIME((unix_timestamp(dateval ,'yyyyMMdd')))) as month,       Day(FROM_UNIXTIME((unix_timestamp(dateval ,'yyyyMMdd')))) as day     from nova where hits_hitnumber is null group by device_browser, device_browserversion, device_operatingsystemversion, device_operatingsystem,channelgrouping ,trafficsource_source,trafficsource_medium, hits_page_pagepath,dateval ")
    val first_hotlead_bqrows=sc.sql("select   2 as Metricstype, count(hits_hitnumber) as Metricsaggno, device_browser  as device_brow, device_browserversion  as device_brwvrsn,  device_operatingsystem as device_os,   device_operatingsystemversion   as device_osvrsn,    channelgrouping  ,    trafficsource_source,    trafficsource_medium,     hits_page_pagepath as landing_page_path,      YEAR(FROM_UNIXTIME((unix_timestamp(dateval ,'yyyyMMdd'))))  as year ,      weekofyear(FROM_UNIXTIME((unix_timestamp(dateval ,'yyyyMMdd')))) as week ,       FROM_UNIXTIME((unix_timestamp(dateval ,'yyyyMMdd')) ,'u') as dayofweek,       Month(FROM_UNIXTIME((unix_timestamp(dateval ,'yyyyMMdd')))) as month,       Day(FROM_UNIXTIME((unix_timestamp(dateval ,'yyyyMMdd')))) as day     from nova  where hits_hitnumber is not  null and hits_eventinfo_eventaction='first_hotlead'  group by device_browser, device_browserversion, device_operatingsystemversion, device_operatingsystem,channelgrouping ,trafficsource_source,trafficsource_medium, hits_page_pagepath,dateval")
    val final_aggdf=session_bqrows.unionAll(first_hotlead_bqrows)
    rowModifier(final_aggdf,sc)*/

    var finalbqaggdf:DataFrame =null;
    var finalbqaggrdd :RDD[Row]=null
    //hc.setConf("hive.exec.dynamic.partition", "true")
    //hc.setConf("hive.exec.dynamic.partition.mode", "nonstrict")

    var counter : Int  =0
    selectList.values.foreach(rw=> {
      bqdf.registerTempTable("nova")
      val parq = sc.sql(rw(1))
      //bqdf.printSchema()
      val reducerdd = parq.map(r => ((
        r.getAs[String](dimensionfields.device_category),
        r.getAs[String](dimensionfields.device_brow),
        r.getAs[String](dimensionfields.device_brwvrsn),
        r.getAs[String](dimensionfields.device_os),
        r.getAs[String](dimensionfields.device_osvrsn),
        r.getAs[String](dimensionfields.channelgrouping),
        r.getAs[String](dimensionfields.trafficsource_source),
        r.getAs[String](dimensionfields.trafficsource_medium),
        r.getAs[String](dimensionfields.landing_page_path),
        r.getAs[Int](dimensionfields.year),
        r.getAs[Int](dimensionfields.week),
        weekname(r.getAs[String](dimensionfields.dayofweek)),
        r.getAs[Int](dimensionfields.numdayofweek),
        r.getAs[Int](dimensionfields.month),
        r.getAs[Int](dimensionfields.day) ,
        r.getAs[String](dimensionfields.created_date)), (r.getAs[Long](dimensionfields.metrics_agg),1)))

      //reducerdd.take(1)
      val finalrdd = reducerdd.reduceByKey((agg, y) => (agg._1 + y._1, agg._2+y._2))


      var lastdf :RDD[Row]=null
      if (rw(0)=="sum")  {
        lastdf = finalrdd.map(rr => Row(rowconvertor(counter+1 , rr._1.productIterator.toList, rr._2._1): _*))
      } else {
        lastdf = finalrdd.map(rr => Row(rowconvertor(counter+1 , rr._1.productIterator.toList, rr._2._2): _*))
      }

     // lastdf.foreach(r=>println(r))
      //finalbqaggrdd.union(lastdf)

      //println(finalbqaggrdd.take(1))


      //val fulldf=hc.createDataFrame(lastdf, DimensionbuildSchema())
      //fulldf.write.mode("append").save(outputpath)

      try {
        var  fulldf= hc.createDataFrame(lastdf, DimensionbuildSchema())
        fulldf.write.mode("append").parquet(outputpath)

       // if (fulldf.count() >0 ) {
       //   fulldf.write.mode("append").partitionBy("created_date").insertInto(outputpath);
       // }
      } catch
        {
          case e: Exception => println("************** Error processing."); e.printStackTrace();
        }



      //fulldf.write.mode("append").save("/tmp/test_agg")
      //fulldf.write.mode("append").parquet(outputpath)
      //fulldf.write.format("csv").save(outputpath+"_"+counter)
      //fulldf.write.format("com.databricks.spark.csv").option("delimiter", "\t").save(outputpath+"_"+counter)

/*
      if (fulldf!=null) {
        if (finalbqaggdf==null) {
          finalbqaggdf=fulldf;
        } else {
          finalbqaggdf.unionAll(fulldf)
        }

      }*/
      //fulldf.write.mode("append").insertInto(outputpath)
      counter+=1
    })

/*
    if (finalbqaggdf!=null) {
      finalbqaggdf.write.mode("append").partitionBy("created_date").insertInto(outputpath);
    }
*/

  }

  def aggDailyMetricsVerification(bqdf: DataFrame ,sc:SQLContext): Unit = {

    var counter : Int  =0

    var finalbqaggrdd :RDD[Row]=null;

    aggmetrics.foreach(rw=> {
      bqdf.registerTempTable("nova")
      val parq = sc.sql(rw._2)
      //println(r)
      val aggval1=parq.take(1)(0)(0)

      println(rw._1+ aggval1)

      //through reduce Mechanism
      val reduceparq = sc.sql(selectList(rw._1)(1))
      val reducerdd = reduceparq.map(r => ((
        r.getAs[String](dimensionfields.device_category),
        r.getAs[String](dimensionfields.device_brow),
        r.getAs[String](dimensionfields.device_brwvrsn),
        r.getAs[String](dimensionfields.device_os),
        r.getAs[String](dimensionfields.device_osvrsn),
        r.getAs[String](dimensionfields.channelgrouping),
        r.getAs[String](dimensionfields.trafficsource_source),
        r.getAs[String](dimensionfields.trafficsource_medium),
        r.getAs[String](dimensionfields.landing_page_path),
        r.getAs[Int](dimensionfields.year),
        r.getAs[Int](dimensionfields.week),
        weekname(r.getAs[String](dimensionfields.dayofweek)),
        r.getAs[Int](dimensionfields.numdayofweek),
        r.getAs[Int](dimensionfields.month),
        r.getAs[Int](dimensionfields.day) ,
        r.getAs[String](dimensionfields.created_date)), (r.getAs[Long](dimensionfields.metrics_agg),1)))

      val finalrdd = reducerdd.reduceByKey((agg, y) => (agg._1 + y._1, agg._2+y._2))

      var lastdf :RDD[Row]=null

      if (selectList(rw._1)(0)=="sum")  {
        lastdf = finalrdd.map(rr => Row(rowconvertor(counter+1 , rr._1.productIterator.toList, rr._2._1): _*))
      } else {
        lastdf = finalrdd.map(rr => Row(rowconvertor(counter+1 , rr._1.productIterator.toList, rr._2._2): _*))
      }

      if (finalbqaggrdd ==null) {
        finalbqaggrdd=lastdf
      } else {
        finalbqaggrdd=finalbqaggrdd.union(lastdf)
      }

      //finalbqaggrdd.map(r=>r.getAs[Int](0)).collect().distinct.foreach(r=>println(rw._1+"hello "+r))

      val fulldf= sc.createDataFrame(lastdf, DimensionbuildSchema())



      fulldf.registerTempTable("nova2")

      val parq2 = sc.sql("select sum(metric_value) from  nova2")

      //parq2.take(1).foreach(r=> rw._1 +println(r))

      val aggval2=parq2.take(1)(0)(0)
      println( "comparing count for " +rw._1)
      assert(aggval1==aggval2)
      counter+=1
    })






  }

  def rowconvertor(metricsType: Int,  keytuple :List[Any] ,aggval :Long): ListBuffer[Any] = {
    val recBuff = ListBuffer.empty[Any]
    recBuff+=metricsType
    keytuple.foreach(r=>recBuff+=r)
    recBuff+=aggval
    val tmp=recBuff.remove(recBuff.length-1)
    recBuff.insert(1,tmp)
    recBuff
  }



  def weekname( data :String): String={
    var mdata :String =null;
    val weekday= data.toInt;
    if (weekday<=7) {mdata=DayofWeek(weekday) }
  mdata
  }


def rowModifier(bqdf: DataFrame  ,sc:SQLContext): Unit = {
try {

  val datardd =bqdf.rdd.map(r=> Row(r.getAs[Int](dimensiongrouped.Metricstype) ,
    r.getAs[Long](dimensiongrouped.Metricsaggno),
    r.getAs[String](dimensiongrouped.device_brow),
      r.getAs[String](dimensiongrouped.device_brwvrsn),
    r.getAs[String](dimensiongrouped.device_os),
  r.getAs[String](dimensiongrouped.device_osvrsn),
    r.getAs[String](dimensiongrouped.channelgrouping),
      r.getAs[String](dimensiongrouped.trafficsource_source),
    r.getAs[String](dimensiongrouped.trafficsource_medium),
  r.getAs[Int](dimensiongrouped.landing_page_path),
    r.getAs[Int](dimensiongrouped.year),
    r.getAs[Int](dimensiongrouped.week),
    weekname(r.getAs[String](dimensiongrouped.dayofweek)),
    r.getAs[Int](dimensiongrouped.month),
    r.getAs[Int](dimensiongrouped.day)
  ))

  val finalrdd= sc.createDataFrame(datardd ,DimensionbuildSchema())

  finalrdd.write.mode("append").save("/tmp/test_agg")

}catch {
  case e: Exception => println("************** Error processing.");
    e.printStackTrace();
    sys.exit(0);
}
}


}








