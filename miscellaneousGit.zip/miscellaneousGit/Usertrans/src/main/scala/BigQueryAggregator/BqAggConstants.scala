package BigQueryAggregator

import scala.collection.mutable.LinkedHashMap

object BqAggConstants {
  
 
  object dimensiongrouped extends java.io.Serializable {
    val Metricstype = 0
    val Metricsaggno = 1
    val device_brow = 2
    val device_brwvrsn = 3
    val device_os = 4
    val device_osvrsn = 5
    val channelgrouping = 6
    val trafficsource_source = 7
    val trafficsource_medium = 8
    val landing_page_path = 9
    val year = 10
    val week = 11
    val dayofweek = 12
    val month = 13
    val day = 14;
  }

  object dimensionfields extends java.io.Serializable {
    val metrics_agg=0
    val device_category = 1
    val device_brow = 2
    val device_brwvrsn = 3
    val device_os = 4
    val device_osvrsn = 5
    val channelgrouping = 6
    val trafficsource_source = 7
    val trafficsource_medium = 8
    val landing_page_path = 9
    val year = 10
    val week = 11
    val dayofweek = 12
    val numdayofweek = 13
    val month = 14
    val day = 15
    val created_date = 16;
  }

  val selectList :LinkedHashMap[String ,List[String]] = LinkedHashMap(
    "sessions_sql"-> List("sum", "select total_visits,device_devicecategory as platform, device_browser as browser_name, device_browserversion  as browser_version,  device_operatingsystem as os_name,   device_operatingsystemversion   as os_version,    channelgrouping  as channel_grouping   ,    trafficsource_source,    trafficsource_medium,     hits_page_pagepath as landing_page_path,      YEAR(FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd'))))  as year ,      weekofyear(FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd')))) as week ,    FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd')) ,'u') as dayofweek, FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd')) ,'u') as numdayofweek,  Month(FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd')))) as month,       Day(FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd')))) as day ,created_date from nova where hits_hitnumber is null"),
    "page_views_sql"-> List("sum","select total_pageviews, device_devicecategory as platform, device_browser as browser_name, device_browserversion  as browser_version,  device_operatingsystem as os_name,   device_operatingsystemversion   as os_version,    channelgrouping  as channel_grouping   ,    trafficsource_source,    trafficsource_medium,     hits_page_pagepath as landing_page_path,      YEAR(FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd'))))  as year ,      weekofyear(FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd')))) as week ,       FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd')) ,'u') as dayofweek, FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd')) ,'u') as numdayofweek,  Month(FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd')))) as month,       Day(FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd')))) as day ,created_date  from nova where hits_hitnumber is null"),
    "lead_received_sql"-> List("count","select hits_hitnumber, device_devicecategory as platform, device_browser as browser_name, device_browserversion  as browser_version,  device_operatingsystem as os_name,   device_operatingsystemversion   as os_version,    channelgrouping  as channel_grouping    ,    trafficsource_source,    trafficsource_medium,     hits_page_pagepath as landing_page_path,      YEAR(FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd'))))  as year ,      weekofyear(FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd')))) as week ,       FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd')) ,'u') as dayofweek, FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd')) ,'u') as numdayofweek,  Month(FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd')))) as month,       Day(FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd')))) as day ,created_date from nova where hits_hitnumber is not  null and hits_eventinfo_eventlabel='lead-received'"),
    "firsthotlead_sql"-> List("count","select hits_hitnumber,device_devicecategory as platform, device_browser as browser_name, device_browserversion  as browser_version,  device_operatingsystem as os_name,   device_operatingsystemversion   as os_version,    channelgrouping  as channel_grouping  ,    trafficsource_source,    trafficsource_medium,     hits_page_pagepath as landing_page_path,      YEAR(FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd'))))  as year ,      weekofyear(FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd')))) as week ,       FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd')) ,'u') as dayofweek, FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd')) ,'u') as numdayofweek,  Month(FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd')))) as month,       Day(FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd')))) as day ,created_date from nova where hits_hitnumber is not  null and hits_eventinfo_eventaction='first_hotlead'"),
    "uniquelead_sql"-> List("count","select hits_hitnumber, device_devicecategory as platform, device_browser as browser_name, device_browserversion  as browser_version,  device_operatingsystem as os_name,   device_operatingsystemversion   as os_version,    channelgrouping  as channel_grouping  ,    trafficsource_source,    trafficsource_medium,     hits_page_pagepath as landing_page_path,      YEAR(FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd'))))  as year ,      weekofyear(FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd')))) as week ,       FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd')) ,'u') as dayofweek, FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd')) ,'u') as numdayofweek,  Month(FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd')))) as month,       Day(FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd')))) as day ,created_date from nova where hits_hitnumber is not  null and hits_eventinfo_eventaction='unique_lead'"),
    "billablelead_sql"-> List("count","select hits_hitnumber, device_devicecategory as platform, device_browser as browser_name, device_browserversion  as browser_version,  device_operatingsystem as os_name,   device_operatingsystemversion   as os_version,    channelgrouping  as channel_grouping   ,    trafficsource_source,    trafficsource_medium,     hits_page_pagepath as landing_page_path,      YEAR(FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd'))))  as year ,      weekofyear(FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd')))) as week ,       FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd')) ,'u') as dayofweek, FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd')) ,'u') as numdayofweek,  Month(FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd')))) as month,       Day(FROM_UNIXTIME((unix_timestamp(created_date ,'yyyyMMdd')))) as day ,created_date from nova where hits_hitnumber is not  null and hits_eventinfo_eventaction='billable_lead'")
  )



val aggmetrics:LinkedHashMap[String ,String] = LinkedHashMap(
 "sessions_sql"-> "select sum(total_visits) from nova where hits_hitnumber is null",
 "page_views_sql"-> "select sum(total_pageviews) from nova where hits_hitnumber is null",
  "lead_received_sql"->"select count(hits_hitnumber) from nova where hits_hitnumber is not  null and hits_eventinfo_eventlabel='lead-received'",
 "firsthotlead_sql"->"select count(hits_hitnumber) from nova where hits_hitnumber is not  null and hits_eventinfo_eventaction='first_hotlead'",
  "uniquelead_sql"->"select count(hits_hitnumber) from nova where hits_hitnumber is not  null and hits_eventinfo_eventaction='unique_lead'",
  "billablelead_sql"->"select count(hits_hitnumber) from nova where hits_hitnumber is not  null and hits_eventinfo_eventaction='billable_lead'"
 )



  val DayofWeek: LinkedHashMap[Int ,String] = LinkedHashMap(
    1-> "Monday",
    2-> "Tuesday",
    3-> "Wednesday",
    4-> "Thursday",
    5-> "Friday",
    6-> "Saturday",
    7-> "Sunday"
  )


}