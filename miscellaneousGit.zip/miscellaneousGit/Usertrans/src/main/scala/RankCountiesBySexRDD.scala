/**
  * Created by manoj on 3/11/17.
  */


/*
import org.apache.spark
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{DataTypes, StructField, StructType}
import org.apache.spark.sql._
import org.apache.spark.sql.functions._
import org.apache.spark.{SparkConf, SparkContext}

object RankCountiesBySexRDD {

  def main(arg: Array[String]): Unit = {

    val sparkSession = SparkSession.builder
      .master("local[*]")
      .appName("Example")
      .getOrCreate()

    import sparkSession.implicits._
    case class Geo(logrecno: String, name: String, sumlev: String)

    case class Population(logrecno: String, male: Int, female: Int)

    case class CountyPopulation(county: String, male: Int, female: Int)


    var geoRDD: RDD[Geo] = sparkSession.sparkContext.textFile("src/main/scala/testdata/co000162010.sf1.csv")
      .map( x => x.split(",") ).map( x=> Geo(x(0),x(8) ,x(1)))

    val populationRDD: RDD[Population] = sparkSession.sparkContext.textFile("src/main/scala/testdata/co000162010.sf1.csv")
      .map(row => row.split(","))
      .map(csv => Population(csv(0), csv(6).toInt, csv(30).toInt))

    // create pair RDDs
    val geoPair: RDD[(String, Geo)] = geoRDD.map(geo => (geo.logrecno, geo))
    val popPair: RDD[(String, Population)] = populationRDD.map(p => (p.logrecno, p))

    // join
    val join: RDD[(String, (Geo, Population))] = geoPair.join(popPair)
    println("userjoined"+ join.take(10).foreach(println))

    println("Finaljoin"+ join.count)
    // flatten
    val flatRDD: RDD[CountyPopulation] = join.map((tuple: (String, (Geo, Population)))
    => CountyPopulation(tuple._2._1.name, tuple._2._2.male, tuple._2._2.female))

    // show top N
    flatRDD.sortBy((p: CountyPopulation) => p.male*1.0f/p.female, ascending = true)
      .zipWithIndex()
      .filter((t: (CountyPopulation, Long)) => t._2 < 10)
      .foreach(println)

  }

}

*/
