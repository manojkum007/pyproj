/**
  * Created by manoj on 15/11/17.
  */

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path};


object SFDC {
  def main(args: Array[String]) {

    //Create Spark Context
    import org.apache.spark._
    val conf = new SparkConf().setAppName("SFDC")
    val sc = new SparkContext(conf)
    val rhino_path :String="hdfs://192.168.120.140:9000"
    //val rhino_path :String="hdfs://localhost:54310"
    var bqrawtable:String=""
    var outputpath :String=""
    var run_date :String=""
    var get_all:String=""
    var get_all_flag:String=""


    if (args.length > 3) {
       bqrawtable =  args(0).toString
       outputpath = args(1).toString
       run_date=args(2)
        get_all=args(3)
    } else {
      println(" sorry no parameter passed")
      System.exit(-1)
    }

     if (get_all.contains("True")) {  get_all_flag =" <= "
    } else {
      get_all_flag =" = "
    }



    val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)




    val pone="/user/hive/warehouse/bq_nova.db/sessions_hits_parquet_newschema/updated_date=2017-04-18"

    if (bqrawtable.toString.length>0) {
      val parqfile=sqlContext.read.parquet(bqrawtable.toString)
      parqfile.registerTempTable("sessions_hits_parquet_newschema")

     // "select * from sessions_hits_parquet_newschema where (cast(hitarray.eventinfo.eventlabel AS string) like '%lead-received%'  or  cast(hitarray.eventinfo.eventlabel AS string) like '%lead-confirmed%' or cast(hitarray.eventinfo.eventaction AS string) like '%first_hotlead%')"


    }

    val adword_click_perf_report = sqlContext.read.parquet("/user/hive/warehouse/adwords.db/click_performance_report")
    adword_click_perf_report.registerTempTable("click_performance_report")


    val adword_keyword_perf_report = sqlContext.read.parquet("/user/hive/warehouse/adwords.db/keywords_performance_report")
    adword_keyword_perf_report.registerTempTable("keywords_performance_report")

    val adword_final_url_report = sqlContext.read.parquet("/user/hive/warehouse/adwords.db/final_url_report")
    adword_final_url_report.registerTempTable("final_url_report")

    val adword_placement_performance_report = sqlContext.read.parquet("/user/hive/warehouse/adwords.db/placement_performance_report")
    adword_placement_performance_report.registerTempTable("placement_performance_report")


    val adword_adgroup_performance_report = sqlContext.read.parquet("/user/hive/warehouse/adwords.db/adgroup_performance_report")
    adword_adgroup_performance_report.registerTempTable("adgroup_performance_report")


    val adword_ad_performance_report = sqlContext.read.parquet("/user/hive/warehouse/adwords.db/ad_performance_report")
    adword_ad_performance_report.registerTempTable("ad_performance_report")






/*
val session_data=sqlContext.sql(
  """ select
    |fullvisitorid  from sessions_hits_parquet_newschema where `date`='20171113' limit 10  """.stripMargin)
*/

/*

    val session_data=sqlContext.sql(
      """SELECT  *  FROM      (
                         SELECT fullvisitorid ,
                                trafficsource_referralpath,
                                trafficsource_campaign,
                                trafficsource_source,
                                trafficsource_medium,
                                trafficsource_keyword,
                                trafficsource_adwordsclickinfo_campaignid ,
                                trafficsource_adwordsclickinfo_adgroupid ,
                                trafficsource_adwordsclickinfo_creativeid ,
                                trafficsource_adwordsclickinfo_criteriaid ,
                                trafficsource_adwordsclickinfo_page ,
                                trafficsource_adwordsclickinfo_slot ,
                                trafficsource_adwordsclickinfo_criteriaparameters ,
                                trafficsource_adwordsclickinfo_gclid ,
                                trafficsource_adwordsclickinfo_customerid ,
                                trafficsource_adwordsclickinfo_adnetworktype ,
                                trafficsource_adwordsclickinfo_isvideoad ,
                                trafficsource_adwordsclickinfo_targetingcriteria_boomuserlistid ,
                                device_mobiledevicemarketingname ,
                                geonetwork_city ,
                                hits_hitnumber,
                                hits_time ,
                                hits_hour ,
                                hits_minute ,
                                visitnumber ,
                                visitid ,
                                Cast( visitid+(hits_time/1000) AS TIMESTAMP) AS event_timestamp,
                                hits_eventinfo_eventaction ,
                                hits_eventinfo_eventlabel ,
                                `date`,
                                hits_customdimensions_index_32
                         FROM   sessions_hits_parquet_newschema
                         WHERE  `date` = '20171113' ) bq
               LEFT JOIN
                          (
                            SELECT    clicks.report_date,
                                      clicks.gclid AS adwordgclid,
                                      clicks.ad_format,
                                      clicks.ad_group_id,
                                      clicks.ad_id,
                                      clicks.campaign_id,
                                      clicks.device,
                                      clicks.keyword_id,
                                      clicks.keyword_match_type,
                                      clicks.keyword_placement,
                                      clicks.slot,
                                      clicks.ad_network_type_1,
                                      clicks.ad_network_type_2,
                                      keywords.keyword AS adwordkeyword,
                                      keywords.match_type
                            FROM      click_performance_report clicks
                            LEFT JOIN
                                      (
                                                      SELECT DISTINCT keyword_id,
                                                                      match_type,
                                                                      keyword
                                                      FROM            keywords_performance_report ) keywords
                            ON        clicks.keyword_id = keywords.keyword_id
                            LEFT JOIN
                                      (
                                                      SELECT DISTINCT ad_group_id,
                                                                      campaign_id,
                                                                      final_url
                                                      FROM            final_url_report ) url
                            ON        clicks.ad_group_id = url.ad_group_id
                            AND       clicks.campaign_id = url.campaign_id
                            LEFT JOIN
                                      (
                                                      SELECT DISTINCT criterion_id,
                                                                      placement,
                                                                      criteria_display_name
                                                      FROM            placement_performance_report ) placement
                            ON        clicks.keyword_id = placement.criterion_id
                            LEFT JOIN
                                      (
                                                      SELECT DISTINCT ad_group_id,
                                                                      ad_group
                                                      FROM            adgroup_performance_report ) adgroups
                            ON        clicks.ad_group_id = adgroups.ad_group_id
                            LEFT JOIN
                                      (
                                                      SELECT DISTINCT ad_id,
                                                                      image_ad_name
                                                      FROM            ad_performance_report ) adreports
                            ON        clicks.ad_id = adreports.ad_id) aw
        ON        aw.adwordgclid = bq.trafficsource_adwordsclickinfo_gclid limit 10""")

    val newrdd=sc.parallelize(session_data.collect())
    */

    val config = new Configuration()
    config.set("fs.defaultFS", rhino_path)
    val fs= FileSystem.get(config)
    if ( fs.exists(new Path(outputpath.toString))) {
      fs.delete(new Path(outputpath.toString))

    }

/*
    val finalrdd=sqlContext.sql(""" select *  from (select * , rank() over(partition by test.hotleadid order by lead_priority asc) as finalpriority from ( select t.* , min(lead_priority)  over (partition by t.hotleadid order by t.lead_priority asc  ) as lpriority from (select  *, case  when eventaction like '%first_hotlead%'  then 1
when eventlabel like '%lead-received%'  then 2
when eventlabel like '%lead-confirmed%'  then 3
else 0 end as lead_priority  from (SELECT cast(a.fullvisitorid AS string)              AS fullvisitorid,
                        cast(a.trafficsource.referralpath AS string) AS referralpath,
                        cast(a.trafficsource.campaign AS string)     AS campaign,
                        cast(a.trafficsource.source AS string)       AS trafficsource,
                        cast(a.trafficsource.medium AS string)       AS medium,
                        cast(a.trafficsource.keyword AS string)      AS keyword,
                        a.trafficsource.adwordsclickinfo.campaignid,
                        a.trafficsource.adwordsclickinfo.adgroupid,
                        a.trafficsource.adwordsclickinfo.creativeid,
                        a.trafficsource.adwordsclickinfo.criteriaid,
                        a.trafficsource.adwordsclickinfo.page,
                        cast(a.trafficsource.adwordsclickinfo.slot AS string)               AS adworkclickslot,
                        cast(a.trafficsource.adwordsclickinfo.criteriaparameters AS string) AS criteriaparameters,
                        cast(a.trafficsource.adwordsclickinfo.gclid AS string)              AS gclid,
                        a.trafficsource.adwordsclickinfo.customerid,
                        cast(a.trafficsource.adwordsclickinfo.adnetworktype AS string) AS adworkclicknetworktype,
                        a.trafficsource.adwordsclickinfo.targetingcriteria.boomuserlistid,
                        a.trafficsource.adwordsclickinfo.isvideoad,
                        cast(a.device.mobiledevicemarketingname AS string) AS mobiledevicemarketingname,
                        cast(a.geonetwork.city AS string)                  AS city,
                        hitarray.hitnumber,
                        hitarray.`time`   AS event_time,
                        hitarray.`hour`   AS event_hour,
                        hitarray.`minute` AS event_minute,
                        a.visitnumber,
                        a.visitid,
                        cast( visitid+(hitarray.`time`/1000) AS timestamp) AS event_timestamp,
                        cast(hitarray.eventinfo.eventaction AS string)     AS eventaction,
                        cast(hitarray.eventinfo.eventlabel AS string)      AS eventlabel,
                        cast(a.`date` AS string)                           AS visitdate,
                        cast(custom.`value` AS string)                     AS hotleadid,
                        cast(custom.`INDEX` AS string)                     AS customindex
                 FROM   sessions_hits_parquet_newschema a lateral VIEW explode(hits.`array`) c       AS hitarray lateral VIEW explode(hitarray.customdimensions.`array`) d AS custom
                 WHERE     custom.`INDEX`=32
                 AND    (cast(hitarray.eventinfo.eventlabel AS string) like '%lead-received%'  or  cast(hitarray.eventinfo.eventlabel AS string) like '%lead-confirmed%' or cast(hitarray.eventinfo.eventaction AS string) like '%first_hotlead%') ) bigquery_flattened ) t where  t.lead_priority>0 ) test  ) test1 where test1.finalpriority=1""")

*/
    var matched_query=""" SELECT  *  FROM      (select *  from (select * , rank() over(partition by test.hotleadid order by lead_priority asc) as finalpriority from ( select t.* , min(lead_priority)  over (partition by t.hotleadid order by t.lead_priority asc  ) as lpriority from (select  *, case  when eventaction like '%first_hotlead%'  then 1
                             when eventlabel like '%lead-received%'  then 2
                             when eventlabel like '%lead-confirmed%'  then 3
                             else 0 end as lead_priority  from (SELECT cast(a.fullvisitorid AS string)              AS fullvisitorid,
                                                     cast(a.trafficsource.referralpath AS string) AS referralpath,
                                                     cast(a.trafficsource.campaign AS string)     AS campaign,
                                                     cast(a.trafficsource.source AS string)       AS trafficsource,
                                                     cast(a.trafficsource.medium AS string)       AS medium,
                                                     cast(a.trafficsource.keyword AS string)      AS keyword,
                                                     a.trafficsource.adwordsclickinfo.campaignid,
                                                     a.trafficsource.adwordsclickinfo.adgroupid,
                                                     a.trafficsource.adwordsclickinfo.creativeid,
                                                     a.trafficsource.adwordsclickinfo.criteriaid,
                                                     a.trafficsource.adwordsclickinfo.page,
                                                     cast(a.trafficsource.adwordsclickinfo.slot AS string)               AS adworkclickslot,
                                                     cast(a.trafficsource.adwordsclickinfo.criteriaparameters AS string) AS criteriaparameters,
                                                     cast(a.trafficsource.adwordsclickinfo.gclid AS string)              AS gclid,
                                                     a.trafficsource.adwordsclickinfo.customerid,
                                                     cast(a.trafficsource.adwordsclickinfo.adnetworktype AS string) AS adworkclicknetworktype,
                                                     a.trafficsource.adwordsclickinfo.targetingcriteria.boomuserlistid,
                                                     a.trafficsource.adwordsclickinfo.isvideoad,
                                                     cast(a.device.mobiledevicemarketingname AS string) AS mobiledevicemarketingname,
                                                     cast(a.geonetwork.city AS string)                  AS city,
                                                     hitarray.hitnumber,
                                                     hitarray.`time`   AS event_time,
                                                     hitarray.`hour`   AS event_hour,
                                                     hitarray.`minute` AS event_minute,
                                                     a.visitnumber,
                                                     a.visitid,
                                                     cast( visitid+(hitarray.`time`/1000) AS timestamp) AS event_timestamp,
                                                     cast(hitarray.eventinfo.eventaction AS string)     AS eventaction,
                                                     cast(hitarray.eventinfo.eventlabel AS string)      AS eventlabel,
                                                     cast(a.`date` AS string)                           AS visitdate,
                                                     cast(custom.`value` AS string)                     AS hotleadid,
                                                     cast(custom.`INDEX` AS string)                     AS customindex
                                              FROM   sessions_hits_parquet_newschema a lateral VIEW explode(hits.`array`) c       AS hitarray lateral VIEW explode(hitarray.customdimensions.`array`) d AS custom
                                              WHERE     custom.`INDEX`=32
                                              AND    (cast(hitarray.eventinfo.eventlabel AS string) like '%lead-received%'  or  cast(hitarray.eventinfo.eventlabel AS string) like '%lead-confirmed%' or cast(hitarray.eventinfo.eventaction AS string) like '%first_hotlead%') ) bigquery_flattened ) t where  t.lead_priority>0 ) test  ) test1 where test1.finalpriority=1 ) bq
                                            LEFT JOIN
                                                       (
                                                         SELECT    clicks.report_date,
                                                                   clicks.gclid AS adwordgclid,
                                                                   clicks.ad_format,
                                                                   clicks.ad_group_id,
                                                                   clicks.ad_id,
                                                                   clicks.campaign_id,
                                                                   clicks.device,
                                                                   clicks.keyword_id,
                                                                   clicks.keyword_match_type,
                                                                   clicks.keyword_placement,
                                                                   clicks.slot,
                                                                   clicks.ad_network_type_1,
                                                                   clicks.ad_network_type_2,
                                                                   keywords.keyword AS adwordkeyword,
                                                                   keywords.match_type,
                                                                   url.final_url,
                                                                   placement.placement,
                                                                   placement.criteria_display_name,
                                                                   adgroups.ad_group,
                                                                   adreports.image_ad_name
                                                         FROM      click_performance_report clicks
                                                         LEFT JOIN
                                                                   (
                                                                                   SELECT DISTINCT keyword_id,
                                                                                                   match_type,
                                                                                                   keyword
                                                                                   FROM            keywords_performance_report ) keywords
                                                         ON        clicks.keyword_id = keywords.keyword_id
                                                         LEFT JOIN
                                                                   (
                                                                                   SELECT DISTINCT ad_group_id,
                                                                                                   campaign_id,
                                                                                                   final_url
                                                                                   FROM            final_url_report ) url
                                                         ON        clicks.ad_group_id = url.ad_group_id
                                                         AND       clicks.campaign_id = url.campaign_id
                                                         LEFT JOIN
                                                                   (
                                                                                   SELECT DISTINCT criterion_id,
                                                                                                   placement,
                                                                                                   criteria_display_name
                                                                                   FROM            placement_performance_report ) placement
                                                         ON        clicks.keyword_id = placement.criterion_id
                                                         LEFT JOIN
                                                                   (
                                                                                   SELECT DISTINCT ad_group_id,
                                                                                                   ad_group
                                                                                   FROM            adgroup_performance_report ) adgroups
                                                         ON        clicks.ad_group_id = adgroups.ad_group_id
                                                         LEFT JOIN
                                                                   (
                                                                                   SELECT DISTINCT ad_id,
                                                                                                   image_ad_name
                                                                                   FROM            ad_performance_report ) adreports
                                                         ON        clicks.ad_id = adreports.ad_id) aw
                                     ON        aw.adwordgclid = bq.gclid  and cast(aw.report_date as date) [get_all] '[run_date]'""".replace("[get_all]",get_all_flag)


    matched_query=matched_query.replace("[run_date]",run_date)

    println("final res "+ matched_query)
    val finalrdd=sqlContext.sql(matched_query)
    finalrdd.write.format("com.databricks.spark.csv").save(outputpath)


    val final_result=sc.parallelize(finalrdd.map(_.toSeq.toArray).collect)
                      .map(r=>r.mkString("\t"))
                      .saveAsTextFile(outputpath)





  }

}
