/**
  * Created by manoj on 15/11/17.
  */

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.Path
import org.apache.spark.rdd._
import org.apache.spark.sql
import java.text.SimpleDateFormat

import org.apache.spark.sql.functions._
import org.apache.spark.sql.Row
import org.apache.spark.sql.types._
import org.joda.time.DateTime

import scala.collection.mutable.ListBuffer;





object AccessLog {
  def main(args: Array[String]) {

    //Create Spark Context
    import org.apache.spark._
    val conf = new SparkConf().setAppName("SFDC")
    val sc = new SparkContext(conf)
    val rhino_path :String="hdfs://192.168.120.128:9000"
    //val rhino_path :String="hdfs://localhost:54310"
    var bqrawtable:String=""
    var outputpath :String=""
    var start_date :String=""
    var end_date :String=""
    var get_all:String=""
    var get_all_flag:String=""



/*
    if (args.length > 4) {
      bqrawtable =  args(0).toString
      outputpath = args(1).toString
      start_date=args(2)
      end_date=args(3)
      get_all=args(4)
    } else {
      println(" sorry no parameter passed")
      System.exit(-1)
    }

    */
    var bqdates = ListBuffer[String]()

    val inputFormat = new SimpleDateFormat("yyyy-MM-dd")
    val outputFormat = new SimpleDateFormat("yyyyMMdd")

    outputpath= "/tmp/commondf"

    val config = new Configuration()
    config.set("fs.defaultFS", rhino_path)
    val fs= FileSystem.get(config)
    if ( fs.exists(new Path(outputpath.toString))) {
      fs.delete(new Path(outputpath.toString))

    }

    //bqdates=partitiongenerator(start_date ,end_date).map(  e=>bqrawtable+"/date="+outputFormat.format(inputFormat.parse(e)))

    //bqdates.foreach(println)



    if (get_all.contains("yes")) {
      get_all_flag =" <= "

    } else {
      get_all_flag =" = "

      //val inputFormat = new SimpleDateFormat("yyyy-MM-dd")
      //val outputFormat = new SimpleDateFormat("yyyyMMdd")

      //val formattedDate = outputFormat.format(inputFormat.parse(run_date))
      //bqrawtable+="/date="+formattedDate
    }

    println("path checked" + bqdates )

    val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)



/*
    val listingtable="hdfs://localhost:54310/user/hive/warehouse/mls.db/mls_listing_snapshot_parq"
     val addresstable="hdfs://localhost:54310/user/hive/warehouse/mls.db/mls_address_snapshot_delta"
    val attributetable="hdfs://localhost:54310/user/hive/warehouse/mls.db/attribute"



    val listingtable="/user/hive/warehouse/mlstemp.db/mls_listing_parq"
    val addresstable="/user/hive/warehouse/mlstemp.db/address_snapshot_par"

    val attributetable="/user/hive/warehouse/mlstemp.db/attribute"
*/

    val listingtable="/user/hive/warehouse/mls.db/mls_listing_snapshot_orc_load"
    val addresstable="/user/hive/warehouse/mls.db/mls_address_snapshot_orc_load"

    val attributetable="/user/hive/warehouse/mls.db/mls_attribute_orc_load"



    val listparqdf=sqlContext.read.parquet(listingtable)
    listparqdf.registerTempTable("listing")


    val addressdf=sqlContext.read.parquet(addresstable)
        addressdf.registerTempTable("address")


    val attributedf=sqlContext.read.parquet(attributetable)
    attributedf.registerTempTable("attribute")



   val listprimarydf=  listparqdf.select("mls_address_id")
    val addressprimarydf =addressdf.select("id")


    //val commondf=listprimarydf.rdd.intersection(addressprimarydf.rdd)


    val commondf=listprimarydf.join(addressprimarydf , (listprimarydf.col("mls_address_id") === addressprimarydf.col("id")) , "inner")

    //val bcast_cust_table=sc.broadcast(commondf);

    //commondf.saveAsParquetFile(outputpath)


    val broadcastList = sc.broadcast(commondf.map(r=>r(0).toString).collect)


    val listingnewdf=listparqdf.filter(col("mls_address_id").isin(broadcastList.value : _*))


    val addressnewdf=addressdf.filter(col("id").isin(broadcastList.value : _*))




    val joineddf=listingnewdf.join(addressnewdf, (listingnewdf.col("mls_address_id") === addressnewdf.col("id")) ,"left").drop(addressnewdf.col("created_at")).drop(addressnewdf.col("updated_at"))

    val finaljoineddf=joineddf.join(attributedf, (joineddf.col("standard_status") === attributedf.col("id") ) ,"left").drop(attributedf.col("created_at")).drop(attributedf.col("updated_at"))

    val fullfinaljoineddf=joineddf.join(attributedf, (joineddf.col("property_type") === attributedf.col("id") ) ,"left").drop(attributedf.col("created_at")).drop(attributedf.col("updated_at"))

   // StructType(StructField(_1,StringType,true), StructField(_2,StructType(StructField(_1,IntegerType,false), StructField(_2,StructType(StructField(_1,IntegerType,false), StructField(_2,IntegerType,false)),true)),true))


   /*
      dd.fields.foreach(r=> if (r.dataType.isInstanceOf[StringType]) { println(r.name)})



      val s=dd.fields(0)
      def matcher (x:Any) {
        s match {
          case s.dataType.isInstanceOf[StringType]=>println("String")
          case _ => println("else")
        }

      }*/







    //
    // || joineddf.col("property_type") === attributedf.col("id") ) ,"inner")

    //listparqdf.filter(listparqdf.select("mls_address_id").isNull )

/*
    val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)

    val listingtable="/user/hive/warehouse/inventorystats_newraw"

      val novadfpath="/home/manoj/spark_helper/2017-04-07_071416-m-00004.snappy.parquet"



    val novadf=sqlContext.read.parquet(novadfpath)
*/





  }



  def partitiongenerator( sdate:String,  edate:String) :ListBuffer[String]= {
    val buf = new ListBuffer[String]
    var t1=DateTime.parse(sdate).getDayOfYear
    var t2=DateTime.parse(edate).getDayOfYear

    //buf+=DateTime.parse(sdate).toString("YYYY-MM-dd")
    //  println(DateTime.parse(sdate).getYear)
    // println(DateTime.parse(edate).getYear)
    if (DateTime.parse(edate).getYear<=DateTime.parse(sdate).getYear) {
      for (i <- 0 to t2-t1) {
        val d = DateTime.parse(sdate).plusDays(i).toString("YYYY-MM-dd")
        buf+=d
      }

    } else
    {
      var datediff :Int=0;
      if (DateTime.parse(sdate).getYearOfEra%4==0){datediff=(366-t1)+t2 }
      else { datediff=(365-t1)+t2}


      for (i <- 0 to datediff) {
        val d = DateTime.parse(sdate).plusDays(i).toString("YYYY-MM-dd")
        buf+=d
      }

    }

    //buf+=DateTime.parse(edate).toString("YYYY-MM-dd")
    buf

  }

}


