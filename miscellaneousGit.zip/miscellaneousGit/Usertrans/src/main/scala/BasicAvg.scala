/**
  * Created by manoj on 7/11/17.
  */


import org.apache.spark.sql.DataFrame


case class SimpsonCharacter(name: String, actor: String, episodeDebut: String)
case class Auction(auctionid: String, bid: Float, bidtime: Float, bidder: String, bidderrate: Integer, openbid: Float, price: Float, item: String, daystolive: Integer)


object BasicAvg {

  def main(args: Array[String]): Unit = {

    import org.apache.spark._
    val conf = new SparkConf().setAppName("BasicAvg").setMaster("local[2]")
    val sc = new SparkContext(conf)

    val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)




/*
    val simpsonsDF = sc.parallelize(
      SimpsonCharacter("Homer", "Dan Castellaneta", "Good Night") ::
        SimpsonCharacter("Marge", "Julie Kavner", "Good Night") ::
        SimpsonCharacter("Bart", "Nancy Cartwright", "Good Night") ::
        SimpsonCharacter("Lisa", "Yeardley Smith", "Good Night") ::
        SimpsonCharacter("Maggie", "Liz Georges and more", "Good Night") ::
        SimpsonCharacter("Sideshow Bob", "Kelsey Grammer", "The Telltale Head") ::
        Nil).toDF().repartition(1)*/



    val ebaydf = sc.textFile("/home/manoj/miscellaneousGit/sparkdataframeexample/ebay.csv")

   /* val auctionRDD  =ebaydf.map(row=>row.split(",")).map(newdf=>Auction(
      newdf(0),newdf(1).toFloat,newdf(2).toFloat,newdf(3),newdf(4).toInt,newdf(5).toFloat,newdf(6).toFloat,newdf(7),newdf(8).toInt))
*/
    val auctionRDD = sc.textFile("/home/manoj/miscellaneousGit/sparkdataframeexample/ebay.csv")
      .map(_.split(",")).
      map(p =>Auction(p(0),p(1).toFloat,p(2).toFloat,p(3),p(4).toInt,p(5).toFloat,p(6).toFloat,p(7),p(8).toInt ))
/*

    val apair = auctionRDD.map(auction=>((auction.auctionid,auction.item), (auction.bid, 1)))

    val atotalcount = apair.reduceByKey((x,y) => (x._1 + y._1, x._2 + y._2))
    atotalcount.take(10).foreach(println)
*/

    //optbay.toDF().select("auctionid").distinct.count
   /* println(for (elem <- optbay.take(3)) {println(elem)})

    val nebaydf= optbay.toDF()

    println(nebaydf.select($"auctionid").distinct.count)

    */



    //val resultantrdd=input.filter(r=> (r.contains("No of matching record")))

    //resultantrdd.foreach(println)
    //println("count"+resultantrdd.count())
    sc.stop()

  }
/*
  def avgByItem(autionrdd :RDD[Auction]): Unit =  {

       (autionrdd groupBy("auctionid", "item")).count

  }*/

  def pushtoElasticSearch(df :DataFrame): Unit ={
    println("pushing started")
    /*

 optbay.toDF().write.format("org.elasticsearch.spark.sql")
   .option("es.nodes" , "192.168.120.135:9200,192.168.120.136:9200")
   .option("es.port","9200")
   .mode("Append")
   .save("megacorp/ebaymultiple")
 */


    /*
        aggsparkdf.toDF().write.format("org.elasticsearch.spark.sql")
          .option("es.nodes" , "192.168.120.21")
          .option("es.port","9200")
          .mode("Append")
          .save("/sparkpost_test/metric_agg")*/



    df.toDF().write.format("org.elasticsearch.spark.sql")
      .option("es.nodes" , "192.168.120.21")
      .option("es.port","9200")
      .mode("Append")
      .save("megacorp/ebaynew")


    println("pushing completed")

  }



}
