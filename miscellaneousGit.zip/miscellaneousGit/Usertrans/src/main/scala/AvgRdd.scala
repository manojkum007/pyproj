/**
  * Created by manoj on 2/11/17.
  */

package com.oreilly.learningsparkexamples.scala

//import com.movoto.webanalytics.gabq.GABQBlindSchema
import org.apache.spark._
import org.apache.spark.rdd.RDD


//import oi.thekraken.grok.api._

  //import oi.thekraken.grok.api.{Grok, Match}

import oi.thekraken.grok.api.Grok
import oi.thekraken.grok.api.Match
import oi.thekraken.grok.api.exception.GrokException

object AvgRdd {
  def main(args: Array[String]) {
    val master = args.length match {
      case x: Int if x > 0 => args(0)
      case _ => "local"
    }
    //val sc = new SparkContext(master, "BasicAvg", System.getenv("SPARK_HOME"))
    val conf = new SparkConf().setAppName("BasicAvg").setMaster("local[2]")
    val sc = new SparkContext(conf)
    val input = sc.parallelize(List(1,2,3,4))
    //val result = computeAvg(input)
    //val avg = result._1 / result._2.toFloat


    val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)


   //val bigquerytable="/home/manoj/spark_helper/2017-04-07_071416-m-00004.snappy.parquet"
    //val novadf=sqlContext.read.parquet(bigquerytable)

    //Grok g = new Grok()
    val grok: Grok = new Grok()
      //.create("patterns.txt")
    grok.addPatternFromFile("/home/manoj/miscellaneousGit/Usertrans/src/main/scala/patterns.txt")
    grok.compile("%{BING}")

    val  log:String = "112.169.19.192 - -bing  [06/Mar/2013:01:36:30 +0900] \"GET / HTTP/1.1\" 200 44346 \"-\" \"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1364.152 Safari/537.22\""

    //val Match:gm = grok.match(log)
    val gm: Match = grok.`match`(log)
    gm.captures()
    val page_id = gm.toMap.keySet()
    println(page_id)


    //println(novardd.count)

    /*val schm = new GABQBlindSchema
    schm.df = sqlContext.read.parquet(bigquerytable)

    val dfschma = schm.buildSchema
    println ("tree of schwma" + dfschma.printTreeString)*/



  }
  def computeAvg(input: RDD[Int]) = {
    input.aggregate((0, 0))((x, y) => (x._1 + y, x._2 + 1),
      (x,y) => (x._1 + y._1, x._2 + y._2))
  }
}