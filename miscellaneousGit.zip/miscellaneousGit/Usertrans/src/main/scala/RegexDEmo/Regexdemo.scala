/**
  * Created by manoj on 23/1/18.
  */

object Regexdemo {

  val number = "07923 874123"                     //> number  : String = 07923 874123
  val pattern = """(\d{5})[ -]?(\d{6})"""         //> pattern  : String = (\d{5})[ -]?(\d{6})

  number.matches(pattern)                         //> res0: Boolean = true

  // Compiled pattern
  val Phone = pattern.r                           //> Phone  : scala.util.matching.Regex = (\d{5})[ -]?(\d{6})

  // Integrates with Scala pattern matching:
  number match { case Phone(area, num) => num }   //> res1: String = 874123

  // and Options:
  Phone findFirstIn number                        //> res2: Option[String] = Some(07923 874123)

  // Multiple matches:
  val numbers = "07923 874123, 07923-874124, 07923874125"
  //> numbers  : String = 07923 874123, 07923-874124, 07923874125
  (Phone findAllIn numbers) foreach println       //> 07923 874123
  //| 07923-874124
  //| 07923874125

  (Phone findAllMatchIn numbers) map (_ group 2) foreach println
  //> 874123
  //| 874124
  //| 874125
  // Avoids 'magic' group numbers, but matches twice:
  (Phone findAllIn numbers) foreach {case Phone(a,n) => println(n)}
  //> 874123
  //| 874124
  //| 874125

  val Email = """(\w+)@([\w\.]+)""".r

  Email.findFirstIn("test@example.com")

  val Email(name, domain) = "test@example.com"

}