/**
  * Created by manoj on 29/6/18.
  */;
//import RddJdbc.JDBCConstants;
import RddJdbc.JDBCConstants;

object HivetoPostgres extends JDBCConstants {


  import org.apache.spark._

  val conf = new SparkConf().setAppName("HivetoPostgres")
  val sc = new SparkContext(conf)
  val production_path: String = "hdfs://192.168.120.131:9000"

  var inputtable: String = ""
  var propertyfile: String = ""
  var outputtable: String = ""


  def main(args: Array[String]): Unit = {

    if (args.length > 2) {
      inputtable = args(0).toString
      propertyfile = args(1).toString
      outputtable = args(2)

    } else {
      println(" sorry no parameter passed")
      System.exit(-1)
    }


    try {
      println("hello");
      /*
    }
    val jdbcProperties = new java.util.Properties()
    jdbcProperties.load(new FileInputStream(propertyfile))


    val databasename=jdbcProperties.getProperty(this.JDBC_DATABASENAME)
    val driver=jdbcProperties.getProperty(this.JDBC_DRIVER)
    val host=jdbcProperties.getProperty(this.JDBC_HOST)
    val port=jdbcProperties.getProperty(this.JDBC_PORT)
    val user=jdbcProperties.getProperty(this.JDBC_USER)
    val password=jdbcProperties.getProperty(this.JDBC_PASSWORD)
    val database=jdbcProperties.getProperty(this.JDBC_DATABASE)

    DataBaseConnector.connecttodatabase(databasename ,host,port ,user, password, driver ,database )
*/
    }
      catch {
        case e: Exception => println("************************** Error processing."); e.printStackTrace();
      } finally {
        println("completed")
        if (sc != null) sc.stop()
      }

    }


}

