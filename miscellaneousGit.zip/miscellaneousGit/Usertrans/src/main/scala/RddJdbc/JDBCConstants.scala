/**
  * Created by manoj on 2/7/18.
  */

package RddJdbc

trait JDBCConstants {
  val JDBC_DATABASENAME = "database_name";
  val JDBC_HOST = "host";
  val JDBC_PORT = "port";
  val JDBC_DRIVER = "driver";
  val JDBC_USER = "username";
  val JDBC_PASSWORD = "password";
  val JDBC_DATABASE = "database";

}