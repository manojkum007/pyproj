package RddJdbc

import org.apache.spark.sql.DataFrame

/**
  * Created by manoj on 2/7/18.
  */





object DataBaseConnector  {

  var Host :String =null;
  var Port :String =null;
  var Database:String=null;
  var databaseName:String=null;
  var Username :String =null;
  var Password :String =null;
  var Driver :String =null;
  var Connectionstring :String =null;
  var ConnectorObject=null;
  val prop = new java.util.Properties

  def connecttodatabase(databasename:String ,host:String, port :String ,username :String, password :String, driver:String ,database:String): String = {

    Database = database;
    databaseName = databasename;
    Host = host;
    Port = port;
    Username = username;
    Password = password;
    Driver = driver;
    //Connectionstring = connectionstring;

    try {

      prop.setProperty("driver", Driver)
      prop.setProperty("user", Username)
      prop.setProperty("password", Password)
      val url = "jdbc:$Database://$Host/$databaseName"
      Connectionstring= url
      Connectionstring
    } catch {
      case e: Exception => {
        e.printStackTrace();
        "error"
      }
    }
  }


  def executeQuery():Unit={}

  def WriteQuery():Unit={}

  def writeToJDBC(table:String , overwritemode :String, hivedataFrame: DataFrame):Unit={

    //val table = "public.public_rcd"
    //mode="overwrite"
    hivedataFrame.write.mode(overwritemode).jdbc(Connectionstring, table, prop)
  }

}