package leadscore

import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, Row}

import scala.collection.mutable.ArrayBuffer

class LeadScoreAggregator extends LeadScoreAggregatorSchema {

  /**
   * Maps GA id to Nova id from given dataframe.
   */
  def mapGAToNovaId(ngmapdf: DataFrame): scala.collection.Map[String, String] = {
    ngmapdf.map(rw => {
      val gaid = rw.getAs[String]("ga_id").trim
      val novaid = rw.getAs[String]("nova_id").trim

      (gaid, novaid)
    })
      .collectAsMap()
  }

  def aggLeadScores(bqdf: DataFrame, ngmap: Broadcast[scala.collection.Map[String, String]]): RDD[Row] = {

    //create group by gaid
    val bqmap = bqdf
      .map(rw => {
        // import indexes of selected columns
        import LeadScoreConstants.gaselect._
        
        val gaidval = if( !rw.isNullAt(gaid) ) rw.getAs[String](gaid).trim else ""
        
        (ngmap.value.get(gaidval).getOrElse("0x"),
          Array(
            rw.getAs[Long](visitnumber),
            rw.getAs[Long](visitstarttime),
            rw.getAs[String](strvdate),
            rw.getAs[Long](pgvwcount),
            rw.getAs[String](hittype),
            rw.getAs[Long](hittime),
            rw.getAs[String](action),
            rw.getAs[String](label),
            rw.getAs[String](category),
            rw.getAs[String](pgpath),
            rw.getAs[String](dpp),
            rw.getAs[String](loggedin),
            rw.getAs[String](mlsid),
            rw.getAs[String](lsid),
            rw.getAs[String](listingprice),
            rw.getAs[String](no_of_photos),
            rw.getAs[String](no_of_bedrooms),
            rw.getAs[String](no_of_bathrooms),
            rw.getAs[String](sqft_of_house),
            rw.getAs[String](plstatus),
            rw.getAs[String](pview),
            rw.getAs[String](propid)))
      })      
      .filter(_._1 != "0x")
      .groupByKey()

    val outrdd =
      bqmap
        .mapValues(rwIter => {
          // import the indexes of the grouped values
          import LeadScoreConstants.gagrouped._
          
          rwIter.find(e=>(e(label)== "first_hotlead" ||  e(label) == "lead-received" || e(label) == "lead-confirmed" )) match {
            case Some(rw) => {
              computAggForFirstLead( rwIter.toSeq )

            }
            case None => {
              computAggForPropertyViews( rwIter.toSeq )
            }
          }
        })
        .map(rw => {
          val allrows = ArrayBuffer.empty[Any]
          allrows += rw._1
          allrows += rw._2
          Row(allrows: _*)
        })

    outrdd
  }



  

  def computAggForFirstLead(leadrows: Seq[Array[Any]]): ArrayBuffer[Any] = {
    // import the indexed ordering after grouping
    import LeadScoreConstants.gagrouped._;

    val leadrowssorted = leadrows.sortBy(_(visitstarttime).asInstanceOf[Long]) //sort in default ascending order
    var filterevent :String="first_hotlead"
    var lsfirstlead = leadrowssorted.filter(_(label) == "first_hotlead")
    if (lsfirstlead==null) {
       lsfirstlead = leadrowssorted.filter(_(label) == "lead-received");
      filterevent="lead-received"
    }
    if (lsfirstlead==null) {
       lsfirstlead = leadrowssorted.filter(_(label) == "lead-confirmed");
      filterevent="lead-confirmed"
    }

    val fleadtime = (lsfirstlead(0)(visitstarttime).asInstanceOf[Long] * 1000L) //in milliseconds
    val fleadtimestamp = LeadScoreAggUtils.toVisitTSMillis(lsfirstlead(0)(visitstarttime), lsfirstlead(0)(hittime))
    val aggrow = ArrayBuffer.empty[Any]

    val (a4s, b4s) = leadrowssorted.filter(_(label) != filterevent)
      .partition(e => ((e(visitstarttime).asInstanceOf[Long] * 1000) > fleadtime))

    // -- number of sessions after first lead
    // -- number of sessions before first lead    
    // -- number of saved searches after first lead
    // -- number of saved searches before first lead
    // -- number of favorited homes after first lead
    // -- number of favorited homes before first lead
    aggrow ++= LeadScoreAggUtils.a4b4SessionsCounts(a4s, b4s)

    val (a4, b4) = leadrowssorted.filter(_(label) != filterevent)
      .partition(e => (LeadScoreAggUtils.toVisitTSMillis(e(visitstarttime), e(hittime)) > fleadtimestamp))

    // -- number of properties viewed after first lead
    // -- number of properties viewed before first lead
    // -- number of distinct days visiting the site after first lead
    // -- number of distinct days visiting the site before first lead
    // -- number of pages seen while logged in after first lead
    // -- number of pages seen while logged in before first lead
    // -- number of photo pages seen after first lead
    // -- number of photo pages viewed before first lead
    // -- number of sold properties viewed after first lead
    // -- number of sold properties viewed before first lead
    // -- number of active properties viewed after first lead
    // -- number of active properties viewed before first lead
    aggrow ++= LeadScoreAggUtils.a4b4Properties(a4s, b4s, a4, b4)

    // -- number of days since the last session
    // -- number of days since the last property viewed
    // -- number of days since the last active property viewed
    // -- number of days since the last page view
    // -- number of days between first hit on the site and first lead
    aggrow ++= LeadScoreAggUtils.daysAndLeads(fleadtime, leadrowssorted)

    // -- minimum number of days between viewing properties	prop_timelag_day
    // -- median number of days between property views	prop_timelag_med
    // -- mean number of days between property views		prop_timelag_mean
    // -- variance of the number of days between property views	prop_timelag_var
    // -- kurtosis of the number of days between property views	prop_timelag_kurt
    // -- skew of the number of days between property views	prop_timelag_skew
    aggrow ++= LeadScoreAggUtils.aggDaysBetweenPropViews(leadrowssorted)

    // -- MLS Id of the house of the last hot lead (HL)
    // -- Listing Id of the house of the last hot lead (HL)
    // -- sqft of the house of the last hot lead (HL)
    // -- number of photos on the MLS for the property of the most recent HL
    // -- number of bathrooms for the most recent HL
    // -- number of bedrooms of the most recent HL
    // -- price of the most recent HL
    aggrow ++= LeadScoreAggUtils.aggLeadPropertyDetails(leadrowssorted)

    // -- number of pages viewed while logged after first HL divided by the number of pages viewed while logged off after first HL
    // -- number of pages viewed while logged on before first HL divided by number of pages viewed while logged off before first HL
    // -- number of sold properties viewed after first HL divided by number of active properties viewed after first HL
    // -- number of sold properties viewed before first HL divided by the number of active properties viewed before first HL
    aggrow ++= LeadScoreAggUtils.divideFirstHL(a4, b4)
    
    // -- the last visit date for each Nova_id
    aggrow ++= LeadScoreAggUtils.aggLastVisitDetails( leadrowssorted )

    aggrow
  }

  def computAggForPropertyViews(leadrows: Seq[Array[Any]]): ArrayBuffer[Any] = {
    import LeadScoreConstants.gagrouped._;
    val leadrowssorted = leadrows.sortBy(_(visitstarttime).asInstanceOf[Long]) //sort in default ascending order

    val aggval = ArrayBuffer[Any](
      // -- number of sessions after first lead  nos_ahtld
      null.asInstanceOf[Int],
      //  -- number of sessions before first lead   nos_bhtld
      null.asInstanceOf[Int],
      // -- number of saved searches after first lead  noss_ahtld
      null.asInstanceOf[Int],
      // -- number of saved searches before first lead  noss_bhtld
      null.asInstanceOf[Int],
      // -- number of favorited homes after first lead  nofh_ahtld
      null.asInstanceOf[Int],
      // -- number of favorited homes before first lead  nofh_bhtld
      null.asInstanceOf[Int],
      // -- number of properties viewed after first lead  nopv_ahtld
      null.asInstanceOf[Int],
      // -- number of properties viewed before first lead  nopv_bhtld
      null.asInstanceOf[Int],
      // -- number of distinct days visiting the site after first lead  nodd_ahtld
      null.asInstanceOf[Int],
      // -- number of distinct days visiting the site before first lead  nodd_bhtld
      null.asInstanceOf[Int],
      // -- number of pages seen while logged in after first lead  
      null.asInstanceOf[Int],
      // -- number of pages seen while logged in before first lead
      null.asInstanceOf[Int],
      // -- number of photo pages seen after first lead  nopgv_ahtld
      null.asInstanceOf[Int],
      // -- number of photo pages viewed before first lead  nopgv_bhtld
      null.asInstanceOf[Int],
      // -- number of sold properties viewed after first lead  noslpv_ahtld
      null.asInstanceOf[Int],
      // -- number of sold properties viewed before first lead  noslpv_bhtld
      null.asInstanceOf[Int],
      // -- number of active properties viewed after first lead  noapv_ahtld
      null.asInstanceOf[Int],
      // -- number of active properties viewed before first lead  noapv_bhtld
      null.asInstanceOf[Int],
      // -- number of days since the last session  nod_lst_sess
      null.asInstanceOf[Int])

    // -- number of days since the last property viewed
    aggval += null.asInstanceOf[Int]
    // -- number of days since the last active property viewed
    aggval += null.asInstanceOf[Int]
    // -- number of days since the last page view
    aggval += null.asInstanceOf[Int]

    // -- number of days between first hit on the site and first lead
    aggval += null.asInstanceOf[Int]

    // -- minimum number of days between viewing properties	prop_timelag_day
    // -- median number of days between property views	prop_timelag_med
    // -- mean number of days between property views		prop_timelag_mean
    // -- variance of the number of days between property views	prop_timelag_var
    // -- kurtosis of the number of days between property views	prop_timelag_kurt
    // -- skew of the number of days between property views	prop_timelag_skew
    aggval ++= LeadScoreAggUtils.aggDaysBetweenPropViews(leadrowssorted)

    // -- Property Id of the house of the last hot lead (HL)
    // -- MLS Id of the house of the last hot lead (HL)
    // -- Listing Id of the house of the last hot lead (HL)
    // -- sqft of the house of the last hot lead (HL)
    // -- number of photos on the MLS for the property of the most recent HL
    // -- number of bathrooms for the most recent HL
    // -- number of bedrooms of the most recent HL
    // -- price of the most recent HL
    aggval += null.asInstanceOf[String]
    aggval += null.asInstanceOf[String]
    aggval += null.asInstanceOf[String]
    aggval += null.asInstanceOf[String]
    aggval += null.asInstanceOf[String]
    aggval += null.asInstanceOf[String]
    aggval += null.asInstanceOf[String]
    aggval += null.asInstanceOf[String]

    // -- number of pages viewed while logged after first HL divided by the number of pages viewed while logged off after first HL
    aggval += null.asInstanceOf[Double]

    // -- number of pages viewed while logged on before first HL divided by number of pages viewed while logged off before first HL
    aggval += null.asInstanceOf[Double]

    // -- number of sold properties viewed after first HL divided by number of active properties viewed after first HL
    aggval += null.asInstanceOf[Double]

    //-- number of sold properties viewed before first HL divided by the number of active properties viewed before first HL
    aggval += null.asInstanceOf[Double]
    
    // -- the last visit date for each Nova_id
    aggval ++= LeadScoreAggUtils.aggLastVisitDetails( leadrowssorted )

    aggval
  }

}








