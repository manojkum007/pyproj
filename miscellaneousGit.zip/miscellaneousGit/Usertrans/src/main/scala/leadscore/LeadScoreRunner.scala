package leadscore

import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.{SparkConf, SparkContext}

object LeadScoreRunner {
  
  var sc: SparkContext = null
  var sqlContext: SQLContext = null
  var hiveContext: HiveContext = null
    
  
  def runLeadScore(partlist: String, ngmaptable: String, srctable: String, desttable: String) = {
    sc = new SparkContext(new SparkConf)
    sqlContext = new SQLContext(sc)
    hiveContext = new HiveContext(sc)
    /*
    val leadscoreagg = new LeadScoreAggregator
    val srcdf = hiveContext.sql( leadscoreagg.getLeadScoreAggQuery(partlist, srctable) )
    */
    /*
    val ngmapdf = hiveContext.sql( leadscoreagg.getNovaIdGAIdMapQuery(ngmaptable) )
    val ngmap = sc.broadcast( leadscoreagg.mapGAToNovaId(ngmapdf) )
    val aggrdd = leadscoreagg.aggLeadScores( srcdf, ngmap )
    val aggdf =  hiveContext.createDataFrame(aggrdd, leadscoreagg.buildSchema)
    
    hiveContext.setConf("hive.exec.dynamic.partition", "true")
    hiveContext.setConf("hive.exec.dynamic.partition.mode", "nonstrict")
    
    val reccount = 
      aggdf.write.mode("append")
    	  .insertInto(desttable);

          	
    println(s"$reccount rows written for input partitions ($partlist) from $srctable into $desttable .")
    */
    
  }
  
  
  def main(args: Array[String]) {

    /*
    args.toList match {
      case partlist :: ngmaptable :: srctable :: desttable :: others => {
        try {
          runLeadScore(partlist, ngmaptable, srctable, desttable)
        } catch {
          case e: Exception => println("************** Error processing."); e.printStackTrace(); 
        } finally {
          if(sc != null) sc.stop()
        }
      }
      case _ => { 
        println("Invalid use of arguments. Usage: spark-submit ... <comma_separted_list_of_partitions> <db.table_name>"); 
        System.exit(-1);
      }
     }*/

    sc = new SparkContext(new SparkConf().setAppName("Flattenbigquery").setMaster("local[2]"))
    sqlContext = new SQLContext(sc)
    hiveContext = new HiveContext(sc)
    val srctable = Array("/home/manoj/miscellaneousGit/movoto-webanalytics/gabigquery/src/test/resources/data/shn/date=20170315")

    val ngmaptable = "/home/manoj/miscellaneousGit/movoto-webanalytics/gabigquery/src/test/resources/data/novaid_gaid_mapping"

    val tobj = new LeadScoreAggregator
    sqlContext.read.parquet(srctable:_*).registerTempTable("sessions_hits_newschema")
    sqlContext.read.parquet(ngmaptable).registerTempTable("novaid_gaid_mapping")

    val dfquery = tobj.getLeadScoreAggQuery("all", "sessions_hits_newschema")

    val bqdf = sqlContext.sql(dfquery)

    val ngmapdf = sqlContext.sql(tobj.getNovaIdGAIdMapQuery("novaid_gaid_mapping"))
    val ngmap = sc.broadcast( tobj.mapGAToNovaId(ngmapdf) )
    val bqrdd = tobj.aggLeadScores(bqdf, ngmap)


  }
}