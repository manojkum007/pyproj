package leadscore

trait SimpleAggregator extends java.io.Serializable {
  
}