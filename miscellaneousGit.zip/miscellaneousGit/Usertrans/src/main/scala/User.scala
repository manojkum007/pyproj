//package com.movoto.scala

import org.apache.spark
import org.apache.spark.SparkContext._
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.rdd.RDD
import scala.collection.immutable._
import scala.collection.Map
//import org.apache.spark.sql.types._
//import org.apache.spark.sql.SaveMode


object User {


  def processData (t: RDD[(Int, Int)], u: RDD[(Int, String)]) : Map[Int,Long] = {
    var jn = t.leftOuterJoin(u).values.distinct
    return jn.countByKey
  }


  def main(args: Array[String]){
    val conf = new SparkConf().setAppName("User").setMaster("local[2]")
    val sc = new SparkContext(conf)
    val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)
    val usr=sc.textFile("./src/main/scala/users_test.txt")
    val newUsersPair = usr.map{t => val p = t.split("\t")
      (p(0).toInt, p(3))
    }

    val transactions = sc.textFile("/home/manoj/miscellaneousGit/Usertrans/src/main/scala/transactions_test.txt")
    val newTransactionsPair = transactions.map{t =>
      val p = t.split("\t")
      (p(1).toInt, p(2).toInt)
    }

    //var jn = newTransactionsPair.leftOuterJoin(newUsersPair).values.distinct
    val result = processData(newTransactionsPair, newUsersPair)
    //jn.saveAsTextFile("/home/manoj/miscellaneousGit/Usertrans/src/main/scala/tt.txt")
    //println(jn.take(2))
    println("data" + sc.parallelize(result.toSeq).map(t => (t._1.toString, t._2.toString)))
  //}

    /*
  def processData (t: RDD[(Int, Int)], u: RDD[(Int, String)]) : Map[Int,Long] = {
    var jn = t.leftOuterJoin(u).values.distinct
    return jn.countByKey
  }*/

  //println("result"+result)

}

}