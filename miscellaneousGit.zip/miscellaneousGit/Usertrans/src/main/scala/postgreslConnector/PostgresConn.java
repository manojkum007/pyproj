package postgreslConnector;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 * Created by manoj on 25/6/18.
 */

public class PostgresConn
{
    public void dbConnect()
    {
        try {
            /*Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection conn = DriverManager.getConnection(db_connect_string,
                    db_userid, db_password);*/


            //String url = "jdbc:postgresql://localhost/postgres?user=postgres&password=admin&ssl=true";

            String url = "jdbc:postgresql://192.168.120.118/movotogeo?user=postgres&password=igen4movoto&ssl=false";

            Connection conn = DriverManager.getConnection(url);
            System.out.println("connected");

            Statement statement = conn.createStatement();
            //String queryString = "select * FROM public.file_upload_status;";
            String queryString = "select * FROM public.public_record;";
            ResultSet rs = statement.executeQuery(queryString);
            while (rs.next()) {
                System.out.println(rs.getString(1) +  " "+ rs.getString(2));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args)
    {
        PostgresConn connServer = new PostgresConn();
        connServer.dbConnect();
    }
}