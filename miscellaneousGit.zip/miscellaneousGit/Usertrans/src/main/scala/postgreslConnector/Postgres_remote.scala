/**
  * Created by manoj on 25/6/18.
  */

import java.sql.{Connection, DriverManager};

object Postgres_remote {

  import org.apache.spark._
  val conf = new SparkConf().setAppName("Dataframe Maker").setMaster("local[2]")
  val sc = new SparkContext(conf)



  def dataframe_maker(): Unit = {
     val path:String="/home/manoj/miscellaneousGit/Usertrans/src/main/resources/spark_post"

    val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)

    val sparkpostdf=sqlContext.read.parquet(path)
    //val newsparkpostdf =sparkpostdf.drop("swu_template_id").drop("day")
    sparkpostdf.registerTempTable("data")
    val newsparkpostdf =sqlContext.sql("select swu_template_id, swu_template_name, event_type  from  data limit 10")


    sparkpostdf.printSchema()

    //create properties object
    val prop = new java.util.Properties
    prop.setProperty("driver", "org.postgresql.Driver")
    prop.setProperty("user", "postgres")
    prop.setProperty("password", "igen4movoto")

    val url = "jdbc:postgresql://192.168.120.118/movotogeo"

    //val table = "bkfs.address_refresh"

    val table = "public.public_rcd"
    newsparkpostdf.write.mode("overwrite").jdbc(url, table, prop)


    /*
    root
 |-- swu_template_id: string (nullable = true)
 |-- swu_template_name: string (nullable = true)
 |-- event_type: string (nullable = true)
 |-- event_timestamp: timestamp (nullable = true)
 |-- day: date (nullable = true)

     */

  }

  def main(args: Array[String]) {


    dataframe_maker();


    //val url: String = "jdbc:postgresql://192.168.120.118/movotogeo?user=postgres&password=igen4movoto&ssl=false"
    val driver = "org.postgresql.Driver"
    val url = "jdbc:postgresql://192.168.120.118/movotogeo"
    val username = "postgres"
    val password = "igen4movoto"

    // there's probably a better way to do this
    var connection:Connection = null

    try {
      // make the connection
      Class.forName(driver)
      connection = DriverManager.getConnection(url, username, password)

      // create the statement, and run the select query
      val statement = connection.createStatement()
      val resultSet = statement.executeQuery("select * FROM public.public_record;")
      while ( resultSet.next() ) {
        val host = resultSet.getString("id")
        val user = resultSet.getInt("tax_year")
        println("host, user = " + host + ", " + user)
      }
    } catch {
      case e => e.printStackTrace
    }
    connection.close()


  }

}