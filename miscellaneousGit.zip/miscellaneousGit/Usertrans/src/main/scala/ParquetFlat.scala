/**
  * Created by manoj on 15/11/17.
  */

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.Path
import org.apache.spark.rdd._
import org.apache.spark.sql
import java.text.SimpleDateFormat

import org.apache.spark.sql.functions._
import org.apache.spark.sql.Row
import org.apache.spark.sql.types._
import org.joda.time.DateTime

import scala.collection.mutable.ListBuffer;





object ParquetFlat {
  def main(args: Array[String]) {

    //Create Spark Context
    import org.apache.spark._
    val conf = new SparkConf().setAppName("SFDC")
    val sc = new SparkContext(conf)
    val rhino_path :String="hdfs://192.168.120.140:9000"
    //val rhino_path :String="hdfs://localhost:54310"
    var bqrawtable:String=""
    var outputpath :String=""
    var start_date :String=""
    var end_date :String=""
    var get_all:String=""
    var get_all_flag:String=""


    if (args.length > 4) {
      bqrawtable =  args(0).toString
      outputpath = args(1).toString
      start_date=args(2)
      end_date=args(3)
      get_all=args(4)
    } else {
      println(" sorry no parameter passed")
      System.exit(-1)
    }
    var bqdates = ListBuffer[String]()

    val inputFormat = new SimpleDateFormat("yyyy-MM-dd")
    val outputFormat = new SimpleDateFormat("yyyyMMdd")

    bqdates=partitiongenerator(start_date ,end_date).map(  e=>bqrawtable+"/date="+outputFormat.format(inputFormat.parse(e)))


    val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)




    val gaparquetfile="/home/manoj/spark_helper/biq/2016-11-14_184513-m-00003.snappy.parquet"



    val novaparqfile=sqlContext.read.parquet(gaparquetfile)
    novaparqfile.registerTempTable("nova")

    val totalsdf=novaparqfile.select("totals")
/*
    visits:long
    hits:long
    pageviews:long
    timeOnSite:long
    bounces:long
    transactions:long
    transactionRevenue:long
    newVisits:long
    screenviews:long
    uniqueScreenviews:long
    timeOnScreen:long
    totalTransactionRevenue:long
*/


    


    /*
    SELECT  a.state,
                   a.city,
                   status.NAME                                                 AS
                   status,
                   l.mls_id,
                   type.NAME                                                   AS
                          property_type,
                   l.id
            FROM    mls.mls_listing_snapshot_parq l
                   INNER JOIN mls.mls_address_snapshot_delta a
                           ON a.id = l.mls_address_id
                   INNER JOIN mls.attribute status
                           ON status.id = l.standard_status
                   INNER JOIN mls.attribute type
                           ON type.id = l.property_type;*/



    val config = new Configuration()
    config.set("fs.defaultFS", rhino_path)
    val fs= FileSystem.get(config)
    if ( fs.exists(new Path(outputpath.toString))) {
      fs.delete(new Path(outputpath.toString))

    }


  }



  def partitiongenerator( sdate:String,  edate:String) :ListBuffer[String]= {
    val buf = new ListBuffer[String]
    var t1=DateTime.parse(sdate).getDayOfYear
    var t2=DateTime.parse(edate).getDayOfYear

    //buf+=DateTime.parse(sdate).toString("YYYY-MM-dd")
    //  println(DateTime.parse(sdate).getYear)
    // println(DateTime.parse(edate).getYear)
    if (DateTime.parse(edate).getYear<=DateTime.parse(sdate).getYear) {
      for (i <- 0 to t2-t1) {
        val d = DateTime.parse(sdate).plusDays(i).toString("YYYY-MM-dd")
        buf+=d
      }

    } else
    {
      var datediff :Int=0;
      if (DateTime.parse(sdate).getYearOfEra%4==0){datediff=(366-t1)+t2 }
      else { datediff=(365-t1)+t2}


      for (i <- 0 to datediff) {
        val d = DateTime.parse(sdate).plusDays(i).toString("YYYY-MM-dd")
        buf+=d
      }

    }

    //buf+=DateTime.parse(edate).toString("YYYY-MM-dd")
    buf

  }

}


