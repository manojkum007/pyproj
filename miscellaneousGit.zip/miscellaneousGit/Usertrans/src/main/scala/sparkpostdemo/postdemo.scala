/**
  * Created by manoj on 28/1/18.
  */



object postdemo {
  def main(args: Array[String]) {

    //println("In main : " + args(0) + "," + args(1))

    //Create Spark Context
    import org.apache.spark._
    import org.apache.spark.sql.functions._


    val conf = new SparkConf().setAppName("WordCountApp").setMaster("local[2]")
    val sc = new SparkContext(conf)
    val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)


    val templated_df=sqlContext.read.parquet("/home/manoj/miscellaneousGit/Usertrans/src/main/resources/spark_post")


    println(templated_df.printSchema())

    val tt= templated_df.map(r=> {
      val first =r.getAs[String]("swu_template_id")
      val sec=r.getAs[String]("event_type")

      (first, sec)
    }).collectAsMap()

    //tt.foreach(println)

    val selectList = List(
      ("gaid", 0, "customdimensions_index_6"),
      ("visitnumber", 1, "visitnumber"),
      ("visitstarttime", 2, "visitstarttime"),
      ("strvdate", 3, "cast(cast(from_unixtime(visitstarttime) as date) as string)"),
      ("pgvwcount", 4, "total_pageviews"),
      ("hittype", 5, "hits_type"),
      ("hittime", 6, "hits_time"),
      ("action", 7, "hits_eventinfo_eventaction"),
      ("label", 8, "hits_eventinfo_eventlabel"),
      ("category", 9, "hits_eventinfo_eventcategory"),
      ("pgpath", 10, "hits_page_pagepath"),
      ("dpp", 11, "hits_customdimensions_index_2"),
      ("loggedin", 12, "hits_customdimensions_index_7"),
      ("mlsid", 13, "hits_customdimensions_index_14"),
      ("lsid", 14, "hits_customdimensions_index_15"),
      ("listingprice", 15, "hits_customdimensions_index_16"),
      ("no_of_photos", 16, "hits_customdimensions_index_17"),
      ("no_of_bedrooms", 17, "hits_customdimensions_index_18"),
      ("no_of_bathrooms", 18, "hits_customdimensions_index_19"),
      ("sqft_of_house", 19, "hits_customdimensions_index_20"),
      ("plstatus", 20, "hits_customdimensions_index_23"),
      ("pview", 21, "hits_customdimensions_index_64"),
      ("propid", 22, "hits_customdimensions_index_82")
    )

    //println(selectList.map(e=>(e._3 + " as " + e._1)))

    val grpdf =templated_df.groupBy("swu_template_id", "swu_template_name" ,"event_type")

    val gaggdf=grpdf.agg(count("event_timestamp").as("event_type_count"))

    val newgdf=gaggdf.withColumn("delivery_rate", when(gaggdf.col("event_type") === "injection",  gaggdf.col("event_type_count")).otherwise(null))
    //val just_newdf=newgdf.withColumn("open_rate", when(newgdf.col("event_type") === "open",  newgdf.col("event_type_count")/sum(newgdf.col("delivery_rate"))).otherwise(null))


    //just_newdf.show()


    //Load Data from File
    //val tt= if (args.length>0) args(1) else "/home/manoj/logs/crawl_stat.log"
    //val tt="hdfs://localhost:54310/home/manoj/logs/crawl_stat.log"\

    /*
    val tt="/home/manoj/logs/crawl_stat.log"
    println("path"+tt)
    val input = sc.textFile(tt)

    //Split into words
    val words = input.flatMap(line => line.split(" "))

    //Assign unit to each word
    val units = words.map ( word => (word, 1) )

    //Reduce each key
    val counts = units.reduceByKey ( (x, y) => x + y )

    //Write output to Disk
    counts.saveAsTextFile("/home/manoj/logs/wordcntdir")*/

    //Shutdown spark. System.exit(0) or sys.exit() can also be used
    sc.stop();
  }
}