/**
  * Created by manoj on 10/11/17.
  */

import org.apache.spark._
import org.apache.spark.rdd.RDD

object RddReader {
  def main(args: Array[String]) {
     val master = args.length match {
       case x: Int if x > 0 => args(0)
       case _ => "local"
     }
     val sc = new SparkContext(master, "BasicAvg", System.getenv("SPARK_HOME"))
     val text_file = sc.textFile("/home/manoj/logs/crawl_stat.log")
      println("text_file"+text_file.count())
  }

   def computeAvg(input: RDD[Int]) = {
     input.aggregate((0, 0))((x, y) => (x._1 + y, x._2 + 1),
       (x,y) => (x._1 + y._1, x._2 + y._2))
   }
}