/**
  * Created by manoj on 21/11/17.
  */



import java.text.SimpleDateFormat

import org.apache.spark._
import org.joda.time._
import org.joda.time.format.DateTimeFormat

import scala.collection.mutable.ListBuffer


object Jodatime {
   def main(args: Array[String]) {
     val master = args.length match {
       case x: Int if x > 0 => args(0)
       case _ => "local"
     }
     val sc = new SparkContext(master, "BasicAvg", System.getenv("SPARK_HOME"))

     //val s1 = "2016-12-31"
    // val s2 = "2017-01-23"


     val s1 = "20180215"
     val s2 = "20180216"

     var bqdates = ListBuffer[String]()
     //bqdates += "/user/hive/warehouse/webanalytics.db/sessions_hits_newschema/date=20171117"
     //bqdates +=  "/user/hive/warehouse/webanalytics.db/sessions_hits_newschema/date=20171118"





     val inputFormat = new SimpleDateFormat("yyyy-MM-dd")
     val outputFormat = new SimpleDateFormat("yyyyMMdd")
     var bqrawtable:String="/user/hive/warehouse/webanalytics.db/sessions_hits_newschema"


    // val formattedDate = outputFormat.format(inputFormat.parse(s1))
     //bqrawtable+="/date="+formattedDate
     var tt:String=null
     partitiongenerator(s1 ,s2, "yyyyMMdd").map(r=>tt+=":"+r)
     println("rr "+tt)

     //bqdates=partitiongenerator(s1 ,s2).map(  e=>bqrawtable+"/date="+outputFormat.format(inputFormat.parse(e)))

     bqdates.foreach(println)




     //foreach(bqdates)



   }




  def partitiongenerator1( sdate:String,  edate:String, formatdate:String) :ListBuffer[String]= {
    val buf = new ListBuffer[String]
    val DATE_TIME_PATTERN = DateTimeFormat.forPattern(formatdate)
    var t1=DateTime.parse(sdate ,DATE_TIME_PATTERN).getDayOfYear
    var t2=DateTime.parse(edate ,DATE_TIME_PATTERN ).getDayOfYear
    if (DateTime.parse(edate).getYear<=DateTime.parse(sdate).getYear) {
      for (i <- 0 to t2-t1) {
        val d = DateTime.parse(sdate ,DATE_TIME_PATTERN).plusDays(i).toString(formatdate)
        buf+=d
       }
    } else
       {
        var datediff :Int=0;
         if (DateTime.parse(sdate ,DATE_TIME_PATTERN).getYearOfEra%4==0){datediff=(366-t1)+t2 }
         else { datediff=(365-t1)+t2}
       for (i <- 0 to datediff) {
         val d = DateTime.parse(sdate ,DATE_TIME_PATTERN ).plusDays(i).toString(formatdate)
         buf+=d
       }
    }
      //buf+=DateTime.parse(edate).toString("YYYY-MM-dd")
      buf
  }


  def partitiongenerator( sdate:String,  edate:String, formatdate:String) :ListBuffer[String]= {
    val buf = new ListBuffer[String]
    val DATE_TIME_PATTERN = DateTimeFormat.forPattern(formatdate)
    val newsdate=DateTime.parse(sdate ,DATE_TIME_PATTERN)
    val newedate=DateTime.parse(edate ,DATE_TIME_PATTERN)

    var t1=newsdate.getDayOfYear
    var t2=newedate.getDayOfYear
    if (newedate.getYear<=newsdate.getYear) {
      for (i <- 0 to t2-t1) {
        val d = newsdate.plusDays(i).toString(formatdate)
        buf+=d
      }
    } else
    {
      var datediff :Int=0;
      if (newsdate.getYearOfEra%4==0){datediff=(366-t1)+t2 }
      else { datediff=(365-t1)+t2}
      for (i <- 0 to datediff) {
        val d = newsdate.plusDays(i).toString(formatdate)
        buf+=d
      }
    }
    buf
  }


}