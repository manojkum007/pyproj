/**
  * Created by manoj on 11/11/17.
  */

object Wordcount {
  def main(args: Array[String]) {

    //println("In main : " + args(0) + "," + args(1))

    //Create Spark Context
    import org.apache.spark._
    val conf = new SparkConf().setAppName("WordCountApp").setMaster("local[2]")
    val sc = new SparkContext(conf)

    //Load Data from File
    //val tt= if (args.length>0) args(1) else "/home/manoj/logs/crawl_stat.log"
    //val tt="hdfs://localhost:54310/home/manoj/logs/crawl_stat.log"
    val tt="/home/manoj/logs/crawl_stat.log"
     println("path"+tt)
    val input = sc.textFile(tt)

    //Split into words
    val words = input.flatMap(line => line.split(" "))

    //Assign unit to each word
    val units = words.map ( word => (word, 1) )

    //Reduce each key
    val counts = units.reduceByKey ( (x, y) => x + y )

    //Write output to Disk
    counts.saveAsTextFile("/home/manoj/logs/wordcntdir")

    //Shutdown spark. System.exit(0) or sys.exit() can also be used
    sc.stop();
  }
}