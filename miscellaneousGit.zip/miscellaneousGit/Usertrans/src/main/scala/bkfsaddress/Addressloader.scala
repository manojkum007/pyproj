


/**
  * Created by manoj on 23/11/17.
  */



package bkfsaddress;


//import bkfsaddress.AddressConstants;



object Addressloader {


  def main(args: Array[String]): Unit = {

    //AddressConstants.call()

    //println(AddressConstants.hashMap2("GD"))


    println("hello in loader")
  }

}