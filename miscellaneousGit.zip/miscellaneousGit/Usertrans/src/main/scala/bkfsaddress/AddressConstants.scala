/**
  * Created by manoj on 23/11/17.
  */

package bkfsaddress;

import scala.collection.mutable.HashMap;


object AddressConstants {


  val tablecolumns: HashMap[String, String] = HashMap(
    "id"-> "id",
    "subpremise"-> "subpremise",
    "strtnum"->"street_number",
    "strtdir"-> "street_direction",
    "strtname"-> "street_name",
    "st_dir_suff"->"street_direction_suffix",
    "strtdesg"->"street_designator",
  "city"->"city",
  "state"->"state",
  "county"->"county",
  "ngr_r"->"neighborhood_r",
  "ngr_m"->"neighborhood_m",
  "ngr_n"->"neighborhood_n",
  "ngr_s"->"neighborhood_s",
  "ngrh"->"neighborhood",
  "addr"->"address",
  "zip"->"zip_code",
  "zip4"->"zip_plus_4",
  "lat"->"latitude",
  "long"->"longitude",
  "type"->"type",
  "srctype"->"source_type",
  "countyid"->"county_geo_id",
  "city_id"->"city_geo_id",
  "ngr_r_geoid"->"neighborhood_r_geo_id",
  "ngr_m_geoid"->"neighborhood_m_geo_id",
  "ngr_n_geoid"->"neighborhood_n_geo_id",
  "ngr_s_geoid"->"neighborhood_s_geo_id",
  "crt_at"->"created_at",
  "upd_at"->"updated_at",
  "addr_s_f"->"addr_source_flag",
  "unittpe"->"unit_type",
  "unitnum"->"unit_num",
  "addr_c_r"->"addr_carrier_route",
  "addr_c_t"->"addr_census_tract",
  "dataver"->"data_ver"
  )



def call(): Unit = {

  println("testing packages")
}


 /* def main(args: Array[String]): Unit = {

    print("hello")
  }
*/
}