
/**
  * Created by manoj on 11/11/17.
  */

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext

object CSVtoparquet {
  def main(args: Array[String]) {

    //println("In main : " + args(0) + "," + args(1))

    //Create Spark Context
    import org.apache.spark._
    val conf = new SparkConf().setAppName("csvtoparquet").setMaster("local[2]")
    val sc = new SparkContext(conf)
    val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)

    import sqlContext.implicits._;
    //sqlContext.setConf("spark.sql.parquet.binaryAsString","true")
    //sqlContext.setConf("spark.files.overwrite","true")

    //Load Data from File
    //val att= if (args.length>0) args(1) else "/home/manoj/logs/crawl_stat.log"
    //val tt="hdfs://localhost:54310/home/manoj/logs/crawl_stat.log"
   // val tt="/home/manoj/scripts/tiger_analyatics/panther/attribute_1885.csv"
    //println("path"+tt)
    //val input = sc.textFile(tt)
    //val resultantrdd=input.filter(r=> !(r.contains("attribute_type_id")))

    //resultantrdd.toDF().write.parquet("/home/manoj/spark_helper/user_transaction/attribute_test1")
    //Split into words
    //val words = input.flatMap(line => line.split("\t"))
    //val dataarr=resultantrdd.take(2)
    //resultantrdd.foreach(println)
    //println("filecount "+ resultantrdd.count())

    //Assign unit to each word
    //val units = words.map ( word => (word, 1) )

    //Reduce each key
    //val counts = units.reduceByKey ( (x, y) => x + y )

    //Write output to Disk
    //counts.saveAsTextFile("/home/manoj/logs/wordcntdir")

    //Shutdown spark. System.exit(0) or sys.exit() can also be used

    ///Reading parquetFile##########
      //val addressrdd=sqlContext.read.parquet("hdfs://localhost:54310/user/hive/warehouse/mls.db/mls_address_snapshot_delta")

    val addressrdd=sqlContext.read.parquet("/user/hive/warehouse/mls.db/mls_address_snapshot_delta")
     //addressrdd.take(10).foreach(println)
       println("address count"+addressrdd.count())  //46601

      val listingrdd=sqlContext.read.parquet("/user/hive/warehouse/mls.db/mls_listing_snapshot_orc_load")
       println("listing count"+listingrdd.count())  //126446
       //df1.createTempView('df1')
       //df2.createTempView('df2')

      val  joinedrdd=addressrdd.join(listingrdd ,addressrdd("id")===listingrdd("mls_address_id"))

      //val subsetrdd=joinedrdd.select("id")

       println("joined count"+joinedrdd.count())


    sc.stop();
  }
}