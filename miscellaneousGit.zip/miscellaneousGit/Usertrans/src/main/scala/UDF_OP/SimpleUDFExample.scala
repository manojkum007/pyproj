import org.apache.spark.{SparkConf, SparkContext}

/**
  * Created by manoj on 1/4/18.
  */



class DiscountSalesUDF extends org.apache.hadoop.hive.ql.exec.UDF {
  def evaluate (sales: Double, discount: Double) : Double = {
    sales - discount
  }
}


object SimpleUDFExample {


  val conf = new SparkConf().setAppName("SFDC")
  val sc = new SparkContext(conf)
  val rhino_path :String="hdfs://192.168.120.140:9000"


  val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)

  def main(args: Array[String]): Unit = {



    //import spark.implicits._

    // create an RDD of tuples with some data
    val custs = Seq(
      (1, "Widget Co", 120000.00, 0.00, "AZ"),
      (2, "Acme Widgets", 410500.00, 500.00, "CA"),
      (3, "Widgetry", 410500.00, 200.00, "CA"),
      (4, "Widgets R Us", 410500.00, 0.0, "CA"),
      (5, "Ye Olde Widgete", 500.00, 0.0, "MA")
    )
    val customerRows = sc.parallelize(custs, 4)
    //val customerDF = customerRows.toDF("id", "name", "sales", "discount", "state")

  }
  }