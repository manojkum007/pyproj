/**
  * Created by manoj on 5/1/18.
  */


package Webhook;

import java.text.SimpleDateFormat

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.hive.HiveContext

import scala.collection.mutable.ListBuffer;



object EmailMetrics {
  def main(args: Array[String]) {
    import org.apache.spark._
    //val conf = new SparkConf().setAppName("sparkpost_metrics").setMaster("local[2]")

    val conf = new SparkConf().setAppName("sparkpost_metrics")
    val sc = new SparkContext(conf)
    val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)

    var esindex:String=null
    var doctype :String=null
    var port :String=null
    var nodes :String=null
    var start_date:String=null
    var end_date:String=null
    var inputpath:String=null
    var sparkpost_temptable :String = null
    var outputpath :String = null
    var mapping_table_path:String=null
    val rhino_path :String="hdfs://192.168.120.140:9000"


    if (args.length > 9) {
      esindex =  args(0).toString
      doctype = args(1).toString
      port=args(2)
      nodes=args(3)
      start_date=args(4)
      end_date=args(5)
      sparkpost_temptable=args(6)
      inputpath=args(7)
      outputpath=args(8)
      mapping_table_path=args(9)

    } else {
      println(" sorry  incorrect number of parameter passed")
      System.exit(-1)
    }



   // val response_df=sqlContext.read.json("/home/manoj/scripts/tiger_analyatics/rhino/115")
   //val response_df=sqlContext.read.json(" hdfs://localhost:54310/tmp//115")

    //"/tmp/SparkPost/JsonOutput/JsonOutput_2018-01-02"


    var bqdates = ListBuffer[String]()
    val inputFormat = new SimpleDateFormat("yyyy-MM-dd")
    val outputFormat = new SimpleDateFormat("yyyy-MM-dd")

    val hiveContext = new HiveContext(sc)
    hiveContext.setConf("hive.exec.dynamic.partition", "true")
    hiveContext.setConf("hive.exec.dynamic.partition.mode", "nonstrict")

    bqdates=MetricEspush.partitiongenerator(start_date ,end_date).map(e=>inputpath+"_"+outputFormat.format(inputFormat.parse(e)))


    val response_df=sqlContext.read.json(bqdates:_*)

    if (response_df.count==0){
      println(" No files are present in given directory")
      System.exit(-1)
    }



    val config = new Configuration()
    config.set("fs.defaultFS", rhino_path)

    val fs= FileSystem.get(config)
    if ( fs.exists(new Path(outputpath.toString))) {
      fs.delete(new Path(outputpath.toString))
    }


    try {

      val mapping_df =sqlContext.read.parquet(mapping_table_path)

      //val mapping_df =sqlContext.read.parquet("/user/hive/warehouse/recsys.db/sparkpost_template_mapping")

      val flattened = response_df.select(response_df.col("total_count"), explode(response_df.col("results")).as(MetricMappingName.Json_reponse_map("results_flat")))
      val rcp_meta_df= flattened.select(flattened.col(MetricMappingName.Json_reponse_map("rcpt_meta")), flattened.col(MetricMappingName.Json_reponse_map("totalcount")) , flattened.col("results_flat.type" ) ,flattened.col(MetricMappingName.Json_reponse_map("tdate") ) ,flattened.col(MetricMappingName.Json_reponse_map("timestamp")))

      val joineddf =rcp_meta_df.join(mapping_df , (rcp_meta_df.col(MetricMappingName.Json_reponse_map("swu_id")) === mapping_df.col("swu_template_id")) , "left")

      joineddf.registerTempTable("sparkpost")

      val  intermediate_df =sqlContext.sql("SELECT %s , %s ,type as %s,  cast( `timestamp` as timestamp)  as %s , cast (regexp_replace(`timestamp`, 'T.*', '')  as date) as %s  from sparkpost".format(MetricMappingName.parsed_jsontable("swu_id"), MetricMappingName.parsed_jsontable("swu_name"),MetricMappingName.parsed_jsontable("type"), MetricMappingName.parsed_jsontable("event_timestamp") ,MetricMappingName.parsed_jsontable("day")))
      intermediate_df.registerTempTable("sparkpost_summary")

      //sqlContext.sql("truncate table " +sparkpost_temptable)

      //intermediate_df.write.mode("overwrite").insertInto(sparkpost_temptable);

      intermediate_df.write.mode("overwrite").partitionBy(MetricMappingName.parsed_jsontable("day")).insertInto(sparkpost_temptable);


      //intermediate_df.write.mode("overwrite").insertInto(sparkpost_temptable)

      val final_df  =sqlContext.sql(MetricEspush.metric_agg())

      val final_null_df=final_df.toDF().filter(final_df.col(MetricMappingName.Aggtablecolumns("swu_id")).isNotNull && final_df.col(MetricMappingName.Aggtablecolumns("total_sent")).isNotNull )

      val nullremoved_df=final_null_df.na.fill(0, Seq(MetricMappingName.Aggtablecolumns("openrate"))).na.fill(0, Seq(MetricMappingName.Aggtablecolumns("clickrate"))).na.fill(0, Seq(MetricMappingName.Aggtablecolumns("delayrate")))

      nullremoved_df.write.parquet(outputpath)

      MetricEspush.Es_push(esindex, doctype, nodes, port, nullremoved_df)

    }catch {
      case e: Exception => println("************** Error processing."); e.printStackTrace();
    } finally {
      println("successfully saved")
    }




  }

}