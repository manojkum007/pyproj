
package Webhook

import org.apache.spark.sql.DataFrame
import org.joda.time.DateTime

import scala.collection.mutable.ListBuffer


/**
  * Created by manoj on 6/1/18.
  */

object MetricEspush {

  var es_index: String =null
  var es_doctype: String =null
  var es_nodes: String =null
  var es_port: String =null

  def Es_push(esindex :String, doctype :String, nodes:String, port :String ,df :DataFrame): Unit ={
    es_index=esindex
    es_doctype=doctype
    es_nodes=nodes
    es_port=port

    try {
        df.toDF().write.format("org.elasticsearch.spark.sql")
        .option("es.nodes" , es_nodes)
        .option("es.port",es_port)
        .mode("Append")
        .save(es_index + "/"+ es_doctype)

    } catch {
      case e: Exception => println("************** Processing Error ."); e.printStackTrace();
    } finally {
      println("successfully saved")
    }


  }


  def metric_agg( ): String = {
    """select t.%s , t.%s, sum(t.deliverycount)  as %s, sum(t.opencount)/sum(t.deliverycount) as %s,  sum(t.clickcount)/sum(t.deliverycount) as %s , sum(t.delaycount)/sum(t.deliverycount) as %s , sum(t.bouncecount)/sum(t.deliverycount) as %s , t.`day` as %s from (
             SELECT [swu_template_id] , [swu_template_name] , [event_type],  count(*)  as typecount , case
            when [event_type] like '%s' then count([event_type]) else null  end as deliverycount,
          case
            when [event_type] like '%s' then count([event_type]) else null  end as clickcount,
          case
           when [event_type] like '%s' then count([event_type]) else null  end as delaycount,
          case
           when [event_type] like '%s' then count([event_type]) else null  end as bouncecount,
         case
           when [event_type] like '%s' then count([event_type]) else null  end as opencount ,%s
         FROM sparkpost_summary  group by  [swu_template_id], [swu_template_name] , [event_type] , %s order by [swu_template_id] ) t  where t.[swu_template_id] is not null  group by  t.[swu_template_id] , t.[swu_template_name],  t.%s""".format(MetricMappingName.Aggtablecolumns("swu_id") , MetricMappingName.Aggtablecolumns("swu_name") , MetricMappingName.Aggtablecolumns("total_sent") , MetricMappingName.Aggtablecolumns("openrate") ,MetricMappingName.Aggtablecolumns("clickrate") , MetricMappingName.Aggtablecolumns("delayrate") , MetricMappingName.Aggtablecolumns("bouncerate")
      , MetricMappingName.Aggtablecolumns("timestamp") ,"%injection%" ,"%click%" ,"%delay%" ,"%bounce%" ,"%open%" , MetricMappingName.parsed_jsontable("day") ,MetricMappingName.parsed_jsontable("day"), MetricMappingName.parsed_jsontable("day")).replace("[event_type]", MetricMappingName.parsed_jsontable("type")).replace("[swu_template_id]", MetricMappingName.parsed_jsontable("swu_id")).replace("[swu_template_name]", MetricMappingName.parsed_jsontable("swu_name"))


  }


  def partitiongenerator( sdate:String,  edate:String) :ListBuffer[String]= {
    val buf = new ListBuffer[String]
    var t1=DateTime.parse(sdate).getDayOfYear
    var t2=DateTime.parse(edate).getDayOfYear
    if (DateTime.parse(edate).getYear<=DateTime.parse(sdate).getYear) {
      for (i <- 0 to t2-t1) {
        val d = DateTime.parse(sdate).plusDays(i).toString("YYYY-MM-dd")
        buf+=d
      }

    } else
    {
      var datediff :Int=0;
      if (DateTime.parse(sdate).getYearOfEra%4==0){datediff=(366-t1)+t2 }
      else { datediff=(365-t1)+t2}
      for (i <- 0 to datediff) {
        val d = DateTime.parse(sdate).plusDays(i).toString("YYYY-MM-dd")
        buf+=d
      }

    }
    buf

  }

  }
