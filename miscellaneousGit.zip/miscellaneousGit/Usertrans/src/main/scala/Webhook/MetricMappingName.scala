/**
  * Created by manoj on 12/1/18.
  */


/**
  * Created by manoj on 23/11/17.
  */

package Webhook;


import scala.collection.mutable.HashMap;


object MetricMappingName {


  val Aggtablecolumns: HashMap[String, String] = HashMap(
    "swu_id"-> "swu_template_id",
    "swu_name"-> "swu_template_name",
    "total_sent"->"total_sent",
    "openrate"-> "openrate",
    "clickrate"-> "clickrate",
    "delayrate"-> "delayrate",
    "bouncerate"->"bouncerate",
    "timestamp"->"`@timestamp`"
  )




  val parsed_jsontable: HashMap[String, String] = HashMap(
    "swu_id"-> "swu_template_id",
    "swu_name"-> "swu_template_name",
    "type"->"event_type",
    "event_timestamp"-> "`event_timestamp`",
    "day"-> "`day`"
  )


  val Json_reponse_map: HashMap[String, String] = HashMap(
    "results_flat"->"results_flat",
    "rcpt_meta"-> "results_flat.rcpt_meta",
    "swu_id"-> "rcpt_meta.swu_template_id",
    "totalcount"-> "total_count",
    "type"->"results_flat.type",
    "tdate"-> "results_flat.tdate",
    "timestamp"-> "results_flat.timestamp"
  )





  /* def main(args: Array[String]): Unit = {

     print("hello")
   }
 */
}