/**
  * Created by manoj on 15/9/18.
  */


package DuplicateId

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
;

object RankId {
  def main(args: Array[String]) {

    //Create Spark Context
    import org.apache.spark._
    val conf = new SparkConf().setAppName("DuplicateMls")
    val sc = new SparkContext(conf)
    val rhino_path :String="hdfs://192.168.120.140:9000"
    //val rhino_path :String="hdfs://localhost:54310"
    var mls_table:String=""
    var primary_id:String=""
    var updated_col:String=""
    var panthercount:String="";
    var outputpath:String="";

    if (args.length > 1) {
      mls_table =  args(0).toString
      primary_id =  args(1).toString
      updated_col =  args(2).toString
      panthercount=  args(3).toString
      outputpath =  args(4).toString
    } else {
      println(" sorry no parameter passed")
      System.exit(-1)
    }
    import org.apache.spark.sql.expressions.Window
    import org.apache.spark.sql.functions.row_number

    val hiveContext = new org.apache.spark.sql.hive.HiveContext(sc)

    if (mls_table.toString.length>0) {
      val parqfile=hiveContext.table(mls_table)


      val config = new Configuration()
      config.set("fs.defaultFS", rhino_path)
      val fs= FileSystem.get(config)
      if ( fs.exists(new Path(outputpath.toString))) {
        fs.delete(new Path(outputpath.toString))
      }


      val newparq=parqfile.withColumn("rank", row_number().over(Window.partitionBy(primary_id).orderBy(updated_col)))
        val distdf=newparq.where(newparq.col("rank")===1).drop(newparq.col("rank"))

      assert(distdf.count==panthercount.toLong)

      hiveContext.setConf("hive.exec.dynamic.partition", "true")
      hiveContext.setConf("hive.exec.dynamic.partition.mode", "nonstrict")

      distdf.write.mode("overwrite").parquet(outputpath)


    }





    }
}


