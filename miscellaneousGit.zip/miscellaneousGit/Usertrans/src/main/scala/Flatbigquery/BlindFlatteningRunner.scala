package Flatbigquery

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.FileSystem
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.{SparkConf, SparkContext}
import org.joda.time.DateTime
import org.joda.time.format.DateTimeFormat

import scala.collection.mutable.ListBuffer;


object BlindFlatteningRunner {
  
  val HISTORIC_BQ_TABLE_FLAG = "spark.movoto.gabq.isHistoric";
  
  def main(args: Array[String]) {
	  /*
    if(! (args.length <= 3) ) {  
      System.out.println(args.mkString(", "))
      println("Usage: " + usage)
      System.exit(-1);
    }
    
    
    val inpath = args(0).trim
    val outpath = args(1).trim
    var filterPartitions:String =  if(args.length > 2) args(2).trim else null
    */
    
    var sc:SparkContext = null



    try {
      val conf = new SparkConf().setAppName("BasicAvg").setMaster("local[2]")
      sc = new SparkContext(conf)
      val sqlContext = new SQLContext(sc)
      val hiveContext = new HiveContext(sc)
    
      val flattener = new GABQBlindFlattener;
      val hadoopFS = FileSystem.get(new Configuration)
      
      //runFlattening(inpath, outpath, filterPartitions, sc, hiveContext, flattener, hadoopFS);
      runFlattening("/home/manoj/spark_helper/2017-04-07_071416-m-00004.snappy.parquet", "/home/manoj/spark_helper/log", "2018-08-15", sc, hiveContext, flattener, hadoopFS);
    } catch {
      case e:Exception => {
        println("*************** Error: " + e.getLocalizedMessage);
        e.printStackTrace()
        System.exit(-1)
      }
    } finally {
      if(sc != null) sc.stop()
    }
    
  }
  
  def runFlattening(inpath: String, outpath: String, filterPartitions: String, sc: SparkContext, hiveContext: HiveContext, flattener: GABQBlindFlattener, hadoopFS: FileSystem) = {
    
   // var allpartitions = hadoopFS.listStatus(new Path(inpath));

    //var filterPartitions="date=20180215:20180216"   format yyyyMMdd

    //var filterPartitions="date=2018-02-15:2018-02-16"   format yyyy-MM-dd

    /*
    try {

      val pattern = "(\\S+_\\S+)=(\\d+\\-\\d+\\-\\d+):(\\d+\\-\\d+\\-\\d+)".r

      val pattern(partitioncolumn, date1,date2)=filterPartitions
      var filterPartitionsList = ListBuffer[String]()
      partitiongenerator(date1, date2,"yyyy-MM-dd").map(r=>filterPartitionsList+=partitioncolumn+"="+r)


      allpartitions = allpartitions.filter(partfile => (partfile.isDirectory && filterPartitionsList.contains(partfile.getPath.getName)) )

      /*
      if( filterPartitions.split(":").length != filterPartitionsList.length ) {
        throw new Exception("Missing source partition(s). " + allpartitions.mkString(",") + s" does not match $filterPartitions." )
      }
      */
    } catch {
      case e: Exception =>{
      println( "some Error while parsing arguments" + e.printStackTrace())
      System.exit(-1)
      }
    }
*/

    /*

    if(filterPartitions != null) {      
      allpartitions = allpartitions.filter(partfile => (partfile.isDirectory && filterPartitions.contains(partfile.getPath.getName)) )
      if( filterPartitions.split(",").length != allpartitions.length ) {
        throw new Exception("Missing source partition(s). " + allpartitions.mkString(",") + s" does not match $filterPartitions." )
      }
    }

    */

    val allpartitions=List("/home/manoj/spark_helper/2017-04-07_071416-m-00004.snappy.parquet")
    for(infile <- allpartitions) {
     // val infileName = infile.getPath.getName
      //val inpartition = buildInPath( infileName, inpath )
     // println(s"Processing $inpartition")


      val rowRDD = flattener.flattenDailyExport( hiveContext.read.parquet(infile) )
      //println("outRows" +rowRDD.take(1))
      //rowRDD.foreach(r=>println(r))
      val df = hiveContext.createDataFrame(rowRDD, flattener.buildSchema)
      //println(df.take(1))
      /*
      hiveContext.setConf("hive.exec.dynamic.partition", "true")
      hiveContext.setConf("hive.exec.dynamic.partition.mode", "nonstrict")
    	val reccount = 
    	  df.write.mode("append")
    	  .partitionBy("date")
    	  .insertInto(outpath);
          	*/
    	//println(s"$reccount rows written for input $infileName to $outpath")

    }
  }
  
  def buildInPath(infileName: String, indir: String): String = {
    if(indir.endsWith("/")) indir.concat(infileName) 
    else indir.concat("/").concat(infileName)
  }



  def partitiongenerator( sdate:String,  edate:String, formatdate:String) :ListBuffer[String]= {
    val buf = new ListBuffer[String]
    val DATE_TIME_PATTERN = DateTimeFormat.forPattern(formatdate)
    val newsdate=DateTime.parse(sdate ,DATE_TIME_PATTERN)
    val newedate=DateTime.parse(edate ,DATE_TIME_PATTERN)

    var t1=newsdate.getDayOfYear
    var t2=newedate.getDayOfYear
    if (newedate.getYear<=newsdate.getYear) {
      for (i <- 0 to t2-t1) {
        val d = newsdate.plusDays(i).toString(formatdate)
        buf+=d
      }
    } else
    {
      var datediff :Int=0;
      if (newsdate.getYearOfEra%4==0){datediff=(366-t1)+t2 }
      else { datediff=(365-t1)+t2}
      for (i <- 0 to datediff) {
        val d = newsdate.plusDays(i).toString(formatdate)
        buf+=d
      }
    }
    buf
  }


  val usage = """spark-submit app ... <input directory> <output tablename> [<filter directory name1>,<filter directory name2>,...]
    FOR OLD GA BQ SCHEMA USE --conf spark.movoto.gabq.isHistoric=true """
}
