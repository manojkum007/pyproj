package Flatbigquery;

/**
  * Created by manoj on 11/5/18.
  */


import org.apache.spark.{SparkConf, SparkContext}

import scala.collection.mutable.ListBuffer


object ArrayFlattening {

  val conf = new SparkConf().setAppName("arayFlatten").setMaster("local[2]")
  val sc = new SparkContext(conf)
  val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)


  def main(args: Array[String]) = {
    case class Person(name: String, age: Int, phones: Seq[String])

    case class Likes(name: String, likes: String)

    val people = sc.parallelize(Array(
      Person("adam", 19, Seq("123-5767", "234-1544")),
      Person("bob", 23, Seq("456")),
      Person("cathy", 14, Seq("454-1222", "433-1212", "345-2343")),
      Person("dave", 44, Seq("454-1222"))
    ))
    val lsbuff = new ListBuffer[String];

    val peoplerdd = people.map(r => r.phones).map(rw => {
      for (elem <- rw) {lsbuff+=elem}
      //println("lsBuff="+lsbuff)
    })


    println("lsBuff="+lsbuff)
    for (elem <- peoplerdd.collect()) {println(elem)}
  }
}