package Flatbigquery;

import org.apache.spark.sql.Row
import org.apache.spark.sql.types._
import org.apache.spark.{SparkConf, SparkContext}

import scala.collection.mutable.{HashMap, ListBuffer, WrappedArray}

object Flattenbigquery {
  //val warehouseLocation = "file:///tmp/ware"

  val conf = new SparkConf().setAppName("Flattenbigquery").setMaster("local[2]")
  val sc = new SparkContext(conf)
  val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)

  var customDimensions: Seq[StructField] = null;

  val helper = FlatteningHelper;
  var totals: Seq[StructField] = null;

  def getAsByteStringOrBoolean(rw: Row, colName: String) : Any = {
    var finalvalue:Any=null
    if (rw.getAs[Array[Byte]](colName).isInstanceOf[Array[Byte]]) {
      val temp=rw.getAs[Array[Byte]](colName) match {
        case a: Array[Byte] => new String(a, "utf-8")
        case _ => null.asInstanceOf[String]
      }
      finalvalue=temp
    }
    else if (rw.getAs[BooleanType](colName).isInstanceOf[Boolean]) {
      val tbool=rw.getAs[Boolean](colName) match {
        case a: Boolean => a
        case _ => null.asInstanceOf[Boolean]
      }
      finalvalue=tbool
    }
    else {
      println("some other value")
    }

    finalvalue
  }



  def getAsByteString(rw: Row, colName: String) : String = {
    rw.getAs[Array[Byte]](colName) match {
      case a: Array[Byte] => new String(a, "utf-8")
      case _ => null.asInstanceOf[String]
    }
  }




  def deviceschemagenerator (rw:Row ,schema:HashMap[String, String]): ListBuffer[Any] ={
    var ll= new ListBuffer[Any];
    for ((col,v)<-schema) {
      ll+=getAsByteStringOrBoolean(rw,col)
    }
     println("list"+ ll)
    ll
  }

  def binaryconvertor(x:Any) :String ={
    new String(x.asInstanceOf[Array[Byte]],"utf-8")
  }




      def schemaForCustDims: Unit = {
    val colNamePrefix = "customDimensions_index_";
     customDimensions =
      (for(columnName <-
           List(6, 61, 65, 66, 71, 72, 73, 74, 75, 76, 77, 79, 80, 81, 83, 84, 85) )
        yield {
          StructField((colNamePrefix.concat(columnName.toString)), StringType, true, helper.getCommentMetadata(columnName.toString) )
          //.withComment(columnName.toString)
        })

  }


  def explodeCustomDimensions(rw: Row, recBuff: ListBuffer[Any]): Unit = {
    addCustomDimensionFields(customDimensions, rw.getAs[Row]("customDimensions").getAs[WrappedArray[Row]]("array"), recBuff)
  }


  def addCustomDimensionFields(fields: Seq[StructField], rwArr: WrappedArray[Row], recBuff: ListBuffer[Any]): Unit = {
    fields.foreach(sf => {
      recBuff += null.asInstanceOf[String] // insert value as null by default
      rwArr.foreach(rw => {
        val indexValue = rw.getAs[Long]("index")
        if(indexValue == sf.metadata.getString(helper.CONST_COMMENT).toLong) {
          recBuff( (recBuff.size - 1) ) = helper.getAsByteString(rw, "value")
        }
      })
    })
    println("prting row ")
    recBuff.foreach(println)
  }

  def main(args: Array[String]) = {
    var errorCode: Int = 0;


    println("spark engine started")
    //
/*
    val bqdf=sqlContext.read.parquet("/user/hive/warehouse/bq_nova.db/sessions_hits_parquet_newschema/update_date=2018-02-15")


    val newdf=sqlContext.sql("select  hits.`array`.customDimensions.`array` from  nova")

    bqdf.rdd.map(r=>r.getAs[Row]("customDimensions")).map(r=>r.getAs[WrappedArray[Row]](0)).map(r=>r(0)(0)).filter(_.isInstanceOf[Long]).filter(r=>r==65).take(10)
*/

    val bqdf=sqlContext.read.parquet("/home/manoj/miscellaneousGit/Usertrans/src/main/resources/bigquery_data/2017-10-03_131535-m-00004.snappy.parquet")
    bqdf.registerTempTable("nova")



    val recBuff = ListBuffer.empty[Any]
    schemaForCustDims

    customDimensions.foreach(println)
   /* val customdimensiondf=bqdf.flatMap(rw=> {
      addCustomDimensionFields(customDimensions, rw.getAs[Row]("customDimensions").getAs[mutable.WrappedArray[Row]]("array") ,recBuff)

    }
    })*/
    println("printing dataframe count"+ bqdf.count)

    val rowRDD  =bqdf.flatMap(rw => {
    val recBuff = ListBuffer.empty[Any]
    explodeCustomDimensions(rw, recBuff)
    val outRows=ListBuffer.empty[Row]
    outRows :+ Row(recBuff: _*)
    })


    println("printing new dataframe count"+ rowRDD.count)
    for (elem <- rowRDD.take(2)) {println(elem)}



    //maindf.rdd.map(r=>r.get(4).asInstanceOf[WrappedArray[Int]].toList).map(r=>r.foreach(rw=>recBuff+=r)).coll
  //(RowEncoder(schema))


     //customdimensiondf.flatMap(r=>r)




    
    /*
    val dd=bqdf.rdd.flatMap(r=>r.getAs[Row]("customDimensions").getAs[WrappedArray[Row]](0)).
      map(r=>getAsByteString(r,"value")).take(1)
    dd.foreach(println)
    */

    val devicebgschema: HashMap[String, String] = HashMap(
      "browser"-> "binary",
      "browserVersion"-> "binary",
      "browserSize"-> "binary",
      "operatingSystem"-> "binary",
      "operatingSystemVersion"-> "binary",
      "isMobile"-> "boolean",
      "mobileDeviceBranding"-> "binary",
      "mobileDeviceModel"-> "binary",
      "mobileInputSelector"-> "binary",
      "mobileDeviceInfo"-> "binary",
      "mobileDeviceMarketingName"-> "binary",
      "flashVersion"-> "binary",
      "javaEnabled"-> "boolean",
      "language"-> "binary",
      "screenColors"-> "binary",
      "screenResolution"-> "binary",
      "deviceCategory"-> "binary")





    //val deviceDF=bqdf.select("device")
    //val brow_rd=deviceDF.rdd.map(r=>r.getAs[Row]("device")).map(r=>deviceschemagenerator(r,devicebgschema))

    //val brow_rd=deviceDF.rdd.map(r=>r.getAs[Row]("device")).map(r=>Row(getAsByteString(r,"browser"),getAsByteString(r,"browserVersion")))


    //brow_rd.take(2)


    val deviceSchema =
      StructType(
        Array(
          StructField("browser", StringType, nullable=true),
          StructField("browserVersion", StringType, nullable=true)
        /*  StructField("browserSize", StringType, nullable=true),
          StructField("operatingSystem", StringType, nullable=true),
          StructField("operatingSystemVersion", StringType, nullable=true),
          StructField("isMobile", StringType, nullable=true)*/
        )
      )


    /*
    val deviceSchema =
      StructType(
        Array(

          ArrayType(StructType(StructField("index1",LongType,true)),true)
          //StructField("browserVersion", StringType, nullable=true)
        )
      )
*/


       //val finaldf=sqlContext.createDataFrame(brow_rd, deviceSchema) //
    // finaldf.foreach(println)
/*

    |    |-- browser: binary (nullable = true)
    |    |-- browserVersion: binary (nullable = true)
    |    |-- browserSize: binary (nullable = true)
    |    |-- operatingSystem: binary (nullable = true)
    |    |-- operatingSystemVersion: binary (nullable = true)
    |    |-- isMobile: boolean (nullable = true)
    |    |-- mobileDeviceBranding: binary (nullable = true)
    |    |-- mobileDeviceModel: binary (nullable = true)
    |    |-- mobileInputSelector: binary (nullable = true)
    |    |-- mobileDeviceInfo: binary (nullable = true)
    |    |-- mobileDeviceMarketingName: binary (nullable = true)
    |    |-- flashVersion: binary (nullable = true)
    |    |-- javaEnabled: boolean (nullable = true)
    |    |-- language: binary (nullable = true)
    |    |-- screenColors: binary (nullable = true)
    |    |-- screenResolution: binary (nullable = true)
    |    |-- deviceCategory: binary (nullable = true)
*/





    /*
    root
    |-- visitorId: long (nullable = true)
    |-- visitNumber: long (nullable = true)
    |-- visitId: long (nullable = true)
    |-- visitStartTime: long (nullable = true)
    |-- date: binary (nullable = true)
    |-- totals: struct (nullable = true)
    |    |-- visits: long (nullable = true)
    |    |-- hits: long (nullable = true)
    |    |-- pageviews: long (nullable = true)
    |    |-- timeOnSite: long (nullable = true)
    |    |-- bounces: long (nullable = true)
    |    |-- transactions: long (nullable = true)
    |    |-- transactionRevenue: long (nullable = true)
    |    |-- newVisits: long (nullable = true)
    |    |-- screenviews: long (nullable = true)
    |    |-- uniqueScreenviews: long (nullable = true)
    |    |-- timeOnScreen: long (nullable = true)
    |    |-- totalTransactionRevenue: long (nullable = true)
    |    |-- sessionQualityDim: long (nullable = true)
    |-- trafficSource: struct (nullable = true)
    |    |-- referralPath: binary (nullable = true)
    |    |-- campaign: binary (nullable = true)
    |    |-- source: binary (nullable = true)
    |    |-- medium: binary (nullable = true)
    |    |-- keyword: binary (nullable = true)
    |    |-- adContent: binary (nullable = true)
    |    |-- adwordsClickInfo: struct (nullable = true)
    |    |    |-- campaignId: long (nullable = true)
    |    |    |-- adGroupId: long (nullable = true)
    |    |    |-- creativeId: long (nullable = true)
    |    |    |-- criteriaId: long (nullable = true)
    |    |    |-- page: long (nullable = true)
    |    |    |-- slot: binary (nullable = true)
    |    |    |-- criteriaParameters: binary (nullable = true)
    |    |    |-- gclId: binary (nullable = true)
    |    |    |-- customerId: long (nullable = true)
    |    |    |-- adNetworkType: binary (nullable = true)
    |    |    |-- targetingCriteria: struct (nullable = true)
    |    |    |    |-- boomUserlistId: long (nullable = true)
    |    |    |-- isVideoAd: boolean (nullable = true)
    |    |-- isTrueDirect: boolean (nullable = true)
    |    |-- campaignCode: binary (nullable = true)
    |-- device: struct (nullable = true)
    |    |-- browser: binary (nullable = true)
    |    |-- browserVersion: binary (nullable = true)
    |    |-- browserSize: binary (nullable = true)
    |    |-- operatingSystem: binary (nullable = true)
    |    |-- operatingSystemVersion: binary (nullable = true)
    |    |-- isMobile: boolean (nullable = true)
    |    |-- mobileDeviceBranding: binary (nullable = true)
    |    |-- mobileDeviceModel: binary (nullable = true)
    |    |-- mobileInputSelector: binary (nullable = true)
    |    |-- mobileDeviceInfo: binary (nullable = true)
    |    |-- mobileDeviceMarketingName: binary (nullable = true)
    |    |-- flashVersion: binary (nullable = true)
    |    |-- javaEnabled: boolean (nullable = true)
    |    |-- language: binary (nullable = true)
    |    |-- screenColors: binary (nullable = true)
    |    |-- screenResolution: binary (nullable = true)
    |    |-- deviceCategory: binary (nullable = true)
    |-- geoNetwork: struct (nullable = true)
    |    |-- continent: binary (nullable = true)
    |    |-- subContinent: binary (nullable = true)
    |    |-- country: binary (nullable = true)
    |    |-- region: binary (nullable = true)
    |    |-- metro: binary (nullable = true)
    |    |-- city: binary (nullable = true)
    |    |-- cityId: binary (nullable = true)
    |    |-- networkDomain: binary (nullable = true)
    |    |-- latitude: binary (nullable = true)
    |    |-- longitude: binary (nullable = true)
    |    |-- networkLocation: binary (nullable = true)
    |-- customDimensions: struct (nullable = true)
    |    |-- array: array (nullable = true)
    |    |    |-- element: struct (containsNull = true)
    |    |    |    |-- index: long (nullable = true)
    |    |    |    |-- value: binary (nullable = true)
    |-- hits: struct (nullable = true)
    |    |-- array: array (nullable = true)
    |    |    |-- element: struct (containsNull = true)
    |    |    |    |-- hitNumber: long (nullable = true)
    |    |    |    |-- time: long (nullable = true)
    |    |    |    |-- hour: long (nullable = true)
    |    |    |    |-- minute: long (nullable = true)
    |    |    |    |-- isSecure: boolean (nullable = true)
    |    |    |    |-- isInteraction: boolean (nullable = true)
    |    |    |    |-- isEntrance: boolean (nullable = true)
    |    |    |    |-- isExit: boolean (nullable = true)
    |    |    |    |-- referer: binary (nullable = true)
    |    |    |    |-- page: struct (nullable = true)
    |    |    |    |    |-- pagePath: binary (nullable = true)
    |    |    |    |    |-- hostname: binary (nullable = true)
    |    |    |    |    |-- pageTitle: binary (nullable = true)
    |    |    |    |    |-- searchKeyword: binary (nullable = true)
    |    |    |    |    |-- searchCategory: binary (nullable = true)
    |    |    |    |    |-- pagePathLevel1: binary (nullable = true)
    |    |    |    |    |-- pagePathLevel2: binary (nullable = true)
    |    |    |    |    |-- pagePathLevel3: binary (nullable = true)
    |    |    |    |    |-- pagePathLevel4: binary (nullable = true)
    |    |    |    |-- transaction: struct (nullable = true)
    |    |    |    |    |-- transactionId: binary (nullable = true)
    |    |    |    |    |-- transactionRevenue: long (nullable = true)
    |    |    |    |    |-- transactionTax: long (nullable = true)
    |    |    |    |    |-- transactionShipping: long (nullable = true)
    |    |    |    |    |-- affiliation: binary (nullable = true)
    |    |    |    |    |-- currencyCode: binary (nullable = true)
    |    |    |    |    |-- localTransactionRevenue: long (nullable = true)
    |    |    |    |    |-- localTransactionTax: long (nullable = true)
    |    |    |    |    |-- localTransactionShipping: long (nullable = true)
    |    |    |    |    |-- transactionCoupon: binary (nullable = true)
    |    |    |    |-- item: struct (nullable = true)
    |    |    |    |    |-- transactionId: binary (nullable = true)
    |    |    |    |    |-- productName: binary (nullable = true)
    |    |    |    |    |-- productCategory: binary (nullable = true)
    |    |    |    |    |-- productSku: binary (nullable = true)
    |    |    |    |    |-- itemQuantity: long (nullable = true)
    |    |    |    |    |-- itemRevenue: long (nullable = true)
    |    |    |    |    |-- currencyCode: binary (nullable = true)
    |    |    |    |    |-- localItemRevenue: long (nullable = true)
    |    |    |    |-- contentInfo: struct (nullable = true)
    |    |    |    |    |-- contentDescription: binary (nullable = true)
    |    |    |    |-- appInfo: struct (nullable = true)
    |    |    |    |    |-- name: binary (nullable = true)
    |    |    |    |    |-- version: binary (nullable = true)
    |    |    |    |    |-- id: binary (nullable = true)
    |    |    |    |    |-- installerId: binary (nullable = true)
    |    |    |    |    |-- appInstallerId: binary (nullable = true)
    |    |    |    |    |-- appName: binary (nullable = true)
    |    |    |    |    |-- appVersion: binary (nullable = true)
    |    |    |    |    |-- appId: binary (nullable = true)
    |    |    |    |    |-- screenName: binary (nullable = true)
    |    |    |    |    |-- landingScreenName: binary (nullable = true)
    |    |    |    |    |-- exitScreenName: binary (nullable = true)
    |    |    |    |    |-- screenDepth: binary (nullable = true)
    |    |    |    |-- exceptionInfo: struct (nullable = true)
    |    |    |    |    |-- description: binary (nullable = true)
    |    |    |    |    |-- isFatal: boolean (nullable = true)
    |    |    |    |    |-- exceptions: long (nullable = true)
    |    |    |    |    |-- fatalExceptions: long (nullable = true)
    |    |    |    |-- eventInfo: struct (nullable = true)
    |    |    |    |    |-- eventCategory: binary (nullable = true)
    |    |    |    |    |-- eventAction: binary (nullable = true)
    |    |    |    |    |-- eventLabel: binary (nullable = true)
    |    |    |    |    |-- eventValue: long (nullable = true)
    |    |    |    |-- product: struct (nullable = true)
    |    |    |    |    |-- array: array (nullable = true)
    |    |    |    |    |    |-- element: struct (containsNull = true)
    |    |    |    |    |    |    |-- productSKU: binary (nullable = true)
    |    |    |    |    |    |    |-- v2ProductName: binary (nullable = true)
    |    |    |    |    |    |    |-- v2ProductCategory: binary (nullable = true)
    |    |    |    |    |    |    |-- productVariant: binary (nullable = true)
    |    |    |    |    |    |    |-- productBrand: binary (nullable = true)
    |    |    |    |    |    |    |-- productRevenue: long (nullable = true)
    |    |    |    |    |    |    |-- localProductRevenue: long (nullable = true)
    |    |    |    |    |    |    |-- productPrice: long (nullable = true)
    |    |    |    |    |    |    |-- localProductPrice: long (nullable = true)
    |    |    |    |    |    |    |-- productQuantity: long (nullable = true)
    |    |    |    |    |    |    |-- productRefundAmount: long (nullable = true)
    |    |    |    |    |    |    |-- localProductRefundAmount: long (nullable = true)
    |    |    |    |    |    |    |-- isImpression: boolean (nullable = true)
    |    |    |    |    |    |    |-- isClick: boolean (nullable = true)
    |    |    |    |    |    |    |-- customDimensions: struct (nullable = true)
    |    |    |    |    |    |    |    |-- array: array (nullable = true)
    |    |    |    |    |    |    |    |    |-- element: struct (containsNull = true)
    |    |    |    |    |    |    |    |    |    |-- index: long (nullable = true)
    |    |    |    |    |    |    |    |    |    |-- value: binary (nullable = true)
    |    |    |    |    |    |    |-- customMetrics: struct (nullable = true)
    |    |    |    |    |    |    |    |-- array: array (nullable = true)
    |    |    |    |    |    |    |    |    |-- element: struct (containsNull = true)
    |    |    |    |    |    |    |    |    |    |-- index: long (nullable = true)
    |    |    |    |    |    |    |    |    |    |-- value: long (nullable = true)
    |    |    |    |    |    |    |-- productListName: binary (nullable = true)
    |    |    |    |    |    |    |-- productListPosition: long (nullable = true)
    |    |    |    |-- promotion: struct (nullable = true)
    |    |    |    |    |-- array: array (nullable = true)
    |    |    |    |    |    |-- element: struct (containsNull = true)
    |    |    |    |    |    |    |-- promoId: binary (nullable = true)
    |    |    |    |    |    |    |-- promoName: binary (nullable = true)
    |    |    |    |    |    |    |-- promoCreative: binary (nullable = true)
    |    |    |    |    |    |    |-- promoPosition: binary (nullable = true)
    |    |    |    |-- promotionActionInfo: struct (nullable = true)
    |    |    |    |    |-- promoIsView: boolean (nullable = true)
    |    |    |    |    |-- promoIsClick: boolean (nullable = true)
    |    |    |    |-- refund: struct (nullable = true)
    |    |    |    |    |-- refundAmount: long (nullable = true)
    |    |    |    |    |-- localRefundAmount: long (nullable = true)
    |    |    |    |-- eCommerceAction: struct (nullable = true)
    |    |    |    |    |-- action_type: binary (nullable = true)
    |    |    |    |    |-- step: long (nullable = true)
    |    |    |    |    |-- option: binary (nullable = true)
    |    |    |    |-- experiment: struct (nullable = true)
    |    |    |    |    |-- array: array (nullable = true)
    |    |    |    |    |    |-- element: struct (containsNull = true)
    |    |    |    |    |    |    |-- experimentId: binary (nullable = true)
    |    |    |    |    |    |    |-- experimentVariant: binary (nullable = true)
    |    |    |    |-- publisher: struct (nullable = true)
    |    |    |    |    |-- dfpClicks: long (nullable = true)
    |    |    |    |    |-- dfpImpressions: long (nullable = true)
    |    |    |    |    |-- dfpMatchedQueries: long (nullable = true)
    |    |    |    |    |-- dfpMeasurableImpressions: long (nullable = true)
    |    |    |    |    |-- dfpQueries: long (nullable = true)
    |    |    |    |    |-- dfpRevenueCpm: long (nullable = true)
    |    |    |    |    |-- dfpRevenueCpc: long (nullable = true)
    |    |    |    |    |-- dfpViewableImpressions: long (nullable = true)
    |    |    |    |    |-- dfpPagesViewed: long (nullable = true)
    |    |    |    |    |-- adsenseBackfillDfpClicks: long (nullable = true)
    |    |    |    |    |-- adsenseBackfillDfpImpressions: long (nullable = true)
    |    |    |    |    |-- adsenseBackfillDfpMatchedQueries: long (nullable = true)
    |    |    |    |    |-- adsenseBackfillDfpMeasurableImpressions: long (nullable = true)
    |    |    |    |    |-- adsenseBackfillDfpQueries: long (nullable = true)
    |    |    |    |    |-- adsenseBackfillDfpRevenueCpm: long (nullable = true)
    |    |    |    |    |-- adsenseBackfillDfpRevenueCpc: long (nullable = true)
    |    |    |    |    |-- adsenseBackfillDfpViewableImpressions: long (nullable = true)
    |    |    |    |    |-- adsenseBackfillDfpPagesViewed: long (nullable = true)
    |    |    |    |    |-- adxBackfillDfpClicks: long (nullable = true)
    |    |    |    |    |-- adxBackfillDfpImpressions: long (nullable = true)
    |    |    |    |    |-- adxBackfillDfpMatchedQueries: long (nullable = true)
    |    |    |    |    |-- adxBackfillDfpMeasurableImpressions: long (nullable = true)
    |    |    |    |    |-- adxBackfillDfpQueries: long (nullable = true)
    |    |    |    |    |-- adxBackfillDfpRevenueCpm: long (nullable = true)
    |    |    |    |    |-- adxBackfillDfpRevenueCpc: long (nullable = true)
    |    |    |    |    |-- adxBackfillDfpViewableImpressions: long (nullable = true)
    |    |    |    |    |-- adxBackfillDfpPagesViewed: long (nullable = true)
    |    |    |    |    |-- adxClicks: long (nullable = true)
    |    |    |    |    |-- adxImpressions: long (nullable = true)
    |    |    |    |    |-- adxMatchedQueries: long (nullable = true)
    |    |    |    |    |-- adxMeasurableImpressions: long (nullable = true)
    |    |    |    |    |-- adxQueries: long (nullable = true)
    |    |    |    |    |-- adxRevenue: long (nullable = true)
    |    |    |    |    |-- adxViewableImpressions: long (nullable = true)
    |    |    |    |    |-- adxPagesViewed: long (nullable = true)
    |    |    |    |    |-- adsViewed: long (nullable = true)
    |    |    |    |    |-- adsUnitsViewed: long (nullable = true)
    |    |    |    |    |-- adsUnitsMatched: long (nullable = true)
    |    |    |    |    |-- viewableAdsViewed: long (nullable = true)
    |    |    |    |    |-- measurableAdsViewed: long (nullable = true)
    |    |    |    |    |-- adsPagesViewed: long (nullable = true)
    |    |    |    |    |-- adsClicked: long (nullable = true)
    |    |    |    |    |-- adsRevenue: long (nullable = true)
    |    |    |    |    |-- dfpAdGroup: binary (nullable = true)
    |    |    |    |    |-- dfpAdUnits: binary (nullable = true)
    |    |    |    |    |-- dfpNetworkId: binary (nullable = true)
    |    |    |    |-- customVariables: struct (nullable = true)
    |    |    |    |    |-- array: array (nullable = true)
    |    |    |    |    |    |-- element: struct (containsNull = true)
    |    |    |    |    |    |    |-- index: long (nullable = true)
    |    |    |    |    |    |    |-- customVarName: binary (nullable = true)
    |    |    |    |    |    |    |-- customVarValue: binary (nullable = true)
    |    |    |    |-- customDimensions: struct (nullable = true)
    |    |    |    |    |-- array: array (nullable = true)
    |    |    |    |    |    |-- element: struct (containsNull = true)
    |    |    |    |    |    |    |-- index: long (nullable = true)
    |    |    |    |    |    |    |-- value: binary (nullable = true)
    |    |    |    |-- customMetrics: struct (nullable = true)
    |    |    |    |    |-- array: array (nullable = true)
    |    |    |    |    |    |-- element: struct (containsNull = true)
    |    |    |    |    |    |    |-- index: long (nullable = true)
    |    |    |    |    |    |    |-- value: long (nullable = true)
    |    |    |    |-- type: binary (nullable = true)
    |    |    |    |-- social: struct (nullable = true)
    |    |    |    |    |-- socialInteractionNetwork: binary (nullable = true)
    |    |    |    |    |-- socialInteractionAction: binary (nullable = true)
    |    |    |    |    |-- socialInteractions: long (nullable = true)
    |    |    |    |    |-- socialInteractionTarget: binary (nullable = true)
    |    |    |    |    |-- socialNetwork: binary (nullable = true)
    |    |    |    |    |-- uniqueSocialInteractions: long (nullable = true)
    |    |    |    |    |-- hasSocialSourceReferral: binary (nullable = true)
    |    |    |    |    |-- socialInteractionNetworkAction: binary (nullable = true)
    |    |    |    |-- latencyTracking: struct (nullable = true)
    |    |    |    |    |-- pageLoadSample: long (nullable = true)
    |    |    |    |    |-- pageLoadTime: long (nullable = true)
    |    |    |    |    |-- pageDownloadTime: long (nullable = true)
    |    |    |    |    |-- redirectionTime: long (nullable = true)
    |    |    |    |    |-- speedMetricsSample: long (nullable = true)
    |    |    |    |    |-- domainLookupTime: long (nullable = true)
    |    |    |    |    |-- serverConnectionTime: long (nullable = true)
    |    |    |    |    |-- serverResponseTime: long (nullable = true)
    |    |    |    |    |-- domLatencyMetricsSample: long (nullable = true)
    |    |    |    |    |-- domInteractiveTime: long (nullable = true)
    |    |    |    |    |-- domContentLoadedTime: long (nullable = true)
    |    |    |    |    |-- userTimingValue: long (nullable = true)
    |    |    |    |    |-- userTimingSample: long (nullable = true)
    |    |    |    |    |-- userTimingVariable: binary (nullable = true)
    |    |    |    |    |-- userTimingCategory: binary (nullable = true)
    |    |    |    |    |-- userTimingLabel: binary (nullable = true)
    |    |    |    |-- sourcePropertyInfo: struct (nullable = true)
    |    |    |    |    |-- sourcePropertyDisplayName: binary (nullable = true)
    |    |    |    |    |-- sourcePropertyTrackingId: binary (nullable = true)
    |    |    |    |-- contentGroup: struct (nullable = true)
    |    |    |    |    |-- contentGroup1: binary (nullable = true)
    |    |    |    |    |-- contentGroup2: binary (nullable = true)
    |    |    |    |    |-- contentGroup3: binary (nullable = true)
    |    |    |    |    |-- contentGroup4: binary (nullable = true)
    |    |    |    |    |-- contentGroup5: binary (nullable = true)
    |    |    |    |    |-- previousContentGroup1: binary (nullable = true)
    |    |    |    |    |-- previousContentGroup2: binary (nullable = true)
    |    |    |    |    |-- previousContentGroup3: binary (nullable = true)
    |    |    |    |    |-- previousContentGroup4: binary (nullable = true)
    |    |    |    |    |-- previousContentGroup5: binary (nullable = true)
    |    |    |    |    |-- contentGroupUniqueViews1: long (nullable = true)
    |    |    |    |    |-- contentGroupUniqueViews2: long (nullable = true)
    |    |    |    |    |-- contentGroupUniqueViews3: long (nullable = true)
    |    |    |    |    |-- contentGroupUniqueViews4: long (nullable = true)
    |    |    |    |    |-- contentGroupUniqueViews5: long (nullable = true)
    |    |    |    |-- dataSource: binary (nullable = true)
    |-- fullVisitorId: binary (nullable = true)
    |-- userId: binary (nullable = true)
    |-- channelGrouping: binary (nullable = true)
    |-- socialEngagementType: binary (nullable = true)
*/
    /*
    root
 |-- customDimensions: array (nullable = true)
 |    |-- element: struct (containsNull = true)
 |    |    |-- array: array (nullable = true)
 |    |    |    |-- element: struct (containsNull = true)
 |    |    |    |    |-- index: long (nullable = true)
 |    |    |    |    |-- value: binary (nullable = true)

     */
    //println(newdf.show())

    /*
        import org.apache.spark.sql.DataFrame
        import org.apache.spark.sql.types._


        case class Bar(x: Int, y: String)
        case class Foo(bar: Bar)

        val df = sc.parallelize(Seq(Foo(Bar(1, "first")), Foo(Bar(2, "second")))).toDF

        df.printSchema

        def children(colname: String, df: DataFrame) = {
          val parent = df.schema.fields.filter(_.name == colname).head
          val fields = parent.dataType match {
            case x: StructType => x.fields
            case _ => Array.empty[StructField]
          }
          fields.map(x => col(s"$colname.${x.name}"))
        }


        df.select(children("bar", df): _*).printSchema


        scala> tt.asInstanceOf[StructType].fields.foreach(r=>ss+=StructField(prefix+ "."+r.name,r.dataType,true))

        import org.apache.spark.sql.types.StructType

        val nested_fields = df.schema
          .filter(c => c.name == "b2")
          .flatMap(_.dataType.asInstanceOf[StructType].fields)
          .map(_.name)

    */

    //var totals=null

    /*
    schemaForTotals(bqdf);

    println("totals: "+ totals);

    val hitsdf=sqlContext.sql("select hits from nova limit 10")

    hitsdf.rdd.map(rw=>rw.getAs[Row]("hits").getAs[WrappedArray[Row]]("array"))

    hitsdf.rdd.map(rw=>rw.getAs[Row]("hits").getAs[WrappedArray[Row]]("array")).flatMap(r=>r).map(r=>r.getAs[Row]("customDimensions")).map(r=>r.getAs[WrappedArray[Row]](0)).map(r=>r).filter(r=>r.length>0).map(r=>println(r(0)(0))).take(10)

    //rw.getAs[Row]("customDimensions").getAs[WrappedArray[Row]]("array")
//> hitsdf.rdd.map(rw=>rw.getAs[Row]("hits").getAs[WrappedArray[Row]]("array")).flatMap(r=>r).map(r=>r.getAs[Row]("customDimensions")).map(r=>r.getAs[WrappedArray[Row]](0)).map(r=>r(0)).take(5)


    val customdf=sql("select customDimensions from nova limit 10")


    //customdf.rdd.map(r=>r.getAs[Row]("customDimensions")).map(r=>r.getAs[WrappedArray[Row]]("array")).take(10).foreach(r=>println(r(1)(0)))



    println("\nFlattening rows "+ flattenDailyExport(bqdf).count)

    def flattenDailyExport(dailyDF: DataFrame): RDD[Row] = {
      val bqrdd=dailyDF.rdd
      var outRows=null
      println("total row")
      bqrdd.map(r=>println(r.getAs[Row]("totals")))

      /*
      bqrdd.map(rw=>{
        val recBuff = ListBuffer.empty[Any]
        println("Rows"+ rw)
        recBuff+=rw.getAs[Row]("totals")
        explodeTotals(rw, recBuff)
        val dateValue = helper.getAsByteString(rw, "date")
        recBuff+=dateValue
      })
      */

      bqrdd
    }


    // println("recBuff "+ recBuff)

    //rhino search for customdimensions

    import scala.util.Try
    //Data is avilable at 05 dec
    val bqdf=sqlContext.read.parquet("/user/hive/warehouse/bq_nova.db/sessions_hits_parquet_newschema/updated_date=2017-12-05")


    val bqdf=sqlContext.read.parquet("/user/hive/warehouse/bq_nova.db/sessions_hits_parquet_newschema/updated_date=2017-12-05")
    bqdf.registerTempTable("nova")
    val hitsdf=sqlContext.sql("select  hits.`array`.customDimensions, cast(`date` as string)  from  nova")

    hitsdf.rdd.flatMap(r=>r.getAs[WrappedArray[Row]]("customDimensions")).flatMap(r=>r.getAs[WrappedArray[Row]](0)).map(r=>r(0)).filter(r=>r>89).take(10)

    hitsdf.rdd.flatMap(r=>r.getAs[WrappedArray[Row]]("customDimensions")).flatMap(r=>r.getAs[WrappedArray[Row]](0)).map(r=>r(0)).map(x => Try(x.asInstanceOf[Number].longValue)).map(r=>r.get).filter(r=>r>88).take(10)



  }

  def explodeTotals(rw: Row, recBuff: ListBuffer[Any]): Unit = {
    addRecordsByType(totals, rw.getAs[Row]("totals"), recBuff);
  }


  def addRecordsByType(fields: Seq[StructField], rw: Row, recBuff: ListBuffer[Any]): Unit = {
    fields.foreach(sf => sf.dataType match {
      case _: LongType => if(rw==null) recBuff += null.asInstanceOf[Long] else recBuff += rw.getAs[Long](sf.metadata.getString(helper.CONST_COMMENT))
      case _: StringType => if(rw==null) recBuff += null.asInstanceOf[String] else recBuff += helper.getAsByteString(rw, sf.metadata.getString(helper.CONST_COMMENT))
      case _: BooleanType => if(rw==null) recBuff += null.asInstanceOf[Boolean] else recBuff += rw.getAs[Boolean](sf.metadata.getString(helper.CONST_COMMENT))
      case _ => println("Error: Data type of column not recognized- " + sf.metadata.getString(helper.CONST_COMMENT))
    })
  }

  def schemaForTotals(df : DataFrame) : Unit = {
    val colNamePrefix = "total_";
    totals =
      (for(columnName <-
           List("visits",
             "hits",
             "pageviews",
             "timeOnSite",
             "bounces",
             "transactions",
             "transactionRevenue",
             "newVisits",
             "screenviews",
             "uniqueScreenviews",
             "timeOnScreen",
             "totalTransactionRevenue"
           ) )
        yield { val sf = df.schema("totals").dataType.asInstanceOf[StructType](columnName)
          helper.newStructField(sf, colNamePrefix)
        })

        */




  }

}
