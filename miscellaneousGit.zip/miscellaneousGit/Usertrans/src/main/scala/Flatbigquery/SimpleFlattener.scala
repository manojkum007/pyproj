package Flatbigquery

trait SimpleFlattener extends java.io.Serializable {
  
}