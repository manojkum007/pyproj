
api_base_url = '/api/v1'
es_base_url = {
    'beers': 'http://localhost:9200/cheermeapp/beers',
    'styles': 'http://localhost:9200/cheermeapp/styles',
}
