# -*- coding: utf-8 -*-
"""
Created on Wed Jan 11 00:57:07 2017

@author: manoj
"""

import re

addressToVerify ='inf1111111111111o@emailhvvfvippo.com'
match = re.match('^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$', addressToVerify)

if match == None:
    print('Bad Syntax')
    raise ValueError('Bad Syntax')

print match.group(0)