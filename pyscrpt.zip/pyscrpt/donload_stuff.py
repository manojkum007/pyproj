# -*- coding: utf-8 -*-
"""
Created on Wed Jun 20 15:30:46 2018

@author: manoj
"""


import requests

#This URL will be the URL that your login form points to with the "action" tag.
POST-LOGIN-URL = 'https://my.freecycle.org/login'

#This URL is the page you actually want to pull down with requests.
REQUEST-URL = 'https://my.freecycle.org/home/posts'


#username-input-name is the "name" tag associated with the username input field of the login form.
#password-input-name is the "name" tag associated with the password input field of the login form.
payload = {
    'username-input-name': 'kumardeveloper',
	'password-input-name': '007007'  #Preferably set your password in an env variable and sub it in.
}

with requests.Session() as session:
    post = session.post(POST-LOGIN-URL, data=payload)
    r = session.get(REQUEST-URL)
    print(r.text)   #or whatever else you want to do with the request data!