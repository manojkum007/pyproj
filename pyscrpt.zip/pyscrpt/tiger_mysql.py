# -*- coding: utf-8 -*-
"""
Created on Fri Apr 22 17:14:12 2016

@author: manoj
"""

import MySQLdb

db = MySQLdb.connect(host="192.168.120.130",    # your host, usually localhost
                     user="admin",         # your username
                     passwd="school123",  # your password
                     db="target")        # name of the data base

# you must create a Cursor object. It will let
#  you execute all the queries you need
cur = db.cursor()
db.autocommit(1)

# Use all the SQL you like
#cur.execute("select distinct(mls_id) from mls_listing")
#cur.execute("""select addr.latitude as latitude, addr.longitude as longitude
#                      from mls_public_record_association pra
#                      inner join mls_listing ml on pra.primary_listing_id = ml.id
#                      inner join address addr on ml.mls_address_id = addr.id
#                      inner join attribute a on ml.standard_status = a.id""")
 

school_id=["2402058","2400791"]
district_id =["4201920", "4201917"] 


#sql ="""INSERT INTO mls_school VALUES (%s,%s,%s)"""

#print cur.execute(sql,(15,(','.join(school_id)),(','.join(district_id))))   

cur.execute("""INSERT INTO school.mls_school VALUES (24, PointFromText('POINT(10 10)'),'5646', '254541')""")   


#cur.execute(  """select * from mls_school;""")  

#cur.execute("CREATE TABLE song ( id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT, title TEXT NOT NULL )")
#songs = ('Purple Haze', 'All Along the Watch Tower', 'Foxy Lady')
#for song in songs:
#    cur.execute("INSERT INTO song (title) VALUES (%s)", songs)
#    print "Auto Increment ID: %s" % cur.lastrowid
# print all the first cell of all the rows

#print  cur.fetchall()


#for row in cur.fetchall():
#    print row[0]

db.close()