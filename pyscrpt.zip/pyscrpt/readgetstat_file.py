# -*- coding: utf-8 -*-
"""
Created on Tue Dec 13 12:27:09 2016

@author: manoj
"""
ll=10
filename='/home/manoj/movoto_project/rajgetstat/61516.json'

out="/home/manoj/scripts/python_scripts/out1.txt"
fout=open(out,'w')

f = open(filename, 'rb')
while True:
    piece = f.read(1024*1024)      
    fout.write(piece)      
    break
f.close()

fout.close()


#for i in range(ll):    
#    print f.readlines()
#f.close()

