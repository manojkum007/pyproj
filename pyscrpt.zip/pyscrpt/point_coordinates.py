# -*- coding: utf-8 -*-
"""
Created on Sat Apr 14 20:43:25 2018

@author: manoj
"""
import math


class Point :
    def __init__(self,x,y):
        self.x=x
        self.y=y



def circle(x,y,r):
    lis=[]
    def fo(i,j):
        return i*i+j*j
    for i in range(x):
        for j in range(y):
            if fo(i,j)==r:
                lis.append([i,j])
    return lis


pointlis= circle(11,11,100)               
pointlis=sorted(pointlis,reverse=True)      
        
pointlis=[[10, 0], [ 6,8], [ 8,6], [0, 10] ,[12,1]]
center=Point(0,0)

#math.degrees(math.atan(90/45))
def degree_calc(x,y,centre):
    offset_degree=0
    if (x<0 and y>0):
        offset_degree=180
    if (x<0 and y<0):
        offset_degree=180
        
    return math.degrees(math.atan(y-centre[1]/float(x-centre[0])))+offset_degree


def cross_product(x,y):
    return x[0]*y[1]-x[1]*y[0]
    
    
#a=[10,0]
#b=[10,10]
#base = math.degrees(math.atan(0))
#tt=degree_calc(b[1], b[0]) - degree_calc(a[1], a[0]) + ( - 2 * math.pi  if  (degree_calc(b[1], b[0]) > base ) else  0) + (2 * math.pi if (degree_calc(a[1], a[0]) > base) else  0)

#ll=[[1,1],[-1,1],[-1,-1],[1,-1]]
#
#ll=[[36.763038, -119.731004],
# [36.730813, -119.720134],
# [36.785166, -119.786319],
# [36.72108, -119.691109],
# [36.824161, -119.788619],
# [36.742096, -119.766413]]
# 
#ll= [[29.834136000000001, -81.497883000000002], [36.833188999999997, -119.735212], [37.777861999999999, -122.252335], [47.321004000000002, -122.96754799999999], [39.370901000000003, -74.603206], [29.834136000000001, -81.497883000000002]]
ll=[[1, 1],[ 2,2],[ 2,1],[1, 2]]

#ll=[ [ 2,1], [ 2,2] ,[1, 1] ,[1, 2]]
centre=[1.5,1.5]
#centre=[0,0]


def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
        
#print cross(centre ,ll[0] ,ll[1])
#print cross_product(ll[0],ll[1])


#lower = []
#for p in ll:
#    while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0:
#        print "poped",lower.pop()
#    lower.append(p)
#    print lower
#        
#print "lower" ,lower        
#       
       
       
       
upper = []
for p in ll:
    while len(upper) >= 2 and cross(upper[-2], upper[-1], p) >= 0:
        print "poped",upper.pop()
    upper.append(p)
    print upper
        
print "upper" ,upper        
lis={}
#for i in ll:
#    lis["{0} {1}".format(i[0] ,i[1])]=degree_calc(i[0],i[1],centre)+45


#for r in ll:
#    lis["{0} {1}".format(r[0] ,r[1])]=cross_product(centre ,r)
#    

#for r in range(len(ll)-1):
#    lis["{0} {1}".format(ll[r] ,ll[r+1])]=cross(centre ,ll[r],ll[r+1])

    
for key, value in sorted(lis.iteritems(), key=lambda (k,v): (v,k)):
    print "%s: %s" % (key, value)
#for k in sorted(lis ,reverse=True):
#    print lis[k],k
#for i in range(len(pointlis)):
#    #print pointlis[i]
#    a=Point(pointlis[0][0] ,pointlis[0][1])
#    b=Point(pointlis[i][0] ,pointlis[i][1])
#    det = (a.x - center.x) * (b.y - center.y) - (b.x - center.x) * (a.y - center.y)
#    print det