# -*- coding: utf-8 -*-
"""
Created on Fri Jun 16 16:11:07 2017

@author: manoj
"""

import MySQLdb
import pymssql





db = MySQLdb.connect(host="10.77.1.249",    # your host, usually localhost
                     user="analytics-ro",         # your username
                     passwd="AX89nc!#GCfmplcul80",  # your password
                     db="mls")        # name of the data base


print "connected"

minid=0
maxid=1
page=1

conn = pymssql.connect('192.168.120.138', 'sa', 'igen', 'tmp') 

for oid in range(minid,maxid,page):
    cur = db.cursor()
    query="""select id, json_attributes from metadata_t WHERE ID BETWEEN %s AND %s;"""%(oid,oid+page)
    cur.execute(query)
    rowfetched=[]
    for row in cur:
        res=cur.fetchone()
        rowfetched.append(res[0])
        rowfetched.append(res[1])


    #print "result",rowfetched
    
    for rr in rowfetched: 
        insert_qry="INSERT INTO tmp.dbo.db1_Metadata (id,json_attributes ) values ( %s ,'%s' );"%(rr[0],rr[1])
        upcursor = conn.cursor()
        #print "insert_query",insert_qry
        upcursor.execute(insert_qry)
        
        conn.commit()
        







        



