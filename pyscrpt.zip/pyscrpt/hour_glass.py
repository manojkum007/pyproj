# -*- coding: utf-8 -*-
"""
Created on Mon Apr  9 23:13:51 2018

@author: manoj
"""



lis=[]
for i in range(4):
    ll=[]
    for  j in range(4):
        ll.append(i+j)
    lis.append(ll)
    
lis=[[1, 1, 1, 0, 0, 0],
     [0, 1, 0, 0, 0, 0],
     [1, 1, 1, 0, 0, 0],
     [0, 0, 2, 4, 4, 0],
     [0, 0, 0, 2, 0, 0],
     [0, 0, 1, 2, 4, 0]]    

def hourglass(lis):
    alllis=[]
    for i in range(len(lis[0])):
        for j in range(len(lis[0])):
            hourlis=[]
            startx=i
            starty=j
            for x in range(startx,startx+3):
                for y  in range(starty,starty+3):
                    if (startx<=x<len(lis[0])  and  starty<=y<len(lis) 
                    and (x!=startx+1 or y!=starty)
                    and ( x!=startx+1 or y!=starty+2) and startx+3<=len(lis[0])
                    and starty+3<=len(lis)):
                        #print "a-",x,"y-",y ,i,j
                        hourlis.append(lis[x][y])
            #print hourlis
            #break
        #break
            if len(hourlis)>0:
                alllis.append(reduce(lambda x,y: x+y, hourlis))
    return max(alllis)

print hourglass(lis)