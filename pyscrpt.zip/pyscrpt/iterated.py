# -*- coding: utf-8 -*-
"""
Created on Wed Dec 14 23:59:02 2016

@author: manoj
"""

class Iteraobj:
    
    def __init__(self,num):
        self.num=num
        
    def __iter__(self):
        self.n=0
        return self.n
        
    def __next__(self):
        if(self.n<self.max):
            b=2**self.n
            self.n+=1
            return b
        else:
            raise StopIteration
            

#it=Iteraobj(3)
#mapp =iter(it)
#print next(mapp)
#
#for i in mapp:
#    print i

class PowTwo:
    """Class to implement an iterator
    of powers of two"""

    def __init__(self, max = 0):
        self.max = max

    def __iter__(self):
        self.n = 0
        return self

    def next(self):
        if self.n <= self.max:
            result = 2 ** self.n
            self.n += 1
            return result
        else:
            raise StopIteration
            
            
a = PowTwo(4)

b = iter(a)
for c in b:
    print c
          



class Counter:
    def __init__(self, low, high):
        self.current = low
        self.high = high

    def __iter__(self):
        return self

    def next(self): # Python 3: def __next__(self)
        if self.current > self.high:
            raise StopIteration
        else:
            self.current += 1
            return self.current - 1

#
#for c in Counter(3, 8):
#    print c   



class Incrementor:
    def __init__(self):
        