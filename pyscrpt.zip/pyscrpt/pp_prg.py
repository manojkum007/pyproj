# -*- coding: utf-8 -*-
"""
Created on Sun Dec  3 16:45:13 2017

@author: manoj
"""

ll=[]
for i in range(5):
    ll.append('*')
    

for i in range(3,0,-2):
    lis=ll[:]
    for j in range(i,0,-1):
        if (i==1):
            j+=1
        lis[j]=' '
    print " ".join(lis)
print " ".join(ll)