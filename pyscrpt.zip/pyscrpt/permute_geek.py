# -*- coding: utf-8 -*-
"""
Created on Sun Jan 14 00:13:28 2018

@author: manoj
"""

def permutation(lst):
    if len(lst) == 0:
        return []
    if len(lst) == 1:
        return [lst]
    l = [] # empty list that will store current permutation
 
    # Iterate the input(lst) and calculate the permutation
    for i in range(len(lst)):
       m = lst[i]
 
       # Extract lst[i] or m from the list.  remLst is
       # remaining list
       remLst = lst[:i] + lst[i+1:]
       #print lst[:i],lst[i+1:],i ,remLst
 
       # Generating all permutations where m is first
       # element
       print "rmlst" ,remLst
       for p in permutation(remLst):
           print [m] + p
           l.append([m] + p)
    
    return l
    
    
    
print permutation([1,2,3])