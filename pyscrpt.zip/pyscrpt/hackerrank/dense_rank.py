# -*- coding: utf-8 -*-
"""
Created on Sat Jul 28 13:11:19 2018

@author: manoj
"""

import math
import os
import random
import re
import sys

# Complete the climbingLeaderboard function below.
def climbingLeaderboard(scores, alice):
    dd={}
    count=0
    for key in scores:
        if dd.get(key)==None:  
            count+=1
            dd[key]=count
            
    #print dd       
    #ll=[5,25,50,120]
    ll=alice
    retlis=[]
    #print ll
    minlis=sorted(list(set(scores)))
    for ele in ll:
        if ele>max(scores):
            retlis.append(dd.get(max(scores))) 
        elif ele<min(scores):
            retlis.append(dd.get(min(scores))+1)
        elif ele==max(scores):
            retlis.append(dd.get(max(scores)))
        else:
           # print minlis
            for j in range(len(minlis)-1):
                if minlis[j]==ele:
                    retlis.append(dd.get(minlis[j]))
                elif  ele>minlis[j] and ele<minlis[j+1]:
                    retlis.append(dd.get(minlis[j]))
                    
                
                else:pass
        #print ele, retlis
    return retlis
        

#lis=[100,100,50,40,40,20,10]
#ll=[5,25,50,120]
#print climbingLeaderboard(lis, ll)

                
            
            

if __name__ == '__main__':
    fptr = open('/home/manoj/logs/test12.text', 'w')

    scores_count = int(raw_input())

    scores = map(int, raw_input().rstrip().split())

    alice_count = int(raw_input())

    alice = map(int, raw_input().rstrip().split())

    result = climbingLeaderboard(scores, alice)

    fptr.write('\n'.join(map(str, result)))
    fptr.write('\n')

    fptr.close()