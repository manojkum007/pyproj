# -*- coding: utf-8 -*-
"""
Created on Wed Mar 14 14:32:15 2018

@author: manoj
"""

import sys


lis=[-4 ,3 ,-9 ,0 ,4, 1 ]


def plusMinus(arr):
    posnum=filter(lambda x : x>0,arr)
    posfraction=len(posnum)/float(len(arr))
    print  posfraction
    
    negnum=filter(lambda x : x<0,arr)
    negfraction=len(negnum)/float(len(arr))
    print  negfraction
    
    zeronum=filter(lambda x : x==0,arr)
    zerofraction=len(zeronum)/float(len(arr))
    print  zerofraction


plusMinus(lis)
#if __name__ == "__main__":
#    n = int(raw_input().strip())
#    arr = map(int, raw_input().strip().split(' '))
#    plusMinus(arr)
