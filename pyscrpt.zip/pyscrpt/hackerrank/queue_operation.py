# -*- coding: utf-8 -*-
"""
Created on Tue Feb  6 14:34:25 2018

@author: manoj
"""

import sys
class Queueop:
    def __init__( self):
        self.Q=[]
        
    def qoperation(self,arr):
        if int(arr[0])==1:
            self.enqueue(arr[1])
        elif int(arr[0])==2:
            self.dequeue(self.Q.index(arr[1]))
        elif int(arr[0])==3:
            self.printqueue_min()
        #print "queue size",self.Q
    
    def enqueue(self,ele):
        self.Q.append(ele)
    
    def dequeue(self ,ele):
        self.Q.pop(ele)
    
    def printqueue_min(self):
        print min(self.Q)
       

f=open('/home/manoj/scripts/python_scripts/hackerrank/testcase.txt' ,'r')
lis=[]
lis=f.readlines()
    #break

f.close()
lis.pop(0)

d=Queueop()

for indexdata in lis:
    #d.qoperation(
    mm=list(indexdata.strip().split(" "))
    d.qoperation(mm)
    
#n = int(raw_input().strip())
#d=Queueop()
#while n:
#    ar = map(int, raw_input().strip().split(' '))
#    d.qoperation(ar)
#    n-=1