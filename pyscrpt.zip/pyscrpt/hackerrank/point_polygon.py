# -*- coding: utf-8 -*-
"""
Created on Tue Apr 24 16:26:39 2018

@author: manoj
"""

point =0,0


polygon=[[1,1],[2,1],[2,2],[1,2]]

def point_tanget(point , ploygon):
    pass