# -*- coding: utf-8 -*-
"""
Created on Mon Apr 16 16:28:28 2018

@author: manoj
"""

lis=['a', 'a','a', 'b', 'b', 'c' ,'c','b','d']


lis=['a', 'a', 'b', 'b']

ll=lis[:]
#last=ll[0]
def super_reduced_string(ll):
    first=0
    second=1
    while (second<len(ll)):
        #print "start" ,first ,second,ll
        if len(ll)<=1:
            break
        if (ll[first]==ll[second]):
            ll.pop(first)
            ll.pop(first)
            if first>0:
                first-=1
            if second>1:
                second-=1
            #print first,second,cnt,len(ll)
            #cnt-=1
        else:
            first+=1
            second+=1
            print len(ll),first ,second
            
    if len(ll)>0:
        return ''.join(ll)
    else:
        return "Empty String"
        
s="kagoyzkgfjnyvjewazalxngpdcfahneqoqgiyjgpzobhaghmgzmnwcmeykqzgajlmuerhhsanpdtmrzibswswzjjbjqytgfewiuu"
#s="bswswzjjbjqytgfewiiuu"
#s='txxmubonuhlaryeuujgftedrmmhmaadxrplneqpwhsketqicdpqlecluydmgykrubgmpwfqviabkjoiqdftbbwwgiuudmgrdbkrr'
#s='aa'
print super_reduced_string(list(s)[:])
#print "output", "kagoyzkgfjnyvjewazalxngpdcfahneqoqgiyjgpzobhaghmgzmnwcmeykqzgajlmuersanpdtmrzibswswzbjqytgfewi"

