# -*- coding: utf-8 -*-
"""
Created on Mon Apr 23 15:10:33 2018

@author: manoj
"""





def superdigit(numstr,n):
    numstr*=n
    print numstr
    while (len(numstr)>1):
        numstr=str(reduce(lambda x,y :x+y ,map(long,list(numstr))))
    return  numstr 


x="9875"
x="148"  
repeat=3  
print superdigit(x,repeat)