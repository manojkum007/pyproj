# -*- coding: utf-8 -*-
"""
Created on Fri Jul 27 17:14:07 2018

@author: manoj
"""

import math
import os
import random
import re
import sys

# Complete the miniMaxSum function below.
def miniMaxSum(arr):
    arr=sorted(arr)
    minarr=arr[:len(arr)-1]
    maxarr=arr[1:len(arr)]
    minsum=reduce(lambda x,y: x+y,minarr)
    print minarr ,maxarr
    maxsum=reduce(lambda x,y: x+y,maxarr)
    print minsum ,maxsum

if __name__ == '__main__':
    arr = map(int, raw_input().rstrip().split())

    miniMaxSum(arr)