# -*- coding: utf-8 -*-
"""
Created on Fri Jul 27 15:46:02 2018

@author: manoj
"""

import math
import os
import random
import re
import sys

# Complete the staircase function below.
def staircase(n):
    for i in range(n,0,-1):
        for  j in range(n):
            if i-(j+1)>0:
                #print ".",
                sys.stdout.write(' ')
            else:
                sys.stdout.write('#')
                #print '#',
                
        print 

if __name__ == '__main__':
    print ("eneter a number")
    n = int(raw_input())
    staircase(n)
