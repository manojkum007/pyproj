# -*- coding: utf-8 -*-
"""
Created on Fri Aug 11 16:10:42 2017

@author: manoj
"""

import luigi

class TaskOne(luigi.Task):
    custid= luigi.Parameter() 
    def requires(self):
        pass
    def output(self):
        return luigi.LocalTarget("logs/"+str(self.custid)+"_success")
    def run(self):
        with self.output().open('w') as f:
            f.write("%s\n" % '')
        
               
class TaskTwo(luigi.Task):  
    def requires(self): 
        customersList = ['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I']
        #yield luigi.build([TaskOne(custid=cust_id) for cust_id in customersList], workers=2)  
        yield [TaskOne(custid=cust_id) for cust_id in customersList] 
        
    def output(self):
        return luigi.LocalTarget("logs/overall_success.txt")
    def run(self):
        with self.output().open('w') as f:
            f.write("%s\n" % "success")
         
if __name__ == '__main__':
    luigi.run()