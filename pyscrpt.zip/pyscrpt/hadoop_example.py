import sys, urllib, re

title_re = re.compile("<title>(.*?)</title>",re.MULTILINE | re.DOTALL | re.IGNORECASE)

for url in sys.argv[1:]:
    match = title_re.search(urllib.urlopen(url).read())
    if match:
        print url, "\t", match.group(1).strip()
