# -*- coding: utf-8 -*-
"""
Created on Sat Jan  7 11:25:35 2017

@author: manoj
"""

abc = lambda: lambda *args, **kwargs: myFunction(*args, **kwargs)

# Style 2
def abc():
    return myFunction(124)

abc() 
 
def myFunction(a):
    print a
    
 