# -*- coding: utf-8 -*-
"""
Created on Sat Sep 16 12:42:42 2017

@author: manoj
"""

import luigi
import datetime
import os

class GetagentAppData(luigi.Task):
    date_range = luigi.DateIntervalParameter()
    profile_name_range = luigi.Parameter(default="all")

    def requires(self):
        pass

    def run(self):
        print "daterange" ,self.date_range
        with self.output().open('w') as f:
            f.write('{word}\n'.format(word='LoadAvroFile'))
        pass

    def output(self):
        path1 = os.path.join('target', ('GetagentAppData_%s_%s.txt')%(self.profile_name_range,self.date_range))
        return luigi.LocalTarget(path=path1)
