# -*- coding: utf-8 -*-
"""
Created on Tue Dec  5 09:20:43 2017

@author: manoj
"""

import pymssql
server = "192.168.120.139"
user ="sa"

password = "igen"
db_name =  "tmp"
conn=pymssql.connect(server, user, password, db_name)
print "connected"
conn.autocommit(True)

cursor = conn.cursor()
#cursor.executemany(
#    "INSERT INTO persons VALUES (%d, %s, %s)",
#    [(1, 'John Smith', 'John Doe'),
#     (20, 'Jane Doe', 'Joe Dog'),
#     (30, 'Mike T.', 'Sarah H.')])

for i in range(2):
    try:
        #cursor.execute("INSERT INTO persons VALUES (%d, %s, %s)",(i+10, 'John Smith', 'John Doe'))
        cursor.executemany("INSERT INTO persons VALUES (%d, %s, %s)",
    [(1, 'John Smith', 'John Doe'),
     (20, 'Jane Doe', 'Joe Dog'),
     (30, 'Mike T.', 'Sarah H.')])
    except Exception as e:
        print e
    
    
print "done changes"

cursor.execute('SELECT * FROM persons WHERE salesrep=%s', 'John Doe')
row = cursor.fetchone()
while row:
    print("ID=%d, Name=%s" % (row[0], row[1]))
    row = cursor.fetchone()
conn.close()