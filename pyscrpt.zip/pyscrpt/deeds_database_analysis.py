# -*- coding: utf-8 -*-
"""
Created on Sat Jun  4 20:35:48 2016

@author: manoj
"""

import csv
import re

def writelogfile(deedsFailFile,row):  
    with open(deedsFailFile, 'a') as failed_file:
        writer = csv.writer(failed_file, delimiter='\t')
        writer.writerow(row)
        

srch="For /data/bkfs/extracts/(\d+)_Deed_Refresh_20160509.txt: Out of (\d+) record \, totally (\d+) record inserted"       
logfile="/home/manoj/scripts/tiger_analyatics/6047/ded_ny_res.csv"      

with open ("/home/manoj/scripts/tiger_analyatics/deedsError_ny.csv" ,'r') as infile:
    for line in infile:
        srchobj=re.search(srch ,line)
        if (srchobj):
            row=[srchobj.group(1),srchobj.group(2),srchobj.group(3)]
            writelogfile(logfile,row)


#
#deedfile="/home/manoj/scripts/tiger_analyatics/analysed_res.csv"       
#        
#orl=[]
#pylis=[]
#original_lis=[]
#with open ("/home/manoj/scripts/tiger_analyatics/deed_analysis.csv" ,'r') as infile:
#    for line in infile:
#        line=re.sub('\n' ,'' ,line)
#        data=line.split("\t")
#        orl.append(data[0])
#        if (data[2]!=''):
#            pylis.append(data[2])
##        lis1.append([data[0],data[1]])
#        original_lis.append([data[0],data[1]])
#
#print len(orl),len(pylis)     
#
#count=0
#lis3=[]
#for i in orl:
#    if (i in pylis):
#        lis3.append(i)
##print lis3
#for j in original_lis:
#        if j[0] in lis3:
#            row=[j[0] ,j[1]]
#            writeRowfail(deedfile,row)
#
#            
#            
#            