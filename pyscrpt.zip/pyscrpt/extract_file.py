# -*- coding: utf-8 -*-
"""
Created on Thu Feb 25 16:42:10 2016

@author: manoj
"""
import glob
import zipfile
destination="/data/bkfs/Orphan"
fo = open(destination + "/deeds_list.txt", "w")   
for name in glob.glob(destination + "/*.txt"):    
    fo.write(name + "\n")
fo.close
