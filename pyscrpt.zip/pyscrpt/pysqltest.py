# -*- coding: utf-8 -*-
"""
Created on Wed Apr 26 10:59:38 2017

@author: manoj
"""

import pymssql
import luigi




class BgSfMatch(luigi.Task):
    tables_list = luigi.Parameter(default = 'Qatables')
    get_all = luigi.Parameter(default = 'no')
    
    
    def run(self):
        self.connect()
        hotlead_bqjoinqry="""SELECT li.id AS lead_info_id,bq.*
                                FROM [sf_raw_dev].[dbo].[bigqry_tmp] bq
                                INNER JOIN (
                                	SELECT hotleadid AS hl_id
                                		,MAX(hitnumber) AS last_hit
                                	FROM [sf_raw_dev].[dbo].[bigqry_tmp] bq_tmp
                                	GROUP BY hotleadid -- Get last hit information for each hotlead id
                                ) Q1
                                ON Q1.hl_id = [hotleadid]
                                AND last_hit = hitnumber
                                INNER JOIN sf_raw.dbo.LeadInfo__c li
                                ON li.Hot_Lead_Id__c = bq.[hotleadid]"""
        
                                        
        res=self.execute_qry(hotlead_bqjoinqry)
        
        
    
    def connect(self):
        luigi_config = luigi.configuration.get_config()
        
        db_name = luigi_config.get('puma', 'db-name')
        db_host = luigi_config.get('puma', 'db-host')
        db_username = luigi_config.get('puma', 'db-user')
        db_password = luigi_config.get('puma', 'db-password')
        try:
            self.conn = pymssql.connect(db_host, db_username, db_password, db_name, as_dict=True)
        except Exception as e:
            print "Error in connecting",e
    
    
    
    def execute_qry(self,bqqry):
        result=[]
        self.cursor = self.conn.cursor()
        self.cursor.execute(bqqry)
        for row in self.cursor:
            result.append(row)
        return result
        
    
    def output(self):
        pass
        
        
        


