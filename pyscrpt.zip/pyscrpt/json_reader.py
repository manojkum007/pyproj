# -*- coding: utf-8 -*-
"""
Created on Mon Feb 15 11:54:28 2016

@author: manoj
"""
import json
json_data=open('/home/manoj/scripts/python scripts/config.json').read()

data = json.loads(json_data)

data_dict=data["movoto"]["database"]["postgres"]
local_data_dict=data["movoto"]["database"]["local_postgres"]
print data_dict["host"]
