# -*- coding: utf-8 -*-
"""
Created on Sat May 19 19:12:23 2018

@author: manoj
"""

import pandas as pd
import glob

label=["swu_template_id", "swu_template_name" , "event_type" , "event_timestamp" ,"day" ]
data=[]
for name in glob.glob("/home/manoj/scripts/python_scripts/mls_download/sparkpost/*.csv"):
    f=open(name ,"r")
    data.extend(f.readlines())
    

#print len(data)
lis=[]
for r in data:
    lis.append(r.strip().split(","))
#    print lis
#    break
#del data
#[['tem_CVMbBv8trWSbxVKCpfBkXMPX', 'AB TEST - NOVA - Customer - We found recommended houses\xc2\xa0', 'open', '1514820906000000', '17532']]
 
df = pd.DataFrame(lis, columns=label)
spark_post={}
for name, group  in df.groupby(["swu_template_id" ,"event_type"]):  
    for row in group.iterrows():
        #print row
        #key="{0}.{1}".format(name[0] ,name[1])
        key=name[0]
        if spark_post.get(key)==None:
            spark_post[key]= {}
            spark_post[key][name[1]]=1
        elif spark_post.get(key).get(name[1])==None:
            spark_post[key][name[1]]=1
        elif spark_post.get(key).get(name[1])!=None:
             spark_post[key][name[1]]=  spark_post[key][name[1]]+1
        #print spark_post
    #break


for key , value in spark_post.iteritems():
    for k,v in  value.iteritems():
        spark_post[key][k +"rate="]=(v/float(value.get('injection')))*100
        del  spark_post[key][k]

print spark_post
    