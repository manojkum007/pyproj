# -*- coding: utf-8 -*-
"""
Created on Wed Jan 25 12:17:54 2017

@author: manoj
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Oct 25 12:31:57 2016

@author: manoj
"""
import collections
import pymssql
import itertools
import os
from shutil import copyfile
import re
import sys
import glob
import time
import fnmatch

import os, sys
from PIL import Image
import math



print "connecting server"

conn = pymssql.connect('192.168.120.139', 'sa', 'igen', 'AgentDirectory') 
agentimage=collections.OrderedDict()  
distinctqry="select  top 5 OGuserID, NovaId FROM AgentDirectory.dbo.ListOfS3Images where novaid like '00e5cee1-8b7d-4f61-8eb0-768448583c9c';"
cursor = conn.cursor() 

cursor.execute(distinctqry)
for r in cursor:
    agentimage[r[0]]=r[1]
#print "connected ",agentimage
imagepath="F:\\pyscript\\agentimages\\"
og_copyimagepath="F:\\pyscript\\OGImage\\"
sf_copyimagepath="F:\\pyscript\\SFImage\\"
limit=[400,225,110]



def resize(width,height):
    newsizelist=[]
    if width>height:
        for l in limit:
            if width>l:
                new_width=l
                new_height=(height/float(width))*l
                nsize=(new_width,int(math.ceil(new_height)))
                newsizelist.append(nsize)
                #width=new_width
    elif height>=width:
        for l in limit:
            if height>l:
                new_height=l
                new_width=(width/float(height))*l
                nsize=(int(math.ceil(new_width)),new_height)
                newsizelist.append(nsize)
                #height=new_height
        
    return newsizelist

destinationpath="F:\\pyscript\\image_new\\"

destinationpath="F:\\pyscript\\logs\\"
#imagepath=destinationpath


#00e5cee1-8b7d-4f61-8eb0-768448583c9c_1485174448977_267_400

agentnames=[]

for key,novaid in agentimage.iteritems():
    for name in glob.glob(imagepath+str(key)+'.jpg'):
        try:
##            statinfo= os.stat(name)
##            if maxsize<statinfo.st_size:
##                lisimage[name]=name
##            maxsize=statinfo.st_size
        
            im = Image.open(name)
            if im.mode != "RGB":
                im = im.convert("RGB")
            width,height=im.size
            print "or" ,width ,height
            final_image_size=resize(width,height)
            print final_image_size
            if len(final_image_size)<1:
                print "agent images",name,final_image_size
            milli_sec = lambda: int(round(time.time() * 1000))
            for imsize in final_image_size:
                agentdestinpath=os.path.basename(name).split(".")[0]
                agentextension=os.path.basename(name).split(".")[1]
                if novaid!=None:
                    milli_sec=lambda: int(round(0 * 1000))
                    temp = im.copy()
                    im.thumbnail(imsize, Image.ANTIALIAS)
                    neww,newh=im.size
                    outfile = destinationpath+ "{0}_{1}_{2}_{3}.{4}".format(str(novaid), str(milli_sec()),int(neww),int(newh),agentextension)
                    print "userid  %s novaimage  %s"%(key,outfile)
                    im.save(outfile, "JPEG")
        except Exception as e:
            print "io error",e
            
              

