# -*- coding: utf-8 -*-
"""
Created on Thu Sep 27 16:35:57 2018

@author: manoj
"""
import re
t = raw_input()   
n = raw_input()   
lis=filter(lambda x : isinstance(x,int) ,n.split(" "))
#lis=filter(int, map(lambda x : x if x!='' else None , n.split(" ")))

print lis
#for n in lis:
#    for j in range(1,n+1):
#        if (j%3==0 and j%5==0):
#            print "FizzBuzz"
#        elif (j%3==0):
#            print "Fizz"
#        elif (j%5==0):
#            print "Buzz"
#        else :
#            print j

#lis=[1,2,3,4,9,8]
def profitmaximiser(lis):
    maxprofit=[]
    for i in range(len(lis)):
        counter=0
        maxsum=lis[counter]
        for j in range(i+1,len(lis)):  
            if (counter<j):
                res=re.search("\d+.(\d+)" ,str(lis[j]/float(lis[counter]))).group(1)
                if int(res)==0:
                    maxsum+=lis[j]
                    counter=j
            #print counter ,j , res,maxsum
        #print maxsum 
        maxprofit.append(maxsum)
    if len(maxprofit)>0:
        return reduce(lambda x,y :  x if (x>y) else y , maxprofit)
    else :
        return None

print profitmaximiser(lis)
            