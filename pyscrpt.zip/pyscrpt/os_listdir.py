# -*- coding: utf-8 -*-
"""
Created on Wed Aug 23 12:34:12 2017

@author: manoj
"""
import os 
import re


syspath='/home/manoj/scripts/python_scripts/s3file'
ll=os.listdir(syspath)
table_stat={}

def parse_rowcount(path):
    try:
        contentlis=open(path).readlines()
        for content in contentlis:
            ob=re.search('Total\s+Row\s+Count\s+=\s+(\d+)',content)
            if ob:
                return ob.group(1)
    except Exception as e:
        print e
    return 0 
        
        
for p in ll:
    ob=re.search('(\d+)_(\S+)_metadata.txt',p)
    if ob:
        date=ob.group(1)
        tablekey=ob.group(2).split(".")[1]
        rowcount=parse_rowcount(syspath+'/'+p)
        if (table_stat.get(tablekey))==None:
            table_stat[tablekey]={}
            table_stat[tablekey][date]=rowcount
        else:
            table_stat[tablekey][date]=rowcount
            
print table_stat