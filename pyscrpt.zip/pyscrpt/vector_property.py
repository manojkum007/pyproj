# -*- coding: utf-8 -*-
"""
Created on Sat Jun 17 22:39:25 2017

@author: manoj
"""

class Vector2d:
    typecode='d'
    
    def __init__(self,x,y):
        self._x=x
        self._y=y
    
#    @property
#    def x(self):
#        return self._x
#
#    @property
#    def y(self):
#        return self._y
    
v=Vector2d(5,6)
print v._x