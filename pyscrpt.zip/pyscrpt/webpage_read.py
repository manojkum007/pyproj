# -*- coding: utf-8 -*-
"""
Created on Fri May  6 14:24:11 2016

@author: manoj
"""
import urllib
import re


sock=urllib.urlopen("http://www.movoto.com/san-jose-ca/1245-sundown-ln-san-jose-ca-95127-100_81224991/")
htmlSource = sock.read()
sock.close() 
'''
print htmlSource    

nklnnkn

'''


def run(data_folder='/home/jack/apple_share/BKFS_AVM_20150215'):
    time3=datetime.datetime.now()
    ok = rename_table()
    time4 = datetime.datetime.now()
    logger.info("rename table, total {0} seconds".format(int((time4-time3).total_seconds())))
    if ok == 1:
        add_index()
        track_new_est_value()
        time5 = datetime.datetime.now()
        logger.info("track est values of new version, total {0} seconds".format(int((time5-time4).total_seconds())))
    else:
        logger.log("failed to RENAME avm table of new version")

    return
    
    
    