# -*- coding: utf-8 -*-
"""
Created on Fri Dec 23 00:01:31 2016

@author: manoj
"""

# Written with pymongo-3.2 
# Documentation: http://api.mongodb.org/python/
# A python script connecting to a MongoDB given a MongoDB Connection URI.

import sys
import pymongo
import datetime

### Create seed data

SEED_DATA = [
    {
        'decade': '1970s',
        'artist': 'Debby Boone',
        'song': 'You Light Up My Life',
        'weeksAtOne': 10
    },
    {
        'decade': '1980s',
        'artist': 'Olivia Newton-John',
        'song': 'Physical',
        'weeksAtOne': 10
    },
    {
        'decade': '1990s',
        'artist': 'Mariah Carey',
        'song': 'One Sweet Day',
        'weeksAtOne': 16
    }
]

### Standard URI format: mongodb://[dbuser:dbpassword@]host:port/dbname

MONGODB_URI = 'mongodb://user:pass@host:port/db' 
MONGODB_URI ="localhost:27017"

###############################################################################
# main
###############################################################################




import json


agentschema=[
                 ['userId', 'idType'],
                 ['profileDisplayPermissions', 'showProfilePage'],
                 ['agentType'],
                 ['agentStatus'],
                 ['movotoAgentSince'],
                 ['agentSince'],
                 ['contact', 'firstName'],
                 ['contact', 'middleName'],
                 ['contact', 'lastName'],
                 ['contact', 'phones', 'displayPhone'],
                 ['contact', 'phones', 'homePhone'],
                 ['contact', 'phones', 'officePhone'],
                 ['contact', 'phones', 'cellPhone'],
                 ['contact', 'email'],
                 ['contact', 'altEmail'],
                 ['contact', 'linkedInProfile'],
                 ['contact', 'facebookProfile'],
                 ['contact', 'twitterProfile'],
                 ['languages'],
                 ['contact', 'website'],
                 ['contact', 'homeAddress', 'streetAddress'],
                 ['contact', 'homeAddress', 'zipcode'],
                 ['contact', 'homeAddress', 'state', 'stateCode'],
                 ['contact', 'homeAddress', 'state', 'name'],
                 ['contact', 'homeAddress', 'city', 'cityId'],
                 ['contact', 'homeAddress', 'city', 'cityName'],
                 ['contact', 'homeAddress', 'county', 'countyId'],
                 ['contact', 'homeAddress', 'county', 'countyName'],
                 ['brokerage', 'name'],
                 ["licenses"], 
                 ["mlsAssociations"],
                 ['agentDetails', 'agentBio'],
                 ['agentDetails', 'interests'],
                 ['agentDetails', 'specialities'],
                 ['agentDetails', 'otherSpecialities'],
                 ["agentDetails","certifications"],
                 ["locations"]
    ]           
    



#agentschema=[
#                 ['agentType'],
#                 ['agentStatus'],
#                 ['movotoAgentSince']
#    ]           
       
    
mongodblis=[]

dictdata=None


def getdict(cur,lis):
    global dictdata
    if len(lis)>0:
        if len(lis)==1:
            dictdata=cur.get(lis[0])
            return 0
        else:
            if  cur.has_key(lis[0]):
                getdict(cur[lis[0]],lis[1:])

def convert_dict(data):
    if isinstance(data, basestring):
        return str(data)
    elif isinstance(data, collections.Mapping):
        return dict(map(convert_dict, data.iteritems()))
    elif isinstance(data, collections.Iterable):
        return type(data)(map(convert_dict, data))
    else:
        return data


def fetch_updatedict( updateagentdoc):
    global dictdata
    update_agent_dict={}
    delete_agent_dict={}
    for ele in  agentschema:
        dictdata=None
        getdict(updateagentdoc,ele) 
        if dictdata!=None:
            if ".".join(ele)=="agentDetails.interests" or ".".join(ele)=='agentType':
                print ".".join(ele), dictdata
            update_agent_dict[".".join(ele)]=dictdata
        else:
            delete_agent_dict[".".join(ele)]=dictdata
    #update_agent_dict.update(delete_agent_dict)
    return (update_agent_dict ,delete_agent_dict)
    #print useragent_dict
            
        


#with open("/home/manoj/scripts/tiger_analyatics/rhino/dev_rhino/production/sfdaily/march_agent/ffd1bfc7-3ef7-45d5-b619-1f7520f2274c_2017-03-12_2017-03-13.json") as data_file:    
#    mongodblis.append(json.load(data_file))
#    
#print mongodblis[0].get('inactiveUrls')




MONGODB_URI ="mongodb://%s:%s@%s:%s/%s"%('agentdirectory', 'agent4movoto', '172.24.0.17', '27017', 'agentdirectory')


def mongo():

    client = pymongo.MongoClient(MONGODB_URI)
    
    #print client.database_names()

    #db = client.get_default_database() 
    #db=client.temp

    db=client.agentdirectory
    print "default database",db
    
    # First we'll add a few songs. Nothing is required to create the songs 
    # collection; it is created automatically when we insert.

#    songs = db['youtubesong']
#    
#    agent_test = db['Agent_test1']
    
    
    agent = db['agents']
#    
#    for novaid in ll:
#        cnt = agent.find({'userId.id': novaid}).count()
#        if cnt==1:
#            print "found"
#        else:
#            print "not found",novaid
    
    f= open('/home/manoj/movoto_project/gousal/locatest.txt','w')
    cursorobj = agent.find({'agentStatus': {'$nin': ['X', 'R', 'Q']}} , {'locations':1, 'userId.id': 1, '_id': 0 })   
    
    for row in cursorobj:
        userid=row['userId'] 
        #print userid.get('id')
        loc=row.get('locations')
        if loc!=None:
            #print "length of loc" ,len(loc)
            f.write(str(userid.get('id'))+","+str(len(loc))+"\n")
            #break
    f.close()
    
#    query = {'userId.id': '08ef9f81-31e2-49d3-9f3c-bff24fd41096'}
#    update_data,del_data=fetch_updatedict(mongodblis[0])
#
#    
    #print "update_date",update_data , "delete_data", delete_data
    #update_data=convert_dict(fetch_updatedict(mongodblis[0]))
    #update_data={'agentType': 2, 'agentStatus': 'N'}
    #print "update_result",del_data
#    data=agent_test.update_one(query, {'$set':update_data })
#    
#    res=agent_test.update_one({ 'userId.id':'08ef9f81-31e2-49d3-9f3c-bff24fd4109fjxfjfj6'},{ '$currentDate': {'lastModifiedDateTime': True }})
#    
#    print "time update",res.raw_result
    #deldata=agent_test.update_one(query, { '$unset': { 'migrationSource': ""}})
    
#    delete_data={'contact.altEmail': None, 'contact.website': None, 'profileDisplayPermissions.showDREName': None, 'contact.middleName': None, 'contact.phones.homePhone': None, 'movotoAgentSince': None, 'contact.homeAddress.streetAddress': None, 'mlsAssociations': None, 'brokerage.name': None, 'contact.blog': None, 'contact.twitterProfile': None, 'profileDisplayPermissions.showInDPP': None, 'profileDisplayPermissions.showMailingAddress': None, 'contact.facebookProfile': None, 'contact.linkedInProfile': None}
#    deldata=agent_test.update_one(query, {'$set': update_res})
    #data=agent_test.update_one(query, { '$pullAll': { 'licences': [ 0, 5 ] } } )

    #data=agent_test.update_one(query, {'$set': {'score': "licenseNumber"}})
    #print "update test ", data.raw_result
    
    
#    
#    deldata=agent_test.update_one(query, { '$unset': del_data})
#    print "delete test ", deldata.raw_result
    
    
#    for doc in cursor:
#        print "agebt information" ,doc

    # Note that thnsert method can take either an array or a single dict.

    #songs.insert_many(SEED_DATA)

    # Then we need to give Boyz II Men credit for their contribution to
    # the hit "One Sweet Day".

##    query = {'decade': '1989s'}
##
##    data=songs.update_one(query, {'$set': {'artist': 'pggmnbbadfdfhrikshit ' ,'team':'data analytics'}})
##    
#    print "update song ", data.raw_result

    # Finally we run a query which returns all the hits that spent 10 or
    # more weeks at number 1.

#    cursor = songs.find({'weeksAtOne': {'$gte': 10}}).sort('decade', -1)
#    -1 descending
#    1 asending

#    for doc in cursor:
#        print doc,"\n"
#        print ('In the %s, %s by %s topped the charts for %d straight weeks.' %
#               (doc['decade'], doc['song'], doc['artist'], doc['weeksAtOne']))
#    
    ### Since this is an example, we'll clean up after ourselves.

    #db.drop_collection('songs')

    ### Only close the connection when your app is terminating

    client.close()


ll=[]
def mongo_novaidlist():
    client = pymongo.MongoClient(MONGODB_URI)
    db=client.agentdirectory
    dppview = db['UserbehaviorDppStat']
    cursorobj = dppview.find({'novaId':{'$exists':True}},{"novaId" : 1})   
    for row in cursorobj:
        ll.append(row.get('novaId'))
#        break
    dd={
                            "novaId" : "00582247-2133-4fb3-80b6-4a43b578dee0",
                            "dppViewsStats" : {
                                "last3Months" : {
                                    "totalDppViews" : 100,
                                    "bedStats" : {
                                        "averageBedsViewed" : 3.6,
                                        "bedsHistogram" : [ 
                                            {
                                                "beds" : "3",
                                                "dppViewCount" : 5
                                            }, 
                                            {
                                                "beds" : "4",
                                                "dppViewCount" : 4
                                            }, 
                                            {
                                                "beds" : "5+",
                                                "dppViewCount" : 1
                                            }
                                        ]
                                    },
                                    "bathStats" : {
                                        "averageBathsViewed" : 2.25,
                                        "bathsHistogram" : [ 
                                            {
                                                "baths" : "2",
                                                "dppViewCount" : 3
                                            }, 
                                            {
                                                "baths" : "3",
                                                "dppViewCount" : 1
                                            }, 
                                            {
                                                "baths" : None,
                                                "dppViewCount" : 6
                                            }
                                        ]
                                    },
                                    "sqftStats" : {
                                        "averageSqftViewed" : 2104.8,
                                        "sqftHistogram" : [ 
                                            {
                                                "sqft" : 2000,
                                                "dppViewCount" : 3
                                            }, 
                                            {
                                                "sqft" : 2500,
                                                "dppViewCount" : 6
                                            }, 
                                            {
                                                "sqft" : 3000,
                                                "dppViewCount" : 1
                                            }
                                        ]
                                    },
                                    "priceStats" : {
                                        "averagePriceViewed" : 169990.0,
                                        "priceHistogram" : [ 
                                            {
                                                "price" : 125000,
                                                "dppViewCount" : 1
                                            }, 
                                            {
                                                "price" : 150000,
                                                "dppViewCount" : 1
                                            }, 
                                            {
                                                "price" : 175000,
                                                "dppViewCount" : 5
                                            }, 
                                            {
                                                "price" : 200000,
                                                "dppViewCount" : 2
                                            }, 
                                            {
                                                "price" : 225000,
                                                "dppViewCount" : 1
                                            }
                                        ]
                                    },
                                    "zipcodeStats" : {
                                        "zipcodeHistogram" : [ 
                                            {
                                                "zipcode" : "77084",
                                                "dppViewCount" : 1
                                            }, 
                                            {
                                                "zipcode" : "77082",
                                                "dppViewCount" : 9
                                            }
                                        ]
                                    }
                                },
                                "lastWeek" : {
                                    "totalDppViews" : 7,
                                    "bedStats" : {
                                        "averageBedsViewed" : 3.42857142857143,
                                        "bedsHistogram" : [ 
                                            {
                                                "beds" : "3",
                                                "dppViewCount" : 4
                                            }, 
                                            {
                                                "beds" : "4",
                                                "dppViewCount" : 3
                                            }
                                        ]
                                    },
                                    "bathStats" : {
                                        "averageBathsViewed" : 2.33333333333333,
                                        "bathsHistogram" : [ 
                                            {
                                                "baths" : "2",
                                                "dppViewCount" : 2
                                            }, 
                                            {
                                                "baths" : "3",
                                                "dppViewCount" : 1
                                            }, 
                                            {
                                                "baths" : None,
                                                "dppViewCount" : 4
                                            }
                                        ]
                                    },
                                    "sqftStats" : {
                                        "averageSqftViewed" : 2098.85714285714,
                                        "sqftHistogram" : [ 
                                            {
                                                "sqft" : 2000,
                                                "dppViewCount" : 2
                                            }, 
                                            {
                                                "sqft" : 2500,
                                                "dppViewCount" : 5
                                            }
                                        ]
                                    },
                                    "priceStats" : {
                                        "averagePriceViewed" : 182557.142857143,
                                        "priceHistogram" : [ 
                                            {
                                                "price" : 175000,
                                                "dppViewCount" : 4
                                            }, 
                                            {
                                                "price" : 200000,
                                                "dppViewCount" : 2
                                            }, 
                                            {
                                                "price" : 225000,
                                                "dppViewCount" : 1
                                            }
                                        ]
                                    },
                                    "zipcodeStats" : {
                                        "zipcodeHistogram" : [ 
                                            {
                                                "zipcode" : "77084",
                                                "dppViewCount" : 1
                                            }, 
                                            {
                                                "zipcode" : "77082",
                                                "dppViewCount" : 6
                                            }
                                        ]
                                    }
                                }
                            }
                        }
                        

    query = {'novaId': '00582247-2133-4fb3-80b6-4a43b578dee0'}
    mongores=dppview.update_one(query, {'$set': dd}).raw_result
    print "mongores",mongores
            
    
    
mongo_novaidlist()
print "length of list" ,len(ll)
#mongo()




#for updateagentdoc in updatelist:
#                    nova_id=updateagentdoc.get('userId').get('id')
#                    try:
#                        update_lis_cnt=[]
#                        query = {'userId.id': nova_id}
#                        update_agent_dict, delete_agent_dict=fetch_updatedict(updateagentdoc)
#                        try:
#                            mongores=mongocollections.update_one(query, {'$set': update_agent_dict}).raw_result
#                            update_lis_cnt.append((mongores.get('updatedExisting') , mongores.get('nModified') ))
#                        except Exception as e:
#                            logger.info("failed in set section for update ")
#                            logger.info("update_agent_dict %s"%update_agent_dict)
#                            failedupdatelist.append((nova_id ,"failed in set section for update having reason  %s"%e))
#                        try:
#                            delmongores=mongocollections.update_one(query, {'$unset': delete_agent_dict}).raw_result
#                            update_lis_cnt.append((delmongores.get('updatedExisting') , delmongores.get('nModified') ))
#                        except Exception as e:
#                            logger.info("error in unset section for delete")
#                            logger.info("delete_agent_dict %s"%delete_agent_dict)
#                            if nova_id not in [nova[0] for nova in failedupdatelist]:
#                                failedupdatelist.append((nova_id ,"failed in unset section for delete field having reason  %s"%e))
#                        #logger.info("mongo update res %s agent_test and mongo delete res %s"%(mongores, delmongores))
#
#                        current_date_res=mongocollections.update_one(query,{ '$currentDate': {'lastModifiedDateTime': True }}).raw_result
#                            
#                        if  (False,0) in update_lis_cnt or (current_date_res.get('updatedExisting')==False and current_date_res.get('updatedExisting').getget('nModified') ==0):
#                            if nova_id not in [nova[0] for nova in failedupdatelist]:
#                                failedupdatelist.append((nova_id ,"some error"))
#                        else:
#                            movfiles_list.append(nova_id)
#                    except Exception as e:
#                        logger.info("Update Process Error  while running for novaid %s with following error %s"%(nova_id, e))
#                        if nova_id not in [nova[0] for nova in failedupdatelist]:
#                            failedupdatelist.append((nova_id ,e))
#                            
                            

#if __name__ == '__main__':
#    main(sys.argv[1:])