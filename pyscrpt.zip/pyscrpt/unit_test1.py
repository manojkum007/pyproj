# -*- coding: utf-8 -*-
"""
Created on Thu Aug 10 19:18:56 2017

@author: manoj
"""

def is_prime(number):
    """Return True if *number* is prime."""
    for element in range(2,number):
        if number % element == 0:
            return False

    return True


#print is_prime(47)

import unittest
#from primes import is_prime

class PrimesTestCase(unittest.TestCase):
    """Tests for `primes.py`."""

    def test_is_five_prime(self):
        """Is five successfully determined to be prime?"""
        self.assertTrue(is_prime(47))
    
    def test_is_five_prime_not(self):
        """Is five successfully determined to be prime?"""
        self.assertTrue(is_prime(11)) 



class FixturesTest(unittest.TestCase):

    def setUp(self):
        print 'In setUp()'
        self.fixture = range(1, 10)

    def tearDown(self):
        print 'In tearDown()'
        del self.fixture
    

    def test(self):
        print 'in test()'
        self.failUnlessEqual(self.fixture, range(1, 10))


class EqualityTest(unittest.TestCase):

    def testEqual(self):
        print "In equaltest"
        print self.failUnlessEqual(2,2)

    def testNotEqual(self):
        print "in not equal"
        self.failIfEqual(2, 3-2)
        
        

if __name__ == '__main__':
    unittest.main()
    
    
    