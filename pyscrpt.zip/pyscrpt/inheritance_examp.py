# -*- coding: utf-8 -*-
"""
Created on Wed May 31 15:31:05 2017

@author: manoj
"""
#
class Parent(object):
    def __init__(self,name):
        self.pname=name
    def show(self):
        print "name is ",self.pname
    
    

class child(Parent):
    def __init__(self,name):
        self.childname=name
        #Parent.__init__(self,name)
        #super().__init__(self,name)
        super(child,self).__init__(name)
    
    def show(self):
        print "child name" ,self.childname
        
    
    
c=child("manoj")
c.show()
print c.pname



class A(object):
    def foo(self):
        print 'A'
 
class B(A):
    def foo(self):
        print 'B'
        super(B, self).foo()
 
class C(A):
    def foo(self):
        print 'C'
        super(C, self).foo()
 
class D(B,C):
    def foo(self):
        print 'D'
        super(D, self).foo()
        print D.__mro__ 
 
d = D()
d.foo()