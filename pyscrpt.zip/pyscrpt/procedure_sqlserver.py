# -*- coding: utf-8 -*-
"""
Created on Tue Feb 21 11:54:14 2017

@author: manoj
"""

import pymssql


#with pymssql.connect('192.168.120.139', 'sa', 'igen', 'AgentDirectory') as conn:
#    with conn.cursor(as_dict=True) as cursor:
#        cursor.execute("""CREATE PROCEDURE FindPerson @name VARCHAR(100) 
#        AS BEGIN 
#        SELECT * FROM AgentDirectory.dbo.s_02_10_2017 WHERE AgentID = @name 
#        END""")
#        cursor.callproc('FindPerson', ('000b1ecd-b5d5-4e15-ab82-cdf986e64d06',))
#        for row in cursor:
#            print("ID=%s, Name=%s" % (row['AgentID'], row['Width']))





with pymssql.connect('192.168.120.139', 'sa', 'igen', 'AgentDirectory') as conn:
    with conn.cursor() as cursor:
        print "calling procesure"
        cursor.callproc('AgentDirectory.dbo.usp_DeltaLoadToAgentsCollection', ("2017-02-18", "2017-02-20", 12))
        print " procedure completed"        
        for row in cursor:
            print row