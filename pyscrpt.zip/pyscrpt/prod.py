# -*- coding: utf-8 -*-
"""
Created on Thu May 19 15:12:58 2016

@author: manoj
"""

mnoj ="vdfvd"


def prs(a,b):
    prod=a*b
    return prod
    
def sum1(5,23):
    return 56
    

if __name__ == '__main__':   
    print prs(56,12)
    
#print prs(56,12)