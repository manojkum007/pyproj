import luigi
from luigi.contrib import sqla
import movoto_logger
import pyhs2
import pymssql
import datetime
from salesforce_bulk import SalesforceBulk, CsvDictsAdapter
from simple_salesforce import Salesforce

logger = movoto_logger.get_logger('first_touch_to_sfdc.log')
luigi_config = luigi.configuration.get_config()

FIRST_TOUCH_QUERY = '''
    SELECT Q2.Id  --Contact ID
        ,Q2.Initial_Marketing_Activity_Date__c
        ,Q2.Initial_Marketing_Campaign__c
        ,Q2.Initial_Marketing_Lead_Source__c
    FROM
    (
        SELECT
            Q1.Id
            ,DATEADD(second, visitid, '19700101') AS Initial_Marketing_Activity_Date__c
            ,c.Initial_Marketing_Activity_Date__c cur_first_touch_date
            ,campaign AS Initial_Marketing_Campaign__c
            ,[source] + '/' + [medium] AS Initial_Marketing_Lead_Source__c
            ,ROW_NUMBER() OVER (PARTITION BY Q1.Id ORDER BY visitid ASC) AS seq
        FROM
        (
            SELECT DISTINCT c.Id, li.GoogleID__c
            FROM sf_raw.dbo.LeadInfo__c li
            INNER JOIN sf_raw.dbo.Contact c
            ON li.Contact__c = c.Id
            WHERE GoogleID__c IS NOT NULL
            -- AND c.Initial_Marketing_Activity_Date__c IS NULL
        ) Q1
        INNER JOIN sf_raw_dev.dbo.bq_first_touch bq
        ON Q1.GoogleID__c = bq.ga_id
        INNER JOIN sf_raw.dbo.Contact c
        ON c.id = Q1.Id
        AND (c.Initial_Marketing_Activity_Date__c IS NULL
            OR c.Initial_Marketing_Activity_Date__c > DATEADD(second, visitid, '19700101'))
    ) Q2
    WHERE seq = 1
'''

LAST_TOUCH_QUERY = '''
    SELECT Q2.Id
        ,Q2.Latest_Marketing_Activity_Date__c
        ,Q2.Latest_Marketing_Campaign__c
    FROM
    (
        SELECT
            Q1.Id  --Contact ID
            ,DATEADD(second, visitid, '19700101') AS Latest_Marketing_Activity_Date__c
            ,campaign AS Latest_Marketing_Campaign__c
            ,[source] + '/' + [medium] AS Latest_Marketing_Lead_Source__c
            ,ROW_NUMBER() OVER (PARTITION BY Q1.Id ORDER BY visitid DESC) AS seq
        FROM
        (
            SELECT DISTINCT c.Id, li.GoogleID__c
            FROM sf_raw.dbo.LeadInfo__c li
            INNER JOIN sf_raw.dbo.Contact c
            ON li.Contact__c = c.Id
            WHERE GoogleID__c IS NOT NULL
        ) Q1
        INNER JOIN sf_raw_dev.dbo.bq_last_touch bq
        ON Q1.GoogleID__c = bq.ga_id
    ) Q2
    WHERE seq = 1
'''


def paginate(seq, rowlen):
    for start in xrange(0, len(seq), rowlen):
        yield seq[start: start + rowlen]


def db_target(job_name, marker_table, timestamp, get_all):
    db_config = 'puma'
    db_name = luigi_config.get(db_config, 'db')
    db_host = luigi_config.get(db_config, 'host')
    db_username = luigi_config.get(db_config, 'user')
    db_password = luigi_config.get(db_config, 'pw')

    # sqla_string = 'mssql+pyodbc://%s:%s@%s/%s?driver=SQL+Server' % (db_username, db_password, db_host, db_name)
    sqla_string = 'mssql+pymssql://%s:%s@%s/%s' % (db_username, db_password, db_host, db_name)

    return sqla.SQLAlchemyTarget(sqla_string, marker_table, '%s_%s_%s' % (job_name, timestamp, get_all), echo=False, connect_args={})


class QueryBQ(luigi.Task):
    run_date = luigi.DateParameter(default=datetime.date.today()-datetime.timedelta(days=1))
    get_all = luigi.BoolParameter(default=False)
    first_touch = luigi.BoolParameter(default=False)

    def requires(self):
        pass

    def run(self):
        # Query BQ
        host = luigi_config.get('bq', 'host')
        port = luigi_config.get('bq', 'port')
        user = luigi_config.get('bq', 'user')
        pw = ''
        auth = luigi_config.get('bq', 'auth')

        conn = pyhs2.connect(host=host, port=port, authMechanism=auth, user=user, password=pw, database='bq_nova')
        cur = conn.cursor()
        logger.info('running query')
        query_string = '''
            SELECT *
            FROM
            (
                SELECT `date` AS visit_date
                    ,a.fullvisitorid
                    ,a.userid
                    ,a.visitnumber
                    ,a.visitid
                    ,cd.value AS ga_id
                    ,trafficsource.campaign
                    ,trafficsource.keyword
                    ,trafficsource.source
                    ,trafficsource.medium
                    ,trafficsource.referralPath
                    ,trafficsource.campaignCode
                    ,trafficsource.adwordsClickInfo.adGroupId
                    ,trafficsource.adwordsClickInfo.adNetworkType
                    ,trafficsource.adwordsClickInfo.campaignId
                    ,trafficsource.adwordsClickInfo.creativeId
                    ,trafficsource.adwordsClickInfo.criteriaId
                    ,trafficsource.adwordsClickInfo.criteriaParameters
                    ,trafficsource.adwordsClickInfo.customerId
                    ,trafficsource.adwordsClickInfo.gclId
                    ,trafficsource.adwordsClickInfo.page
                    ,trafficsource.adwordsClickInfo.slot
                    ,ROW_NUMBER() OVER (PARTITION BY cd.value ORDER BY a.visitnumber [SORT_ORDER]) seq
                FROM bq_nova.sessions_hits_parquet_newschema a
                lateral view explode(customdimensions.`array`) c as cd
                WHERE cd.index = 6
                [DATE_CLAUSE]
            ) q1
            WHERE seq = 1
        '''.replace('[DATE_CLAUSE]', self.get_date_clause()).replace('[SORT_ORDER]', 'ASC' if self.first_touch else 'DESC')
        logger.info(query_string)
        cur.execute(query_string)

        res = []

        while cur.hasMoreRows:
            row = cur.fetchone()
            if not row:
                break
            row[0] = datetime.datetime.strptime(row[0], '%Y%m%d')
            res.append(tuple(row))

        logger.info('retrieved %s rows.' % len(res))

        # Push results to staging table in Puma
        self.results_to_db(res)

        logger.info('Job complete. Updating marker table.')
        self.output().touch()

        pass

    def get_date_clause(self):
        if self.get_all:
            return 'AND `date` IS NOT NULL'
        else:
            return "AND CAST(`date` AS STRING) = '%s'" % self.run_date.strftime('%Y%m%d')
        pass

    def results_to_db(self, res):
        logger.info('Saving results to db...')
        host = luigi_config.get('puma', 'host')
        user = luigi_config.get('puma', 'user')
        pw = luigi_config.get('puma', 'pw')
        db = luigi_config.get('puma', 'temp-db')

        conn = pymssql.connect(host, user, pw, db)
        cur = conn.cursor()

        # truncate staging table
        if self.get_all:
            truncate_query_string = '''
            TRUNCATE TABLE sf_raw_dev.dbo.[TABLE_NAME]
            '''.replace('[TABLE_NAME]', 'bq_first_touch' if self.first_touch else 'bq_last_touch')

            cur.execute(truncate_query_string)
            conn.commit()

        query_string = '''
        INSERT INTO sf_raw_dev.dbo.[TABLE_NAME]
        VALUES(
            %s, -- visit_date			DATE
            %s, -- fullvisitorid		NVARCHAR(100)
            %s, -- userid
            %d, -- visitnumber		INT
            %d, -- visitid			BIGINT
            %s, -- ga_id				NVARCHAR(64)
            %s, -- campaign			NVARCHAR(255)
            %s, -- keyword			NVARCHAR(255)
            %s, -- source				NVARCHAR(255)
            %s, -- medium				NVARCHAR(255)
            %s, -- referralPath		NVARCHAR(1024)
            %s, -- campaignCode		NVARCHAR(255)
            %s, -- adGroupId			NVARCHAR(255)
            %s, -- adNetworkType		NVARCHAR(255)
            %s, -- campaignId			NVARCHAR(255)
            %s, -- creativeId			NVARCHAR(255)
            %s, -- criteriaId			NVARCHAR(255)
            %s, -- criteriaParameters	NVARCHAR(MAX)
            %s, -- customerId			NVARCHAR(255)
            %s, -- gclId				NVARCHAR(500)
            %s, -- page				NVARCHAR(max)
            %s -- slot				NVARCHAR(255)
        )
        '''.replace('[TABLE_NAME]', 'bq_first_touch' if self.first_touch else 'bq_last_touch')

        i = 0
        for r in res:
            try:
                cur.execute(query_string, r)
            except Exception as e:
                logger.info('failed to insert row: %s' % [str(x) for x in r])
                logger.info('error: %s' % e.message)
            i += 1
            if i % 10000 == 0:
                conn.commit()
                logger.info('%s rows...' % i)

        conn.commit()

        self.output().touch()
        pass

    def output(self):
        return db_target('QueryBQ_%s' % 'bq_first_touch' if self.first_touch else 'bq_last_touch',
                         ('sf_raw_dev.dbo.%s' % 'bq_first_touch' if self.first_touch else 'bq_last_touch'),
                         self.run_date,
                         self.get_all)
        pass


class ContactFirstLastTouchToSf(luigi.Task):
    run_date = luigi.DateParameter(default=datetime.date.today()-datetime.timedelta(days=1))
    get_all = luigi.BoolParameter(default=False)
    first_touch = luigi.BoolParameter(default=False)

    def requires(self):
        return QueryBQ(get_all=self.get_all, run_date=self.run_date, first_touch=self.first_touch)
        pass

    def run(self):
        # Connect to Puma
        host = luigi_config.get('puma', 'host')
        user = luigi_config.get('puma', 'user')
        pw = luigi_config.get('puma', 'pw')
        db = luigi_config.get('puma', 'temp-db')

        conn = pymssql.connect(host, user, pw, db, as_dict=True)
        cur = conn.cursor()

        query_string = FIRST_TOUCH_QUERY if self.first_touch else LAST_TOUCH_QUERY

        cur.execute(query_string)

        res = cur.fetchall()

        for r in res:
            if self.first_touch:
                r['Initial_Marketing_Activity_Date__c'] = r['Initial_Marketing_Activity_Date__c'].strftime('%Y-%m-%dT%H:%M:%S.000Z')
            else:
                r['Latest_Marketing_Activity_Date__c'] = r['Latest_Marketing_Activity_Date__c'].strftime('%Y-%m-%dT%H:%M:%S.000Z')

        # Connect to Salesforce Bulk
        sf_config = 'sf'

        logger.info('Connecting to Salesforce%s...' % '')
        # Create SF connection through simple_salesforce

        sf_user = luigi_config.get(sf_config, 'username')
        sf_password = luigi_config.get(sf_config, 'password')
        sf_token = luigi_config.get(sf_config, 'token') or ''
        sf_sandbox = False

        sf = Salesforce(username=sf_user, password=sf_password, security_token=sf_token, sandbox=sf_sandbox)

        # Pass session id from simple_salesforce to salesforce_bulk
        session_id = sf.session_id
        session_host = sf.sf_instance

        bulk = SalesforceBulk(sessionId=session_id, host=session_host)

        logger.info('Collecting list of Contacts to update...')

        res = paginate(res, 10000)  # Returns list of list of scores

        for page in res:
            try:
                job = bulk.create_update_job('Contact', contentType='CSV')
                csv_iter = CsvDictsAdapter(iter(page))
                batch = bulk.post_bulk_batch(job, csv_iter)
                bulk.wait_for_batch(job, batch)
            finally:
                bulk.close_job(job)

        self.output().touch()
        pass

    def output(self):
        return db_target('ContactFirstLastTouchToSf_%s' % 'bq_first_touch' if self.first_touch else 'bq_last_touch',
                         ('sf_raw_dev.dbo.bq_%s_touch' % 'first' if self.first_touch else 'last'),
                         self.run_date,
                         self.get_all)
        pass


class OpportunityFirstTouchToSf(luigi.Task):
    run_date = luigi.DateParameter(default=datetime.date.today()-datetime.timedelta(days=1))
    get_all = luigi.BoolParameter(default=False)

    def requires(self):
        return QueryBQ(get_all=self.get_all, run_date=self.run_date, first_touch=True)
        pass

    def run(self):

        logger.info('Loading Opportunity first touch campaign to SFDC...')

        # Connect to Puma
        host = luigi_config.get('puma', 'host')
        user = luigi_config.get('puma', 'user')
        pw = luigi_config.get('puma', 'pw')
        db = luigi_config.get('puma', 'temp-db')

        conn = pymssql.connect(host, user, pw, db, as_dict=True)
        cur = conn.cursor()

        logger.info('Retrieving results from DB...')

        query_string = '''
            SELECT Q2.Id  --Opportunity ID
                ,Q2.Initial_Marketing_Campaign__c
            FROM
            (
                SELECT
                    Q1.Id
                    ,DATEADD(second, visitid, '19700101') AS Initial_Marketing_Activity_Date__c
                    ,campaign AS Initial_Marketing_Campaign__c
                    ,[source] + '/' + [medium] AS Initial_Marketing_Lead_Source__c
                    ,ROW_NUMBER() OVER (PARTITION BY Q1.Id ORDER BY visitid ASC) AS seq
                FROM
                (
                    SELECT DISTINCT o.Id, li.GoogleID__c
                    FROM sf_raw.dbo.LeadInfo__c li
                    INNER JOIN sf_raw.dbo.Opportunity o
                    ON li.Opportunity__c = o.Id
                    WHERE GoogleID__c IS NOT NULL
                    AND o.Initial_Marketing_Campaign__c IS NULL
                ) Q1
                INNER JOIN sf_raw_dev.dbo.bq_first_touch bq
                ON Q1.GoogleID__c = bq.ga_id
            ) Q2
            WHERE seq = 1
            AND Initial_Marketing_Campaign__c IS NOT NULL
        '''

        cur.execute(query_string)

        res = cur.fetchall()

        # Connect to Salesforce Bulk
        sf_config = 'sf'

        logger.info('Connecting to Salesforce%s...' % '')
        # Create SF connection through simple_salesforce

        sf_user = luigi_config.get(sf_config, 'username')
        sf_password = luigi_config.get(sf_config, 'password')
        sf_token = luigi_config.get(sf_config, 'token') or ''
        sf_sandbox = False

        sf = Salesforce(username=sf_user, password=sf_password, security_token=sf_token, sandbox=sf_sandbox)

        # Pass session id from simple_salesforce to salesforce_bulk
        session_id = sf.session_id
        session_host = sf.sf_instance

        bulk = SalesforceBulk(sessionId=session_id, host=session_host)

        res = paginate(res, 10000)  # Returns list of list of scores

        for page in res:
            try:
                job = bulk.create_update_job('Opportunity', contentType='CSV')
                csv_iter = CsvDictsAdapter(iter(page))
                batch = bulk.post_bulk_batch(job, csv_iter)
                bulk.wait_for_batch(job, batch)
            finally:
                bulk.close_job(job)

        self.output().touch()
        pass

    def output(self):
        return db_target('OpportunityFirstTouchToSf',
                         'sf_raw_dev.dbo.bq_first_touch',
                         self.run_date,
                         self.get_all)
        pass


class MarketingToSf(luigi.Task):
    run_date = luigi.DateParameter(default=datetime.date.today()-datetime.timedelta(days=1))
    get_all = luigi.BoolParameter(default=False)

    def requires(self):
        return (ContactFirstLastTouchToSf(run_date=self.run_date,
                                          get_all=self.get_all,
                                          first_touch=True),
                ContactFirstLastTouchToSf(run_date=self.run_date,
                                          get_all=self.get_all,
                                          first_touch=False),
                OpportunityFirstTouchToSf(run_date=self.run_date,
                                          get_all=self.get_all))
        pass

    def output(self):
        return db_target('MarketingToSf',
                         'sf_raw_dev.dbo.bq_first_touch',
                         self.run_date,
                         self.get_all)
        pass

    def run(self):
        # Dummy job which wraps Contacts and Opportunities
        self.output().touch()
        pass


if __name__ == '__main__':
    luigi.run()

