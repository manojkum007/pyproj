import luigi
from luigi.contrib import sqla
import movoto_logger
import pyhs2
import pymssql
import datetime
from salesforce_bulk import SalesforceBulk, CsvDictsAdapter
from simple_salesforce import Salesforce

logger = movoto_logger.get_logger('marketing_to_sfdc.log')
luigi_config = luigi.configuration.get_config()

QUERY_STRING = '''
    SELECT *
    FROM (
        select
--            CAST(`date` AS STRING) AS bq_date,
            cast(a.fullvisitorid as string) as fullvisitorid,
            cast(a.trafficsource.referralPath  as string) as referralPath,
            cast(a.trafficsource.campaign  as string)  as campaign,
            cast(a.trafficsource.source as string) as trafficsource,
            cast(a.trafficsource.medium  as string) as medium,
            cast(a.trafficsource.keyword  as string) as keyword,
            a.trafficsource.adwordsClickInfo.campaignId,
            a.trafficsource.adwordsClickInfo.adGroupId,
            a.trafficsource.adwordsClickInfo.creativeId,
            a.trafficsource.adwordsClickInfo.criteriaId,
            a.trafficsource.adwordsClickInfo.page,
            cast(a.trafficsource.adwordsClickInfo.slot as string) as adworkclickslot,
            cast(a.trafficsource.adwordsClickInfo.criteriaParameters as string) as criteriaparameters,
            cast(a.trafficsource.adwordsClickInfo.gclId as string) as gclid,
            a.trafficsource.adwordsClickInfo.customerId,
            cast(a.trafficsource.adwordsClickInfo.adNetworkType as string) as adworkclicknetworktype,
            a.trafficsource.adwordsClickInfo.targetingCriteria.boomUserlistId,
            a.trafficsource.adwordsClickInfo.isVideoAd,
            cast(a.device.mobileDeviceMarketingName as string) as mobiledevicemarketingname,
            cast(a.geonetwork.city as string) as city,
            hitarray.hitNumber,
            hitarray.`time` as event_time,
            hitarray.`hour` as event_hour,
            hitarray.`minute` as event_minute,
            a.visitnumber,
            a.visitid,
            cast( visitid+(hitarray.`time`/1000)   as timestamp) as event_timestamp,
            cast(hitarray.eventInfo.eventAction as string) as eventaction,
            cast(hitarray.eventInfo.eventLabel as string) as eventlabel,
            cast(a.`date` as string) as visitdate,
            cast(custom.`value` as string)  as hotleadid,
            cast(custom.`index` as string) as customindex
        FROM bq_nova.sessions_hits_parquet_newschema a
        lateral view explode(hits.`array`) c  as hitarray
        lateral view explode(hitarray.customDimensions.`array`) d as custom
        -- where CAST(`date` AS STRING) ='20170510'
        WHERE
        cast(custom.`index` as string) = '32'
        AND cast(hitarray.eventInfo.eventLabel as string) = 'lead-received'
        [BQ_DATE_STRING]
    ) bq
    LEFT JOIN
    (
        SELECT
            clicks.report_date
            ,clicks.gclid
            ,clicks.ad_format
            ,clicks.ad_group_id
            ,clicks.ad_id
            ,clicks.campaign_id
            ,clicks.device
            ,clicks.keyword_id
            ,clicks.keyword_match_type
            ,clicks.keyword_placement
            ,clicks.slot
            ,keywords.keyword
            ,keywords.match_type
            ,url.final_url
            ,placement.placement
            ,placement.criteria_display_name
        FROM adwords.click_performance_report clicks
        LEFT JOIN (
            SELECT DISTINCT keyword_id, match_type, keyword
            FROM adwords.keywords_performance_report
        ) keywords
        ON clicks.keyword_id = keywords.keyword_id
        LEFT JOIN (
            SELECT DISTINCT ad_group_id, campaign_id, final_url
            FROM adwords.final_url_report
        ) url
        ON clicks.ad_group_id = url.ad_group_id
        AND clicks.campaign_id = url.campaign_id
        LEFT JOIN (
            SELECT DISTINCT criterion_id, placement, criteria_display_name
            FROM adwords.placement_performance_report
        ) placement
        ON clicks.keyword_id = placement.criterion_id
        [ADWORDS_DATE_STRING]
    ) aw
    ON aw.gclid = bq.gclid
'''


def paginate(seq, rowlen):
    for start in xrange(0, len(seq), rowlen):
        yield seq[start: start + rowlen]


def db_target(job_name, marker_table, timestamp, get_all):
    db_config = 'puma'
    db_name = luigi_config.get(db_config, 'db')
    db_host = luigi_config.get(db_config, 'host')
    db_username = luigi_config.get(db_config, 'user')
    db_password = luigi_config.get(db_config, 'pw')

    # sqla_string = 'mssql+pyodbc://%s:%s@%s/%s?driver=SQL+Server' % (db_username, db_password, db_host, db_name)
    sqla_string = 'mssql+pymssql://%s:%s@%s/%s' % (db_username, db_password, db_host, db_name)

    return sqla.SQLAlchemyTarget(sqla_string, marker_table, '%s_%s_%s' % (job_name, timestamp, get_all), echo=False, connect_args={})


class QueryBQ(luigi.Task):
    run_date = luigi.DateParameter(default=datetime.date.today()-datetime.timedelta(days=1))
    get_all = luigi.BoolParameter(default=False)
    first_touch = luigi.BoolParameter(default=False)

    def requires(self):
        pass

    def run(self):
        # Query BQ
        host = luigi_config.get('bq', 'host')
        port = luigi_config.get('bq', 'port')
        user = luigi_config.get('bq', 'user')
        pw = ''
        auth = luigi_config.get('bq', 'auth')

        conn = pyhs2.connect(host=host, port=port, authMechanism=auth, user=user, password=pw, database='bq_nova')
        cur = conn.cursor()
        logger.info('running query')

        query_string = QUERY_STRING.replace('[BQ_DATE_STRING]', self.get_date_clause()).replace('[ADWORDS_DATE_STRING]', self.get_date_clause(True))
        logger.info(query_string)
        cur.execute(query_string)

        res = []

        while cur.hasMoreRows:
            row = cur.fetchone()
            if not row:
                break
            # row[0] = datetime.datetime.strptime(row[0], '%Y%m%d')
            res.append(tuple(row))

        logger.info('retrieved %s rows.' % len(res))

        # Push results to staging table in Puma
        self.results_to_db(res)

        logger.info('Job complete. Updating marker table.')
        self.output().touch()

        pass

    def get_date_clause(self, adwords=False):
        if self.get_all:
            return 'AND `date` IS NOT NULL'
        elif adwords:
            return "WHERE CAST(`report_date` AS STRING) = '%s'" % self.run_date.strftime('%Y-%m-%d')
        else:
            return "AND CAST(`date` AS STRING) = '%s'" % self.run_date.strftime('%Y%m%d')
        pass

    def results_to_db(self, res):
        logger.info('Saving results to db...')
        host = luigi_config.get('puma', 'host')
        user = luigi_config.get('puma', 'user')
        pw = luigi_config.get('puma', 'pw')
        db = luigi_config.get('puma', 'temp-db')

        conn = pymssql.connect(host, user, pw, db)
        cur = conn.cursor()

        # truncate staging table
        # truncate_query_string = '''
        # TRUNCATE TABLE sf_raw_dev.dbo.[TABLE_NAME]
        # '''.replace('[TABLE_NAME]', 'bq_first_touch' if self.first_touch else 'bq_last_touch')

        # cur.execute(truncate_query_string)
        # conn.commit()

        query_string = '''
        INSERT INTO sf_raw_dev.dbo.[TABLE_NAME]
        VALUES(
            %s	-- [fullvisitorid] [nvarchar](255) NULL,
            ,%s	-- [referralpath] [nvarchar](4000) NULL,
            ,%s	-- [campaign] [nvarchar](255) NULL,
            ,%s	-- [trafficsource] [nvarchar](255) NULL,
            ,%s	-- [medium] [nvarchar](255) NULL,
            ,%s	-- [bigquerykeyword] [nvarchar](4000) NULL,
            ,%s	-- [campaignid] [nvarchar](255) NULL,
            ,%s	-- [adgroupid] [nvarchar](255) NULL,
            ,%s	-- [creativeid] [nvarchar](255) NULL,
            ,%s	-- [criteriaid] [nvarchar](255) NULL,
            ,%s	-- [page] [nvarchar](255) NULL,
            ,%s	-- [adworkclickslot] [nvarchar](255) NULL,
            ,%s	-- [criteriaparameters] [nvarchar](255) NULL,
            ,%s	-- [bigquerygclid] [nvarchar](255) NULL,
            ,%s	-- [customerid] [nvarchar](255) NULL,
            ,%s	-- [adworkclicknetworktype] [nvarchar](255) NULL,
            ,%s	-- [boomuserlistid] [nvarchar](255) NULL,
            ,%s	-- [isvideoad] [nvarchar](255) NULL,
            ,%s	-- [mobiledevicemarketingname] [nvarchar](255) NULL,
            ,%s	-- [city] [nvarchar](255) NULL,
            ,%s	-- [hitnumber] [nvarchar](255) NULL,
            ,%s	-- [event_time] [nvarchar](255) NULL,
            ,%s	-- [event_hour] [nvarchar](255) NULL,
            ,%s	-- [event_minute] [nvarchar](255) NULL,
            ,%s	-- [visitnumber] [nvarchar](255) NULL,
            ,%s	-- [visitid] [nvarchar](255) NULL,
            ,%d	-- [event_timestamp] [datetime] NULL,
            ,%s	-- [eventaction] [nvarchar](255) NULL,
            ,%s	-- [eventlabel] [nvarchar](255) NULL,
            ,%s	-- [visitdate] [nvarchar](255) NULL,
            ,%s	-- [hotleadid] [nvarchar](255) NULL,
            ,%s	-- [customindex] [nvarchar](255) NULL,
            ,%s	-- [report_date] [nvarchar](255) NULL,
            ,%s	-- [adwordgclid] [nvarchar](255) NULL,
            ,%s	-- [ad_format] [nvarchar](255) NULL,
            ,%s	-- [ad_group_id] [nvarchar](255) NULL,
            ,%s	-- [ad_id] [nvarchar](255) NULL,
            ,%s	-- [campaign_id] [nvarchar](255) NULL,
            ,%s	-- [device] [nvarchar](255) NULL,
            ,%s	-- [keyword_id] [nvarchar](255) NULL,
            ,%s	-- [keyword_match_type] [nvarchar](255) NULL,
            ,%s	-- [keyword_placement] [nvarchar](255) NULL,
            ,%s	-- [slot] [nvarchar](255) NULL,
            ,%s	-- [adwordkeyword] [nvarchar](255) NULL,
            ,%s	-- [match_type] [nvarchar](255) NULL,
            ,%s	-- [final_url] [nvarchar](255) NULL,
            ,%s	-- [placement] [nvarchar](255) NULL,
            ,%s	-- [criteria_display_name] [nvarchar](255) NULL
        )
        '''.replace('[TABLE_NAME]', 'bq_lead_info')

        i = 0
        for r in res:
            try:
                cur.execute(query_string, r)
            except Exception as e:
                logger.info('failed to insert row: %s' % [str(x) for x in r])
                logger.info('error: %s' % str(e))
            i += 1
            if i % 10000 == 0:
                conn.commit()
                logger.info('%s rows...' % i)

        conn.commit()

        self.output().touch()
        pass

    def output(self):
        return db_target('QueryBQ_%s' % 'bq_lead_info',
                         'sf_raw_dev.dbo.%s' % 'bq_lead_info',
                         self.run_date,
                         self.get_all)
        pass

if __name__ == '__main__':
    luigi.run()

