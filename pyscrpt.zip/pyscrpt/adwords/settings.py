# EMAIL DETAILS
HOST = 'localhost'
FROM_ADDRESS = ['datajobs@movoto.com']
TO_ADDRESS = ['rpazcoguin@movoto.com', 'upidathala@movoto.com', 'adesai@movoto.com', 'mkumar@movoto.com']
SUBJECT = 'Adwords Jobs - Error'

ES_INDEX = 'kpis'
