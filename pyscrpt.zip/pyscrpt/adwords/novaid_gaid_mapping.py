# import pyodbc
import pymssql
import luigi
from luigi.contrib.hive import HiveTableTarget
import movoto_logger
import csv
import datetime
import os

logger = movoto_logger.get_logger('novaid_gaid_mapping.log')


class MappingTableTarget(HiveTableTarget):
    def exists(self):
        query_string = '''
        SELECT 'EXISTS' FROM default.novaid_gaid_mapping
        WHERE batch_time LIKE '%s%%'
        LIMIT 1
        ''' % datetime.date.today().strftime('%Y-%m-%d')

        ret_val = luigi.contrib.hive.run_hive_cmd(query_string)
        return True if 'EXISTS' in ret_val else False


class NovaidGaidMapping(luigi.Task):

    def run(self):
        # connect to db
        # conn = pyodbc.connect('DRIVER={SQL Server};SERVER=puma.san-mateo.movoto.net;DATABASE=NovaProduction;UID=sa;PWD=igen')
        conn = pymssql.connect(server='puma.san-mateo.movoto.net',
                               user='sa',
                               password='igen',
                               database='NovaProduction')
        cur = conn.cursor()
        query_string = '''
        SELECT *
        FROM
        (
            SELECT DISTINCT user_id, [google_analytics_id], GETDATE() batch_time
            FROM NovaProduction.dbo.hot_lead
            WHERE [google_analytics_id] IS NOT NULL
            AND [google_analytics_id] != ''
        ) q1
        '''

        cur.execute(query_string)

        c = csv.writer(open('mappings.csv', 'w+'), delimiter=',', lineterminator='\n')
        for r in cur.fetchall():
            c.writerow(r)

    def output(self):
        return luigi.LocalTarget(path='mappings.csv')


class MappingsToHive(luigi.contrib.hive.HiveQueryTask):

    def requires(self):
        return NovaidGaidMapping()

    def query(self):
        logger.info('Pushing data into hive table...')

        query_string = '''
        TRUNCATE TABLE default.novaid_gaid_mapping_staging;
        LOAD DATA LOCAL INPATH "%s" INTO TABLE default.novaid_gaid_mapping_staging;

        TRUNCATE TABLE default.novaid_gaid_mapping;
        INSERT INTO default.novaid_gaid_mapping
        SELECT * FROM default.novaid_gaid_mapping_staging
        order by nova_id ASC;
        ''' % self.input().path
        return query_string

    def output(self):
        return MappingTableTarget(table='default.novaid_gaid_mapping')
        pass


class RemoveStagingFile(luigi.Task):
    def requires(self):
        return MappingsToHive()

    def run(self):
        if os.path.isfile('mappings.csv'):
            os.remove('mappings.csv')
            logger.info('Removed mapping staging file')

if __name__ == '__main__':
    luigi.run()

