import luigi
import datetime
import json
from googleads import adwords
from luigi.contrib.hdfs.hadoopcli_clients import HdfsClient
from luigi.contrib.hive import HiveTableTarget  # , run_hive_cmd
import os
import movoto_logger

luigi_config = luigi.configuration.get_config()
logger = movoto_logger.get_logger('adwords_reports.log')


class AdwordsReportTarget(HiveTableTarget):
    def __init__(self, table, database='default', report_date=None, client=None):
        self.report_date = report_date
        super(AdwordsReportTarget, self).__init__(table, database, client)

    def exists(self):
        query_string = '''
        SELECT 'EXISTS' FROM %s.%s a WHERE report_date = '%s' LIMIT 1;
        ''' % (luigi_config.get('adwords', 'hive-schema'), self.table, self.report_date.strftime('%Y-%m-%d'))

        ret_val = luigi.contrib.hive.run_hive_cmd(query_string)
        return True if 'EXISTS' in ret_val else False


class FileDeleteTarget(luigi.Target):
    def __init__(self, file_path):
        self.file_path = file_path

    def exists(self):
        return True if not os.path.exists(self.file_path) else False


class DownloadReport(luigi.Task):
    report_date = luigi.DateParameter(default=datetime.date.today()-datetime.timedelta(days=1))
    report_type = luigi.Parameter()

    def requires(self):
        pass

    def run(self):
        with open('./report_configs/%s.json' % self.report_type, 'r') as f:
            job_config = json.load(f)

        adwords_client = adwords.AdWordsClient.LoadFromStorage('/home/manoj/scripts/python_scripts/adwords/googleads.yaml')
        report_downloader = adwords_client.GetReportDownloader(version='v201702')
        # report_query = REPORT_QUERIES['click_performance_report']
        report_query = job_config['query']
        report_query += ' DURING %s, %s' % (self.report_date.strftime('%Y%m%d'), self.report_date.strftime('%Y%m%d'))
        
        print "report_query" ,report_query
        logger.info('Downloading %s, date = %s' % (self.report_type, self.report_date.strftime('%Y%m%d')))
        with open(self.output().path, 'w') as output_file:
            report_downloader.DownloadReportWithAwql(
                report_query, 'CSV', output_file, skip_report_header=True,
                skip_column_header=False, skip_report_summary=True,
                include_zero_impressions=job_config['include_zero_impressions'])

        logger.info('Download complete.')
        pass

    def output(self):
        return luigi.LocalTarget(path='./report_output/%s_%s.csv' % (self.report_type, self.report_date.strftime("%Y-%m-%d")))
        pass


class ReportToHiveTable(luigi.contrib.hive.HiveQueryTask):
    report_date = luigi.DateParameter(default=datetime.date.today()-datetime.timedelta(days=1))
    report_type = luigi.Parameter()

    def requires(self):
        return DownloadReport(report_date=self.report_date, report_type=self.report_type)
        pass

    def query(self):
        parquet_table = '%s.%s' % (luigi_config.get('adwords', 'hive-schema'), self.report_type)
        staging_table = parquet_table + '_staging'

        logger.info('Pushing data into hive table...')
        query_string = ('''
        TRUNCATE TABLE [staging_table];
        LOAD DATA LOCAL INPATH "%s" INTO TABLE [staging_table];
        INSERT INTO [parquet_table] SELECT * FROM [staging_table]
        WHERE report_date = '%s';
        ''' % (self.input().path,
               self.report_date.strftime('%Y-%m-%d'))).replace('[staging_table]',
                                                               staging_table).replace('[parquet_table]',
                                                                                      parquet_table)
        logger.info(query_string)
        return query_string
        pass

    def output(self):
        return AdwordsReportTarget(table=self.report_type, report_date=self.report_date)
        pass


class ReportToParquet(luigi.Task):
    report_date = luigi.DateParameter(default=datetime.date.today()-datetime.timedelta(days=1))
    report_type = luigi.Parameter()

    def requires(self):
        return ReportToHiveTable(report_date=self.report_date, report_type=self.report_type)
        pass

    def run(self):
        raise NotImplementedError
        pass

    def output(self):
        pass


class DeleteLocalReport(luigi.Task):
    report_date = luigi.DateParameter(default=datetime.date.today()-datetime.timedelta(days=1))
    report_type = luigi.Parameter()

    def requires(self):
        return ReportToHiveTable(report_date=self.report_date, report_type=self.report_type)
        pass

    def run(self):
        logger.info('Deleting local file ' + './report_output/%s_%s.csv' % (self.report_type, self.report_date.strftime("%Y-%m-%d")))
        local_file = luigi.LocalTarget(path='./report_output/%s_%s.csv' % (self.report_type, self.report_date.strftime("%Y-%m-%d")))
        if local_file.exists():
            local_file.remove()
            logger.info('File deleted successfully.')
        else:
            logger.info('File does not exist. No deletion occurred.')
        pass

    def output(self):
        # return FileDeleteTarget('./report_output/%s_%s.csv' % (self.report_type, self.report_date.strftime("%Y-%m-%d")))
        pass


class GetReportsForRange(luigi.Task):
    date_range = luigi.DateIntervalParameter(default=datetime.date.today()-datetime.timedelta(days=1))
    report_type = luigi.Parameter()

    def requires(self):
        yield [ReportToHiveTable(report_date=d, report_type=self.report_type) for d in self.date_range]
        pass

    def run(self):
        for d in self.date_range:
            DeleteLocalReport(report_date=d, report_type=self.report_type).run()
        pass

    def output(self):
        pass


if __name__ == '__main__':
    luigi.run()
