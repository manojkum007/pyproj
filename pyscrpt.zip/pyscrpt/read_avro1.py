# -*- coding: utf-8 -*-
"""
Created on Thu Jul 28 16:42:40 2016

@author: manoj
"""
import csv
import avro.schema
from avro.datafile import DataFileReader, DataFileWriter
from avro.io import DatumReader, DatumWriter

writedir="/home/manoj/scripts/tiger_analyatics/rhino/20151222/20151222_avro.json"
def writeRowfail(writedir,row):  
    with open(writedir, 'a') as failed_file:
        writer = csv.writer(failed_file, delimiter='\t')
        writer.writerow(row)

count=0       
        
avr="/home/manoj/scripts/tiger_analyatics/rhino/20151222/20151222_ga_sessions_000000000000.avro"
reader = DataFileReader(open(avr, "r"), DatumReader())
for user in reader:
    count+=1
    #writeRowfail(writedir,[user])
    #print user
reader.close()

print "total no of line in file" ,count