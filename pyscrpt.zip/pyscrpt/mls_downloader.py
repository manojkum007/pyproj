# -*- coding: utf-8 -*-
"""
Created on Thu Apr 12 13:19:01 2018

@author: manoj
"""


import urllib2
from lxml import etree
import pandas as pd

from fuzzywuzzy import process

AUTH_TOKEN = 'c34z7xKwq8e'
DB_SCHEMA = 'mls_updates'


MLS_URL = 'http://www.terradatum.com/apis/movoto/movoto/mls-data-2.0.xml?authToken=%s'


row_mls=[]

def MlsGetid():
    #response_mls = urllib2.urlopen(MLS_URL % (AUTH_TOKEN))
    response_mls1="""<results>
<MLS>
      <mlsId>ACTRIS</mlsId>
      <description>Austin Central Texas Realty Information Services</description>
      <stateCode>TX</stateCode>
</MLS>
<MLS>
      <mlsId>AKMLS</mlsId>
      <description>Alaska Multiple Listing Service, Inc</description>
      <stateCode>AK</stateCode>
</MLS>
<MLS>
      <mlsId>ARMLS</mlsId>
      <description>Arizona Regional MLS</description>
      <stateCode>AZ</stateCode>
</MLS>
<MLS>
      <mlsId>BAR</mlsId>
      <description>Birmingham Associaton of Realtors</description>
      <stateCode>AL</stateCode>
</MLS>
<MLS>
      <mlsId>BAREIS</mlsId>
      <description>Bay Area Real Estate Information Services</description>
      <stateCode>CA</stateCode>
</MLS>
<MLS>
      <mlsId>CARMLS</mlsId>
      <description>Cooperative Arkansas REALTORS MLS</description>
      <stateCode>AR</stateCode>
</MLS>
<MLS>
      <mlsId>CBRMLS</mlsId>
      <description>Columbus and Central Ohio Regional MLS</description>
      <stateCode>OH</stateCode>
</MLS>
<MLS>
      <mlsId>CCAR</mlsId>
      <description>Coastal Carolinas Association of REALTORS</description>
      <stateCode>SC</stateCode>
</MLS>
<MLS>
      <mlsId>CHARLOTTE</mlsId>
      <description>Carolina Multiple Listing Service</description>
      <stateCode>NC</stateCode>
</MLS>
<MLS>
      <mlsId>CINCYMLS</mlsId>
      <description>Cincy MLS</description>
      <stateCode>OH</stateCode>
</MLS>
<MLS>
      <mlsId>CRMLS</mlsId>
      <description>California Regional Multiple Listing Service</description>
      <stateCode>CA</stateCode>
</MLS>
<MLS>
      <mlsId>CTARMLS</mlsId>
      <description>Charleston Trident Association of REALTORS</description>
      <stateCode>SC</stateCode>
</MLS>
<MLS>
      <mlsId>CVRMLS</mlsId>
      <description>Central Virginia Regional Multiple Listing Service</description>
      <stateCode>VA</stateCode>
</MLS>
<MLS>
      <mlsId>DMAAR</mlsId>
      <description>Des Moines Area Association of Realtors</description>
      <stateCode>IA</stateCode>
</MLS>
<MLS>
      <mlsId>ECAOR</mlsId>
      <description>Emerald Coast Association of REALTORS</description>
      <stateCode>FL</stateCode>
</MLS>
<MLS>
      <mlsId>ENYRMLS</mlsId>
      <description>Eastern New York Regional MLS</description>
      <stateCode>NY</stateCode>
</MLS>
<MLS>
      <mlsId>FRESNO</mlsId>
      <description>Fresno Association of REALTORS®</description>
      <stateCode>CA</stateCode>
</MLS>
<MLS>
      <mlsId>GAMLS</mlsId>
      <description>Georgia MLS</description>
      <stateCode>GA</stateCode>
</MLS>
<MLS>
      <mlsId>GFLR</mlsId>
      <description>Greater Fort Lauderdale REALTORS®</description>
      <stateCode>FL</stateCode>
</MLS>
<MLS>
      <mlsId>GGAR</mlsId>
      <description>Greater Greenville Association of REALTORS</description>
      <stateCode>SC</stateCode>
</MLS>
<MLS>
      <mlsId>GLAR</mlsId>
      <description>Greater Louisville Association of Realtors</description>
      <stateCode>KY</stateCode>
</MLS>
<MLS>
      <mlsId>GLVAR</mlsId>
      <description>Greater Las Vegas Association of Realtors</description>
      <stateCode>NV</stateCode>
</MLS>
<MLS>
      <mlsId>GSMLS</mlsId>
      <description>Garden State MLS</description>
      <stateCode>NJ</stateCode>
</MLS>
<MLS>
      <mlsId>HAR</mlsId>
      <description>Houston Association of Realtors</description>
      <stateCode>TX</stateCode>
</MLS>
<MLS>
      <mlsId>HEARTLAND</mlsId>
      <description>Heartland MLS</description>
      <stateCode>KS</stateCode>
</MLS>
<MLS>
      <mlsId>HEARTLAND</mlsId>
      <description>Heartland MLS</description>
      <stateCode>MO</stateCode>
</MLS>
<MLS>
      <mlsId>HGMLS</mlsId>
      <description>Hudson Gateway Multiple Listing Service</description>
      <stateCode>NY</stateCode>
</MLS>
<MLS>
      <mlsId>HICENTRAL</mlsId>
      <description>Honolulu Board of REALTORS®</description>
      <stateCode>HI</stateCode>
</MLS>
<MLS>
      <mlsId>IMLS</mlsId>
      <description>Intermountain Multiple Listing Service, Inc.</description>
      <stateCode>ID</stateCode>
</MLS>
<MLS>
      <mlsId>IRES</mlsId>
      <description>Information and Real Estate Services, LLC</description>
      <stateCode>CO</stateCode>
</MLS>
<MLS>
      <mlsId>IRMLS</mlsId>
      <description>Indiana Regional MLS</description>
      <stateCode>IN</stateCode>
</MLS>
<MLS>
      <mlsId>KAAR</mlsId>
      <description>Knoxville Area Association of REALTORS®</description>
      <stateCode>TN</stateCode>
</MLS>
<MLS>
      <mlsId>LBAR</mlsId>
      <description>Lexington Bluegrass Association of REALTORS®</description>
      <stateCode>KY</stateCode>
</MLS>
<MLS>
      <mlsId>MAAR</mlsId>
      <description>Memphis Area Association of Realtors</description>
      <stateCode>TN</stateCode>
</MLS>
<MLS>
      <mlsId>MARIS</mlsId>
      <description>Mid America Regional Information Systems</description>
      <stateCode>IL</stateCode>
</MLS>
<MLS>
      <mlsId>MARIS</mlsId>
      <description>Mid America Regional Information Systems</description>
      <stateCode>MO</stateCode>
</MLS>
<MLS>
      <mlsId>METROLIST</mlsId>
      <description>MetroList - Sacramento</description>
      <stateCode>CA</stateCode>
</MLS>
<MLS>
      <mlsId>METROMLS</mlsId>
      <description>Multiple Listing Service, Inc.</description>
      <stateCode>WI</stateCode>
</MLS>
<MLS>
      <mlsId>MFRMLS</mlsId>
      <description>Mid Florida Regional MLS</description>
      <stateCode>FL</stateCode>
</MLS>
<MLS>
      <mlsId>MGCMLS</mlsId>
      <description>Mississippi Gulf Coast Multiple Listing Service</description>
      <stateCode>MS</stateCode>
</MLS>
<MLS>
      <mlsId>MIAMIRE</mlsId>
      <description>Miami Association of Realtors</description>
      <stateCode>FL</stateCode>
</MLS>
<MLS>
      <mlsId>MIBOR</mlsId>
      <description>Metropolitan Indianapolis Board of REALTORS®</description>
      <stateCode>IN</stateCode>
</MLS>
<MLS>
      <mlsId>MLSLI</mlsId>
      <description>Multiple Listing Service of Long Island</description>
      <stateCode>NY</stateCode>
</MLS>
<MLS>
      <mlsId>MLSLSTNGS</mlsId>
      <description>MLSListings, Inc.</description>
      <stateCode>CA</stateCode>
</MLS>
<MLS>
      <mlsId>MLSPIN</mlsId>
      <description>MLS Property Information Network</description>
      <stateCode>MA</stateCode>
</MLS>
<MLS>
      <mlsId>MLSSAZ</mlsId>
      <description>MLS of Southern Arizona</description>
      <stateCode>AZ</stateCode>
</MLS>
<MLS>
      <mlsId>MOMLS</mlsId>
      <description>Monmouth Ocean Multiple Listing Service</description>
      <stateCode>NJ</stateCode>
</MLS>
<MLS>
      <mlsId>MRED</mlsId>
      <description>Midwest Real Estate Data</description>
      <stateCode>IL</stateCode>
</MLS>
<MLS>
      <mlsId>MREIS</mlsId>
      <description>Maine Real Estates Information Systems, Inc.</description>
      <stateCode>ME</stateCode>
</MLS>
<MLS>
      <mlsId>MRIS</mlsId>
      <description>Metropolitan Regional Information Systems, Inc.</description>
      <stateCode>DC</stateCode>
</MLS>
<MLS>
      <mlsId>MRIS</mlsId>
      <description>Metropolitan Regional Information Systems, Inc.</description>
      <stateCode>MD</stateCode>
</MLS>
<MLS>
      <mlsId>MRIS</mlsId>
      <description>Metropolitan Regional Information Systems, Inc.</description>
      <stateCode>VA</stateCode>
</MLS>
<MLS>
      <mlsId>MRIS</mlsId>
      <description>Metropolitan Regional Information Systems, Inc.</description>
      <stateCode>WV</stateCode>
</MLS>
<MLS>
      <mlsId>NABOR</mlsId>
      <description>Northwest Arkansas Board of REALTORS®</description>
      <stateCode>AR</stateCode>
</MLS>
<MLS>
      <mlsId>NCAOR</mlsId>
      <description>Nevada County Association of REALTORS®</description>
      <stateCode>CA</stateCode>
</MLS>
<MLS>
      <mlsId>NEFMLS</mlsId>
      <description>Northeast Florida/Jacksonville</description>
      <stateCode>FL</stateCode>
</MLS>
<MLS>
      <mlsId>NEOHREX</mlsId>
      <description>NorthEast Ohio Real Estate Exchange</description>
      <stateCode>OH</stateCode>
</MLS>
<MLS>
      <mlsId>NEREN</mlsId>
      <description>New England Real Estate Network</description>
      <stateCode>NH</stateCode>
</MLS>
<MLS>
      <mlsId>NEREN</mlsId>
      <description>New England Real Estate Network</description>
      <stateCode>VT</stateCode>
</MLS>
<MLS>
      <mlsId>NNRMLS</mlsId>
      <description>Northern Nevada Regional MLS, Inc.</description>
      <stateCode>NV</stateCode>
</MLS>
<MLS>
      <mlsId>NOMAR</mlsId>
      <description>New Orleans Metropolitan Association of REALTORS</description>
      <stateCode>LA</stateCode>
</MLS>
<MLS>
      <mlsId>NTREIS</mlsId>
      <description>North Texas Real Estate Information Systems</description>
      <stateCode>TX</stateCode>
</MLS>
<MLS>
      <mlsId>NWMLS</mlsId>
      <description>Northwest MLS</description>
      <stateCode>WA</stateCode>
</MLS>
<MLS>
      <mlsId>NYSAMLS</mlsId>
      <description>New York State Alliance of MLSs</description>
      <stateCode>NY</stateCode>
</MLS>
<MLS>
      <mlsId>OABR</mlsId>
      <description>Omaha Association of Realtors</description>
      <stateCode>NE</stateCode>
</MLS>
<MLS>
      <mlsId>OKCMLS</mlsId>
      <description>Oklahoma City Multiple Listing Service</description>
      <stateCode>OK</stateCode>
</MLS>
<MLS>
      <mlsId>RANW</mlsId>
      <description>Realtors Association of Northeast Wisconsin</description>
      <stateCode>WI</stateCode>
</MLS>
<MLS>
      <mlsId>REALCOMP</mlsId>
      <description>RealComp Detroit</description>
      <stateCode>MI</stateCode>
</MLS>
<MLS>
      <mlsId>REALTRAC</mlsId>
      <description>RealEstate Listings in Middle Tennesse</description>
      <stateCode>TN</stateCode>
</MLS>
<MLS>
      <mlsId>RECOLORADO</mlsId>
      <description>REcolorado®</description>
      <stateCode>CO</stateCode>
</MLS>
<MLS>
      <mlsId>REIN</mlsId>
      <description>Real Estate Information Network</description>
      <stateCode>VA</stateCode>
</MLS>
<MLS>
      <mlsId>RIMLS</mlsId>
      <description>Rhode Island MLS</description>
      <stateCode>RI</stateCode>
</MLS>
<MLS>
      <mlsId>RMLS</mlsId>
      <description>Portland Multiple Listing Service</description>
      <stateCode>OR</stateCode>
</MLS>
<MLS>
      <mlsId>RMLS_MN</mlsId>
      <description>Regional Multiple Listing Service of Minnesota</description>
      <stateCode>MN</stateCode>
</MLS>
<MLS>
      <mlsId>SABOR</mlsId>
      <description>San Antonio Board of Realtors</description>
      <stateCode>TX</stateCode>
</MLS>
<MLS>
      <mlsId>SANDICOR</mlsId>
      <description>San Diego Regional MLS</description>
      <stateCode>CA</stateCode>
</MLS>
<MLS>
      <mlsId>SCWMLS</mlsId>
      <description>South Central Wisconsin MLS</description>
      <stateCode>WI</stateCode>
</MLS>
<MLS>
      <mlsId>SFMLS</mlsId>
      <description>San Francisco Multiple Listing Service</description>
      <stateCode>CA</stateCode>
</MLS>
<MLS>
      <mlsId>SJSMLS</mlsId>
      <description>South Jersey Shore MLS</description>
      <stateCode>NJ</stateCode>
</MLS>
<MLS>
      <mlsId>SOMOMLS</mlsId>
      <description>Southern Missouri Regional MLS</description>
      <stateCode>MO</stateCode>
</MLS>
<MLS>
      <mlsId>SWFMLS</mlsId>
      <description>Southwest Florida MLS</description>
      <stateCode>FL</stateCode>
</MLS>
<MLS>
      <mlsId>SWMLS</mlsId>
      <description>Southwest MLS</description>
      <stateCode>NM</stateCode>
</MLS>
<MLS>
      <mlsId>SWMRIC</mlsId>
      <description>Southwest Michigan Regional Information Center</description>
      <stateCode>MI</stateCode>
</MLS>
<MLS>
      <mlsId>TENNVAMLS</mlsId>
      <description>Tennessee Virginia Regional MLS</description>
      <stateCode>TN</stateCode>
</MLS>
<MLS>
      <mlsId>TREND</mlsId>
      <description>TREND</description>
      <stateCode>DE</stateCode>
</MLS>
<MLS>
      <mlsId>TREND</mlsId>
      <description>TREND</description>
      <stateCode>NJ</stateCode>
</MLS>
<MLS>
      <mlsId>TREND</mlsId>
      <description>TREND</description>
      <stateCode>PA</stateCode>
</MLS>
<MLS>
      <mlsId>TRIAD</mlsId>
      <description>TRIAD Multiple Listing Service</description>
      <stateCode>NC</stateCode>
</MLS>
<MLS>
      <mlsId>TRIANGLE</mlsId>
      <description>Triangle MLS Inc.</description>
      <stateCode>NC</stateCode>
</MLS>
<MLS>
      <mlsId>WPML</mlsId>
      <description>West Pen Multi-List, Inc.</description>
      <stateCode>PA</stateCode>
</MLS>
<MLS>
      <mlsId></mlsId>
      <description></description>
      <stateCode>CT</stateCode>
</MLS>
<MLS>
      <mlsId></mlsId>
      <description></description>
      <stateCode>MT</stateCode>
</MLS>
<MLS>
      <mlsId></mlsId>
      <description></description>
      <stateCode>ND</stateCode>
</MLS>
<MLS>
      <mlsId></mlsId>
      <description></description>
      <stateCode>SD</stateCode>
</MLS>
<MLS>
      <mlsId></mlsId>
      <description></description>
      <stateCode>UT</stateCode>
</MLS>
<MLS>
      <mlsId></mlsId>
      <description></description>
      <stateCode>WY</stateCode>
</MLS>
</results>"""
    from StringIO import StringIO
    doc = etree.parse(StringIO(response_mls1))
    root = doc.getroot()
    for MLS in root.findall('MLS'):
        rank = MLS.find('mlsId').text
        statecode = MLS.find('stateCode').text
        if (rank is not None):
          row_mls.append([rank.lower(), statecode.lower()])
    return row_mls


label=["mlsname","state"]
#"lastname","language_preference__c"," sale_price","mobilephone","email","listagentcount","saleagentcount","min_sales","max_sales","avg_sales","median_sales", "latitude","longitude","property_type"]
    
df = pd.DataFrame(MlsGetid(), columns=label)

#print df


def  fuzzymatch(search, df ,searchtag):
    #print "df[searchtag]", df[searchtag]
    searcher= process.extractOne(search, df[searchtag])
    #print searcher
    if len(searcher)>0:
        searchres= df[df[searchtag]==searcher[0]]["mlsname"]
        #return searchres[searchres.index[0]]
        return searchres
    
    
    
    
    
lis=[['12', 'maxebrdi'],
 ['100', 'mlslistings'],
 ['101', 'bareis'],
 ['102', 'metrolist'],
 ['104', 'fresno mls'],
 ['110', 'sfarmls'],
 ['202', 'crmls'],
 ['203', 'the mls'],
 ['204', 'claw'],
 ['205', 'i-tech'],
 ['206', 'desert area mls'],
 ['207', 'vcrds'],
 ['208', 'santa barbara aor'],
 ['210', 'sandicor'],
 ['211', 'high desert mls'],
 ['212', 'gemls'],
 ['213', 'tahoe sierra mls'],
 ['214', 'tulare mls'],
 ['300', 'mls pin'],
 ['301', 'ccimls'],
 ['310', 'bright mls'],
 ['311', 'rein'],
 ['312', 'cvrmls'],
 ['321', 'glvar'],
 ['322', 'nnrmls'],
 ['400', 'gepar'],
 ['401', 'sabor mls'],
 ['402', 'ntreis'],
 ['403', 'harmls'],
 ['404', 'actris'],
 ['405', 'ctxmls'],
 ['406', 'greater tyler aor'],
 ['407', 'longview mls'],
 ['408', 'bryan-college station regional mls'],
 ['409', 'greater mcallen aor'],
 ['410', 'kerrville board of realtors'],
 ['411', 'carolina mls'],
 ['412', 'triad mls'],
 ['413', 'triangle mls'],
 ['414', 'ncmmls'],
 ['415', 'wrar'],
 ['416', 'fayetteville mls'],
 ['421', 'georgia mls'],
 ['422', 'fmls'],
 ['427', 'raccfl mls'],
 ['428', 'rafgc mls'],
 ['429', 'bay county mls'],
 ['430', 'emerald coast mls'],
 ['431', 'mfrmls'],
 ['432', 'sefmls'],
 ['433', 'nefar mls'],
 ['434', 'space coast mls'],
 ['435', 'beaches mls'],
 ['436', 'gflr mls'],
 ['437', 'fkbor mls'],
 ['438', 'florida gulf coast mls'],
 ['439', 'mls of naples'],
 ['440', 'rairc mls'],
 ['441', 'trend'],
 ['442', 'west penn multi-list'],
 ['451', 'gsmlx'],
 ['452', 'monmouth/ocean mls'],
 ['453', 'sjsr mls'],
 ['454', 'new jersey mls'],
 ['455', 'cape may county mls'],
 ['461', 'mred'],
 ['471', 'armls'],
 ['472', 'tarmls'],
 ['481', 'hgmls'],
 ['482', 'mlsli'],
 ['483', 'mid-hudson mls'],
 ['484', 'rebny'],
 ['485', 'capital region mls'],
 ['486', 'wnyreis'],
 ['487', 'ulster county mls'],
 ['491', 'rmls'],
 ['501', 'nwmls'],
 ['502', 'yarmls'],
 ['511', 'wfrmls'],
 ['521', 'recolorado mls'],
 ['522', 'iresmls'],
 ['561', 'imls'],
 ['571', 'realtracs'],
 ['572', 'kaar mls'],
 ['573', 'maar mls'],
 ['574', 'tvrmls'],
 ['575', 'gcar mls'],
 ['611', 'heartland mls'],
 ['621', 'greater alabama mls'],
 ['622', 'valleymls'],
 ['651', 'northstar mls'],
 ['661', 'wirex'],
 ['662', 'scwmls'],
 ['663', 'metromls'],
 ['664', 'ranw mls'],
 ['691', 'maris'],
 ['692', 'somo mls'],
 ['701', 'newhomesource'],
 ['721', 'gsrein'],
 ['741', 'mlsok'],
 ['801', 'fmaar'],
 ['811', 'cclms'],
 ['812', 'charleston trident mls'],
 ['813', 'sptbgmls'],
 ['814', 'cmls'],
 ['821', 'state-wide mls'],
 ['831', 'normls/ neohrex'],
 ['832', 'wrist'],
 ['833', 'dabr mls'],
 ['834', 'cincymls'],
 ['835', 'ccor mls'],
 ['836', 'noris'],
 ['841', 'realcomp'],
 ['842', 'nglrmls'],
 ['843', 'michric'],
 ['844', 'ecar mla'],
 ['851', 'mibor mls'],
 ['852', 'irmls'],
 ['861', 'glar mls'],
 ['862', 'lbar mls'],
 ['871', 'hicentral'],
 ['872', 'ram'],
 ['881', 'ncwvrein'],
 ['890', 'neren'],
 ['900', 'gpr mls'],
 ['910', 'alaska mls'],
 ['920', 'car mls'],
 ['920', 'carmls'],
 ['921', 'nwabor'],
 ['930', 'connecticut mls'],
 ['940', 'dmaar'],
 ['950', 'mreis'],
 ['960', 'central mississippi mls'],
 ['961', 'mgc mls'],
 ['970', 'missoula mls'],
 ['980', 'black hills mls'],
 ['992', 'swmls'],
 ['993', 'wyoming mls'],
['811', 'ccar'] ,
['812', 'ctarmls'] ,
['430', 'ecaor'] ,
 ['421', 'gamls'],
 ['451', 'gsmls'],
 ['403', 'har'],
 ['522', 'ires'],
 ['961', 'mgcmls'],
 ['432', 'miamire'],
 ['100', 'mlslstngs'],
 ['300', 'mlspin'],
 ['452', 'momls'],
 ['310', 'mris_test'],
 ['921', 'nabor'],
['433', 'nefmls'],
 ['831', 'neohrex'],
['721', 'nomar'],
 ['900', 'oabr'],
 ['741', 'okcmls'],
 ['571', 'realtrac'],
 ['821', 'rimls'],
 ['651', 'rmls_mn'],
 ['110', 'sfmls'],
 ['453', 'sjsmls'],
 ['438', 'swfmls'],
 ['843', 'swmric'],
 ['574', 'tennvamls'],
 ['442', 'wpml'],
 ['621', 'bar'],
 ['835', 'cbrmls'],
 ['411', 'charlotte'],
 ['910', 'akmls'],
 ['310', 'mris']
]
 
 
label=["id","mlsname"]
 

lis=map(lambda r: [int(r[0]),r[1].replace(" mls" ,"")] ,lis)
#sprint lis 
[[12, 'maxebrdi'], [100, 'mlslistings'], [101, 'bareis'], [102, 'metrolist'], [104, 'fresno'], [110, 'sfarmls'], [202, 'crmls'], [203, 'the'], [204, 'claw'], [205, 'i-tech'], [206, 'desert area'], [207, 'vcrds'], [208, 'santa barbara aor'], [210, 'sandicor'], [211, 'high desert'], [212, 'gemls'], [213, 'tahoe sierra'], [214, 'tulare'], [300, 'mls pin'], [301, 'ccimls'], [310, 'bright'], [311, 'rein'], [312, 'cvrmls'], [321, 'glvar'], [322, 'nnrmls'], [400, 'gepar'], [401, 'sabor'], [402, 'ntreis'], [403, 'harmls'], [404, 'actris'], [405, 'ctxmls'], [406, 'greater tyler aor'], [407, 'longview'], [408, 'bryan-college station regional'], [409, 'greater mcallen aor'], [410, 'kerrville board of realtors'], [411, 'carolina'], [412, 'triad'], [413, 'triangle'], [414, 'ncmmls'], [415, 'wrar'], [416, 'fayetteville'], [421, 'georgia'], [422, 'fmls'], [427, 'raccfl'], [428, 'rafgc'], [429, 'bay county'], [430, 'emerald coast'], [431, 'mfrmls'], [432, 'sefmls'], [433, 'nefar'], [434, 'space coast'], [435, 'beaches'], [436, 'gflr'], [437, 'fkbor'], [438, 'florida gulf coast'], [439, 'mls of naples'], [440, 'rairc'], [441, 'trend'], [442, 'west penn multi-list'], [451, 'gsmlx'], [452, 'monmouth/ocean'], [453, 'sjsr'], [454, 'new jersey'], [455, 'cape may county'], [461, 'mred'], [471, 'armls'], [472, 'tarmls'], [481, 'hgmls'], [482, 'mlsli'], [483, 'mid-hudson'], [484, 'rebny'], [485, 'capital region'], [486, 'wnyreis'], [487, 'ulster county'], [491, 'rmls'], [501, 'nwmls'], [502, 'yarmls'], [511, 'wfrmls'], [521, 'recolorado'], [522, 'iresmls'], [561, 'imls'], [571, 'realtracs'], [572, 'kaar'], [573, 'maar'], [574, 'tvrmls'], [575, 'gcar'], [611, 'heartland'], [621, 'greater alabama'], [622, 'valleymls'], [651, 'northstar'], [661, 'wirex'], [662, 'scwmls'], [663, 'metromls'], [664, 'ranw'], [691, 'maris'], [692, 'somo'], [701, 'newhomesource'], [721, 'gsrein'], [741, 'mlsok'], [801, 'fmaar'], [811, 'cclms'], [812, 'charleston trident'], [813, 'sptbgmls'], [814, 'cmls'], [821, 'state-wide'], [831, 'normls/ neohrex'], [832, 'wrist'], [833, 'dabr'], [834, 'cincymls'], [835, 'ccor'], [836, 'noris'], [841, 'realcomp'], [842, 'nglrmls'], [843, 'michric'], [844, 'ecar mla'], [851, 'mibor'], [852, 'irmls'], [861, 'glar'], [862, 'lbar'], [871, 'hicentral'], [872, 'ram'], [881, 'ncwvrein'], [890, 'neren'], [900, 'gpr'], [910, 'alaska'], [920, 'car'], [921, 'nwabor'], [930, 'connecticut'], [940, 'dmaar'], [950, 'mreis'], [960, 'central mississippi'], [961, 'mgc'], [970, 'missoula'], [980, 'black hills'], [992, 'swmls'], [993, 'wyoming']]
 
df1 = pd.DataFrame(lis, columns=label)

#print df1


	
result = pd.merge(df,df1 , on ='mlsname' ,how='left')

#len(result[result["id"].notnull()])
print result[result["id"].isnull()]


#print result[result["id"].notnull()]

#print result
result.to_csv("/home/manoj/scripts/python_scripts/Pyspark_module/mlsname_mapping.txt", sep='\t', index=False)
#for index , row in result.iterrows():
#    print row
#    break


#for index , row in df1.iterrows():
#    namefuzzymatch=fuzzymatch(row['mlsname'], df ,'mlsname')
#    print namefuzzymatch
#    break
#             
