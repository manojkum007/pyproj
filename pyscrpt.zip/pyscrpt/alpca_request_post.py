# -*- coding: utf-8 -*-
"""
Created on Mon Feb  6 12:51:17 2017

@author: manoj
"""

import requests
import json


payload = "{\n    \"userId\": {\n        \"id\": \"39126507-21a9-5457-71b8-190a03660b2c\"\n    },\n    \"contact\": {\n        \"firstName\": \"Agent1\",\n        \"middleName\": \"Middle\",\n        \"lastName\": \"Test\",\n        \"phones\": {\n            \"displayPhone\": \"1234567890\",\n            \"homePhone\": \"9876543210\",\n            \"officePhone\": \"8765432187\",\n            \"cellPhone\": \"9807654654\"\n        },\n        \"email\": \"agetn1.test@test.com\",\n        \"altEmail\": \"agetn1alert.test@test.com\",\n        \"linkedInProfile\": \"www.linkedin.com/profile/view?id=2995170&trk=tab_pro\",\n        \"facebookProfile\": \"www.facebook.com/pages/San-Francisco-Bay-Area-Real-Estate-News/161447533871389\",\n        \"twitterProfile\": \"www.twitter.com/movoto\",\n        \"blog\": \"http://alpaca.san-mateo.movoto.net:3025/blog/\",\n        \"website\": \"www.movoto.com\",\n        \"homeAddress\": {\n            \"streetAddress\": \"100 South Brigade, M.G. Road\",\n            \"zipcode\": \"93611\"\n        }\n    },\n    \"agentType\": \"movoto\",\n    \"agentStatus\": \"A\",\n    \"profileDisplayPermissions\": {\n        \"showProfilePage\": true,\n        \"showInDPP\": false,\n        \"showDREName\": false,\n        \"showMailingAddress\": false\n    },\n    \"movotoAgentSince\": 2011,\n    \"agentSince\": 2000,\n    \"brokerage\": {\n        \"name\": \"Keller Williams\",\n        \"website\": \"www.linkedin.com/profile/view?id=2995170&trk=tab_pro\"\n    },\n    \"licenses\": [\n        {\n            \"licenseNumber\": \"01325811\",\n            \"state\": \"CA\",\n            \"validDate\": \"2018-02-12\",\n            \"score\": 0.5\n        }\n    ],\n    \"agentDetails\": {\n        \"gender\": \"F\",\n        \"agentBio\": \"With over 10 years as a San Francisco real estate agent, I love what I do. Real estate is a people business, one where it counts to have integrity, the ability to connect, and to create trust. \\r\\n\\r\\nI stand out through:\\r\\n\\r\\n1. Listening\\r\\n\\r\\n2. Communicating with my clients according to their needs.\\r\\n\\r\\n3. Providing efficient and streamlined services\\r\\n\\r\\n4. Negotiating to attain my clients' goals.\\r\\n\\r\\n5. Educating clients on how to grow their retirement monies\\r\\n     through real estate investing in Self-Directed IRAs.\\r\\n\\r\\nThe mainstay of my business lies in residential real estate - single family homes, condos, TICs, and 1-4 unit buildings with both buyers and sellers. The sales I work with are either regular real estate sales, probates, trust sales, short sales, or REOs, usually a mix of them.\\r\\n\\r\\nSpecialties: San Francisco and Bay Area real estate, residential real estate, REOs, short sales, probates, and investing in real estate through self-directed IRAs.\\r\\n\",\n        \"languages\": [\n            \"Spanish\",\n            \"Mandarin\"\n        ],\n        \"interests\": \"yoga, dance, art, nature, reading, Spanish\",\n        \"specialities\": [\n            \"Timeshares\",\n            \"Appraisals\"\n        ],\n        \"otherSpecialities\": \"•\\tAuctions\\r\\n•\\tFirst Time Buyers\\r\\n•\\tLuxury\\r\\n•\\tShort Sales\\r\\nExperience in Relocation Services\\r\\n\",\n        \"certifications\": [\n            \"CDAT\"\n        ],\n        \"questionnaire\": [\n            {\n                \"question\": \"How do you help buyers to find the right properties for them?\",\n                \"answer\": \"By helping them focus on what they want in a property and neighborhood. Then through education.\"\n            }\n        ]\n    },\n    \"partnerInfo\": {\n        \"isJointProfile\": true,\n        \"partnerFirstName\": \"Alicia\"\n    },\n    \"claimInfo\": {\n        \"isClaimed\": true,\n        \"claimedDateTime\": \"2016-08-12\"\n    },\n    \"coveredZipcodes\": {\n        \"93611\": {\n            \"promotingLocation\": false\n        }\n    }\n}"
url = "http://alpaca.san-mateo.movoto.net:3027/agentdirectory/agents"
headers = {
    'x-mdata-key': "CHUMAGATHUQ9VE7AYEBR",
    'content-type': "application/json",
    'cache-control': "no-cache",
    'postman-token': "556f9573-8bf8-fe9b-8744-a135cd9ca128"
    }
    
    
    
    
def insertjson(payload):
    response = requests.request("POST", url, data=payload, headers=headers)
    jsondata=json.loads(response.text)
print jsondata.get('_id')