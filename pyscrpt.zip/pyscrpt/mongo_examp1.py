# -*- coding: utf-8 -*-
"""
Created on Thu Dec 22 23:41:01 2016

@author: manoj
"""

def get_db():
    from pymongo import MongoClient
    client = MongoClient('localhost:27017')
    db = client.demo1
    return db

def add_country(db):
    db.countries.insert_many([{
      "title": 'MongoDB Overview', 
      "description": 'MongoDB is no sql database',
      "by": 'tutorials point'
   }])
    
def get_country(db):
    return db.countries.find_one()

if __name__ == "__main__":

    db = get_db() 
    add_country(db)
    print get_country(db)