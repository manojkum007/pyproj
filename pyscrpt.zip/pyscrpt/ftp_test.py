# -*- coding: utf-8 -*-
"""
Created on Wed Sep 27 14:14:13 2017

@author: manoj
"""

import pyodbc
import pandas as pd
import csv
import ftplib

msconn = pyodbc.connect(driver='{SQL Server}',
                        server='Puma',
						uid = 'sa',
						pwd = 'igen',
                        database='Movoto_Ops', 
                        trusted_msconnection='yes')                                                                                                                
cursor = msconn.cursor()

f = csv.writer(file('ops_tract.csv','wb'))

c = msconn.cursor()
c.execute("SELECT * FROM ops_tracking")

f.writerow([d[0] for d in c.description])


try:
	while True:
		row=[c.fetchone()]
		f.writerows(row)
	
except Exception as e:
	lis=map(lambda t: str(t) if (type(t)==str or type(t)==unicode) else t,row)
	print("some error  in row %s  havuing %s"%(row,e))
	f.writerows(lis)
	print("writen")


#pd.read_sql_table('ops_tracking', con=msconn).to_csv('C:\git temp\Prasanna\Knoah_ops_tracking\file.csv', index=False)

#session = ftplib.FTP('ftp.knoah.com','Movoto','Welcome@123')
#session.cwd('/Movoto Reports')
#print("connected")
#
##file = open('Knoah_ops_tracking.csv','rb')                  # file to send
##session.storbinary('STOR Knoah_ops_tracking.csv', file)     # send the file
##file.close()                                    # close file and FTP
#
#data = []
#
#session.dir(data.append)
#
#session.quit()

for line in data:
    print "-", line

#session.quit()
print ("Succes")