# -*- coding: utf-8 -*-
"""
Created on Tue Apr 17 14:56:22 2018

@author: manoj
"""

from flask import Flask
from flask import request

from flask import jsonify
from elasticsearch import Elasticsearch
app = Flask(__name__)
import json     
import requests
import re


import requests


@app.route("/")
def hello():
    return "Hello World!"


class FlaskException(Exception):
    """Base class for exceptions in this module."""
    pass

file_prop={}


def property_file_reader(pfile):
    global  file_prop
    f=open(pfile ,'r')
    obj=None
    for line in f:
        match_pattern="({0})\s?=\s?({1})".format("\S+" ,'\S+\s+.*')
        obj=re.match(match_pattern, line)
        if obj:
            file_prop[obj.group(1)] =obj.group(2).strip()
            
            
file_prop=file_prop.get("agent.properties")   

         
            
@app.route("/agent/<string:name>")
def helloagent(name):
    dd={
          "db": "Mysql_analytics05",
          "db_query": "\"select id,description,created_at,updated_at FROM rating where  $CONDITIONS\"",
          "db_daily_query": "\"select cast(id as char(36)) as id,cast(contact_type as varchar(50)) as contact_type,updated_at from contact_info where CAST(updated_at AS date) >= '$START_DATE' AND CAST(updated_at AS date) < '$END_DATE'  AND $CONDITIONS\"",
          "sqoop_output_dir": "/data/LM/Avro/school/rating",
          "avro_transform": True,
          "parquet_output_dir": "/data/LM/Avro/school/rating",
          "run_interval": "daily",
          "partitionedBy":"False",
          "temptable":"rating_temp",
          "parquet_casting":"select id,description,cast(created_at as timestamp),cast(updated_at as timestamp) from [database].[temptable]",
          "parquetable": "rating"
        }
    return jsonify(dd)



class ESConnect(object):
    def __init__(self, lat,lon ,price):
        self.latitude=lat
        self.longitude=lon
        self.price=price
        
    def elastic_connector(self):
        global file_prop
        url = "http://{0}:{1}/{2}/{3}/_search".format(file_prop.get("elastic.host"), 
int(file_prop.get("elastic.port")) ,file_prop.get("elastic.index") ,file_prop.get("elastic.doc_type") )
              
        headers = {
            'cache-control': 'no-cache',
            'content-type': 'application/json'            }


 
        bdy= {"query":{
                        "bool": {
                            "must": {
                          "query_string": {
                            "query": "minSales:<=%s AND maxSales:>=%s"%(self.price , self.price),
                            "analyze_wildcard": True
                          }
                            },
                            "filter": {
                                "geo_shape": {
                                    "boundary": {
                                        "shape": {
                                            "type": "point",
                                            "coordinates" :  [float(self.longitude) ,float(self.latitude)]
                                        },
                                        "relation": "intersects"
                                    }
                                }
                            }
                        }
                    },
                    "size":50,
                    "sort": [{ "medianSales": { "order": "desc" }},
                  { "totalTransaction": { "order": "desc" }}]
                }
        response = requests.request("GET", url,data=json.dumps(bdy), headers=headers)
        return json.loads(response.text)



def property_endpoint(propertyid)       :
    try:
        url = "http://{0}/{1}/primary-listing".format(file_prop.get("property_lat_long_endpoint") , propertyid)
        headers = {'x-mdata-key': "{0}".format(file_prop.get("webservice.access_key")) }
        payload="{}"
        response = requests.request("GET", url, data=payload, headers=headers)
        resultset=json.loads(response.text)
        latitude=resultset.get('address').get('latitude')
        longitude=resultset.get('address').get('longitude')
        price=resultset.get('listPrice')
        return (latitude, longitude, price)
    except Exception as e:
        raise  FlaskException("No property releated information found")
        
        


@app.route("/assignagent_v1")
def Primarylis_Endpoint():
    propertyid = request.args.get('propertyId')
    
    try:
        authentication_key=request.headers.getlist('X-Mdata-Key')
        if len(authentication_key) >0 :
            if authentication_key[0]!='{0}'.format(file_prop.get("webservice.access_key")):
                raise FlaskException("Authentication Error")
        else:
            raise FlaskException("Authentication Error")
            
    except FlaskException as e:
        return  e.message
    
    try :
        lat, lon, price=property_endpoint(propertyid)
    except FlaskException as e:
        return  e.message
        
    try:       
        
        esobj=ESConnect(lat, lon, price)
        fetched_data=esobj.elastic_connector()
        source_data=fetched_data.get('hits').get('hits')
        datadict={}
        for row in source_data:
            data=row['_source'].copy()
            data.pop('boundary')
            datadict[row['_source']['novaId']]=data
            #datadict.pop(row['_source']['novaId']['boundary'])
        
        if len(datadict)>0:
            return  jsonify(datadict)
        else:
            return "No Agent Data Found"
    except Exception as e:
        return jsonify(e)
        #print "error as ",e
    #print response
    #fetched_data={u'hits': {u'hits': [{u'sort': [271550.0, 121], u'_type': u'agent', u'_source': {u'mobilephone': u'559-978-2693', u'language': u'English', u'novaId': u'00cbbddc-839f-4881-aac8-e0189e231635', u'avgSales': 319599.5283018868, u'lastName': u'Ramirez', u'saleagentrole': 42, u'email': u'ryan@ryanramirez.net', u'totalTransaction': 121, u'firstName': u'Ryan', u'propertyType': [u'SINGLE_FAMILY_HOUSE', u'CONDO'], u'maxSales': 1750000.0, u'boundary': {u'type': u'polygon', u'coordinates': [[[-119.447851, 36.642335], [-119.846997, 36.716643], [-120.101489, 36.960521], [-119.987446, 37.043536], [-119.636578, 37.280053], [-119.516058, 37.284826], [-119.33123, 37.066693], [-119.447851, 36.642335]]]}, u'minSales': 42000.0, u'listagentrole': 88, u'medianSales': 271550.0}, u'_score': None, u'_index': u'brokerage2', u'_id': u'00cbbddc-839f-4881-aac8-e0189e231635'}], u'total': 1, u'max_score': None}, u'_shards': {u'successful': 5, u'failed': 0, u'skipped': 0, u'total': 5}, u'took': 4, u'timed_out': False}

#http://localhost:4001/my_route?page=54&filter=manojkumar



@app.route("/assignagent")
def my_route():
    lat = request.args.get('lat')
    lon = request.args.get('lon')
    property_type = request.args.get('propertykind')
    price = request.args.get('price')
    #return "test"
    #elastic_connector()
    try:
        esobj=ESConnect(lat,lon, property_type, price)
        fetched_data=esobj.elastic_connector()
        source_data=fetched_data.get('hits').get('hits')
        datadict={}
        for row in source_data:
            datadict[row['_source']['novaId']]=row['_source']
        
        if len(datadict)>0:
            return  jsonify(datadict)
        else:
            return "No Data Found"
#        f=open('log1.txt','w')
#        f.write(str(esobj.elastic_connector()))
#        f.close()
    except Exception as e:
        return jsonify(e)
        #print "error as ",e
    #print response
    #fetc
        
        

   



    
if __name__ == "__main__":
    app.run(host=file_prop.get("production.host"), port= int(file_prop.get("production.publicport"))
    #app.run(host='192.168.120.131', port=4040 ,debug=True)
    #app.run(host='127.0.0.1', port=4040)