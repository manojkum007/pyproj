import requests
import json

url = "http://192.168.120.17:9200/brokerage2/agent/_search"
bdy={'query': {'query_string': {'query': 'propertyType:CONDO  AND minSales:>120000   AND maxSales:<=1790000'}},
             'sort': [{'medianSales': {'order': 'desc'}},
              {'totalTransaction': {'order': 'desc'}}]}
              
headers = {
            'cache-control': 'no-cache',
            'content-type': 'application/json'            }
            
            
#headers={          'content-type': 'application/octet-stream',
#'content-disposition': 'attachment; filename="test.txt"'}

response = requests.request("GET", url,data=json.dumps(bdy), headers=headers)


datacontent=json.loads(response.text).get('hits').get('hits')


datadict={}

for row in datacontent:
    datadict[row['_source']['novaId']]=row['_source']

print datadict
    



