import requests
import json

class ESConnect(object):
    def __init__(self, lat,lon ,price):
        self.latitude=lat
        self.longitude=lon
        self.price=price
        
    def elastic_connector(self):
        url = "http://192.168.120.17:9200/brokerage2/agent/_search"
              
        headers = {
            'cache-control': 'no-cache',
            'content-type': 'application/json'            }


 
        bdy= {"query":{
                        "bool": {
                            "must": {
                          "query_string": {
                            "query": "minSales:<=%s AND maxSales:>=%s"%(self.price , self.price),
                            "analyze_wildcard": True
                          }
                            },
                            "filter": {
                                "geo_shape": {
                                    "boundary": {
                                        "shape": {
                                            "type": "point",
                                            "coordinates" :  [ float(self.longitude) ,float(self.latitude)]
                                        },
                                        "relation": "intersects"
                                    }
                                }
                            }
                        }
                    },
                     "size":50,
                    "sort": [{ "medianSales": { "order": "desc" }},
                  { "totalTransaction": { "order": "desc" }}]
                }
        response = requests.request("GET", url,data=json.dumps(bdy), headers=headers)
        return json.loads(response.text)


def property_endpoint(propertyid)       :
    try:
        url = "http://backend.service.v2.ng.movoto.net/property/properties/%s/primary-listing"%propertyid
        headers = {  'x-mdata-key': "CHUMAGATHUQ9VE7AYEBR" }
        payload="{}"
        response = requests.request("GET", url, data=payload, headers=headers)
        resultset=json.loads(response.text)
        latitude=resultset.get('address').get('latitude')
        print "l",latitude
        longitude=resultset.get('address').get('longitude')
        price=resultset.get('listPrice')
        return (latitude, longitude, price)
    except Exception as e:
        return  "No :"
        
        

#lat ,lon,price=property_endpoint("1d65c4a3-5e68-49ca-ba96-fdb24625bf73")     
print property_endpoint("1d65c4a3-5e68-49ca-ba96-fdb24625bf73")
#esobj=ESConnect(lat,lon,price)
#fetched_data=esobj.elastic_connector()
#print "result fetched",fetched_data
#print len(fetched_data['hits'].get('hits'))