# -*- coding: utf-8 -*-
"""
Created on Tue Apr 17 23:46:40 2018

@author: manoj
"""

from flask import Flask, request
app = Flask(__name__)

@app.route("/")
def homepage():
    val = request.args.get('hello')
    return """Whats up, {x}""".format(x=val)

if __name__ == '__main__':
    app.run(debug=True, use_reloader=True)