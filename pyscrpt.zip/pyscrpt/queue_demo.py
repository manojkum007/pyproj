# -*- coding: utf-8 -*-
"""
Created on Wed Aug 16 17:49:37 2017

@author: manoj

"""
#


from Queue import Queue
from threading import Thread
import time
import logging
import urllib2
logging.basicConfig(level=logging.DEBUG,
                    format='(%(threadName)-10s) %(message)s',
                  )


#import Queue

#q = Queue()
#
#for i in range(3):
#    q.put(i)
#    
#  
#while not q.empty():
#    logging.debug("getting queue value %s"%q.get())
#    
#
#
#

    
#    
#import Queue
#
#class Job(object):
#    def __init__(self, priority, description):
#        self.priority = priority
#        self.description = description
#        print 'New job:', description
#        return
#    def __cmp__(self, other):
#        return cmp(self.priority, other.priority)
#
#q = Queue.PriorityQueue()
#q.put((3, 'Mid-level job' ))
#q.put( (10, 'Low-level job') )
#q.put((1, 'Important job') )
#
##q.put( Job(3, 'Mid-level job') )
##q.put( Job(10, 'Low-level job') )
##q.put( Job(1, 'Important job') )
#
#while not q.empty():
#    next_job = q.get()
#    print 'Processing job:', next_job[1]
#    
    
    
    
    

 
#def do_stuff(q):
#    while True:
#        logging.debug("Reading value %s"%q.get())
#        global counter
#        counter-=1
#        logging.debug("queue size reduce to value %s"%counter)
#        time.sleep(3)
#        q.task_done()   




counter=0   

def downloader(q, filename):
    try:
        logging.debug("downloading %s"%filename)
        response = urllib2.urlopen(q.get())
        fh = open(filename, "w")
        fh.write(response.read())
        fh.close()
    except Exception as e:
        logging.debug("Unable to download file as %s"%e)
    finally:
        q.task_done() 
        logging.debug("downloaded %s"%filename)



q = Queue(maxsize=0)

urlist=['http://pymotw.com/2/urllib2/', 'http://www.kentsjohnson.com/', 'http://www.voidspace.org.uk/python/articles/urllib2.shtml', 'http://techmalt.com/', 'http://www.hacksparrow.com/', 'http://docs.python.org/2/howto/urllib2.html', 'http://www.stackoverflow.com', 'http://www.oreillynet.com/']
num_threads = len(urlist)

for x in range(len(urlist)):
    logging.debug("putting  item  %s"%urlist[x])
    q.put(urlist[x])
    counter+=1
    logging.debug("queue size increased %s"%counter)

#q.join()
  
  

for i in range(len(urlist)):
    worker = Thread(name='consumer %s'%i, target=downloader, args=(q, "crawlerurl%s.html"%i))
    worker.setDaemon(True)
    worker.start()

q.join()

logging.debug("finished")