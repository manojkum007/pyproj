# -*- coding: utf-8 -*-
"""
Created on Sun May 29 09:37:49 2016

@author: manoj
"""
import csv
import re 


path1 ="/home/manoj/treasure/treasure-hunter/Data_loading/Deeds/deeds_error/deedsError.csv"

nfile="/home/manoj/scripts/tiger_analyatics/diff_err.csv"

fw = open(nfile, 'w')
#try:
#    writer = csv.writer(f)
#    writer.writerow( ('Title 1', 'tle 2', 'Title 3') )
#    for i in range(10):
#        writer.writerow( (i+1, chr(ord('a') + i), '08/%02d/07' % (i+1)) )
#finally:
#    f.close()
#    
    
    
srchstr="^.*duplicate key value"

count=0
with open(path1 ,'rb') as csvfile:
    #reader=csv.reader(csvfile)
    reader=csvfile.readlines()
    for row in reader:
        count+=1
        try:
            searchObj = re.search(srchstr,row)
            #print row ,count           
            if (searchObj):
                fw.write(row+'\n')
                print row ,count           
        except Exception as e:
            pass
        
fw.close()