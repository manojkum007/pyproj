# -*- coding: utf-8 -*-
"""
Created on Sat Oct 22 02:15:03 2016

@author: manoj
"""

lis=['usa usr chi', 'usa usr jpn', 'usa usr ind', 'chi usr ind', 'ind usa usr']

country=dict()
                               
for j in lis:
    row=j.split(" ")
    for index in range(len(row)):
        if (country.get(row[index]))==None:
            country[row[index]]=[0,0,0]
            #print country
        if (country.get(row[index]))!=None:
            country[row[index]][index]=country[row[index]][index]+1
            
for k,v in country.iteritems():
    print k  ,v
    
    
    
    
    

