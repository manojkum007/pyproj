# -*- coding: utf-8 -*-
"""
Created on Sun Jun 10 17:06:42 2018

@author: manoj
"""

from lxml import etree
import traceback
import os 


class BaseGreatSchoolFeedConverter(object):
    def __init__(self, xmlpath, tag_handler_mapping, no_cleanup_tag=[]):#, batch_size, parallel_multiple):
        self.state_code = xmlpath[xmlpath.find('.xml')-2: xmlpath.find('.xml')]
        self.feed_name = os.path.basename(xmlpath)[0:-7]
        self.xmlpath = xmlpath
        self.tag_handler_mapping = tag_handler_mapping
        #self.batch_size = batch_size
        #self.parallel_multiple = parallel_multiple
        #self.pc = ParallelComputation(parallel_multiple=self.parallel_multiple, thread_parallel=True, loop_run_mode=True)
        #self.pc.register_worker(self.handle_xml())
        self.no_cleanup_tag = no_cleanup_tag

    def convert(self):
        elem_batch = []
        print "Start processing ",self.feed_name
        context = etree.iterparse(self.xmlpath, tag=self.tag_handler_mapping.keys())

        for event, elem in context:
            elem_batch.append(elem)
            if len(elem_batch) == 500:
                self.handle_elem_batch(elem_batch)
                elem_batch = []
        else:
            if len(elem_batch) > 0:
                self.handle_elem_batch(elem_batch)

        print "Finish processing ", self.feed_name
    def handle_elem_batch(self, elem_batch):
        #print "elem_batch",elem_batch
        elem_batch_dict = {}
        for elem in elem_batch:
            #print elem.tag
            if elem.tag not in elem_batch_dict:
                elem_batch_dict[elem.tag] = []
            elem_batch_dict[elem.tag].append(elem)

        for tag_name in elem_batch_dict.keys():
            print tag_name
            try:
                handler = getattr(self, self.tag_handler_mapping[tag_name])
                handler(elem_batch_dict[tag_name])
                print "handler" ,handler
            except Exception, e:
                print "some eror",e
                pass
                #print "error processing " , self.feed_name , " , tag:" , tag_name , " detail: %s", traceback.format_exc(), extra={'application': 'GreatSchoolDataImport', 'parameter':self.state_code}
                
            finally:
                print len(elem_batch),' records are processed'
                for elem in elem_batch_dict[tag_name]:
                    print elem.text.encode('utf-8')
                    if elem.tag not in self.no_cleanup_tag:
                         # It's safe to call clear() here because no descendants will be accessed
                        elem.clear()
                        # Also eliminate now-empty references from the root node to current elem
                        while elem.getprevious() is not None:
                            del elem.getparent()[0]
                            







tags={'district': 'handle_district',
 'school': 'handle_school',
 'state-feed': 'handle_state'}
 
 
xml_parser=BaseGreatSchoolFeedConverter('/home/manoj/postprpcessor/postprocessors/great_school/greatschool_files/local-greatschools-feed-WY.xml' ,tags)


xml_parser.convert()