# -*- coding: utf-8 -*-
"""
Created on Fri Dec 22 22:47:47 2017

@author: manoj
"""

ll=[1,2,5,8,9,12,5,8,45,89,56]

total=0
counter=0

def adder(ll,counter):
    global  total
    #print "counter , total ", counter, total
    if (counter<len(ll)):
        total+=ll[counter]
        counter+=1
        adder(ll ,counter)
    #print "ya wrong diversion"


#adder(ll ,counter)
#print "total sum" , total



lchange={25:0,20:0,10:0,5:0,1:0}
#lchange[25]=lchange[25]+1
#print lchange[25]

dvalue=47

dlist=[]
def change(ll):
    global dvalue
    for k,v in lchange.iteritems():
        while dvalue>=k:
            dvalue-=k
            lchange[k]=lchange[k]+1
            
        

change(ll)
for k,v in lchange.iteritems(): 
    if lchange[k]>0:
        print  k ," :", lchange[k]

