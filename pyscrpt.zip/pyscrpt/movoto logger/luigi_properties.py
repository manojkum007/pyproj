#Python libraries

#Internal librarires

#Third-party libraries

DRIVERS = {
  'sql_server': {
     'driver_class': 'com.microsoft.sqlserver.jdbc.SQLServerDriver',
     'jdbc_driver': 'sqlserver',
     'connection_string': 'jdbc:{0}://{1}:{2};databaseName={3}'
  },
  'postgres_sql':{
     'driver_class': 'com.amazon.redshift.jdbc41.Driver',
     'jdbc_driver': 'postgresql',
     'connection_string': 'jdbc:{0}://{1}:{2}/{3}'
  },
  'mysql':{
      'driver_class': 'com.mysql.jdbc.Driver',
      'jdbc_driver': 'mysql',
      'connection_string': 'jdbc:{0}://{1}:{2}/{3}'
  }
}

FILE_TYPES = {
  'avro' : '--as-avrodatafile',
  'parquet' : '--as-parquetfile'
}

DATABASES = {
    'DB_IGEN56_User': {
      'driver': 'sql_server',
      'host': 'production-55.svcolo.movoto.net',
      'name': 'igen56_User',
      'port': 1433,
      'username': 'Cheetah',
      'password': 'd3pY5aun'
    },
    'DB_IGEN56_User_NEW': {
      'driver': 'sql_server',
      'host': 'liger.san-mateo.movoto.net',
      'name': 'iGen56_User_NEW',
      'port': 1433,
      'username': 'sa',
      'password': 'igen'
    },
    'DB_IGEN56_Log' : {
      'driver': 'sql_server',
      'host': 'production-49.svcolo.movoto.net',
      'name': 'igen56_Log',
      'port': 1433,
      'username': 'Cheetah',
      'password': 'd3pY5aun'
    },
    'events': {
     'driver': 'postgres_sql',
     'host': 'movotonova.sql.segment.com',
     'name': 'events',
     'port': '5439',
     'username': 'admin',
     'password': 'a240e66d12c74372a59fe22ec646e3afA' 
    },
    'LOG_SMARTMOVOTO': {
     'driver': 'mysql',
     'host': 'production-73.svcolo.movoto.net',
     'name': 'LOG_SMARTMOVOTO',
     'port': '3306',
     'username': 'cheetah',
     'password': 'd3pY5aun' 
    },
    'SMARTMOVOTO': {
     'driver': 'mysql',
     'host': 'production-73.svcolo.movoto.net',
     'name': 'LOG_SMARTMOVOTO',
     'port': '3306',
     'username': 'cheetah',
     'password': 'd3pY5aun' 
    },
    'RELATEDHOMES': {
     'driver': 'mysql',
     'host': 'production-18.svcolo.movoto.net',
     'name': 'RELATEDHOMES',
     'port': '3306',
     'username': 'cheetah',
     'password': 'pGqcaxQD' 
    },

    'puma': {
     'driver': 'sql_server',
     'host': '192.168.120.139',
     'name': 'sf_raw',
     'port': '1433',
     'username': 'sa',
     'password': 'igen' 
    }
}
