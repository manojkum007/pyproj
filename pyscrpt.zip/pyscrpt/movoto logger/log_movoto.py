import luigi
import  movoto_logger 
logger = movoto_logger.get_logger('nova_pr.log')


logger.info('Running SqoopToParquet Luigi task...')
logger.critical('may be sendimg mail...')


class TaskA(luigi.Task):
    def requires(self):
        pass
    
    def run(self):
        logger.info('luigi tasl logging enabled')
        logger.critical('yes it issending mail')
    
    def output(self):
        pass
        