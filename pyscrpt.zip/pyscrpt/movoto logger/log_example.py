# -*- coding: utf-8 -*-
"""
Created on Wed Mar  9 14:42:02 2016

@author: manoj
"""

import logging
import logging.config
import configparser



config = configparser.ConfigParser()
config.read('logging.ini')
print config.sections()
def ConfigSectionMap(section):
    dict1 = {}
    options = config.options(section)
    for option in options:
        try:
            dict1[option] = config.get(section, option)
            if dict1[option] == -1:
                print("skip: %s" % option)
        except:
            print("exception on %s!" % option)
            dict1[option] = None
    return dict1
Name = ConfigSectionMap("handler_fileHandler")['args']
config.set('handler_fileHandler','args', "('logs/dynamic_rotatinglog1.csv','a',10,3)")
cfgfile = open("logging.ini",'w')
config.write(cfgfile)
cfgfile.close()
#logging.config.fileConfig("logs/rotatingfile.csv", {'log_path': log_path}, False) 
#config = ConfigParser()
# create logger

logging.config.fileConfig("logging.ini")
logger = logging.getLogger("simpleExample")

# "application" code
for i in range(5):
    logger.debug("debug message")
    logger.info("info message")
    logger.warn("warn message")
    logger.error("error message")
    logger.critical("critical message")
