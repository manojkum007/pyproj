# -*- coding: utf-8 -*-
"""
Created on Thu Jan 12 23:57:22 2017

@author: manoj
"""

import os, sys
from PIL import Image
import math
import glob

size = 225, 225
limit=[440,225,110]        
        
def resize(width,height):
    newsizelist=[]
    if width>height:
        for l in limit:
            if width>l:
                new_width=l
                new_height=(height/float(width))*l
                nsize=(new_width,math.ceil(new_height))
                newsizelist.append(nsize)
                #width=new_width
    elif height>=width:
        for l in limit:
            if height>l:
                new_height=l
                new_width=(width/float(height))*l
                nsize=(math.ceil(new_width),new_height)
                newsizelist.append(nsize)
                #height=new_height
        
    return newsizelist

#width=88
#height=134
#print resize(width,height)

#width=288
#height=360
#print resize(width,height)
#
#
#
#width=3456
#height=4556
#print resize(width,height)





from PIL import Image

import StringIO

def thumbnail_image():
    image = Image.open("image.png")
    image.thumbnail((300, 200))
    thumb_buffer = StringIO.StringIO()
    image.save(thumb_buffer, format=image.format)
    fp = open("thumbnail.png", "w")
    fp.write(thumb_buffer.getvalue())
    fp.close()





lisfile=[]
imagepath="/home/manoj/Pictures/image_testing/"
for name in glob.glob(imagepath+'*.png'):
    lisfile.append(name)
    
    
print lisfile

for infile in lisfile:
    try:
        im = Image.open(infile)
        #print im.size,im.getcolors()
        print im.size
        width,height=im.size
        final_image_size=resize(width,height)
        for imsize in final_image_size:
            outfile = os.path.splitext(infile)[0] + "{0}.thumbnail".format(imsize)
            im.thumbnail(imsize, Image.ANTIALIAS)
            im.save(outfile, "JPEG")
            print "image created "
    except IOError:
        print "cannot create thumbnail for '%s'" % infile


            