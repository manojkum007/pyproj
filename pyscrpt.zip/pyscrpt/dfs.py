# -*- coding: utf-8 -*-
"""
Created on Mon Jan  9 23:24:34 2017

@author: manoj
"""
import re

#matobj=re.match(r"(.*)/(\d+)-",i)
#matobj=re.match(r"(.*)-(\d+_\d+)",i)
graph = {'A': set(['B', 'C']),
         'B': set(['A', 'D', 'E']),
         'C': set(['A', 'F']),
         'D': set(['B']),
         'E': set(['B', 'F']),
         'F': set(['C', 'E'])}
         

for k,v in graph.iteritems():
    print v
#    if i in v:
#        print k,i
        
        
#ids_list = range(100)
#sids_set = set(ids_list)      
#
#for i in sids_set:
#    print i
#
#def f(x):
#    for i in x:
#         pass