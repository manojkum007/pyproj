# -*- coding: utf-8 -*-
"""
Created on Wed Jan 11 19:07:10 2017

@author: manoj
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Oct 25 12:31:57 2016

@author: manoj
"""

import collections
import json
import pymssql
import itertools
import datetime
import math
import os
import time
import logging
import logging.handlers
import subprocess
import re
from shutil import copyfile
from  sys import platform
from decimal import *

if platform!='linux2':
    import shlex



row_header=[]
rowlength=86
page =10000000
page =100
counter=0
timediff=19800000

#conn = pymssql.connect('172.24.0.80', 'sa', 'igen', 'AgentDirectory') 

conn = pymssql.connect('192.168.120.139', 'sa', 'igen', 'AgentDirectory') 


minoid,maxoid=0,1132052
minoid,maxoid=0,100

distinctqry="select min(CityId), max(CityId) from AgentDirectory.dbo.Final_CityAgentStaticstics;"
#curslsor = conn.cursor() 
##prinor.executel(distinctqry)
#for r in cursor:
#    minoid,maxoid=r[0],r[1]

print "distinct count completed ", minoid ,maxoid
logger = logging.getLogger()
logger.setLevel(logging.INFO)



#mongohostname='172.24.0.17'
#mongoport=27017
#database='agentdirectory'
#username="agentdirectory"
#password='agent4movoto'
#collectioname='cityAgentStatistics'


mongohostname='localhost'
mongoport=27017
database='temp'
username=""
password=''
collectioname='urldictionary'
mongopath="mongoimport"

#mongopath="./mongodb-linux-x86_64-ubuntu1404-3.4.1/bin/mongoimport"



LOG_PATH = 'logs/'
og_dir="urldictionaryreport"
og_errdir="urldictionaryreport_err"
if not os.path.exists(og_dir):
    os.makedirs(og_dir)

if not os.path.exists(og_errdir):
    os.makedirs(og_errdir)

if not os.path.exists('logs'):
    os.makedirs('logs')
    
    
    
fh = logging.handlers.RotatingFileHandler(os.path.join(LOG_PATH, "cityloading.log"), maxBytes=1024 * 1024 * 50)
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
fh.setFormatter(formatter)
logger.addHandler(fh)

coldict={   'UserName': 0 ,
'MaxCount': 1 ,
'LastUpdateTime': 2 
            
             }

                          
 

def assigndict(cur,lis,val,single):
    if len(val)>0:
        if len(lis)==1:
            if (single==0):
                cur[lis[0]]=val[0]
            else:
                cur[lis[0]]=val
            return
        else:
            if not cur.has_key(lis[0]):
                cur[lis[0]]=collections.OrderedDict()
            assigndict(cur[lis[0]],lis[1:],val,single)


		
def start_fetching():
    agentkeycount=0
    for oid in range(minoid,maxoid,page):
        cursor = conn.cursor()   
        mongodblis=[]
        mongoagentid=[]
        query="""select * from (Select UserName, MaxCount, ROW_NUMBER() OVER (ORDER BY LastUpdateTime asc) as [RowNo] from AgentDirectory.dbo.URLDictionary) t where RowNo between %s AND %s;"""%(oid,oid+page)  
                   
        logger.info("Fetching table rows having row count between  %s and %s"%(oid,oid+page))
        #print "query",query
        cursor.execute(query)
        for row in cursor:
            rowlength=len(row)
            d=collections.OrderedDict()
            row=(row[coldict['UserName']], row[coldict['MaxCount']], row[coldict['LastUpdateTime']])
            lis=[]        
            for i in range(len(row)):
                lis.append(map(lambda t : int(time.mktime(t.utctimetuple()))*1000+timediff if (type(t)==datetime.datetime) else float(t) if isinstance(t,Decimal) else t,[row[i]])[0])
            row=tuple(lis)
            print row            
            assigndict(d,["userName"], [row[coldict['UserName']]], 0)
            assigndict(d,["maxCount"], [row[coldict['MaxCount']]], 0)
            
            mongodblis.append(d)
            if len([row[2]])>0:
                mongoagentid.append(row[2])
        logger.info( "finished preparing json with %s"%agentkeycount)
        fileprefix="urldictionary"
        mongoload(mongodblis, mongoagentid, fileprefix)
        






    
def mongoload(mongodblis, mongoid, fileprefix):
    global og_dir
    global mongohostname
    global mongoport
    global username
    global password
    global database
    global collectioname
    global logger
    global platform
    global mongopath
    global counter
    for docindex in range(len(mongodblis)):
        mongodb=[mongodblis[docindex]]
        path='./%s/%s_%sdec_%s.json'%(og_dir, fileprefix, mongoid[docindex],counter)
        jsonob=open(path,'w')
        json.dump(mongodb,jsonob, indent=4)
        jsonob.close() 
        if platform!='win32':
            fpath=mongopath+" -h "+mongohostname+" --port "+str(mongoport)+"  -u '"+username+"' -p '"+password+"' -d "+database+" -c "+collectioname +"  --type json '"+path+"' --jsonArray" 
            #print "fpath" ,fpath
            p = subprocess.Popen([fpath], stdout=subprocess.PIPE, stderr=subprocess.PIPE,shell=True)
            out, err = p.communicate()
            flag=1
            mongomess=err.split("\n")
            for i in mongomess:
                matchObj=re.match( r'(.*)error inserting documents', i)
                if  matchObj:      
                    flag=-1
                matchObj1=re.match( r'(.*)imported 1 document', i)
                if  matchObj1:      
                    flag=0                   
            if (flag==0):
                print "sucess"
                logger.info("loading successfull %s"%mongomess)
            else:
                print "error"
                logger.info("loading Failed %s"%mongomess)
                try:
                    copyfile(path, './%s/%s_%s_%s.json'%(og_errdir, fileprefix, mongoid[docindex], counter))
                except Exception as e:
                    logger.info("error in copying %s"%path)
        else:
            try:
                fpath=mongopath+" -h "+mongohostname+" --port "+str(mongoport)+"  -u '"+username+"' -p '"+password+"' -d "+database+" -c "+collectioname +"  --type json '"+path+"' --jsonArray"                 
                cmdList=shlex.split(fpath) 
                #print "fpath" ,fpath
                result = subprocess.check_output(cmdList, stderr=subprocess.STDOUT, shell=True)
                flag=1
                err=result
                print result
                logger.info("output %s"%result)
                mongomess=err.split("\n")
                for i in mongomess:
                    matchObj=re.match( r'(.*)error inserting documents', i)
                    if  matchObj:      
                        flag=-1
                    matchObj1=re.match( r'(.*)imported 1 document', i)
                    if  matchObj1:      
                        flag=0              
                if (flag==0):
                        logger.info("loading successfull %s"%mongomess)
                else:
                    print "error"
                    logger.info("loading Failed %s"%mongomess)
                    try:
                        copyfile(path, './%s/%s_%s_%s.json'%(og_errdir, fileprefix, mongoid[docindex], counter))
                    except Exception as e:
                        logger.info("error in copying %s"%path)
            except subprocess.CalledProcessError, ex: 
                logger.info("--------error------")
                logger.info("ex.cmd%s"%ex.cmd)
                logger.info("ex.message%s"%ex.message)
                logger.info("ex.returncode%s"%ex.returncode)
                logger.info("ex.output%s"%ex.output) 
        counter=counter+1
        
        
        
        
        
    
start_fetching()            
                   
        
        


        
     
	
	

