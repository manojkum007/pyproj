# -*- coding: utf-8 -*-
"""
Created on Tue May 16 23:23:28 2017

@author: manoj
"""

#from multiprocessing import Pool
#
#def f(x):
#    return x*x
#
#if __name__ == '__main__':
#    p = Pool(5)
#    print(p.map(f, [1, 2, 3]))

#
#
#from multiprocessing import Process
#
#def f(name):
#    print 'hello', name
#
#if __name__ == '__main__':
#    p = Process(target=f, args=('bob',))
#    p.start()
#    p.join()



#from multiprocessing import Process
#import os
#
#def info(title):
#    print title
#    print 'module name:', __name__
#    if hasattr(os, 'getppid'):  # only available on Unix
#        print 'parent process:', os.getppid()
#    print 'process id:', os.getpid()
#
#def f(name):
#    info('function f')
#    print 'hello', name
#
#if __name__ == '__main__':
#    info('main line')
#    p = Process(target=f, args=('bob',))
#    p.start()
#    p.join()



import multiprocessing

def worker():
    """worker function"""
    print 'Worker'
    return

if __name__ == '__main__':
    jobs = []
    for i in range(5):
        p = multiprocessing.Process(target=worker)
        jobs.append(p)
        p.start()