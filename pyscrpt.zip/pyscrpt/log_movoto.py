
import  movoto_logger 
logger = movoto_logger.get_logger('nova_pr.log')


logger.info('Running SqoopToParquet Luigi task...')
logger.critical('may be sendimg mail...')
