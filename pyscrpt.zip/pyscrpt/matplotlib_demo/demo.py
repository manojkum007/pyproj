# -*- coding: utf-8 -*-
"""
Created on Thu Mar 15 11:01:02 2018

@author: manoj
"""

import matplotlib.pyplot as plt
import numpy as np

t = np.arange(0.0, 2.0, 0.2)
print "x" ,t
s = 1 + np.sin(2*np.pi*t)
print "y" ,s

plt.plot(t, s)

plt.xlabel('time (s)')
plt.ylabel('voltage (mV)')
plt.title('About as simple as it gets, folks')
plt.grid(True)
plt.savefig("test.png")
plt.show()