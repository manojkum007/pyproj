# -*- coding: utf-8 -*-
"""
Created on Fri Jul 14 22:44:10 2017

@author: manoj
"""
class Base:
    pass

class Derived1(Base):
    pass

class Derived2(Derived1):
    pass



class Base1(object):
    pass

class Base2(object):
    pass

class MultiDerived(Base1, Base2):
    pass


#print MultiDerived.__mro__


class Point:
    def __init__(self, x = 0, y = 0):
        self.x = x
        self.y = y
        
    def __add__(self,p):
        self.x+=p.x
        self.y+=p.y
        return Point(self.x, self.y)
        
        
        
    def __str__(self):
        
        return "{0} {1} ".format(self.x , self.y)        
        
        
#p=Point(4,5)
#p1=Point(14,55)
#print p.x     
#
#print p.y


#print p+p1


#
#l=[45,7,1,2,32,45]
#
#b=iter(l)
#
#try:
#    while True:
#        print b.next()
#except StopIteration as e:
#    print "loop finished"
#


#
#for i in  b:
#    print i 

#
#
#fp = open('/home/manoj/scripts/results.log')
#while 1:
#    line = fp.readline()
#    if not line:
#        break
#    print line
#    
#
#class fobj :
#    def __init__(self):
#        f=open('/home/manoj/scripts/results.log','r')
#      

#Mine Failed attempt
#class Powtwo:
#    def __init__(self,n):
#        self.Num=n
#        self.Numlist=[i for i in range(self.Num)]
#        self.incr=0
#    
#    def __iter__(self):
#        self.incr = 0
#        return self
#        
#    def __next__(self):
#        try:
#            while True:
#                b=self.Numlist[self.incr]
#                self.incr+=1
#                return b
#        except Exception as e:
#            print "stop interation error"
#    

class Powtwo:
    def __init__(self , n):
        self.num=n
       
        
    def __iter__(self):
        self.incr=0
        return self
    
    def __next__(self):  
        if self.incr<self.num:
            b=2**self.incr
            self.incr+=1
            return b
        else:
            raise StopIteration
        
        
class PowTwo:
    """Class to implement an iterator
    of powers of two"""

    def __init__(self, max = 0):
        self.max = max

    def __iter__(self):
        self.n = 0
        return self

    def next(self):
        if self.n <= self.max:
            result = 2 ** self.n
            self.n += 1
            return result
        else:
            raise StopIteration
            
            


#def cube(x):
#    for i in range(x):
#        print "start sqr "
#        yield i**2
#        print "start cube "
#        yield i**3
#        print "end yield "
#        
#        
#d=cube(5)
#for i in d:
#    print i
#
#
#



#def my_gen():
#    n = 1
#    print('This is printed first')
#    # Generator function contains yield statements
#    yield n
#
#    n += 1
#    print('This is printed second')
#    yield n
#
#    n += 1
#    print('This is printed at last')
#    yield n
#    
#d= my_gen()
#
#print d.next()
#print d.next()
#print d.next()
#print d.next()


#import csv
#
#with open('/home/manoj/logs/latlog.csv','r') as ff:
#    reader = csv.reader(ff)
#    next(reader)
#    print "Total logintude sold = ",sum(float(x[1]) for x in reader)
            
#    pizza_col = (line[1] for line in ff)
#    per_hour = (int(x) for x in pizza_col if x != 'N/A')
#    print sum(per_hour)
#    for line in ff.readlines():
#        print line[1]

#class infInc:
#    def __init__(self,start):
#        self.start=start
#        self.numstart=start
#    
#    def __iter__(self):
#        self.numstart=self.start
#        return self
#    
#    def next(self):
#        self.numstart+=1
#        return self.numstart
#        
#            
#
#
#c=infInc(6)
#
#d=iter(c)
#for i in range(20): 
#    print d.next()
#    
#a = PowTwo(4)
##i=iter(a)
##print i.next()
##
##print i.next()
##print i.next()
##print i.next()
##print i.next()
##print i.next()
#
#for j in iter(a):
#    print j

        
        
        
####closure#######
        
def divisibe_by_3_5(x):
    
    def divisbleby_3():
        if x%3==0:
            return True
        else:
            return False
            
    def divisbleby_5():
        if x%5==0:
            return True
        else:
            return False
    
    if divisbleby_3() and divisbleby_5():
        return True
    else:
        return False

#print divisibe_by_3_5(107)
            
            
def make_pretty(func):
    def inner():
        print("I got decorated")
        func()
    return inner

@make_pretty
def ordinary():
    print("I am ordinary")
    
    
#ordinary=make_pretty(ordinary)

#ordinary()

def floatdivison(func):
    def inner(a,b):
        return func(float(a), float(b))
    
    return inner

def smartdivide(func):
    def inner(a,b):
        if b==0:
            raise ZeroDivisionError
        print "a =",a ,"b=",b
        return func(a,b)
    return inner

@floatdivison    
@smartdivide
def divide(x,y):
    return x/y
    
print divide(4,10)


