# -*- coding: utf-8 -*-
"""
Created on Mon Feb 22 16:24:21 2016

@author: manoj
"""
command_dict ={}
command_dict["agents"]="""
			BEGIN;
			DROP TABLE IF EXISTS mls_updates.updated_agents_tmp;
                SELECT 
                ua.mlsid, 
                ua.agent_id, 
                COALESCE(ua.status_code,a.status_code) AS status_code,
                COALESCE(ua.first_name,a.first_name) AS first_name,
                COALESCE(ua.last_name,a.last_name) AS last_name,
                COALESCE(ua.office_id,a.office_id) AS office_id,
                COALESCE(ua.email_address,a.email_address) AS email_address,
                COALESCE(ua.phones,a.phones) AS phones,
                COALESCE(ua.full_name,a.full_name) AS full_name,
                COALESCE(ua.clean_fname,a.clean_fname) AS clean_fname,
                COALESCE(ua.clean_lname,a.clean_lname) AS clean_lname,
                COALESCE(ua.clean_full_name,a.clean_full_name) AS clean_full_name,
                COALESCE(ua.clean_phones ,a.clean_phones) AS clean_phones,
                a.created_tstmp, -- use original timestamp
                COALESCE(ua.updated_tstmp,now()) AS updated_tstmp, --make updated tstmp now if not given during update
                a.external_id, -- use original external_id
                ROW_NUMBER() OVER(PARTITION BY ua.mlsid, ua.agent_id ORDER BY a.status_code) AS dedup_seq -- order by status_code so "a" is first, some agents have an "a" and one or more "i" entries
                INTO mls_updates.updated_agents_tmp
                FROM  mls_updates.agents ua
                INNER JOIN mls_all.agents a
                ON ua.mlsid = a.mlsid AND ua.agent_id = a.agent_id
                AND ua.mlsid IS NOT NULL and ua.agent_id IS NOT NULL
                ;

			CREATE INDEX updated_agents_mlsid_tmp ON mls_updates.updated_agents_tmp (mlsid);
                CREATE INDEX updated_agents_agentid_tmp ON mls_updates.updated_agents_tmp (agent_id);	
                INSERT INTO mls_all.agents_hist
                
                SELECT
                DISTINCT -- to prevent duplicate propagation 
                a.mlsid, 
                a.agent_id, 
                a.status_code, 
                a.first_name, 
                a.last_name, 
                a.office_id, 
                a.email_address, 
                a.phones, 
                a.full_name, 
                a.clean_fname, 
                a.clean_lname, 
                a.clean_full_name, 
                NULL::char varying[], 
                a.clean_phones, 
                a.created_tstmp, 
                a.updated_tstmp, 
                a.external_id,
                NOW() AS replaced_tstmp 
                FROM mls_all.agents a
                INNER JOIN mls_updates.updated_agents_tmp ua
                ON a.mlsid = ua.mlsid
                AND a.agent_id = ua.agent_id
                ;
                
                
                DELETE FROM mls_all.agents a 
                WHERE a.mlsid || '-' || a.agent_id IN (SELECT mlsid || '-' || agent_id  FROM mls_updates.updated_agents_tmp);
                
                DELETE FROM mls_updates.agents a
                WHERE a.mlsid || '-' || a.agent_id IN ( SELECT ua.mlsid || '-' || ua.agent_id FROM mls_updates.updated_agents_tmp ua )
                AND (a.mlsid || '-' || a.agent_id) IS NOT NULL;
                
                DO
                    LANGUAGE 'plpgsql'
                    $do$
                    DECLARE
                    _date varchar(30) := ( SELECT DATE_PART('year', NOW())::text || '_' || RIGHT('0'|| DATE_PART('month',NOW())::text,2) || '_' ||  RIGHT('0'|| DATE_PART('day',NOW())::text,2));
                    _table varchar(100) := 'agent_updates_' || _date;
                    BEGIN
                        EXECUTE(FORMAT('DROP TABLE IF EXISTS mls_updates.%s',_table));
                        EXECUTE(FORMAT(
                            'CREATE TABLE mls_updates.%s AS 
                                SELECT
                                mlsid, 
                                agent_id, 
                                status_code, 
                                first_name, 
                                last_name, 
                                office_id, 
                                email_address, 
                                phones, 
                                full_name, 
                                clean_fname, 
                                clean_lname, 
                                clean_full_name, 
                                NULL::char varying[], 
                                clean_phones, 
                                COALESCE(created_tstmp,NOW()) AS created_tstmp, 
                        		COALESCE(updated_tstmp, NOW()) AS updated_tstmp, 
                        		external_id
                                FROM mls_updates.agents a',_table)); 
 

                	EXECUTE(FORMAT(
                            'INSERT INTO mls_all.agents 
                                SELECT 
                                mlsid, 
                                agent_id, 
                                status_code, 
                                first_name, 
                                last_name, 
                                office_id, 
                                email_address, 
                                phones, 
                                full_name, 
                                clean_fname, 
                                clean_lname, 
                                clean_full_name, 
                                NULL::char varying[], 
                                clean_phones, 
                                created_tstmp, 
                                updated_tstmp,
                                external_id
                                FROM mls_updates.%s', _table));

                        	INSERT INTO mls_all.agents
                                SELECT
                                mlsid, 
                                agent_id, 
                                status_code, 
                                first_name, 
                                last_name, 
                                office_id, 
                                email_address, 
                                phones, 
                                full_name, 
                                clean_fname, 
                                clean_lname, 
                                clean_full_name, 
                                NULL::char varying[],  
                                clean_phones, 
                                created_tstmp, 
                                updated_tstmp,
                                external_id
                                FROM mls_updates.updated_agents_tmp
                                WHERE dedup_seq = 1;  
                                
                    EXECUTE(FORMAT(
                        'INSERT INTO mls_updates.%s
                            SELECT mlsid, 
                            agent_id, 
                            status_code, 
                            first_name, 
                            last_name, 
                            office_id, 
                            email_address, 
                            phones, 
                            full_name, 
                            clean_fname, 
                            clean_lname, 
                            clean_full_name, 
                            NULL::char varying[], 
                            clean_phones, 
                            created_tstmp, 
                            updated_tstmp,
                            external_id
                            FROM mls_updates.updated_agents_tmp
                            WHERE dedup_seq = 1',_table));

                END
            $do$
            ;
            
            DROP TABLE IF EXISTS mls_updates.updated_agents_tmp;
            DROP TABLE IF EXISTS mls_updates.agents;
            
            REINDEX TABLE mls_all.agents;
            
            COMMIT;
            --VACUUM ANALYZE mls_all.agents;
        """
        
        
command_dict["listings"]="""
			BEGIN;
			DROP TABLE IF EXISTS mls_updates.updated_listings_tmp;
                SELECT
                    lu.mls, 
                    lu.mls_id, 
                    COALESCE(lu.address, l.address) AS address,
                    COALESCE(lu.address_unit, l.address_unit ) AS address_unit,
                    COALESCE(lu.city, l.city) AS city,
                    COALESCE(lu.state_code, l.state_code) AS state_code,
                    COALESCE(lu.zip, l.zip) AS zip,
                    COALESCE(lu.org_price, l.org_price) AS org_price,
                    COALESCE(lu.list_price, l.list_price) AS list_price,
                    COALESCE(lu.sale_price, l.sale_price) AS sale_price,
                    COALESCE(lu.date_sale, l.date_sale) AS date_sale,
                    COALESCE(lu.list_agent_id, l.list_agent_id) AS list_agent_id,
                    COALESCE(lu.list_office_id, l.list_office_id) AS list_office_id,
                    COALESCE(lu.co_list_agent_id, l.co_list_agent_id) AS co_list_agent_id,
                    COALESCE(lu.co_list_office_id, l.co_list_office_id) AS co_list_office_id,
                    COALESCE(lu.sell_agent_id, l.sell_agent_id) AS sell_agent_id,
                    COALESCE(lu.sell_office_id, l.sell_office_id) AS sell_office_id,
                    COALESCE(lu.co_sell_agent_id, l.co_sell_agent_id) AS co_sell_agent_id,
                    COALESCE(lu.co_sell_office_id, l.co_sell_office_id) AS co_sell_office_id,
                    COALESCE(lu.status_code, l.status_code) AS status_code,
                    COALESCE(lu.class_description, l.class_description) AS class_description,
                    COALESCE(lu.type_description, l.type_description) AS type_description,
                    COALESCE(lu.new_construction, l.new_construction) AS new_construction,
                    COALESCE(lu.tax_id, l.tax_id) AS tax_id,
                    COALESCE(lu.sale_comp_percent, l.sale_comp_percent) AS sale_comp_percent,
                    COALESCE(lu.square_ft, l.square_ft) AS square_ft, 
                    COALESCE(lu.subdivision, l.subdivision) AS subdivision, 
                    COALESCE(lu.reo, l.reo) AS reo, 
                    COALESCE(lu.foreclosure, l.foreclosure) AS foreclosure, 
                    COALESCE(lu.short_sale, l.short_sale) AS short_sale, 
                    COALESCE(lu.full_baths, l.full_baths) AS full_baths, 
                    COALESCE(lu.partial_baths, l.partial_baths) AS partial_baths, 
                    COALESCE(lu.bedrooms, l.bedrooms) AS bedrooms, 
                    COALESCE(lu.street_num, l.street_num) AS street_num, 
                    COALESCE(lu.street_predir, l.street_predir) AS street_predir, 
                    COALESCE(lu.street_premod, l.street_premod) AS street_premod,
                    COALESCE(lu.street_pretype, l.street_pretype) AS street_pretype,
                    COALESCE(lu.street_name, l.street_name) AS street_name,
                    COALESCE(lu.full_street_name, l.full_street_name) AS full_street_name,
                    COALESCE(lu.street_suffix, l.street_suffix) AS street_suffix,
                    COALESCE(lu.street_suffix_normalized, l.street_suffix_normalized) AS street_suffix_normalized,
                    COALESCE(lu.street_postdir, l.street_postdir) AS street_postdir,
                    COALESCE(lu.unit_type, l.unit_type) AS unit_type,
                    COALESCE(lu.unit_number, l.unit_number) AS unit_number,
                    COALESCE(lu.state_full, l.state_full) AS state_full,
                    COALESCE(lu.full_address, l.full_address) AS full_address,
                    l.listing_id, -- use original listing_id
                    COALESCE(lu.remove_flag, l.remove_flag) AS remove_flag,
                    l.transaction_id,
                    l.property_id,
                    l.created_tstmp, -- use original timestamp
                    COALESCE(lu.updated_tstmp, NOW()) AS updated_tstmp -- use updated timestamp or current time
                    INTO mls_updates.updated_listings_tmp
                    FROM mls_updates.listings lu
                    INNER JOIN mls_all.listings l
                    ON lu.mls = l.mls AND lu.mls_id = l.mls_id
                    ;


			CREATE INDEX updated_listings_mls_tmp ON mls_updates.updated_listings_tmp (mls);
                CREATE INDEX updated_listings_mls_id_tmp ON mls_updates.updated_listings_tmp (mls_id);
                
                
                
                INSERT INTO mls_all.listings_hist
                    SELECT
                        l.mls,
                        l.mls_id,
                        l.address,
                        l.address_unit,
                        l.city,
                        l.state_code,
                        l.zip,
                        l.org_price,
                        l.list_price,
                        l.sale_price,
                        l.date_sale,
                        l.list_agent_id,
                        l.list_office_id,
                        l.co_list_agent_id,
                        l.co_list_office_id,
                        l.sell_agent_id,
                        l.sell_office_id,
                        l.co_sell_agent_id,
                        l.co_sell_office_id,
                        l.status_code,
                        l.class_description,
                        l.type_description,
                        l.new_construction,
                        l.tax_id,
                        l.sale_comp_percent,
                        l.square_ft,
                        l.subdivision,
                        l.reo,
                        l.foreclosure,
                        l.short_sale,
                        l.full_baths,
                        l.partial_baths,
                        l.bedrooms,
                        l.street_num,
                        l.street_predir,
                        l.street_premod,
                        l.street_pretype,
                        l.street_name,
                        l.full_street_name,
                        l.street_suffix, 
                        l.street_suffix_normalized,
                        l.street_postdir,
                        l.unit_type,
                        l.unit_number,
                        l.state_full, 
                        l.full_address,
                        l.listing_id,
                        l.remove_flag,
                        l.transaction_id,
                        l.property_id,
                        l.created_tstmp,
                        l.updated_tstmp,
                        NOW() AS replaced_tstmp -- add tstamp to indicate when the entry was replaced
                        FROM mls_all.listings l
                        INNER JOIN mls_updates.updated_listings_tmp lu
                        ON l.mls = lu.mls
                        AND l.mls_id = lu.mls_id
                        ;

                
                
                DELETE FROM mls_all.listings l WHERE l.listing_id IN ( SELECT listing_id FROM mls_updates.updated_listings_tmp )
                AND l.listing_id IS NOT NULL ;
                
               DELETE FROM mls_updates.listings l
               WHERE l.mls || '-' || l.mls_id IN ( SELECT lt.mls || '-' || lt.mls_id FROM mls_updates.updated_listings_tmp lt)
               AND (l.mls || '-' || l.mls_id) IS NOT NULL;
               
               DROP TABLE IF EXISTS mls_updates.listing_indexes_tmp;
               
               SELECT * 
                   INTO mls_updates.listing_indexes_tmp
                   FROM pg_indexes 
                   WHERE schemaname = 'mls_all' AND tablename = 'listings';

                
                 
                DO
                    LANGUAGE 'plpgsql'
                    $do$
                    DECLARE
                    _indexes text[] := (SELECT array_agg(indexname) FROM mls_updates.listing_indexes_tmp);
                    _index text;
                    _indexdef text;

                 BEGIN
                    IF _indexes is not null THEN  
                        FOREACH _index IN ARRAY _indexes
                        LOOP 
                        EXECUTE(FORMAT('DROP INDEX IF EXISTS mls_all.%s', _index)); 
                        END LOOP; 
                    END IF;
                 END
                     $do$
                     ;
                
                DO
                    LANGUAGE 'plpgsql'
                    $do$
                    DECLARE
                    _max_listing_id integer := (SELECT MAX(listing_id) FROM mls_all.listings);
                    _date varchar(30) := ( SELECT DATE_PART('year', NOW())::text || '_' || RIGHT('0'|| DATE_PART('month',NOW())::text,2) || '_' ||  RIGHT('0'|| DATE_PART('day',NOW())::text,2)); 
                    _table varchar(100) := 'listing_updates_' || _date;
                    BEGIN
                    EXECUTE(FORMAT('DROP TABLE IF EXISTS mls_updates.%s',_table));
                    EXECUTE(FORMAT(
                        'CREATE TABLE mls_updates.%s AS 
                            SELECT 
                            mls, 
                            mls_id, 
                            address, 
                            address_unit, 
                            city, 
                            state_code, 
                            zip, 
                            org_price, 
                            list_price, 
                            sale_price, 
                            date_sale, 
                            list_agent_id, 
                            list_office_id, 
                            co_list_agent_id, 
                            co_list_office_id, 
                            sell_agent_id, 
                            sell_office_id, 
                            co_sell_agent_id, 
                            co_sell_office_id, 
                            status_code, 
                            class_description, 
                            type_description, 
                            new_construction, 
                            tax_id, 
                            sale_comp_percent, 
                            square_ft, 
                            subdivision, 
                            reo, 
                            foreclosure, 
                            short_sale, 
                            full_baths, 
                            partial_baths, 
                            bedrooms, 
                            street_num, 
                            street_predir, 
                            street_premod, 
                            street_pretype, 
                            street_name, 
                            full_street_name, 
                            street_suffix, 
                            street_suffix_normalized, 
                            street_postdir, 
                            unit_type, 
                            unit_number, 
                            state_full, 
                            full_address, 
                            COALESCE(listing_id,ROW_NUMBER() OVER(ORDER BY mls, mls_id) + %s) AS listing_id, 
                            remove_flag, 
                            transaction_id, 
                            NULL::int, 
                            COALESCE(created_tstmp, NOW()) AS created_tstmp, 
                            COALESCE(updated_tstmp, NOW()) AS updated_tstmp
                            FROM mls_updates.listings l',_table, _max_listing_id)); 


                EXECUTE(FORMAT(
                    'INSERT INTO mls_all.listings 
                        SELECT 
                            mls, 
                            mls_id, 
                            address, 
                            address_unit, 
                            city, 
                            state_code, 
                            zip, 
                            org_price, 
                            list_price, 
                            sale_price, 
                            date_sale, 
                            list_agent_id, 
                            list_office_id, 
                            co_list_agent_id, 
                            co_list_office_id, 
                            sell_agent_id, 
                            sell_office_id, 
                            co_sell_agent_id, 
                            co_sell_office_id, 
                            status_code, 
                            class_description, 
                            type_description, 
                            new_construction, 
                            tax_id, 
                            sale_comp_percent, 
                            square_ft, 
                            subdivision, 
                            reo, 
                            foreclosure, 
                            short_sale, 
                            full_baths, 
                            partial_baths, 
                            bedrooms, 
                            street_num, 
                            street_predir, 
                            street_premod, 
                            street_pretype, 
                            street_name, 
                            full_street_name, 
                            street_suffix, 
                            street_suffix_normalized, 
                            street_postdir, 
                            unit_type, 
                            unit_number, 
                            state_full, 
                            full_address, 
                            listing_id, 
                            remove_flag, 
                            transaction_id, 
                            NULL::int, 
                            COALESCE(created_tstmp, NOW()) AS created_tstmp, 
                            COALESCE(updated_tstmp, NOW()) AS updated_tstmp
                            FROM mls_updates.%s', _table)); 

                	INSERT INTO mls_all.listings
                         SELECT
                             *
                             FROM mls_updates.updated_listings_tmp;

            	EXECUTE(FORMAT(
                     'INSERT INTO mls_updates.%s
                         SELECT * FROM mls_updates.updated_listings_tmp',_table));

                        END
            $do$
            ;
           
           
            DROP TABLE IF EXISTS mls_updates.updated_listings_tmp;
            DROP TABLE IF EXISTS mls_updates.listings;
            
            DO
                LANGUAGE 'plpgsql'
                $do$
                DECLARE
                    _indexdefs text[] := (SELECT array_agg(indexdef) FROM mls_updates.listing_indexes_tmp);
                    _indexdef text;

                     BEGIN
                     IF _indexdefs is not null THEN  
                     FOREACH _indexdef IN ARRAY _indexdefs 
                     LOOP 
                     EXECUTE(FORMAT( '%s', _indexdef));
                     END LOOP;
                     End if;
                END
         $do$
           ;
            
            COMMIT;
           --- VACUUM ANALYZE mls_all.agents;
        """
        
        
command_dict["offices"]="""BEGIN;
			DROP TABLE IF EXISTS mls_updates.updated_offices_tmp;
                  SELECT 
				uo.mlsid, 
				uo.broker_id, 
				uo.office_id, 
				COALESCE(uo.status_code, o.status_code) AS status_code, 
				COALESCE(uo.office_name, o.office_name) AS office_name, 
				COALESCE(uo.address1, o.address1) AS address1, 
				COALESCE(uo.address2, o.address2) AS address2, 
				COALESCE(uo.city, o.city) AS city, 
				COALESCE(uo.zipcode, o.zipcode) AS zipcode, 
				COALESCE(uo.state_code, o.state_code) AS state_code, 
				COALESCE(uo.broker, o.broker) AS broker, 
				COALESCE(uo.email_address, o.email_address) AS email_address, 
				COALESCE(uo.office_phone, o.office_phone) AS office_phone, 
				COALESCE(uo.office_fax, o.office_fax) AS office_fax, 
				COALESCE(uo.street_number, o.street_number) AS street_number, 
				COALESCE(uo.street_name_predir, o.street_name_predir) AS street_name_predir, 
				COALESCE(uo.street_name_premod, o.street_name_premod) AS street_name_premod, 
				COALESCE(uo.street_name_pretype, o.street_name_pretype) AS street_name_pretype, 
				COALESCE(uo.street_name,  o.street_name) AS street_name, 
				COALESCE(uo.full_street_name, o.full_street_name) AS full_street_name, 
				COALESCE(uo.street_name_posttype, o.street_name_posttype) AS street_name_posttype, 
				COALESCE(uo.street_name_posttype_normalized, o.street_name_posttype_normalized) AS street_name_posttype_normalized, 
				COALESCE(uo.street_name_postdir, o.street_name_postdir) AS street_name_postdir, 
				COALESCE(uo.street_name_occupancytype, o.street_name_occupancytype) AS street_name_occupancytype, 
				COALESCE(uo.street_name_identifier, o.street_name_identifier) AS street_name_identifier, 
				COALESCE(uo.full_state, o.full_state) AS full_state, 
				COALESCE(uo.long_form_address, o.long_form_address) AS long_form_address, 
				COALESCE(uo.street_number_2, o.street_number_2) AS street_number_2, 
				COALESCE(uo.street_name_predir_2, o.street_name_predir_2) AS street_name_predir_2, 
				COALESCE(uo.street_name_premod_2, o.street_name_premod_2) AS street_name_premod_2, 
				COALESCE(uo.street_name_pretype_2, o.street_name_pretype_2) AS street_name_pretype_2, 
				COALESCE(uo.street_name_2, o.street_name_2) AS street_name_2, 
				COALESCE(uo.full_street_name_2, o.full_street_name_2) AS full_street_name_2, 
				COALESCE(uo.street_name_posttype_2, o.street_name_posttype_2) AS street_name_posttype_2, 
				COALESCE(uo.street_name_posttype_normalized_2, o.street_name_posttype_normalized_2) AS street_name_posttype_normalized_2, 
				COALESCE(uo.street_name_postdir_2, o.street_name_postdir_2) AS street_name_postdir_2, 
				COALESCE(uo.street_name_occupancytype_2, o.street_name_occupancytype_2) AS street_name_occupancytype_2, 
				COALESCE(uo.street_name_identifier_2, o.street_name_identifier_2) AS street_name_identifier_2, 
				COALESCE(uo.full_state_2, o.full_state_2) AS full_state_2, 
				COALESCE(uo.long_form_address_2, o.long_form_address_2) AS long_form_address_2, 
				COALESCE(uo.office_key, o.office_key) AS office_key, 
				o.created_tstmp,
				COALESCE(uo.updated_tstmp, NOW()) AS updated_tstmp,
				ROW_NUMBER() OVER(PARTITION BY uo.mlsid, uo.broker_id, uo.office_id ORDER BY o.status_code) AS dedup_seq -- user status_code so "a" entries are first 
				INTO mls_updates.updated_offices_tmp
				FROM mls_updates.offices uo
				INNER JOIN  mls_all.offices o
				ON uo.mlsid = o.mlsid
				AND uo.broker_id = o.broker_id 
				AND uo.office_id = o.office_id
				AND uo.mlsid IS NOT NULL
				AND uo.broker_id IS NOT NULL
				AND uo.office_id IS NOT NULL
				;

				CREATE INDEX updated_offices_mlsid_tmp ON mls_updates.updated_offices_tmp (mlsid);
				CREATE INDEX updated_offices_brokerid_tmp ON mls_updates.updated_offices_tmp (broker_id);
				CREATE INDEX updated_offices_office_tmp ON mls_updates.updated_offices_tmp (office_id);
				
			INSERT INTO mls_all.offices_hist
                    SELECT
                        o.mlsid, 
                        o.broker_id, 
                        o.office_id, 
                        o.status_code, 
                        o.office_name, 
                        o.address1, 
                        o.address2, 
                        o.city,
                        o.zipcode,
                        o.state_code,
                        o.broker, 
                        o.email_address, 
                        o.office_phone, 
                        o.office_fax, 
                        o.street_number, 
                        o.street_name_predir, 
                        o.street_name_premod, 
                        o.street_name_pretype, 
                        o.street_name, 
                        o.full_street_name, 
                        o.street_name_posttype, 
                        o.street_name_posttype_normalized, 
                        o.street_name_postdir, 
                        o.street_name_occupancytype, 
                        o.street_name_identifier, 
                        o.full_state, 
                        o.long_form_address, 
                        o.street_number_2, 
                        o.street_name_predir_2, 
                        o.street_name_premod_2, 
                        o.street_name_pretype_2, 
                        o.street_name_2, 
                        o.full_street_name_2, 
                        o.street_name_posttype_2, 
                        o.street_name_posttype_normalized_2, 
                        o.street_name_postdir_2, 
                        o.street_name_occupancytype_2, 
                        o.street_name_identifier_2,
                        o.full_state_2, 
                        o.long_form_address_2, 
                        o.office_key,
                        o.created_tstmp,
                        o.updated_tstmp,
                        NOW() AS replaced_tstmp -- add tstamp to indicate when the entry was replaced
                        FROM mls_all.offices o
                        INNER JOIN mls_updates.updated_offices_tmp uo
                        ON uo.mlsid = o.mlsid
                        AND uo.broker_id = o.broker_id 
                        AND uo.office_id = o.office_id
                        WHERE uo.dedup_seq = 1 -- stops duplicate propagation
                    ;
            
            
             DELETE FROM mls_all.offices o 
			WHERE o.mlsid || '-' || o.broker_id || '-' || o.office_id IN (
			SELECT 
			uot.mlsid || '-' || uot.broker_id || '-' || uot.office_id 
			FROM mls_updates.updated_offices_tmp uot
			);
			
			DELETE FROM mls_updates.offices o
			WHERE o.mlsid || '-' || o.broker_id || '-' || o.office_id IN (
			SELECT uot.mlsid || '-' || uot.broker_id || '-' || uot.office_id 
			FROM mls_updates.updated_offices_tmp uot
			);
			
			
			 DO
            LANGUAGE 'plpgsql'
            $do$
            DECLARE
            _date varchar(30) := ( SELECT DATE_PART('year', NOW())::text || '_' || RIGHT('0'|| DATE_PART('month',NOW())::text,2) || '_' ||  RIGHT('0'|| DATE_PART('day',NOW())::text,2));
            _table varchar(100) := 'office_updates_' || _date;
            BEGIN
                EXECUTE(FORMAT('DROP TABLE IF EXISTS mls_updates.%s',_table));
                EXECUTE(FORMAT(
                    'CREATE TABLE mls_updates.%s AS 
                     SELECT
                     mlsid,
                     broker_id,
                     office_id,
                     status_code,
                     office_name,
                     address1,
                     address2,
                     city,
                     zipcode,
                     state_code,
                     broker,
                     email_address,
                     office_phone,
                     office_fax,
                     street_number,
                     street_name_predir,
                     street_name_premod,
                     street_name_pretype,
                     street_name,
                     full_street_name,
                     street_name_posttype,
                     street_name_posttype_normalized,
                     street_name_postdir,
                     street_name_occupancytype,
                     street_name_identifier,
                     full_state,
                     long_form_address,
                     street_number_2,
                     street_name_predir_2,
                     street_name_premod_2,
                     street_name_pretype_2,
                     street_name_2,
                     full_street_name_2,
                     street_name_posttype_2,
                     street_name_posttype_normalized_2,
                     street_name_postdir_2,
                     street_name_occupancytype_2,
                     street_name_identifier_2,
                     full_state_2,
                     long_form_address_2,
                     office_key,
                     COALESCE(created_tstmp, NOW()) AS created_tstmp,
            		COALESCE(updated_tstmp, NOW()) AS updated_tstmp
                      FROM mls_updates.offices o',_table)); 
 
             EXECUTE(FORMAT(
                 'INSERT INTO mls_all.offices 
                     SELECT
                     mlsid,
                     broker_id,
                     office_id,
                     status_code,
                     office_name,
                     address1,
                     address2,
                     city,
                     zipcode,
                     state_code,
                     broker,
                     email_address,
                     office_phone,
                     office_fax,
                     street_number,
                     street_name_predir,
                     street_name_premod,
                     street_name_pretype,
                     street_name,
                     full_street_name,
                     street_name_posttype,
                     street_name_posttype_normalized,
                     street_name_postdir,
                     street_name_occupancytype,
                     street_name_identifier,
                     full_state,
                     long_form_address,
                     street_number_2,
                     street_name_predir_2,
                     street_name_premod_2,
                     street_name_pretype_2,
                     street_name_2,
                     full_street_name_2,
                     street_name_posttype_2,
                     street_name_posttype_normalized_2,
                     street_name_postdir_2,
                     street_name_occupancytype_2,
                     street_name_identifier_2,
                     full_state_2,
                     long_form_address_2,
                     office_key,
                     created_tstmp,
                     updated_tstmp
                     FROM mls_updates.%s', _table));

            	INSERT INTO mls_all.offices
                 SELECT
                     mlsid,
                     broker_id,
                     office_id,
                     status_code,
                     office_name,
                     address1,
                     address2,
                     city,
                     zipcode,
                     state_code,
                     broker,
                     email_address,
                     office_phone,
                     office_fax,
                     street_number,
                     street_name_predir,
                     street_name_premod,
                     street_name_pretype,
                     street_name,
                     full_street_name,
                     street_name_posttype,
                     street_name_posttype_normalized,
                     street_name_postdir,
                     street_name_occupancytype,
                     street_name_identifier,
                     full_state,
                     long_form_address,
                     street_number_2,
                     street_name_predir_2,
                     street_name_premod_2,
                     street_name_pretype_2,
                     street_name_2,
                     full_street_name_2,
                     street_name_posttype_2,
                     street_name_posttype_normalized_2,
                     street_name_postdir_2,
                     street_name_occupancytype_2,
                     street_name_identifier_2,
                     full_state_2,
                     long_form_address_2,
                     office_key,
                     created_tstmp,
                     updated_tstmp
                     FROM mls_updates.updated_offices_tmp
                     WHERE dedup_seq = 1;  -- only put in one record incase of duplicates in the mls_all.offices table or mls_all.update table
            
            EXECUTE(FORMAT(
                'INSERT INTO mls_updates.%s
                    SELECT
                    mlsid,
                    broker_id,
                    office_id,
                    status_code,
                    office_name,
                    address1,
                    address2,
                    city,
                    zipcode,
                    state_code,
                    broker,
                    email_address,
                    office_phone,
                    office_fax,
                    street_number,
                    street_name_predir,
                    street_name_premod,
                    street_name_pretype,
                    street_name,
                    full_street_name,
                    street_name_posttype,
                    street_name_posttype_normalized,
                    street_name_postdir,
                    street_name_occupancytype,
                    street_name_identifier,
                    full_state,
                    long_form_address,
                    street_number_2,
                    street_name_predir_2,
                    street_name_premod_2,
                    street_name_pretype_2,
                    street_name_2,
                    full_street_name_2,
                    street_name_posttype_2,
                    street_name_posttype_normalized_2,
                    street_name_postdir_2,
                    street_name_occupancytype_2,
                    street_name_identifier_2,
                    full_state_2,
                    long_form_address_2,
                    office_key,
                    created_tstmp,
                    updated_tstmp
                    FROM mls_updates.updated_offices_tmp
                    WHERE dedup_seq = 1',_table));

				END
			$do$;
			
				DROP TABLE IF EXISTS mls_updates.updated_offices_tmp;
                DROP TABLE IF EXISTS mls_updates.offices;
               
                 REINDEX TABLE mls_all.offices; 
                 COMMIT;
                 --VACUUM ANALYZE mls_all.offices;
            
        """
print command_dict["offices"] 