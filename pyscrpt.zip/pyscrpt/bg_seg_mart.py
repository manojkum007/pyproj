# -*- coding: utf-8 -*-
"""
Created on Mon Aug 29 15:39:09 2016
@author: manoj
"""

import luigi
from luigi.contrib import sqla
from luigi.contrib.hdfs.hadoopcli_clients import HdfsClient
from luigi.contrib.hdfs.target import HdfsTarget
import  movoto_logger 
from luigi.hive import HiveTableTarget, run_hive_cmd
import  movoto_logger

sqlquery="""
                                drop table user_mart.segmentmobilepages;
                                
                                Create table user_mart.segmentmobilepages  as
                                
                                select * from segment_nova_mobile.pages where  to_date(from_UTC_timestamp(sent_at,'')) = '%s';
                                
                                 
                                
                                drop table user_mart.mob_session_hit_normalized2;
                                
                                create table user_mart.mob_session_hit_normalized2 as
                                
                                select * from temp.mob_session_hit_normalized1 where To_DATE(from_unixtime(cast(visitstarttime as bigint))) = '%s';
                                
                                 
                                
                                INSERT INTO user_mart.fact_userbehaviour_new
                                
                                select NULL,
                                
                                bq.fullvisitorid,
                                
                                cd_gaid,
                                
                                visitid,
                                
                                visitnumber,
                                
                                visitstarttime,
                                
                                hits_isentrance,
                                
                                hits_isexit,
                                
                                substring(metro,LENGTH(metro)-2,LENGTH(metro)),
                                
                                substring(metro,1,LENGTH(metro)-3),
                                
                                page,
                                
                                hits_page_searchkeyword + hits_page_searchcategory AS page_search_context,
                                
                                hits_page_pagetitle,
                                
                                NULL as hits_contentinfo, --pages_mlsdb_info
                                
                                NULL as image_page, --seg.page_type
                                
                                bq.userid,
                                
                                NULL as user_name,
                                
                                --case when b.name is not null then 'Registered user' when a.anon_id = b.anonymous_id then 'Returned user' else 'new user' end as
                                
                                NULL user_status,
                                
                                seg.property_id_real as property_id,
                                
                                seg.property_id as listing_id,
                                
                                NULL as poi_id,
                                
                                referralpath AS referral_source_name,
                                
                                seg.referrer_category referrer_category, -- seg
                                
                                campaign,
                                
                                medium,
                                
                                source,
                                
                                NULL as pageid,
                                
                                CASE WHEN hits_page_pagetitle = 'Search Result' then 'T' else 'F' END searc,
                                
                                hits_page_searchkeyword + hits_page_searchcategory as search_criteria,
                                
                                hits_page_pagepath,
                                
                                hits_page_pagetitle,
                                
                                cd_experimentid,--index12
                                
                                hits_eventinfo_eventvalue,
                                
                                cd_hotlead as lead_code,
                                
                                cd_zipcode,
                                
                                seg.num_photos as num_of_photos,
                                
                                to_utc_timestamp(from_unixtime(INT(visitstarttime)+nvl(INT(substring(hits_time,1,LENGTH(hits_time)-3)),0)),"PST") as sent_at_date_time,
                                
                                To_DATE(from_unixtime(INT(visitstarttime))) as sent_at_date,
                                
                                SUBSTR(cast(to_utc_timestamp(from_unixtime(INT(visitstarttime)+nvl(INT(substring(hits_time,1,LENGTH(hits_time)-3)),0)),"PST") as string),12,8) as sent_at_time,
                                
                                weekofyear(from_unixtime(INT(visitstarttime))),
                                
                                from_unixtime(INT(visitstarttime),'u'),
                                
                                hour(from_unixtime(INT(visitstarttime))),
                                
                                CASE WHEN hour(from_unixtime(INT(visitstarttime))) BETWEEN 8 and 17 THEN 'True' ELSE 'False' END,
                                
                                devicecategory,
                                
                                operatingsystem,
                                
                                concat(operatingsystem,operatingsystemversion),
                                
                                concat(browser,' ',browserversion),
                                
                                seg.search_criteria_search_type ,
                                
                                seg.search_criteria_location_lat,
                                
                                seg.search_criteria_min_lat,
                                
                                seg.search_criteria_max_lat,
                                
                                seg.search_criteria_location_lng,
                                
                                seg.search_criteria_min_lng,
                                
                                seg.search_criteria_max_lng,
                                
                                seg.search_criteria_sort_column,
                                
                                seg.search_criteria_sort_column,
                                
                                seg.search_criteria_max_price,
                                
                                seg.search_criteria_min_price,
                                
                                seg.search_criteria_min_bed,
                                
                                seg.search_criteria_min_bath,
                                
                                seg.search_criteria_garage,
                                
                                NULL as p_criteria_single,
                                
                                NULL as p_criteria_condo,
                                
                                seg.search_criteria_has_photo,
                                
                                seg.search_criteria_has_pool,
                                
                                seg.search_criteria_is_fixer_upper,
                                
                                seg.search_criteria_max_sqft,
                                
                                seg.search_criteria_min_sqft,
                                
                                seg.search_criteria_max_dom,
                                
                                seg.search_criteria_min_dom,
                                
                                seg.search_criteria_max_lot,
                                
                                seg.search_criteria_min_lot,
                                
                                seg.search_criteria_max_year,
                                
                                seg.search_criteria_min_year,
                                
                                seg.search_criteria_max_hoa,
                                
                                NULL as p_criteria_is_pending,
                                
                                NULL as p_criteria_is_foreclosure,
                                
                                seg.search_criteria_is_new_listings_only,
                                
                                seg.search_criteria_is_open_houses_only,
                                
                                seg.search_criteria_is_reduced_price,
                                
                                NULL as p_criteria_is_sold,
                                
                                NULL as s_criteria_is_public,
                                
                                NULL as s_criteria_is_private,
                                
                                NULL as s_criteria_is_charter,
                                
                                NULL as article_category,
                                
                                NULL as result_type,
                                
                                NULL as m_criteria_down_payment,
                                
                                NULL as m_criteria_home_price,
                                
                                NULL as m_criteria_loan_type,
                                
                                NULL as m_criteria_zipcode,
                                
                                seg.search_criteria_property_types,
                                
                                NULL as page_params,
                                
                                NULL as ref_platform,
                                
                                case when hits_eventinfo_eventaction = 'Lead_Initiated'
                                
                                                     or hits_eventinfo_eventaction = 'lead_received'
                                
                                                     OR hits_eventinfo_eventaction = 'Lead_Submitted'
                                
                                                     OR hits_eventinfo_eventaction = 'Lead_Confirmation' THEN 1 ELSE 0 END as lead_provided,
                                
                                hits_exceptioninfo_description,
                                
                                NULL as listing_price,
                                
                                cd_status as listing_status,
                                
                                cd_dom as days_on_movoto
                                
                                from  user_mart.mob_session_hit_normalized2 BQ
                                
                                JOIN user_mart.segmentmobilepages Seg 
                                
                                ON  BQ.cd_gaid = seg.gaid
                                
                                AND to_utc_timestamp(from_unixtime(INT(visitstarttime)+nvl(INT(substring(hits_time,1,LENGTH(hits_time)-3)),0)),"PST") = from_UTC_timestamp(sent_at,'')
"""

logger = movoto_logger.get_logger('BigQueryToHive1.log')


class GetUserMartData(luigi.Task):
    date_range = luigi.DateIntervalParameter()

    def requires(self):
        pass
    
    def run(self):
        for d in self.date_range.dates():
            query=sqlquery%(d,d)
            logger.info( "running sql query for %s"%d)
            run_hive_cmd(query)
            logger.info( "completed run for %s"%d)
        
        with self.output().open('w') as f:
            f.write('{word}\n'.format(word='UserMartData'))
            
    def output(self):
        luigi.file.LocalTarget(path='logs/UserMartData.txt')
    


