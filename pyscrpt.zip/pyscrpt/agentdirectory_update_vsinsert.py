# -*- coding: utf-8 -*-
"""
Created on Tue Mar 28 16:28:49 2017

@author: manoj
"""


import pymssql
import pymongo

novalis=[]

with pymssql.connect('192.168.120.139',  'sa' , 'igen','AgentDirectory_Prod') as conn:
    with conn.cursor() as cursor:
        cursor.execute("select distinct NovaId from AgentDirectory_prod.dbo.AgentsCollection")
        for row in cursor:
            novalis.append(str(row[0]))
            


print len(novalis)
        
MONGODB_URI ="mongodb://%s:%s@%s:%s/%s"%('agentdirectory', 'agent4movoto', '172.24.0.17', '27017', 'agentdirectory')



client = pymongo.MongoClient(MONGODB_URI)
    
db=client.agentdirectory
agent = db['agents']

for novaid in novalis:
    cnt = agent.find({'userId.id': novaid}).count()
    if cnt==1:
        print "found"
    else:
        print "not found",novaid
        
        break