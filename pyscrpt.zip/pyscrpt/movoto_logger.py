#python libraries
import logging.handlers
import logging
import os
import traceback
import sys
import csv

#third-party libraries


#internal libraries
import settings



LOG_PATH = 'logs/'

ERRORS_PATH = 'errors/'

def get_logger (filename):
    try:
        logger = logging.getLogger()
        logger.setLevel(logging.INFO)
        fh = logging.handlers.RotatingFileHandler(os.path.join(LOG_PATH, filename), maxBytes=1024 * 1024 * 50)
        fh.setLevel(logging.INFO)
        # create console handler with a higher log level
        ch = logging.StreamHandler()
        ch.setLevel(logging.INFO)
        # create SMTP  handler
        sh = logging.handlers.SMTPHandler(settings.HOST, settings.FROM_ADDRESS, settings.TO_ADDRESS, settings.SUBJECT, credentials=None, secure=None)
        sh.setLevel(logging.CRITICAL)
        # create formatter and add it to the handlers
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        fh.setFormatter(formatter)
        ch.setFormatter(formatter)
        sh.setFormatter(formatter)
        # add the handlers to the logger
        logger.addHandler(fh)
        logger.addHandler(ch)
        logger.addHandler(sh)
        return logger
    except Exception:
        print traceback.format_exc()
        sys.exit(1)


def row_to_csv(filename, row):
    
    with open(os.path.join(ERRORS_PATH, filename), 'w') as fp:
        csv_file = csv.writer(fp, delimiter='\t')

        csv_file.writerows(row)
        
        
        