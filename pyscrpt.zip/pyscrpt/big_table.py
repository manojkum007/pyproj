# -*- coding: utf-8 -*-
"""
Created on Sun Aug  7 10:09:07 201
@author: manoj
"""
import ast
import itertools
from collections import defaultdict

data="""[]
[{"index":10,"value":"Closed"},{"index":2,"value":"CA"},{"index":11,"value":"false"},{"index":4,"value":"210"},{"index":8,"value":"60948364.1453493596"},{"index":9,"value":"485 days"},{"index":1,"value":"San Diego"},{"index":3,"value":"92129"}]
[{"index":10,"value":"Closed"},{"index":2,"value":"CA"},{"index":11,"value":"false"},{"index":4,"value":"210"},{"index":8,"value":"60948364.1453493596"},{"index":9,"value":"485 days"},{"index":1,"value":"San Diego"},{"index":3,"value":"92129"}]
[{"index":10,"value":"Closed"},{"index":2,"value":"CA"},{"index":11,"value":"false"},{"index":4,"value":"210"},{"index":8,"value":"60948364.1453493596"},{"index":9,"value":"485 days"},{"index":1,"value":"San Diego"},{"index":3,"value":"92129"}]"""

lis=data.split("\n")
dic = {}


for i in lis:
    rlis=ast.literal_eval(i)
    clis=[]
    d=dict()
    sqlquery="insert into default.customdimensions values ( '%s','%s','%s','%s','%s','%s','%s','%s','%s');"
    if len(rlis)>0:
        #print rlis
        for j in rlis:
            d[j.get('index')]=j.get('value')
#            if (j.get('index')==1):          
#                clis.append(j.get('value'))
#            else:
#                clis.append(None)
#                
#            if (j.get('index')==2):          
#                clis.append(j.get('value'))
#            else:
#                clis.append(None)
                
        #print d
        clis.append(str(d.get(1)))
        clis.append(str(d.get(2)))
        clis.append(str(d.get(3)))
        clis.append(str(d.get(4)))
        clis.append(str(d.get(8)))
        clis.append(str(d.get(9)))
        clis.append(str(d.get(10)))
        clis.append(str(d.get(11)))
        clis.append(str(d.get(12)))
        #print cli
#        sqlquery+=str(d.get(1))
#        sqlquery+=");"
        sqlquery=sqlquery%(str(d.get(1)),str(d.get(2)),str(d.get(3)),str(d.get(4)),str(d.get(8)),str(d.get(9)),str(d.get(10)),str(d.get(11)),str(d.get(12)))
        print sqlquery
        #d = dict(itertools.izip_longest(*[iter(rlis)] * 2, fillvalue=""))
#        for item in lis:
#            key = "".join(item[:-1])
#            dic.setdefault(key, []).append(item[-1])
#        print dics

#sqlquery+=");"

