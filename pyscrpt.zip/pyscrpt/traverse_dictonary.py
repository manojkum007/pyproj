# -*- coding: utf-8 -*-
"""
Created on Thu Feb  2 16:37:18 2017

@author: manoj
"""

from  collections import OrderedDict
import json

dd=OrderedDict([('userId', OrderedDict([('id', '42324913-b43b-4e6f-95e9-91056d2c1ffe'), ('idType', 'NOVA')])), ('profileDisplayPermissions', OrderedDict([('showProfilePage', True)])), ('agentType', 2), ('agentStatus', 'T'), ('contact', OrderedDict([('firstName', 'Garo'), ('lastName', 'Tchakmakian'), ('phones', OrderedDict([('displayPhone', '8184060758'), ('cellPhone', '8184060758')])), ('email', 'garo@keyfinancial.com'), ('homeAddress', OrderedDict([('state', OrderedDict([('stateCode', 'CA'), ('name', 'California')]))]))])), ('licenses', [OrderedDict([('licenseNumber', 'Garo_Tchakmakian'), ('state', 'CA'), ('score', 1.0), ('licenceStatus', 'Active')])])])

path="/home/manoj/scripts/tiger_analyatics/rhino/dev_rhino/production/agentsMigration_og_test/delta_load_feb.json"

path='/home/manoj/scripts/tiger_analyatics/rhino/dev_rhino/production/finalagents_323190630jan_11370.json'
json_data=open(path).read()

dd=json.loads(json_data)


#print json_data

def traverse(obj,dictkey ,nestedkey=""):
    if isinstance(obj, dict):
        for key, value in obj.iteritems():
            traverse(value,dictkey,nestedkey+"."+key)
    elif isinstance(obj, list):
        for value in obj:
            traverse(value,dictkey,nestedkey+"."+dictkey)
    else:
        if obj.get(dictkey[0])!=None:
            print " nested key",nestedkey , " value " ,obj
            return
        
#traverse(dd,['userId'])

def getdict(cur,lis):
    global a
    if len(lis)>0:
        if len(lis)==1:
            a=cur[lis[0]]
            return 0
        else:
            if  cur.has_key(lis[0]):
                getdict(cur[lis[0]],lis[1:])
            
#        
a=5
b=""
#getdict(dd,['userId','id'])    


#getdict(dd,['userId','idType'])  
#print getdict(dd,['inactiveUrls'])  
#getdict(dd,['profileDisplayPermissions' ,'showMailingAddress'])  
#getdict(dd,['profileDisplayPermissions' ,'showProfilePage'])  

#getdict(dd,['contact' ,'firstName']) 
#
#getdict(dd,['contact' ,'middleName'])
#getdict(dd,['contact' ,'homeAddress','state','stateCode'])

getdict(dd,['claimInfo','claimedDateTime'])


#getdict(dd,['licenses'])


#print getdict(dd,['locations'])

print a
print b





        
