# -*- coding: utf-8 -*-
"""
Created on Mon Jun 20 12:42:18 2016

@author: manoj
"""
#from __future__ import print_function
import time
from threading import Thread


readlis=['36003_Deed_Refresh_20160509.txt',
'36031_Deed_Refresh_20160509.txt',
'36059_Deed_Refresh_20160509.txt',
'36087_Deed_Refresh_20160509.txt',
'36005_Deed_Refresh_20160509.txt',
'36033_Deed_Refresh_20160509.txt',
'36061_Deed_Refresh_20160509.txt',
'36089_Deed_Refresh_20160509.txt']



class FileRead():
    
    def __init__(self,lis):
        self.rlis=lis
    
    def rfile(self,fname):
        with open(fname,'r') as inlinefile:
            for line in inlinefile:
                continue
                #print line
                #break
            print "readfile",fname
            
            
    def wfile(self,fname,data):
        with open(fname,'w') as outlinefile:
            outlinefile.write(data)
                
        
    

ff=FileRead(readlis)
start=time.time()
for i in range(len(ff.rlis)):
    ff.rfile("/home/manoj/scripts/tiger_analyatics/new york/"+ff.rlis[i])
    print "\n\n"
finish=time.time()

print finish-start

#def loop1_10():
#    for i in range(1, 11):
#        time.sleep(1)
#        print(i)
#
#threading.Thread(target=loop1_10).start()
print "now muktithreading"
start=time.time()
for x in range(len(ff.rlis)):
    Thread(target=ff.rfile("/home/manoj/scripts/tiger_analyatics/new york/"+ff.rlis[i])).start()


finish=time.time()
print finish-start    

#class MyThread(threading.Thread):
#    def run(self):
#        print("{} started!".format(self.getName()))              # "Thread-x started!"
#        time.sleep(2)                                      # Pretend to work for a second
#        print("{} finished!".format(self.getName()))             # "Thread-x finished!"
#
#if __name__ == '__main__':
#    for x in range(4):                                     # Four times...
#        mythread = MyThread(name = "Thread-{}".format(x + 1))  # ...Instantiate a thread and pass a unique ID to it
#        mythread.start()                                   # ...Start the thread
#        time.sleep(.9) 

            