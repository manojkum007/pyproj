# -*- coding: utf-8 -*-
"""
Created on Mon Feb 22 17:49:05 2016

@author: manoj
"""
from sqlQuery import command_dict
print command_dict["offices"]