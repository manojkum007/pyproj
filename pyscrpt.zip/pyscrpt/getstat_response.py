# -*- coding: utf-8 -*-
"""
Created on Fri May 19 17:54:12 2017

@author: manoj
"""

import requests
import time

url = "http://movoto.getstat.com/api/v2/8452b165c130a37393e1377fc0abf7d510b77898/keywords/create"

querystring = {"site_id":"9677","market":"US-en","location":"","device":"desktop","type":"regular","keyword":"12413 W Valentine Ave El Mirage AZ,3202 W Avenida Luna Tucson AZ,1928 Landmark Dr Vallejo CA,28 Zircon Dr Maumelle AR,48675 Scott Ave Soldotna AK,710 Peninsula Ave Kenai AK,4511 Bryant St Denver CO,900 Eudora St %23 103 Denver CO,36 W Plumosa Ln Lake Worth FL,17567 Cypress Point Rd Fort Myers FL,12 Courtney Rd Wilmington DE,136 Wortham Ln Bear DE,4941 Blaine St Washington DC,4308 Ellicott St Washington DC,575 Cherry Brook Rd Canton CT,59 Stonecrest Dr Bristol CT,637 Brandy Dr Trussville AL,495 County Road 637 Mentone AL,1953 Riverton Dr Suwanee GA,3510 Concord Rd Newborn GA,2040 Morningview Dr Hoffman Estates IL,455 Sommerset Dr Grayslake IL,115 Coventry Ln Bardstown KY,3640 Hurstbourne Ridge Blvd Louisville KY,3310 Country Village Ave Caldwell ID,3413 Francis St Honolulu HI,1580 E Independence St Boise ID,223 Saratoga Rd %23 1617 Honolulu HI,18 Gaston St Medford MA,23 Millers Rd South Dennis MA,5208 E 21st St Indianapolis IN,3664 W Hinshaw Rd Monrovia IN,601 S Boone St Boone IA,6001 Creston Ave %23 49 Des Moines IA,732 N Mesa St Olathe KS,3138 W Summit Dr Leavenworth KS,114 S Ezidore Ave Gramercy LA,2224 N Friendship Dr Harvey LA,1904 Adams Rd Dundalk MD,100 High St Oxford MD,21738 Riverhaven Dr Paris MI,13563 Karl St Southgate MI,20 Brookwood Dr Smithfield NC,2617 Chesterfield Ave Charlotte NC,305 Hazel Blvd Millville NJ,34 De Shibe Ter Vineland NJ,56 Powsland St Portland ME,53 Gray Rd Gorham ME,22 Old Blaisdell Rd Bradford NH,540 Coral Ave Manchester NH,876 Elmwood Pl West Fargo ND,3103 25th Ave Fargo ND,3916 Bay Hill Loop Rio Rancho NM,2304 Wilma Rd Albuquerque NM,12090 Pleasant Cv Olive Branch MS,5135 Knox St Lincoln NE,215 Spring Creek Dr Kalispell MT,17026 Clay St Bennington NE,204 Bierney Creek Rd Lakeside MT,56 Garden Dr Albertson NY,24 Greenway Roslyn NY,11040 Cherokee Landing St Las Vegas NV,2160 Ascot Ln Reno NV,190 Spur Cir Wayzata MN,2205 10th Ave Willmar MN,3380 Andover Strait Grove City OH,4480 English Oak Ct Mason OH,4909 Laclede Ave %23 1502 Saint Louis MO,3820 Stonewall Ct Independence MO,3300 NW 163rd St Edmond OK,2504 NW 24th St Newcastle OK,2495 Eden Forest Rd Johns Island SC,1039 Oakley St Georgetown SC,2489 Ridge Rd South Park PA,745 Field View Dr Rapid City SD,850 SE 193rd Ave Portland OR,4401 Carriage Hills Dr Rapid City SD,27 Meade Dr Latrobe PA,1719 NW Mill Pond Rd Portland OR,99 Normandy Dr Warwick RI,21 Mile Rd Coventry RI,1117 Woodvale Dr Gallatin TN,2117 Courtney Ave Nashville TN,4608 Reunion Dr Plano TX,1609 Somerset Canyon Ln Cedar Park TX,742 W 2075 Syracuse UT,1785 S 700 Salt Lake City UT,218 Fair Meadows Rd Virginia Beach VA,3930 Plum Run Ct Fairfax VA,4 Green Knolls Ln Rutland VT,404 E 29th St Vancouver WA,2022 30th Ave Issaquah WA,164 Calista Ave Lyndonville VT,246 N 50th St Milwaukee WI,637 Garfield Ave Viroqua WI,329 Buffalo Creek Rd Thermopolis WY,171 Rock Ridge Dr Torrington WY","tag":"dummy_test_python","format":"json"}

headers = {
    'cache-control': "no-cache",
    'postman-token': "7e211d15-9112-44c3-1dba-241b29d9d3cb"
    }

t=time.time()
response = requests.request("POST", url, headers=headers, params=querystring)
t1=time.time()

print "total time taken ",t1-t
print(response.text)