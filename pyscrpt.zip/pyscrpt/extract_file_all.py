# -*- coding: utf-8 -*-
"""
Created on Fri Jun 24 15:17:20 2016

@author: manoj
"""

#import os
#import tarfile
#import zipfile
#import gzip
#
#def extract_file(path, to_directory='.'):
#    if path.endswith('.zip'):
#        opener, mode = zipfile.ZipFile, 'r'
#    elif path.endswith('.gz'):
#        opener, mode = gzip.open, 'r'
#    elif path.endswith('.tar.gz') or path.endswith('.tgz'):
#        opener, mode = tarfile.open, 'r:gz'
#    elif path.endswith('.tar.bz2') or path.endswith('.tbz'):
#        opener, mode = tarfile.open, 'r:bz2'
#    else: 
#        raise ValueError, "Could not extract `%s` as no appropriate extractor is found" % path
#    
#    cwd = os.getcwd()
#    os.chdir(to_directory)
#    
#    try:
#        file = opener(path, mode)
#        try: 
#            #file.extractall()
#
#        finally: file.close()
#    finally:
#        os.chdir(cwd)
#
#
#extract_file('/home/manoj/scripts/tiger_analyatics/deeds_error/06043_Deed_Orphan_Refresh_20160509.txt.gz','/home/manoj/scripts/tiger_analyatics/deeds_error/extract')


import gzip
import os
import glob

sourceFile = '/home/manoj/scripts/tiger_analyatics/deeds_error/06043_Deed_Orphan_Refresh_20160509.txt.gz'

if (os.path.exists(sourceFile)):
    pass
else:
    print "Sorry, cant find the file! Please check if the filename and path are correct!\n"
    exit(0)

#destFile = '/home/manoj/scripts/tiger_analyatics/deeds_error/extract/extract/06043_Deed_Orphan_Refresh_20160509.txt'

destination="/home/manoj/scripts/tiger_analyatics/deeds_error/extract/"
for name in glob.glob(destination + "/*.gz"):
    zipFile = gzip.open(name,"rb")
    destFile=name.replace(".gz" ,"")
    unCompressedFile = open(destFile,"wb")
    decoded = zipFile.read()
    unCompressedFile.write(decoded)
    zipFile.close()
    unCompressedFile.close()