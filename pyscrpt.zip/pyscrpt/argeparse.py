# -*- coding: utf-8 -*-
"""
Created on Fri Jun  9 21:08:42 2017

@author: manoj
"""

import argparse
import datetime

parser = argparse.ArgumentParser()

parser.add_argument('--env', action='store', dest='env',
                    help='Store a simple value')

parser.add_argument('--date', action='store', dest='date',
                    help='Store a simple value')
results = parser.parse_args()
print 'envirroment     =', results.env
print 'envirroment     =', results.date

#dd=datetime.datetime.strptime(results.date,"%Y-%m-%d")
#rint dd



