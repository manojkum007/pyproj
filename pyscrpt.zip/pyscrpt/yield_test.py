import luigi,subprocess
import os
from luigi.hive import run_hive_cmd
from luigi.contrib.hdfs.hadoopcli_clients import HdfsClient
import time
import datetime
from luigi.contrib import sqla


luigi_config = luigi.configuration.get_config()
import logging
logging.basicConfig(level=logging.DEBUG, format=' %(asctime)s - %(levelname)s - %(message)s')

#luigi.Task

#luigi.worker

def db_target(job_name, marker_table, timestamp, get_all):
    db_config = 'puma'
    db_name = luigi_config.get(db_config, 'db')
    db_host = luigi_config.get(db_config, 'host')
    db_username = luigi_config.get(db_config, 'user')
    db_password = luigi_config.get(db_config, 'pw')

    # sqla_string = 'mssql+pyodbc://%s:%s@%s/%s?driver=SQL+Server' % (db_username, db_password, db_host, db_name)
    sqla_string = 'mssql+pymssql://%s:%s@%s/%s' % (db_username, db_password, db_host, db_name)

    return sqla.SQLAlchemyTarget(sqla_string, marker_table, '%s_%s_%s' % (job_name, timestamp, get_all), echo=False, connect_args={})





class TaskOne(luigi.Task):
    
    custid= luigi.Parameter()
    
    def requires(self):
        pass

    
    
#    def complete(self):
#        if os.path.exists("/home/manoj/scripts/python_scripts/logs/"+str(self.custid)+"_success"):
#            return True
#        else:
#            return False
 
    def run(self):
        time.sleep(2)
        #self.output().touch()
        print "parameter receive" ,list(self.custid)
        #print ("cust_id:" + str(self.custid))
        #run_hive_cmd('insert overwrite local directory \'/home/gagan/Desktop/hive_out/{0}\' select * from customers where customernumber={0}'.format(self.cust_id))
        
        with self.output().open('w') as f:
            f.write("%s\n" % '')
        #f.close()
            
            
    def output(self):
#        return db_target('OpportunityFirstTouchToSf',
#                         'sf_raw_dev.dbo.bq_first_touch',
#                         datetime.datetime.today(),
#                         True)
        return luigi.LocalTarget("/home/manoj/scripts/python_scripts/logs/"+str(self.custid)+"_success")       
   
        
class TaskTwo(luigi.Task):

    def requires(self): 
        ll=[]
        for i in range(65,98,1):
            ll.append(chr(i))
        #customersList = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '[', '\\', ']', '^', '_', '`', 'a']
        customersList = ['A', 'B']
#        pass
        #print type(TaskOne(custid=customersList[0]))
#        for i in customersList:
#            yield TaskOne(custid=i)
        #return luigi.build([TaskOne(custid=cust_id) for cust_id in customersList], workers=2)
        return [TaskOne(custid=[cust_id]) for cust_id in customersList]

        #luigi.build()
    
    def output(self):


        return luigi.LocalTarget("/home/manoj/scripts/python_scripts/logs/overall_success.txt")

 
    def run(self):
#        customersList = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '[', '\\', ']', '^', '_', '`', 'a']
#        yield [TaskOne(custid=cust_id) for cust_id in customersList]
#        yield TaskOne(custid='ag')
#        customersList = ['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I']
#        yield luigi.build([TaskOne(custid=cust_id) for cust_id in customersList], workers=2)
        
        with self.output().open('w') as f:
            f.write("%s\n" % "success")
                 

        
if __name__ == '__main__':
    luigi.run()