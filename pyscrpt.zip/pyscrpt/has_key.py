# -*- coding: utf-8 -*-
"""
Created on Sat Dec 24 01:52:08 2016

@author: manoj
"""

d = {}

keyList1 = ["Person", "Male", "Boy", "Student", "id_123", "Name"]
keyList2 = ["Person", "Male", "Boy", "Student", "id_123", "Age"]
keyList1 = ["Person","name"]

value1 = ["Roger","adrew"]
value2 = 3

#def insert(cur, list, value):
#    if len(list) == 1:
#        cur[list[0]] = value
#        return
#    if not cur.has_key(list[0]):
#        print "list",list
#        cur[list[0]] = {}
#    insert(cur[list[0]], list[1:], value)

#insert(d, keyList1, value1)

def assigndict(cur,lis,val,single):
    if len(lis)==1:
        if len(val)>0:
            if (single==0):
                cur[lis[0]]=val[0]
            else:
                cur[lis[0]]=val
        return
    else:
        if not d.has_key(lis[0]):
            cur[lis[0]]={}
        assigndict(cur[lis[0]],lis[1:],val,single)

        
assigndict(d,keyList1, value1,1)
print d

d1={}

def assignd1():
    d1["a"]=5
    b=d1
    b["b"]={"he":45}
    
assignd1()

print d1