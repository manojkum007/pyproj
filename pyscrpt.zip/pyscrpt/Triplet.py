# -*- coding: utf-8 -*-
"""
Created on Thu Oct 19 02:22:54 2017

@author: manoj
"""

class Triplet:
    def __init__(self , a,b,c):
        self.a=a
        self.b=b
        self.c=c
        self.oblist=[self.a ,self.b ,self.c]
        self.points=0
    def compare(self, other):
        for i in range(len(self.oblist)):
            if self.oblist[i]>other.oblist[i]:
                self.points+=1
            elif self.oblist[i]<other.oblist[i]:
                other.points+=1


t=Triplet( 5,6,7)
t1=Triplet(3,6,10)
t.compare(t1)
print "total t points" ,t.points
print "total t1 points" ,t1.points