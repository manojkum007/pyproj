# -*- coding: utf-8 -*-
"""
Created on Sun Jul 30 12:45:40 2017

@author: manoj
"""



###decorators###
def inc(x):
    return x + 1

def dec(x):
    return x - 1

def operate(func1, func2,x):
    result = func2(func1(x))
    return result
    

#print "operate" ,operate(inc,dec, 5) 
 
#print operate(dec,5) 
 
 
def is_called():
    def is_returned():
        print("Hello")
    return is_returned

#new = is_called()
#new1=new
#Outputs "Hello"
#new1()



def make_pretty(func):
    def inner():
        print  "I got decorated"
        func()
    return inner
    
@make_pretty
def ordinary():
    print("I am ordinary")
    


#o=ordinary()
#print o


#m=make_pretty(ordinary) 
#m()

#I got decorated
#I am ordinary


#print ordinary()


def smart_divide(func):
   def inner(a,b,d):
      print("I am going to divide",a,"and",b ,"and " ,d)
      if b == 0:
         print("Whoops! cannot divide")
         raise ValueError

      return func(a,b)
   return inner

@smart_divide
def divide(a,b):
    return a/b


#print divide(4,0)

def Number_check(func):
    def nonstring(a,b):
        if isinstance(a,str) and isinstance(b,str):
            print "please provide number for divison"
            raise TypeError
        return func(a,b)
    return nonstring


def divide_check(func):
    def inner(a,b):
        if b==0:
            print "can't divide"
            raise ValueError
        return func (a,b)
    return inner
    

@Number_check
@divide_check
def divide(a,b):
    print "divison of number is", 
    return a/b
    

print "dividing" ,divide(40,10)



##################Property####################


