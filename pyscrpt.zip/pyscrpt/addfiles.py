# -*- coding: utf-8 -*-
"""
Created on Sun Dec 11 09:53:17 2016

@author: manoj
"""

import glob

import json

import collections

files= glob.glob("/home/manoj/scripts/tiger_analyatics/rhino/dev_rhino/report/withspec*.json")


megalis=[]
for fil in files:     
    f=open(fil, 'r')
    data=json.load(f)
    megalis.append(data[0])  
    f.close() 


fullmongo=collections.OrderedDict()
ff=open("/home/manoj/scripts/tiger_analyatics/rhino/dev_rhino/report/fullandfinal.json",'w')
fullmongo=megalis
json.dump(fullmongo,ff, indent=4)
ff.close()