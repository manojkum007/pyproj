# -*- coding: utf-8 -*-
"""
Created on Tue Feb 16 17:16:25 2016

@author: manoj
"""
import luigi
import datetime
import json
import time 

class TaskA1(luigi.Task):
    def run(self):
        with self.output().open('w') as f:
            f.write('{word}\n'.format(word='createSchema_'))
        
    def output(self):
        return True
        #return luigi.LocalTarget('/home/manoj/scripts/results.log1')

class TaskB1():
    def __init__(self,x):
        self.x=x
        print  'x is ' ,self.x
        
    def output(self):
        return self.x**2
        
        
class FlipLinesBackward1(luigi.Task):
    def requires(self):
        print "calling require "
        return {'a': TaskA1(), 'b': [TaskB1(i) for i in xrange(10)]}

    def output(self):
        return luigi.LocalTarget('/home/mkumar/bigquery/logs/log_29jul.txt')

    def run(self):
        f = self.input()['a'].open('r') # this will return a file stream that reads from "xyz"
        g = self.output().open('w')
        for line in f:
            #g.write('%s\n', ''.join((line.strip().split())))
            g.write(self.input()['b'])
        g.close() # needed because files are atomic
    
        #t = [y.open('r') for y in self.input()['b']]
        #print " gi is " ,t


class FakeDocuments(luigi.Task):
    """
    Generates a local file containing 5 elements of data in JSON format.
    """
    date = luigi.DateParameter(default=datetime.date.today())

    def run(self):
        """
        Writes data in JSON format into the task's output target.
        The data objects have the following attributes:
        * `_id` is the default Elasticsearch id field,
        * `text`: the text,
        * `date`: the day when the data was created.
        """
#        luigi.file.LocalFileSystem.remove('/home/manoj/logs/_docs-%s.ldj' % self.date)
#        ll=LocalTarget()
#        ll.remove'/home/manoj/logs/_docs-%s.ldj' % self.date()
        if self.date==datetime.datetime.strptime('2017-04-01', "%Y-%m-%d"):
            pass
        
        print "after pass"
        
        today = datetime.date.today()
        with self.output().open('w') as output:
            for i in range(5):
                output.write(json.dumps({'_id': i, 'text': 'Hi %s' % i,
                                         'date': str(today)}))
                output.write('\n')
        time.sleep(2)        
        #self.input().remove('/home/manoj/logs/_docs-%s.ldj' % datetime.date.today())

    def output(self):
        """
        Returns the target output for this task.
        In this case, a successful execution of this task will create a file on the local filesystem.
        :return: the target output for this task.
        :rtype: object (:py:class:`luigi.target.Target`)
        """
        #pass
        return luigi.LocalTarget(path='/home/manoj/logs/_docs-%s.ldj' % self.date)
        

class reomovelocalfiles(luigi.Task):
    date = luigi.DateParameter(default=datetime.date.today())
    
    def run(self):
        filedate='/home/manoj/logs/_docs-%s.ldj' % datetime.date.today()
        luigi.LocalTarget(filedate).remove()
        
        
        
if __name__ == '__main__':
    luigi.run()   
