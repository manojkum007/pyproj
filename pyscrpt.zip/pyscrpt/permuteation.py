# -*- coding: utf-8 -*-
"""
Created on Wed Nov 29 23:08:51 2017

@author: manoj
"""

Python 2.7.11 |Anaconda 2.5.0 (64-bit)| (default, Dec  6 2015, 18:08:32) 
Type "copyright", "credits" or "license" for more information.

IPython 4.0.3 -- An enhanced Interactive Python.
?         -> Introduction and overview of IPython's features.
%quickref -> Quick reference.
help      -> Python's own help system.
object?   -> Details about 'object', use 'object??' for extra details.
%guiref   -> A brief reference about the graphical user interface.

lis=['a','b','c']

def swap(lis ,start ,end):
    print lis
    while (end<len(lis)):
        lis[sart],lis[end]=lis[end],lis[start]
        end+=1
    

lis[:}
  File "<ipython-input-3-356bf4c4a6dc>", line 1
    lis[:}
         ^
SyntaxError: invalid syntax


lis[:]
Out[4]: ['a', 'b', 'c']

swap(lis[:], 0,0)
['a', 'b', 'c']
Traceback (most recent call last):

  File "<ipython-input-5-54897c3d89ed>", line 1, in <module>
    swap(lis[:], 0,0)

  File "<ipython-input-2-1645fb3db799>", line 4, in swap
    lis[sart],lis[end]=lis[end],lis[start]

NameError: global name 'sart' is not defined


def swap(lis ,start ,end):
    print lis
    while (end<len(lis)):
        lis[start],lis[end]=lis[end],lis[start]
        print lis
        end+=1
        

swap(lis[:], 0,0)
['a', 'b', 'c']
['a', 'b', 'c']
['b', 'a', 'c']
['c', 'a', 'b']

def swap(lis ,start ,end):
    while (end<len(lis)):
        lis[start],lis[end]=lis[end],lis[start]
        print "".join(lis)
        end+=1
        

swap(lis[:], 0,0)
abc
bac
cab

def swap(lis ,start ,end):
    while (end<len(lis)):
        newlis=lis[:]
        newlis[start],newlis[end]=newlis[end],newlis[start]
        print "".join(newlis)
        end+=1
        

swap(lis[:], 0,0)
abc
bac
cba

for i in range(3):
    print i
    
0
1
2

for i in range(3):
    swap(lis[:], 0,i)
    
abc
bac
cba
bac
cba
cba

for i in range(3):
    swap(lis[:],i,0)
    
abc
bac
cba
bac
abc
acb
cba
acb
abc

finallis=[]

for i in range(3):
    finallis.append(swap(lis[:],i,0))
    
abc
bac
cba
bac
abc
acb
cba
acb
abc

finallis
Out[17]: [None, None, None]

def swap(lis ,start ,end ,fnlis):
    while (end<len(lis)):
        newlis=lis[:]
        newlis[start],newlis[end]=newlis[end],newlis[start]
        fnlis.append("".join(newlis))
        end+=1
        

finallis=[]

for i in range(3):
    swap(lis[:],i,0,finallis)
    

finallis
Out[21]: ['abc', 'bac', 'cba', 'bac', 'abc', 'acb', 'cba', 'acb', 'abc']

set(finallis)
Out[22]: {'abc', 'acb', 'bac', 'cba'}

finallis=[]

for i in range(3):
    swap(lis[:],0,i,finallis)
    

finallis
Out[25]: ['abc', 'bac', 'cba', 'bac', 'cba', 'cba']

set(finallis)
Out[26]: {'abc', 'bac', 'cba'}

list(set(finallis))
Out[27]: ['abc', 'cba', 'bac']

ll=list(set(finallis))

fff=[]

for ele in ll:
    swap(ele.split(""),0,0,fff)
    
Traceback (most recent call last):

  File "<ipython-input-30-d234e1e6f078>", line 2, in <module>
    swap(ele.split(""),0,0,fff)

ValueError: empty separator


for ele in ll:
    print ele
    
abc
cba
bac

for ele in ll:
    print ele.split("")
    
Traceback (most recent call last):

  File "<ipython-input-32-37630eaa0f87>", line 2, in <module>
    print ele.split("")

ValueError: empty separator


for ele in ll:
    print list(ele)
    
['a', 'b', 'c']
['c', 'b', 'a']
['b', 'a', 'c']

for ele in ll:
    swap(list(ele),0,0,fff)
    

fff
Out[35]: ['abc', 'bac', 'cba', 'cba', 'bca', 'abc', 'bac', 'abc', 'cab']

set(fff)
Out[36]: {'abc', 'bac', 'bca', 'cab', 'cba'}

ele
Out[37]: 'bac'
for ele in ll:
    print list(ele)
    
['a', 'b', 'c']
['c', 'b', 'a']
['b', 'a', 'c']

fff=[]

ll
Out[40]: ['abc', 'cba', 'bac']

ll.pop()
Out[41]: 'bac'

ll.pop()
Out[42]: 'cba'

ll.append('bac').append('cab')
Traceback (most recent call last):

  File "<ipython-input-43-595d2cec6281>", line 1, in <module>
    ll.append('bac').append('cab')

AttributeError: 'NoneType' object has no attribute 'append'


ll.append('bac').append('cab')
Traceback (most recent call last):

  File "<ipython-input-44-595d2cec6281>", line 1, in <module>
    ll.append('bac').append('cab')

AttributeError: 'NoneType' object has no attribute 'append'


ll.append('bac')

ll.append('cab')

ll
Out[47]: ['abc', 'bac', 'bac', 'bac', 'cab']

ll.pop('bac')
Traceback (most recent call last):

  File "<ipython-input-48-c8a8bc685ba6>", line 1, in <module>
    ll.pop('bac')

TypeError: an integer is required


ll.pop(1)
Out[49]: 'bac'

ll
Out[50]: ['abc', 'bac', 'bac', 'cab']

ll.pop(1)
Out[51]: 'bac'

ll
Out[52]: ['abc', 'bac', 'cab']

for ele in ll:
    swap(list(ele),0,0,fff)
    

fff
Out[54]: ['abc', 'bac', 'cba', 'bac', 'abc', 'cab', 'cab', 'acb', 'bac']

set(fff)
Out[55]: {'abc', 'acb', 'bac', 'cab', 'cba'}

ll
Out[56]: ['abc', 'bac', 'cab']

ll.pop(1)
Out[57]: 'bac'

ll
Out[58]: ['abc', 'cab']

ll.append('bca')

fff=[]

for ele in ll:
    swap(list(ele),0,0,fff)
    

fff
Out[62]: ['abc', 'bac', 'cba', 'cab', 'acb', 'bac', 'bca', 'cba', 'acb']

set(fff)
Out[63]: {'abc', 'acb', 'bac', 'bca', 'cab', 'cba'}

ll
Out[64]: ['abc', 'cab', 'bca']

abc
Traceback (most recent call last):

  File "<ipython-input-65-0bee89b07a24>", line 1, in <module>
    abc

NameError: name 'abc' is not defined


'abc' ,'bca','cab'
Out[66]: ('abc', 'bca', 'cab')
