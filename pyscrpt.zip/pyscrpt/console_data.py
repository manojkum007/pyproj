# -*- coding: utf-8 -*-
"""
Created on Tue Dec 26 15:43:47 2017

@author: manoj
"""
import sys

if __name__ == '__main__':
    inputData = []
    for line in sys.stdin:
        inputData
        break


print  "inputData" ,inputData