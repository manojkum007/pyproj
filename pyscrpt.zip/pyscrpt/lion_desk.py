# -*- coding: utf-8 -*-
"""
Created on Thu Oct  5 16:10:17 2017

@author: manoj
"""
import requests
import json

url = "https://api.liondesk.com/"


headers = {
    'content-type': "application/json",
    'x-liondesk-id': "6f22227a1a9cc3b0c77f24de0cf26c22",
    'authorization': "Basic dXNlcjo=",
    'cache-control': "no-cache"
    }


#print(response.text)


lionlist=['11220457']

def liondeskreponse(lionlist):
    for lid in lionlist:
        payload = """{"action": "GetContactDetails","liondeskcontactid":  "%s"}"""%lid
        response = requests.request("POST", url, data=payload, headers=headers)
        yield response.text
    
path='reponse _file.txt'

jsonfile=open(path,'w')

for data in liondeskreponse(lionlist):
    print type(data)
    jsonfile.write(data)
    #json.dump(data,jsonfile)
    
jsonfile.close()
    



    