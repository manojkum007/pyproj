# -*- coding: utf-8 -*-
"""
Created on Sun Jul  9 11:16:18 2017

@author: manoj
"""

class JustCounter:
   __secretCount = 0
   public_var=56
  
   def count(self):
      self.__secretCount += 1
      print self.__secretCount

#counter = JustCounter()
#counter.count()
#counter.count()
#print counter.public_var
#print counter._JustCounter__secretCount
##print counter.__secretCount





class A:
    def __init__(self, a=0):
        print " in A constructor"
        self.num=a
    def displaynum(self):
        print "number of A" ,self.num
        
        

class B(A):
    def __init__(self ,a ):
        #A.__init__(s    def __init__(self ,a ):
        A.__init__(self ,a)
        self.bnum=self.num+100
        print "in b constructor"
    
    def displaynum(self):
        print "number of B" ,self.bnum
    
    
        
b=B(80)
b.displaynum()