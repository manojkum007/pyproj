# -*- coding: utf-8 -*-
"""
Created on Wed May 31 17:14:45 2017

@author: manoj
"""

import pandas as pd
import numpy as np

from pandas import DataFrame, Series


df = DataFrame({'int_col' : [1,2,6,8,-1], 'float_col' : [0.1, 0.2,0.2,10.1,None], 'str_col' : ['a','b',None,'c','a']})


#print df.ix[1:,['float_col','int_col']]


#print df[df['float_col'] > 0.15]


#tem_wynufkhXhkMdGKaNuxrxG       bounce  3
#tem_wynufkhXhkMdGKaNuxrxG       click   88
#tem_wynufkhXhkMdGKaNuxrxG       delay   2
#tem_wynufkhXhkMdGKaNuxrxG       delivery        169
#tem_wynufkhXhkMdGKaNuxrxG       generation_rejection    4
#tem_wynufkhXhkMdGKaNuxrxG       injection       173
#tem_wynufkhXhkMdGKaNuxrxG       open    160


#print df[(df['float_col'] > 0.1) & (df['int_col']>2)]


series = pd.Series([20, 21, 12], index=['London','New York','Helsinki'])

df = pd.DataFrame({'A': [1, 1, 2, 2],
                   'B': [1, 2, 3, 4],
                   'C': np.random.randn(4)})
                   
#print "df" ,df     

for i in df.groupby('A'):
    print i
             
print  df.groupby('A').agg('min')



#def inverse(x):
#    return 1/float(x)
#    
#print series.apply(inverse)