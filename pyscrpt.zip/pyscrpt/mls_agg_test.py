# python libraries
import argparse
import datetime

# third-party libraries
import elasticsearch
import luigi
from pyhive import hive
import pymssql
import sys

# internal libraries
import movoto_logger

logger = movoto_logger.get_logger('mls_listings_to_es.log')

COLUMNS = ['mls_id',
           'state',
           'dma_code',
           'dma',
           'property_status',
           'property_type',
           'new_listing',
           'listed_l7d',
           'listing_count',
           'avg_create_delay_days',
           'avg_days_on_movoto',
           'avg_listing_freshness']

ES_INDEX = 'mls_stats'
DOC_TYPE = 'mls_aggregates'


def main(start_date, end_date):
    logger.info('Connecting to Hive...')

    luigi_config = luigi.configuration.get_config()

    # connect to tiger mysql db
    # rhino_host = luigi_config.get('rhino', 'db-host')
    # conn = hive.connect(rhino_host)

    # Connect to Panther
    host = luigi_config.get('panther', 'db-host')
    user = luigi_config.get('panther', 'db-user')
    password = luigi_config.get('panther', 'db-password')
    db_name = luigi_config.get('panther', 'db-name')

    conn = pymssql.connect(host, user, password, db_name)

    es = elasticsearch.Elasticsearch([{'host': 'localhost'}])
    # date = datetime.datetime.today() - datetime.timedelta(days=1)

    err_count = 0
    print "'Connecting to Hive...'"
    sys.exit(0)

    for date in daterange(start_date, end_date):

        # execute stored procedure
        logger.info('Begin retrieving MLS aggs data.')
        # for date in daterange(start_date, end_date):
        logger.info('Retrieving MLS aggs data for %s...' % date.strftime('%Y-%m-%d'))

        cur = conn.cursor()

        # print cur.callproc('dbo.sp_mls_aggs', (date,))
        logger.info('Running stored procedure...')
        cur.execute('EXECUTE dbo.sp_mls_aggs %s', (date,))
        logger.info('Fetching results...')
        data = cur.fetchall()
        cur.close()

        # push each row into elasticsearch
        logger.info('Loading MLS aggs data for %s into Elasticsearch...' % date.strftime('%Y-%m-%d'))
        for row in data:
            try:
                row_to_es(row, es, date)
            except Exception as e:
                logger.warning('''
                Failed to load row into elasticsearch.
                Exception: %s
                Row: %s
                ''' % (row, e))
                err_count += 1

    if err_count > 0:
        logger.critical('Failed to load %s rows into Elasticsearch. Consult the logs for more info.' % err_count)

    logger.info('Data load complete.')

    pass


def row_to_es(row, es, date):

    r = dict()

    for i, field_name in enumerate(COLUMNS):
        r[field_name] = row[i]

    r['@timestamp'] = date

    r['day'] = date.day
    r['month'] = date.month
    r['monthname'] = date.strftime('%b')
    r['year'] = date.year
    r['week_of_the_year'] = date.isocalendar()[1]
    r['day_of_the_week'] = 0 if date.isoweekday() == 7 else date.isoweekday()
    r['weekday_name'] = date.strftime('%a')

    r['state_name'] = r['state']

    es_id = '%s-%s-%s-%s-%s-%s-%s-%s' % (r['mls_id'], r['state'], r['dma_code'], r['property_status'], r['property_type'], date.strftime('%Y-%m-%d'),
                                         r['new_listing'], r['listed_l7d'])

    # print id, r
    es.index(index=ES_INDEX, doc_type=DOC_TYPE, body=r, id=es_id, timestamp=r['@timestamp'])

    pass


def get_args():
    parser = argparse.ArgumentParser()

    parser.add_argument("-s", "--start-date", help="Date from which to start retrieving GA data. Date format must be 'YYYY-MM-DD'", type=valid_date)
    parser.add_argument("-e", "--end-date", help="Date at which to stop retrieving GA data. Date format must be 'YYYY-MM-DD'", type=valid_date)
    parser.add_argument("-d", "--debug", help="Enable debug mode", action='store_true')

    arguments = parser.parse_args()

    # Validate the date range
    if arguments.end_date and not arguments.start_date:
        msg = 'Invalid date range: Cannot have an end date without a start date'
        raise Exception(msg)

    if not arguments.end_date:
        arguments.end_date = datetime.date.today()

    if not arguments.start_date:
        arguments.start_date = datetime.date.today()

    if arguments.start_date > datetime.date.today() or arguments.end_date > datetime.date.today():
        msg = 'Invalid date range: Start date and end date cannot be greater than today'
        raise Exception(msg)

    if arguments.start_date > arguments.end_date:
        msg = 'Invalid date range: Start date must be less than the end date'
        raise Exception(msg)

    return arguments


def valid_date(date_string):
    try:
        return datetime.datetime.strptime(date_string, '%Y-%m-%d').date()
    except ValueError:
        msg = 'Date %s is not valid. Date must follow format "YYYY-MM-DD".' % date_string
        raise argparse.ArgumentTypeError(msg)


def daterange(start_date, end_date):
    date_range = int((end_date - start_date).days)
    if date_range <= 1:
        yield start_date
    else:
        for n in range(date_range):
            yield start_date + datetime.timedelta(n)


if __name__ == '__main__':
    args = get_args()
    print "calling  main ",args.start_date ," " , args.start_date
    main(args.start_date, args.end_date)

