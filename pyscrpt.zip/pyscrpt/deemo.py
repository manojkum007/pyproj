# -*- coding: utf-8 -*-
"""
Created on Wed Aug 16 12:34:22 2017

@author: manoj
"""

import threading
import logging
import time
lock = threading.Lock()
logging.basicConfig(level=logging.DEBUG,
                    format='(%(threadName)-10s) %(message)s',
                    )
i=0
#while True:
#    print "acquiring lock",lock.acquire()
#    i+=1
#    print i
#    if i==10:
#        break
#    print "releasing lock", lock.release()
#
#    
#    
    
while True:
    lock.acquire()
    try:
        logging.debug('Holding')
        time.sleep(0.5)
    finally:
        logging.debug('Not holding')
        lock.release()
    time.sleep(0.5)
