# -*- coding: utf-8 -*-
"""
Created on Wed Jun  1 12:23:34 2016

@author: manoj
"""

import multiprocessing

def worker():
    """worker function"""
    print 'Worker'
    return

if __name__ == '__main__':
    jobs = []
    for i in range(5):
        p = multiprocessing.Process(target=worker)
        jobs.append(p)
        p.start()