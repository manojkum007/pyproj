# -*- coding: utf-8 -*-
"""
Created on Tue Oct 25 12:31:57 2016

@author: manoj
"""

import collections
import json
import pymssql
import itertools
import datetime
import math

mongolis=[]
row_header=[]
rowlength=46
page =100
counter=0


conn = pymssql.connect('172.24.0.80', 'sa', 'igen', 'AgentDirectory') 
userdict=collections.OrderedDict()

distincturl=[]
distinctqry="select  distinct TOP 10000 Url from  AgentDirectory.dbo.FinalQueryResult";
cursor = conn.cursor() 
print "fetching distinct count"
cursor.execute(distinctqry)
for row in cursor:
    distincturl.append(str(row[0]))

print "distinct count completed "
#print  distincturl

agentkeycount=0 
try:
    mongodb=collections.OrderedDict()
    mongodblis=[]
    for i in range(1,int(math.ceil(len(distincturl)/float(page)))+1):
        conn = pymssql.connect('172.24.0.80', 'sa', 'igen', 'AgentDirectory') 
        cursor = conn.cursor()   
        lis=distincturl[counter:i*page]
        query="""select Url, InActiveUrls, OGuserID, NovaId, IdType ,AverageRating ,showProfilePage ,
                showInDPP,IsShowDREName ,IsShowMailingAddress,
                MovotoAgentSince, AgentSince ,AgentType ,AgentStatus  FirstName, MiddleName, 
                LastName, DisplayPhone, HomePhone, OfficePhone, Altphone, CellPhone,
                Email ,  AltEmail ,LinkedInProfile, FacebookProfile, TwitterProfile, Blog, Website,
                streetAddress, HomeCity, HomeZipCode, HomeState,
                HomeCityCode,Brokerage, BrokerageWebSite, LicenseNumber, LicenseState, ExpireDate, Score, MLSID,
                MLSName, MLSState, Biography, PersonalInterests, Speciality, OtherSpeciality, AwardsAndRecognition, QuestionName , Comments, 
                IsJointProfile, SpouseFirstName, IsClaimed, ClaimTime, Zip, StateCode, StateName, CityID, CityName, 
                sitemapCityPropertyPageUrl, CountyID , CountyName , AgentImage  from  AgentDirectory.dbo.FinalQueryResult where Url in ("""
         
        
        ss="'"+"','".join(lis)+"')"
        query+=ss
        #print query
        print "Fetching table rows having row count between  %s and %s"%(counter,page*i)
        counter=page*i
        cursor.execute(query)
        for row in cursor:
            dd=(row[1], row[2], row[3], row[4] ,int(row[5]) ,row[6] ,row[7] ,row[8] ,row[9],row[10] ,row[11],row[12],row[13],row[14],row[15],row[16],row[17],row[18],row[19],row[20],row[21],row[22],row[23],row[24],row[25],row[26],row[27],row[28],row[29],row[30],row[31],row[32],row[33],row[34],row[35],row[36],row[37],row[38],row[39],row[40],row[41],row[42],row[43],row[44],row[45],row[46],row[47],row[48],row[49],row[50],row[51],row[52],row[53],row[54],row[55],row[56],row[57],row[58],row[59],row[60],row[61])
            rowlength=len(dd)
            if (userdict.get(row[0]))==None:
                userdict[row[0]]=[]
                agentkeycount+=1
                userdict[row[0]].append(dd)
            else:
                userdict[row[0]].append(dd)
        print "completed reading from table"
        #print "useridct",userdict 
        print "preparing json"
        for key,v in userdict.iteritems():
            d=collections.OrderedDict()
            darry=[[]]   
            for i in range(rowlength):
                darry.append([])
            for j in range(len(v)):
                for k in range(len(v[j])):            
                    darry[k].append(v[j][k])
            for ind in range(len(darry)):
                darry[ind]=list(set(darry[ind]))

            #print "reduce list" ,darry
            d["Url"]=str(key)
            d["InActiveUrls"]=darry[0]
            #d["OGuserID"]=darry[2]
            d["userId"]=collections.OrderedDict()
            #d["userId"]["id"]=darry[3][0]
            d["userId"]["id"]=darry[2][0]
            d["userId"]["idType"]=darry[4][0]
            d["averageRating"]=darry[5][0]
            d["profileDisplayPermissions"]=collections.OrderedDict()
            d["profileDisplayPermissions"]["showProfilePage"]=darry[6][0]
            d["profileDisplayPermissions"]["showInDPP"]=darry[7][0]
            d["profileDisplayPermissions"]["showDREName"]=darry[8][0]
            d["profileDisplayPermissions"]["showMailingAddress"]=darry[9][0]
            d["movotoAgentSince"]=darry[10][0]
            d["agentSince"]=darry[11][0]
            d["agentType"]=darry[12][0]
            d["agentStatus"]=darry[13][0]
            d["contact"]=collections.OrderedDict()
            d["contact"]["firstName"]=darry[14][0]
            d["contact"]["middleName"]=darry[15][0]
            d["contact"]["lastName"]=darry[16][0]
            d["contact"]["phones"]=collections.OrderedDict()
            d["contact"]["phones"]["displayPhone"]=darry[16][0]
            d["contact"]["phones"]["homePhone"]=darry[17][0]
            d["contact"]["phones"]["officePhone"]=darry[18][0]
            d["contact"]["phones"]["cellPhone"]=darry[19][0]
            d["contact"]["email"]=darry[20][0]
            d["contact"]["altEmail"]=darry[21][0]
            d["contact"]["linkedInProfile"]=darry[22][0]
            d["contact"]["facebookProfile"]=darry[23][0]
            d["contact"]["twitterProfile"]=darry[24][0]
            d["contact"]["blog"]=darry[25][0]
            d["contact"]["website"]=darry[26][0]
            d["contact"]["homeAddress"]=collections.OrderedDict()
            d["contact"]["homeAddress"]["streetAddress"]=darry[27][0]
            d["contact"]["homeAddress"]["city"]=darry[28][0]
            d["contact"]["homeAddress"]["zipcode"]=darry[29][0]
            d["contact"]["homeAddress"]["state"]=darry[30][0]
            d["contact"]["homeAddress"]["cityCode"]=darry[31][0]
            d["brokerage"]=collections.OrderedDict()
            d["brokerage"]["name"]=darry[32][0]
            d["brokerage"]["website"]=darry[33][0]
            licenseslist=[]
            darry[36]=map(lambda t : t.strftime("%Y-%m-%d") if (type(t)==datetime.datetime) else t,darry[36])
            for licence,state,validDate,score  in itertools.izip_longest(darry[34],darry[35],darry[36],darry[37]):
                tempd=collections.OrderedDict()
                tempd["licenseNumber"]=licence
                tempd["state"]=state
                tempd["validDate"]=validDate
                tempd["score"]=score
                licenseslist.append(tempd)
            d["licenses"]=licenseslist
        
            mlsassociationlist=[]
            for mlsAssociationId,mlsAssociationName,states  in itertools.izip_longest(darry[38],darry[39],darry[40]):
                mlstempd=collections.OrderedDict()
                mlstempd["mlsAssociationId"]=mlsAssociationId
                mlstempd["mlsAssociationName"]=mlsAssociationName
                mlstempd["states"]=states
                mlsassociationlist.append(mlstempd)
            d["mlsAssociations"]=mlsassociationlist
        
            d["agentDetails"]=collections.OrderedDict()
            d["agentDetails"]["agentBio"]=darry[41][0]
            d["agentDetails"]["interests"]=darry[42][0]
            d["agentDetails"]["specialities"]=darry[43]
            d["agentDetails"]["otherSpecialities"]=darry[44]
            d["agentDetails"]["certifications"]=darry[45]
            questionairelist=[]
            for ques,comment  in itertools.izip_longest(darry[46],darry[47]):
                tempq=collections.OrderedDict()
                tempq["question"]=ques
                tempq["answer"]=comment
                questionairelist.append(tempq)
            d["agentDetails"]["questionnaire"]=questionairelist
            d["partnerInfo"]=collections.OrderedDict()
            d["partnerInfo"]["isJointProfile"]=darry[48][0]
            d["partnerInfo"]["partnerFirstName"]=darry[49][0]
            d["claimInfo"]=collections.OrderedDict()
            darry[51]=map(lambda t : t.strftime("%Y-%m-%d") if (type(t)==datetime.datetime) else t,darry[51])
            d["claimInfo"]["isClaimed"]=darry[50][0]
            d["claimInfo"]["claimedDateTime"]=darry[51][0]
            locations=[]
            for zipcode,stateCode,name,cityId,cityName,sitemapCity,countId,countName  in itertools.izip_longest(darry[52],darry[53],darry[54],darry[55],darry[56],darry[57],darry[58],darry[59]):
                locd=collections.OrderedDict()
                locd["zipcode"]=zipcode
                locd["state"]=collections.OrderedDict()
                locd["state"]["stateCode"]=stateCode
                locd["state"]["name"]=name
                locd["city"]=collections.OrderedDict()
                locd["city"]["cityId"]=cityId
                locd["city"]["cityName"]=cityName
                locd["city"]["sitemapCityPropertyPageUrl"]=sitemapCity
                locd["county"]=collections.OrderedDict()
                locd["county"]["countId"]=countId
                locd["county"]["countName"]=countName
                locations.append(locd)
            d["locations"]=locations
            d["agentImages"]=darry[60]
            mongodblis.append(d)
        print "finished preparing json with %s"%agentkeycount
    jsonob=open('result2.json','w')
    mongodb=mongodblis
    json.dump(mongodb,jsonob, indent=4)
    jsonob.close()
        #print mongodblis
        
    conn.close()
except Exception as e:
    print "due to following error",e
  