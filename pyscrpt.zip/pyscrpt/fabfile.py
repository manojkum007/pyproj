# -*- coding: utf-8 -*-
"""
Created on Thu Aug  9 19:54:56 2018

@author: manoj
"""

#
#def hello(who="world"):
#    print "Hello {who}!".format(who=who)
#
#def hello():
#    print("Hello world!")

from fabric.api import run
def host_type():
    run('uname -s')