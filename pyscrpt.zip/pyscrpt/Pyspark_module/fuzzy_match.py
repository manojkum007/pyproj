# -*- coding: utf-8 -*-
"""
Created on Fri Mar 16 19:04:03 2018

@author: manoj
"""

import luigi
import pandas as pd 
from luigi.hive import HiveTableTarget, run_hive_cmd

from fuzzywuzzy import process


#res=run_hive_cmd("select  FirstName,LastName,Email , Agent_ID__c from default.contact_test ")


f=open('/home/manoj/scripts/python_scripts/Pyspark_module/test1/testing.csv' ,'r')
res=f.read()

#robert  hatchell        grandstrandrob@gmail.com        20975
#andres  banuelos        listings@capitolreg.com 20975
#lisa    allen   shamrockbuilders@insightbb.com  20975
#tony    walton  tonywalton@nelandmark.com       20975
#darlene tanenbaum       darlene.tanenbaum@carolinaoneplus.com   20975
#gary    kerby           20975
#rezart  daragjati       rezart@reddoorrealtygroup.com   20975
#ann     wittenbach              20975
#debi    ruetz   debiruetz@cox.net       20975


ll=map(lambda r : r.split("\t"),res.split("\n"))

ll.pop()
for i in ll:
    if (len(i)>5):
        print i
#print ll[len(ll)-1]
label=['FirstName','LastName', 'FullName' ,'Email' , 'novaid' ]

df = pd.DataFrame(ll, columns=label)
#df.FirstName.str.match('robert*')


#print df[df['FirstName'].notnull() & (df['FirstName'] == "Robert")]
#print df[df['FirstName'].notnull() & (df['lastName'] == "hatchell")]
#
#
#df[(df.A == 1) & (df.D == 6)]
#df[df['FirstName']=="Robert" & (df['LastName'] == "ha")]
#
#
#print df[df['FirstName'].notnull() & (df['Email'] == "grandstrandrob@gmail.com")]
#

query = 'robert'
choices = df['LastName']
#print df['FisrtName'][:2]
# Get a list of matches ordered by score, default limit to 5
#print process.extract(query, choices)
# [('Barack H Obama', 95), ('Barack H. Obama', 95), ('B. Obama', 85)]
 
# If we want only the top one
def  fuzzymatch(search, pd ,searchtag):
    #print "df[searchtag]", df[searchtag]
    searcher= process.extractOne(search, df[searchtag])
    if len(searcher)>0:
        searchres= df[df[searchtag]==searcher[0]]["novaid"]
        return searchres[searchres.index[0]]
    
    

    

def  contactFuzzyMatch(pd1 , pd2):
    pdlist=[]
    for index , row in pd1.iterrows():
        rowlist=[]
        fFirstNamelis=pd2[pd2['FirstName']==row['FirstName']]["novaid"]
        if len(fFirstNamelis)>0:
            print "in first eact" 
            rowlist.append(fFirstNamelis[fFirstNamelis.index[0]])
        else:
            eFirstNamelis=pd2[pd2['Email']==row['Email']]["novaid"]
            if len(eFirstNamelis)>0:
                #print "in email exact"
                rowlist.append(eFirstNamelis[eFirstNamelis.index[0]])
            else:pass
#                pFirstNamelis=pd2[pd2['Phonenumber']==row['phonenumber']]["FirstName"]
#                if len(pFirstNamelis)>0:
#                    rowlist.append(pFirstNamelis[pFirstNamelis.index[0]])
                    
        if len(rowlist)==0:
            print "in fuzzmatch"
            namefuzzymatch=fuzzymatch(row['FirstName'], pd2 ,'FirstName')
            if len(namefuzzymatch) >0:
                rowlist.append(namefuzzymatch)
                
        if len(rowlist)==0:        
            emailfuzzymatch=fuzzymatch(row['Email'], pd2 ,'Email')
            if len(emailfuzzymatch)> 0:
                print "email fuzzy"
                rowlist.append(emailfuzzymatch)
                
#        if len(rowlist)==0:  
#            phfuzzymatch=fuzzymatch(row['Phonenumber'], pd2 ,'Phonenumber')
#            if len(phfuzzymatch)>0:
#                rowlist.append(phfuzzymatch)
        
        pdlist.append(rowlist)
        
    return pdlist



testdf = pd.DataFrame([['File1',	'Diane',	'Diane Filer',	'dianefiler@remax.net1',	'72634e26-f6e6-4a99-85a2-bae19782fdad']],columns = label)
#print type(testdf)
print contactFuzzyMatch (testdf  ,df)
        
       
                
                
    
    