# -*- coding: utf-8 -*-
"""
Created on Wed Mar 28 19:20:41 2018

@author: manoj
"""



from scipy.spatial import ConvexHull
import numpy as np 
import pandas as pd

import matplotlib.pyplot as plt




#points = np.random.rand(30, 2)   # 30 random points in 2-D

points=np.array([[29.834136000000001, -81.497883000000002], [36.833188999999997, -119.735212], [37.777861999999999, -122.252335], [47.321004000000002, -122.96754799999999], [39.370901000000003, -74.603206], [29.834136000000001, -81.497883000000002]])
points=np.array([[36.857148, -119.720551],
 [36.801583, -119.651922],
 [36.847163, -119.891374],
 [36.823011, -119.890832],
 [36.856482, -119.771351],
 [36.801583, -119.651922],
 [36.849928, -119.775066],
 [36.879, -119.746438],
 [36.832951, -119.872272],
 [36.855545, -119.757407],
 [36.849928, -119.775066],
 [36.738847, -119.7804],
 [36.879938, -119.769541],
 [36.818806, -119.867514],
 [36.860839, -119.719737],
 [36.82036, -119.870312],
 [36.812305, -119.664548],
 [36.871042, -119.746832],
 [36.824957, -119.876418],
 [36.676639, -119.861832]])
 


points=np.array([[36.763038, -119.731004],
 [36.730813, -119.720134],
 [36.785166, -119.786319],
 [36.72108, -119.691109],
 [36.824161, -119.788619],
 [36.742096, -119.766413]])
 
 
points=np.array([[36.833691000000002, -119.670277], 
[36.850411999999999, -119.780266],
 [36.843228000000003, -119.74335000000001],
 [36.798926999999999, -119.678307]])
 


#points = np.random.rand(30, 2)

#print points  

               
#hull = ConvexHull(points)
#
#
#minDiffDict={}
#plt.plot(points[:,0], points[:,1], 'o')
#for simplex in hull.simplices:
#    #print points[simplex,0][0] , points[simplex, 1][0] ,"  "  ,points[simplex,0][1] , points[simplex, 1][1]
#    plt.plot(points[simplex, 0], points[simplex, 1], 'k-')
#    x=points[simplex,0][0]
#    y=points[simplex, 1][0] 
#    x1=points[simplex,0][1]
#    y1=points[simplex, 1][1]
#    first_point="{0}{1}".format(x,y)
#    sec_point="{0}{1}".format(x1,y1)
#    if minDiffDict.get(first_point)==None:
#        minDiffDict[first_point]=[x,y]
#    if minDiffDict.get(sec_point)==None:
#        minDiffDict[sec_point]=[x1,y1]
#    
#print  minDiffDict.values()  
    
label=["latitude","longitude"]
df = pd.DataFrame(points, columns=label)
print df[['latitude','longitude']]
#hull = ConvexHull(df[['latitude','longitude']])
#minDiffDict={}
#for simplex in hull.simplices:
#    for x,y in zip(df['latitude'].iloc[simplex], df['longitude'].iloc[simplex]):
#        one_way="{0}{1}".format(x,y)
#        print x,y
#        #plt.plot(x, y, 'k-')
#        if minDiffDict.get(one_way)==None:
#            minDiffDict[one_way]=[x,y]


#print  "values", minDiffDict.values()                          
    
def convex_hull(points):
        points = sorted(set(points))
        if len(points) <= 1:
            return points
        def cross(o, a, b):
            return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    
        # Build lower hull 
        lower = []
        for p in points:
            while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0:
                lower.pop()
            lower.append(p)
    
        # Build upper hull
        upper = []
        for p in reversed(points):
            while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0:
                upper.pop()
            upper.append(p)
        return lower[:-1] + upper[:-1]
        
points=[[36.857148, -119.720551],
 [36.801583, -119.651922],
 [36.847163, -119.891374],
 [36.823011, -119.890832],
 [36.856482, -119.771351],
 [36.801583, -119.651922],
 [36.849928, -119.775066],
 [36.879, -119.746438],
 [36.832951, -119.872272],
 [36.855545, -119.757407],
 [36.849928, -119.775066],
 [36.738847, -119.7804],
 [36.879938, -119.769541],
 [36.818806, -119.867514],
 [36.860839, -119.719737],
 [36.82036, -119.870312],
 [36.812305, -119.664548],
 [36.871042, -119.746832],
 [36.824957, -119.876418],
 [36.676639, -119.861832]]   


points=[[36.763038, -119.731004],
 [36.730813, -119.720134],
 [36.785166, -119.786319],
 [36.72108, -119.691109],
 [36.824161, -119.788619],
 [36.742096, -119.766413]]

                #ll.append(ll[0]) 
lis=[]   
for name , group in df[['latitude','longitude']].iterrows():
    lis.append([group['latitude'] ,group['longitude']])
print lis
#print convex_hull(map(lambda x: tuple(x) ,points))        
        