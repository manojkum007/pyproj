# -*- coding: utf-8 -*-
"""
Created on Fri Mar 16 00:47:31 2018

@author: manoj
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.spatial  import ConvexHull
import json
import csv
import luigi
from luigi.contrib.hdfs.hadoopcli_clients import HdfsClient

from luigi.hive import HiveTableTarget, run_hive_cmd
import collections
from collections import OrderedDict
import Es_Pusher
import requests
from elasticsearch import Elasticsearch



df = pd.DataFrame({'longitude':np.random.randn(10),
                   'latitude':np.random.randn(10), 
                   'mls_id':np.arange(0, 10, 1)%3})
#print "df", df

#
#
#   col3     col_1     col_2
#0     0 -1.206982  1.464869
#3     0 -0.185861  0.371531
#6     0  1.376490  1.192432
#9     0 -0.377444 -0.039022
#   col3     col_1     col_2
#1     1 -0.125678  1.049136
#4     1 -0.444426 -0.041401
#7     1  0.998594 -0.292926
#   col3     col_1     col_2
#2     2  1.536789  3.134619
#5     2  0.113859  0.239927
#8     2 -0.632913 -0.767156


#print df.groupby('col3').groups


res=run_hive_cmd("set mapred.job.queue.name=low;select novaid,firstname,lastname,language_preference__c, sale_price,mobilephone,email,listagentcount,saleagentcount,min_sales,max_sales,avg_sales,median_sales ,latitude,longitude,property_type from brokerage.convexhull_compute where novaid ='50f9157d-4500-451a-ae9d-403ec5a82330';")

#print res
#res=run_hive_cmd("set mapred.job.queue.name=low;select novaid,firstname,lastname,language_preference__c, sale_price,mobilephone,email,listagentcount,saleagentcount,min_sales,max_sales,avg_sales,median_sales ,latitude,longitude,property_type from brokerage.convexhull_compute;")

#res=run_hive_cmd("set mapred.job.queue.name=low;select  nova_id, latitude,longitude from brokerage.convexhull_compute_text where nova_id  ='f5d959d3-4b6e-4fb0-a235-13a1dea9830a'")


#
#res="""e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	30.248401	-81.390134	CONDO
#e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	36.099318	-94.10909	SINGLE_FAMILY_HOUSE
#e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	35.105391	-106.544584	SINGLE_FAMILY_HOUSE
#e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	39.270607	-74.978999	SINGLE_FAMILY_HOUSE
#e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	NULL	NULL	SINGLE_FAMILY_HOUSE
#e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	39.794858	-84.254733	SINGLE_FAMILY_HOUSE
#e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	48.98071	-123.04399	SINGLE_FAMILY_HOUSE
#e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	35.734188	-83.479168	SINGLE_FAMILY_HOUSE
#e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	39.406177	-84.369984	SINGLE_FAMILY_HOUSE
#e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	35.572636	-97.540209	SINGLE_FAMILY_HOUSE
#e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	NULL	NULL	SINGLE_FAMILY_HOUSE
#e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	36.307923	-94.282296	SINGLE_FAMILY_HOUSE
#e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	35.60207	-82.866885	SINGLE_FAMILY_HOUSE
#e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	39.756514	-105.003171	CONDO
#e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	39.406177	-84.369984	SINGLE_FAMILY_HOUSE
#e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	39.976278	-105.267181	SINGLE_FAMILY_HOUSE
#e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	36.864930	-119.766169	SINGLE_FAMILY_HOUSE
#e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	41.637464	-81.448483	SINGLE_FAMILY_HOUSE
#e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	35.058908	-106.739366	CONDO
#e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	35.50447	-96.724653	SINGLE_FAMILY_HOUSE
#e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	39.794858	-84.254733	SINGLE_FAMILY_HOUSE
#e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	39.680634	-84.11101	SINGLE_FAMILY_HOUSE
#e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	34.528638	-117.307954	SINGLE_FAMILY_HOUSE
#e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	35.724436	-84.248741	SINGLE_FAMILY_HOUSE
#e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	NULL	NULL	SINGLE_FAMILY_HOUSE
#e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	37.321885	-119.665404	SINGLE_FAMILY_HOUSE
#e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	0.000000	0.000000	CONDO
#e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	30.209865	-81.545033	CONDO
#e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	47.160921	-122.590413	SINGLE_FAMILY_HOUSE
#e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	36.307923	-94.282296	SINGLE_FAMILY_HOUSE
#e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	35.23992	-97.435505	SINGLE_FAMILY_HOUSE
#e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	33.46934	-86.792298	SINGLE_FAMILY_HOUSE
#e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	36.790542	-119.648163	SINGLE_FAMILY_HOUSE
#e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	36.099318	-94.10909	SINGLE_FAMILY_HOUSE
#e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	NULL	NULL	CONDO
#e53a66d3-2814-4ef4-b001-00af991d89b0	Jo	Mcdaniel	English	NULL	678-794-7773	jomcdaniel@bellsouth.net	3	NULL	NULL	NULL	NULL	NULL	39.680634	-84.11101	SINGLE_FAMILY_HOUSE
#"""

ll=map(lambda r : r.split("\t"),res.split("\n"))
ll.pop()

for i in ll:
    if len(i)<3:
        print i
#print ll
#label=['novaid','latitude', 'longitude']

label=["novaid","firstname","lastname","language_preference__c"," sale_price","mobilephone","email","listagentcount","saleagentcount","min_sales","max_sales","avg_sales","median_sales", "latitude","longitude","property_type"]
    
df = pd.DataFrame(ll, columns=label)

#df=df.fillna(0)



#print df.dtypes
#print df

newdf =df[df['latitude'].notnull() & (df['latitude'] != "") & (df['latitude'] != "NULL") ]
ultranewdf =newdf[newdf['longitude'].notnull() & (newdf['longitude'] != "") & (newdf['longitude'] != "NULL")]
ultranewdf['latitude']=ultranewdf.latitude.astype(float) 
ultranewdf['longitude']=ultranewdf.longitude.astype(float) 
ultranewdf= ultranewdf[ultranewdf['latitude']>0]


def convex_hull(points):
    """Computes the convex hull of a set of 2D points.

    Input: an iterable sequence of (x, y) pairs representing the points.
    Output: a list of vertices of the convex hull in counter-clockwise order,
      starting from the vertex with the lexicographically smallest coordinates.
    Implements Andrew's monotone chain algorithm. O(n log n) complexity.
    """

    # Sort the points lexicographically (tuples are compared lexicographically).
    # Remove duplicates to detect the case we have just one unique point.
    points = sorted(set(points))

    # Boring case: no points or a single point, possibly repeated multiple times.
    if len(points) <= 1:
        return points

    # 2D cross product of OA and OB vectors, i.e. z-component of their 3D cross product.
    # Returns a positive value, if OAB makes a counter-clockwise turn,
    # negative for clockwise turn, and zero if the points are collinear.
    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])

    # Build lower hull 
    lower = []
    for p in points:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)

    # Build upper hull
    upper = []
    for p in reversed(points):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)

    # Concatenation of the lower and upper hulls gives the convex hull.
    # Last point of each list is omitted because it is repeated at the beginning of the other list. 
    return lower[:-1] + upper[:-1]
    
    
    
def panda_calc(df):
    agent_convex_lis=[]
    for name, group  in df.groupby('novaid'): 
        maindict={}
        try: 
            newdf=df.groupby('novaid').get_group(name)
            if len(newdf)<3:
                continue
            #print newdf
            hull = ConvexHull(newdf[['latitude','longitude']])
            minDiffDict={}
            for simplex in hull.simplices:
                #plt.plot(df['latitude'].iloc[simplex], df['longitude'].iloc[simplex], 'k-')
                for x,y in zip(df['latitude'].iloc[simplex], df['longitude'].iloc[simplex]):
                    one_way="{0}{1}".format(x,y)
                    if minDiffDict.get(one_way)==None:
                        minDiffDict[one_way]=[x,y]
            lis=[]
            data=convex_hull(map(lambda x: tuple(x) ,minDiffDict.values()))
            #ll.append(ll[0])
            lis= map(lambda x: [x[1],x[0]] ,data)
            lis.append(lis[0])
            
            maindict['boundary']=lis
            
            maindict['novaid']=name
            firstname=list(set(list(group['firstname'])))
            if len(firstname)>0:
                maindict['firstname']=str(firstname[0])
            
            lastname=list(set(list(group['lastname'])))
            if len(lastname)>0:
                maindict['lastname']=str(lastname[0])
            
            language=list(set(list(group['language_preference__c'])))
            if len(language)>0:
                maindict['language']=str(language[0])
            
            mobilephone=list(set(list(group['mobilephone'])))
            if len(mobilephone)>0:
                maindict['mobilephone']=str(mobilephone[0])
            
            email=list(set(list(group['email'])))
            if len(email)>0:
                maindict['email']=str(email[0])
            
            listagent=filter(lambda x: x.lower().find('null'),list(set(list(group['listagentcount']))))
            if len(listagent)>0:
                maindict['listagentcount']=int(listagent[0])
            else:
                maindict['listagentcount']=int(0)
                
            
            saleagent=filter(lambda x: x.lower().find('null'),list(set(list(group['saleagentcount']))))
            if len(saleagent)>0:
                maindict['saleagentcount']=int(saleagent[0])     
            else:
                maindict['saleagentcount']=int(0)
            
            minsales=filter(lambda x: x.lower().find('null'),list(set(list(group['min_sales']))))
            if len(minsales)>0:
                maindict['min_sales']= float(minsales[0]) 
            else:
                maindict['min_sales']=float(0)
            
            maxsales=filter(lambda x: x.lower().find('null'),list(set(list(group['max_sales']))))
            if len(maxsales)>0:
                maindict['max_sales']= float(maxsales[0]) 
            else:
                maindict['max_sales']=float(0)
            
            avgsales=filter(lambda x: x.lower().find('null'),list(set(list(group['avg_sales']))))
            if len(avgsales)>0:
                maindict['avg_sales']= float(avgsales[0])
            else:
                maindict['avg_sales']=float(0)
            
            medianSales=filter(lambda x: x.lower().find('null'),list(set(list(group['median_sales']))))
            if len(medianSales)>0:
                maindict['median_sales']=float(medianSales[0]) 
            else:
                maindict['median_sales']=float(0)
            
            property_type=list(set(list(group['property_type'])))
            if len(property_type)>0:
                maindict['property_type']=property_type
            agent_convex_lis.append(maindict)
        except Exception as e:
            print "some exception" , name ,e
    return agent_convex_lis



#data= pd.DataFrame([panda_calc(ultranewdf)])



#res=run_hive_cmd("set mapred.job.queue.name=low;select  nova_id,firstname,lastname,name,language,mls,mls_id,sale_price,phone,mobilephone,homephone,otherphone,email,alt_email__c,alt_name__c,latitude,longitude,property_type,min_sales,max_sales,avg_sales,median_sales from brokerage.convexhull_compute_grouped where nova_id is not null;")

datalis=panda_calc(ultranewdf)

#print data
#
#df = pd.DataFrame([data], columns=data.keys())
#print "dataframe" ,len(df

es = Elasticsearch([{'host': '192.168.120.17' , 'port': 9200}])
esobj=Es_Pusher.EsPush(es ,'test' , 'testgeom')
bulkrow=esobj.results_to_es(datalis)

#bulkrow=[{"agent_id__c": "7bc2dd67-7a72-4cf4-936a-bd571c7b7d87", "convexhull": "[[30.205003000000001, -81.629272], [34.373795000000001, -117.28135899999999], [41.633152000000003, -81.467993000000007], [39.372239999999998, -74.451250999999999], [30.212247999999999, -81.379665000000003], [39.488126000000001, -74.688502999999997], [48.748157999999997, -122.452455], [37.725704, -122.457016], [30.205003000000001, -81.629272]]"}]

#print "bulkrow",bulkrow
Es_Pusher.elastic_search_pusher( '192.168.120.17', 9200 , 'brokerage2', 'agent', bulkrow)


#Es_Pusher.elastic_search_pusher( '192.168.120.17', 9200 , 'megacorp', 'employee', bulkrow)
#ll=[]
#for key,v in data.iteritems():
#    ll.append([key,v])
#
#label=['nova_id','convex']
#
#convexdf = pd.DataFrame(ll, columns=label)



#with open('convex_nova_data.json', 'w') as outfile:
#    for key,v in data.iteritems():
#        writer = csv.writer(outfile, lineterminator='\n' , delimiter = ';')
#        writer.writerow([key]+[v])
    
#with open('convex_nova_data.json', 'w') as outfile:
#    json.dump(data, outfile)

#brokerage.agent_convex_data

#newdict={}
#def assigndict(cur,lis,val,single):
#    if len(val)>0:
#        if len(lis)==1:
#            if (single==0):
#                cur[lis[0]]=val[0]
#            else:
#                cur[lis[0]]=val
#            return
#        else:
#            if not cur.has_key(lis[0]):
#                cur[lis[0]]=collections.OrderedDict()
#            assigndict(cur[lis[0]],lis[1:],val,single)
#            
#            
#
#
#newdict={}            
#for key,v in data.iteritems():
#    #assigndict(newdict ,[key,"boundary"] ,["hello"],0)
#    assigndict(newdict, [key,"boundary","types"], ["multipolygon"], 0)
#    assigndict(newdict, [key,"boundary","coordinates"], [[v]], 1)
          
#with open('convex_nova_id.json', 'w') as outfile:
#    json.dump(newdict, outfile)
