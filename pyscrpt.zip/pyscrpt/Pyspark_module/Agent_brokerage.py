# -*- coding: utf-8 -*-
"""
Created on Mon Mar 19 00:54:37 2018

@author: manoj
"""
import os
import datetime
import csv
import luigi
from luigi.contrib.hdfs.hadoopcli_clients import HdfsClient
from luigi.hive import HiveTableTarget, run_hive_cmd
import pandas as pd
from scipy.spatial  import ConvexHull
import json
import sys
import numpy as np
import collections
from collections import OrderedDict
import requests


#os.environ['SPARK_HOME']='/opt/spark/python/'


sys.path.append('/opt/spark/python/')
sys.path.append('/opt/spark/python/lib/py4j-0.10.1-src.zip')
#sys.path.append('/home/manoj/anaconda2/lib/python2.7/site-packages')
#print sys.path

# Spark libraries
#from pyspark import SparkConf, SparkContext
#from pyspark import SparkContext, SparkConf, HiveContext
from pyspark.sql import SparkSession
from pyspark.sql import Row
import pyspark.sql.functions as F
from pyspark.sql.functions import trim
from pyspark.sql.functions import col, asc


##internal library 
import postgresql
import Es_Pusher



def assigndict(cur,lis,val,single):
    if len(val)>0:
        if len(lis)==1:
            if (single==0):
                cur[lis[0]]=val[0]
            else:
                cur[lis[0]]=val
            return
        else:
            if not cur.has_key(lis[0]):
                cur[lis[0]]=collections.OrderedDict()
            assigndict(cur[lis[0]],lis[1:],val,single)
            

luigi_config = luigi.configuration.get_config()
        
                    



class FraudContactLoading(luigi.Task):
    get_all = luigi.Parameter(default='ALL')
    run_date = luigi.DateParameter(default = datetime.date.today()-datetime.timedelta(days=1))
    fips_list = luigi.Parameter(default='ALL')    
    
    
    def requires(self):
         pass
    
    def run(self):
        try:
            fraudfilename="Listing_agent.txt"
            config = luigi.configuration.get_config()
            tiger_host = config.get('Tigerdb', 'host')
            tiger_user = config.get('Tigerdb', 'user')
            tiger_database = config.get('Tigerdb', 'database')
            tiger_password = config.get('Tigerdb', 'password')
            tiger_port= config.get('Tigerdb', 'port')
            
            pgres=postgresql.DataBaseConnector(host=tiger_host,  database=tiger_database, usrname=tiger_user, passwrd=tiger_password,port=tiger_port ,driver='postgresql')
            sql=""" select agent_id_movoto
                    	,agent_id_mls
                    	,mls
                    	,mls_id
                    	,list_agent_id
                    	,sell_agent_id
                    	,sale_price,
                    	state_code,
                    	city
                    	,role_list_agent
                    	,role_sale_agent 
                    from 
                    (
                    	SELECT agent_id_movoto
                    		,a.agent_id_mls
                    		,l.mls
                    		,l.mls_id
                    		,l.list_agent_id
                    		,l.sell_agent_id
                    		,l.sale_price,
                    		o.state_code,
                    		o.city
                    		,CASE WHEN (list_agent_id=agent_id_mls) THEN 1 END AS role_list_agent
                    		,CASE WHEN (sell_agent_id=agent_id_mls) THEN 1 END AS role_sale_agent
                    		,ROW_NUMBER() OVER (PARTITION BY agent_id_movoto ,concat(l.mls,l.mls_id) ORDER BY agent_id_movoto) AS rowid
                    	FROM fraud.agents_matched a
                    	LEFT JOIN mls_all.listings l
                    		ON a.mls_id = l.mls
                    		AND ((l.list_agent_id = a.agent_id_mls AND l.list_office_id = a.office_id)
                    		OR (l.sell_agent_id = a.agent_id_mls AND l.sell_office_id = a.office_id))
                    	LEFT JOIN mls_all.offices o
                    		ON a.office_id = o.office_id
                    		AND a.mls_id = o.mlsid
                    	WHERE o.city = 'fresno'
                    	AND o.state_code = 'ca' 
                    	AND match_score >= 2
                    )  tmp
                    where rowid = 1
                """ 
                
                
            sql=""" select 
                   agent_id_movoto
                		,agent_id_mls
                		,mls
                		,mls_id
                		,list_agent_id
                		,sell_agent_id
                		,sale_price
                          	,address
                           ,address_unit
                           ,listing_city
                           ,state_code
                           ,zip
                           ,list_price
                           ,office_address
                           ,office_city
                           ,office_state
                           ,office_zip
                		,movoto_full_name
                		,mls_full_name
                                    	,role_list_agent
                                    	,role_sale_agent 
                from 
                (
                	SELECT  a.agent_id_movoto
                		,a.agent_id_mls
                		,l.mls
                		,l.mls_id
                		,l.list_agent_id
                		,l.sell_agent_id
                		,l.sale_price
                          	,l.address
                           ,l.address_unit
                           ,l.city as listing_city
                           ,l.state_code
                           ,l.zip
                           ,l.list_price
                            ,address1  as office_address
                           ,l.city  as office_city
                           ,l.state_code  as office_state
                           ,zipcode  as office_zip
                		,movoto_full_name
                		,mls_full_name
                		,CASE WHEN (list_agent_id=agent_id_mls) THEN 1 END AS role_list_agent
                		,CASE WHEN (sell_agent_id=agent_id_mls) THEN 1 END AS role_sale_agent
                		,ROW_NUMBER() OVER (PARTITION BY agent_id_movoto ,concat(l.mls,l.mls_id) ORDER BY agent_id_movoto ) AS rowid
                	FROM (	SELECT *,
                	ROW_NUMBER() OVER (PARTITION BY agent_id_movoto ORDER BY match_score DESC) rn
                	FROM fraud.agents_matched  )a
                INNER JOIN mls_all.offices o
                ON a.mls_id = o.mlsid
                AND o.office_id = a.office_id
                AND rn = 1
                INNER JOIN mls_all.listings l
                		ON a.mls_id = l.mls
                		AND ((l.list_agent_id = a.agent_id_mls AND l.list_office_id = a.office_id)
                		OR (l.sell_agent_id = a.agent_id_mls AND l.sell_office_id = a.office_id) )
                where  o.state_code = 'ca'
                AND o.city IN ('fresno','clovis','fowler','del rey','raisin city','biola','madera','selma','parlier','caruthers','sanger','prather','friant','piedra','reedley','riverdale','burrel','laton','kerman','kingsburg','san joaquin','tollhouse','o neals','dinuba','traver','sultana','auberry','orange cove','coarsegold','helm','tranquillity','hanford','squaw valley','armona','lemoore','cutler','visalia','orosi','five points','yettem','goshen','cantua creek','chowchilla','raymond','huron','wishon','big creek','north fork','dunlap','miramonte','bass lake','ivanhoe','ahwahnee','le grand','woodlake')
                AND match_score >= 2  
                ) tmp
                where tmp.rowid = 1"""
            data=pgres.execQuery(sql)
            pgres.writeDataFile(fraudfilename, data ,"\t")
            
            pgres.loadToStagingTable("brokerage", "final_agent_agg")
        except Exception as e:
            print "Problem due to  %s",e
        
      
      
      #####################Laoding conatct Test table################################33
        contactfilename="contact_test.txt"
        puma_host = config.get('Pumadb', 'host')
        puma_user = config.get('Pumadb', 'user')
        puma_database = config.get('Pumadb', 'database')
        puma_password = config.get('Pumadb', 'password')
        puma_port= config.get('Pumadb', 'port')
        
        
        try: 
            puma=postgresql.DataBaseConnector(puma_host, puma_user, puma_password, puma_database , puma_port, "puma") 
            sql="""select FirstName ,LastName ,Name ,Language_Preference__c ,Phone , MobilePhone ,       HomePhone ,       OtherPhone , Email , Agent_ID__c ,       Alt_Email__c ,       Alt_Name__c ,       Zip_Code__c   FROM sf_raw.dbo.Contact  where Contact_Type__c like '%agent%'""" 
            data=puma.execQuery(sql)
            puma.writeDataFile(contactfilename, data ,"\t")
            puma.loadToStagingTable("brokerage", "contact_test")
        except Exception as e:
            print "Problem due to  %s",e
            sys.exit()
        
        with self.output().open('w') as f:
            f.write('{word}\n'.format(word='BigqueryExporter'))
        
        
    def output(self):
        return luigi.LocalTarget(path='FraudContactLoading_%s.txt'%self.run_date.strftime('%Y-%m-%d'))
         
                    

class BrokegaeAnlaytics(luigi.Task):
    get_all = luigi.Parameter(default='ALL')
    run_date = luigi.DateParameter(default = datetime.date.today()-datetime.timedelta(days=1))
    fips_list = luigi.Parameter(default='ALL')
    

    def requires(self):
        yield [FraudContactLoading(get_all=self.get_all,fips_list=self.fips_list )]
    


    def run(self):
        try:
            #eshost=luigi_config.get('Elastic', 'host')
            print "starting program"
            
            spark = SparkSession.builder.appName("brokerage").config("hive.metastore.warehouse.dir", "/tmp/").config("spark.sql.crossJoin.enable", "true").enableHiveSupport().getOrCreate()
            
            print "running spark program"
            
            listingdf=spark.read.parquet("/user/hive/warehouse/mls.db/mls_listing")
            
            contact_df=spark.table("brokerage.contact_test")
            list_agent_df=spark.table("brokerage.final_agent_agg")         
            addrdf=spark.read.parquet("/user/hive/warehouse/mls.db/address")
            
            listingdf.registerTempTable("listing")
            list_agent_df.registerTempTable("list_agent")
            new_list_agent_df=spark.sql("""select c1.novaid,c1.agent_id_mls ,c1.mls,c1.mls_id,c1.list_agent_id,c1.sell_agent_id,c1.sale_price, 
                                        c1.state_code, c1.listing_city ,c1.role_list_agent, c1.role_sale_agent ,  tmp.listagentcount ,tmp.saleagentcount, tmp.total_transaction, tmp.min_sales  , tmp.max_sales ,  tmp.avg_sales  ,tmp.median_sales from  brokerage.final_agent_agg  c1 inner join   (select novaid, sum(role_list_agent) as listagentcount, sum(role_sale_agent) as saleagentcount, count(*) as total_transaction, min(sale_price) as min_sales,max(sale_price)  as max_sales ,avg(sale_price) as   avg_sales  ,percentile(sale_price,0.5) as median_sales  from brokerage.final_agent_agg  group by  novaid) tmp  on c1.novaid =tmp.novaid""")
            new_list_agent_df.registerTempTable("new_list_agent")
            contact_df.registerTempTable("contact")
            addrdf.registerTempTable("addr")
            
            mls_contact_list_agent_joined_df =spark.sql("""SELECT la.novaid ,con.firstname , con.lastname ,
            con.Language_Preference__c , la.sale_price,con.MobilePhone,con.Email,la.mls ,la.mls_id, la.state_code, la.listing_city, la.listagentcount ,la.saleagentcount, la.total_transaction,
            la.min_sales  , la.max_sales ,  la.avg_sales  ,la.median_sales from contact con inner join  new_list_agent la  on la.novaid=con.Agent_ID__c""")
            
            mls_contact_list_agent_joined_df.registerTempTable("merged_table")
            
            print "register table spark program"
            
            
            mls_mapping_df=spark.table("brokerage.mlsname_mapping")
            mls_mapping_df.registerTempTable("mls_mapping")
            
            mls_mapped_newdf= spark.sql( """SELECT fa.*, Concat(fa.mls_id, COALESCE(Cast(mlscode AS INT), '')) AS mlsindetifier FROM   merged_table fa INNER JOIN mls_mapping mp ON fa.mls = mp.mlsname""")
            mls_mapped_newdf.registerTempTable("final_merged_table")
            
            #mls_movoto_joined_df=spark.sql("""select la.*, a.latitude, a.longitude  , att.name  as property_type from merged_table la inner join listing l on la.mls_id = l.mls_number inner join addr a  on l.mls_address_id =a.id and la.state_code=a.state and la.city=a.city inner join mls.attribute  att on att.id = l.property_type""")
            
            #mls_movoto_joined_df=spark.sql("""select la.*, a.latitude, a.longitude ,a.state, a.city as address_city, att.name  as property_type from merged_table la inner join listing l on la.mls_id = l.mls_number inner join addr a  on l.mls_address_id =a.id  inner join mls.attribute  att on att.id = l.property_type""")
            
            #mls_movoto_joined_df=spark.sql("""select la.*, a.latitude, a.longitude ,a.state, a.city as address_city, att.name  as property_type from final_merged_table la inner join listing l on (la.mlsindetifier = l.mls_number or  la.mlsindetifier = Concat(l.mls_number,l.mls_id))  inner join addr a  on l.mls_address_id =a.id  inner join mls.attribute  att on att.id = l.property_type""")
            
            mls_movoto_joined_df=spark.sql("""select la.*, a.latitude, a.longitude ,a.state, a.city as address_city, att.name  as property_type from final_merged_table la inner join listing l on  la.mlsindetifier = Concat(l.mls_number,l.mls_id) inner join addr a  on l.mls_address_id =a.id  inner join mls.attribute  att on att.id = l.property_type""")
            
#            mls_movoto_joined_df.registerTempTable("final_merged_table")
#            mls_movoto_joined_new_df= spark.sql("""select * from final_merged_table where state like '%ca%' and address_city  like '%fresno%'""")
#            mls_movoto_joined_new_df.printSchema()
            
            #final_df=mls_movoto_joined_df.filter(F.upper(col("state")).isin(F.upper(col("state_code"))) & F.lower(col("address_city")).isin(F.lower(col("city"))))
            final_df=mls_movoto_joined_df.filter(F.upper(col("state")).isin(F.upper(col("state_code"))))
            #df = mls_movoto_joined_df.withColumn("newstate", trim(mls_movoto_joined_df.state)).withColumn("newaddress_city", trim(mls_movoto_joined_df.address_city))
            
            final_df.write.mode('overwrite').saveAsTable('brokerage.convexhull_compute')
        except Exception as e:
            print "Problem due to  %s",e
            sys.exit()
        spark.stop()
        
        
        with self.output().open('w') as f:
            f.write('{word}\n'.format(word='BrokegaeAnlaytics'))
        
        
    def output(self):
        return luigi.LocalTarget(path='BrokegaeAnlaytics_%s.txt'%self.run_date.strftime('%Y-%m-%d'))



class Agent_ConvexhullCalulator(luigi.Task):
    get_all = luigi.Parameter(default='ALL')
    run_date = luigi.DateParameter(default = datetime.date.today()-datetime.timedelta(days=1))
    fips_list = luigi.Parameter(default='ALL')
    
    def requires(self):
        yield [BrokegaeAnlaytics(get_all=self.get_all,fips_list=self.fips_list )]
    
    def run(self):
        
        try:
            #print "running hive query"
            res=run_hive_cmd("set mapred.job.queue.name=low;select novaid,firstname,lastname,language_preference__c, sale_price,mobilephone,email,listagentcount,saleagentcount,total_transaction ,min_sales,max_sales,avg_sales,median_sales ,latitude,longitude,property_type from brokerage.convexhull_compute  where novaid not in ('bf64b310-63d2-4f7c-9ea6-52d0985dc35a') order by novaid;")
            #res=run_hive_cmd("set mapred.job.queue.name=low;select novaid,firstname,lastname,language_preference__c, sale_price,mobilephone,email,listagentcount,saleagentcount,total_transaction ,min_sales,max_sales,avg_sales,median_sales ,latitude,longitude,property_type from brokerage.convexhull_compute  where novaid in ('00cbbddc-839f-4881-aac8-e0189e231635','a5eb8af0-9036-467a-9360-016fbbf4a343') order by novaid;")          
            #where novaid ='bf64b310-63d2-4f7c-9ea6-52d0985dc35a' 'bf64b310-63d2-4f7c-9ea6-52d0985dc35a' ,
            print "result" ,res
            ll=map(lambda r : r.split("\t"),res.split("\n"))
            ll.pop()
            label=["novaid","firstname","lastname","language_preference__c"," sale_price","mobilephone","email","listagentcount","saleagentcount","total_transaction", "min_sales","max_sales","avg_sales","median_sales", "latitude","longitude","property_type"]
                
            df = pd.DataFrame(ll, columns=label)
            
            newdf =df[df['latitude'].notnull() & (df['latitude'] != "") & (df['latitude'] != "NULL") ]
            ultranewdf =newdf[newdf['longitude'].notnull() & (newdf['longitude'] != "") & (newdf['longitude'] != "NULL")]
            ultranewdf['latitude']=ultranewdf.latitude.astype(float) 
            ultranewdf['longitude']=ultranewdf.longitude.astype(float) 
            ultranewdf= ultranewdf[ultranewdf['latitude']>0]
            print "ultranedf" ,ultranewdf
            datalis=self.panda_calc(ultranewdf)
            print datalis
            #es = Elasticsearch([{'host': '192.168.120.17' , 'port': 9200}])
            #host , port, indexname, doctype
            esobj=Es_Pusher.EsPush('192.168.120.17' ,9200 , 'brokerage2', 'agent' )
            bulkrow=esobj.results_to_es(datalis)
            
            esobj.elastic_search_pusher(bulkrow)
            
        except Exception as e:
            print "Problem due to  %s",e
        
        with self.output().open('w') as f:
            f.write('{word}\n'.format(word='Agent_ConvexhullCalulator'))


    def convex_hull(self, points):
        points = sorted(set(points))
        if len(points) <= 1:
            return points
        def cross(o, a, b):
            return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    
        # Build lower hull 
        lower = []
        for p in points:
            while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0:
                lower.pop()
            lower.append(p)
    
        # Build upper hull
        upper = []
        for p in reversed(points):
            while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0:
                upper.pop()
            upper.append(p)
        return lower[:-1] + upper[:-1]
    
    
    
    def panda_calc(self, df):
        agent_convex_lis=[]
        for name, group  in df.groupby('novaid'): 
            try: 
                maindict={}
                newdf=df.groupby('novaid').get_group(name)
                if len(newdf)<3:
                    continue
                templis=[]   
                for ind , grp in newdf[['latitude','longitude']].iterrows():
                    templis.append([grp['latitude'] ,grp['longitude']])
                
                data=self.convex_hull(map(lambda x: tuple(x) ,templis))
                #ll.append(ll[0])
                lis= map(lambda x: [x[1],x[0]] ,data)
                lis.append(lis[0])
                
#                hull = ConvexHull(newdf[['latitude','longitude']])
#                minDiffDict={}
#                for simplex in hull.simplices:
#                    for x,y in zip(df['latitude'].iloc[simplex], df['longitude'].iloc[simplex]):
#                        one_way="{0}{1}".format(x,y)
#                        if minDiffDict.get(one_way)==None:
#                            minDiffDict[one_way]=[x,y]
#                            
#                print name, "scipy convex" ,minDiffDict.values()
#                data=self.convex_hull(map(lambda x: tuple(x) ,minDiffDict.values()))
#                #ll.append(ll[0])
#                lis= map(lambda x: [x[1],x[0]] ,data)
#                lis.append(lis[0])
                
                
                print name,"convex lis" ,lis
                maindict['novaid']=name
                maindict['boundary']=lis
                print  "boundary", maindict['boundary']
                firstname=list(set(list(group['firstname'])))
                if len(firstname)>0:
                    maindict['firstname']=str(firstname[0])
                
                lastname=list(set(list(group['lastname'])))
                if len(lastname)>0:
                    maindict['lastname']=str(lastname[0])
                
                language=list(set(list(group['language_preference__c'])))
                if len(language)>0:
                    maindict['language']=str(language[0])
                
                mobilephone=list(set(list(group['mobilephone'])))
                if len(mobilephone)>0:
                    maindict['mobilephone']=str(mobilephone[0])
                
                email=list(set(list(group['email'])))
                if len(email)>0:
                    maindict['email']=str(email[0])
                
                listagent=filter(lambda x: x.lower().find('null'),list(set(list(group['listagentcount']))))
                if len(listagent)>0:
                    maindict['listagentcount']=int(listagent[0])
                else:
                    maindict['listagentcount']=int(0)
                    
                
                saleagent=filter(lambda x: x.lower().find('null'),list(set(list(group['saleagentcount']))))
                if len(saleagent)>0:
                    maindict['saleagentcount']=int(saleagent[0])     
                else:
                    maindict['saleagentcount']=int(0)
                
                
                totaltrans=filter(lambda x: x.lower().find('null'),list(set(list(group['total_transaction']))))
                if len(totaltrans)>0:
                    maindict['totaltransaction']=int(totaltrans[0])     
                else:
                    maindict['totaltransaction']=int(0)
                
                minsales=filter(lambda x: x.lower().find('null'),list(set(list(group['min_sales']))))
                if len(minsales)>0:
                    maindict['min_sales']= float(minsales[0]) 
                else:
                    maindict['min_sales']=float(0)
                
                maxsales=filter(lambda x: x.lower().find('null'),list(set(list(group['max_sales']))))
                if len(maxsales)>0:
                    maindict['max_sales']= float(maxsales[0]) 
                else:
                    maindict['max_sales']=float(0)
                
                avgsales=filter(lambda x: x.lower().find('null'),list(set(list(group['avg_sales']))))
                if len(avgsales)>0:
                    maindict['avg_sales']= float(avgsales[0])
                else:
                    maindict['avg_sales']=float(0)
                
                medianSales=filter(lambda x: x.lower().find('null'),list(set(list(group['median_sales']))))
                if len(medianSales)>0:
                    maindict['median_sales']=float(medianSales[0]) 
                else:
                    maindict['median_sales']=float(0)
                
                property_type=list(set(list(group['property_type'])))
                if len(property_type)>0:
                    maindict['property_type']=property_type
                    
                agent_convex_lis.append(maindict)
            except Exception as e:
                print "some exception" , name ,e
        return agent_convex_lis
    
    
    
    def output(self):
        return luigi.LocalTarget(path='Agent_ConvexhullCalulator_%s.txt'%self.run_date.strftime('%Y-%m-%d'))



if __name__ == "__main__":
    luigi.run()
    
    