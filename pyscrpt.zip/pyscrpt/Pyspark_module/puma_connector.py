# -*- coding: utf-8 -*-
"""
Created on Wed Mar 14 12:27:57 2018

@author: manoj
"""

import pymssql
import csv
#import sys
#sys.setdefaultencoding('utf8')

class Puma_connector

def writeDataFile(mlsFile,lisdata):
    with open(mlsFile, 'w') as log_file:
        writer = csv.writer(log_file, delimiter='\t')
        try:
            for row in lis:
                 row=map(lambda t: t.encode('utf-8') if (type(t)==str or type(t)==unicode) else t,row)
                 writer.writerow(row)
        except Exception as e:
            print row


conn = pymssql.connect('192.168.120.139', 'sa', 'igen', 'sf_raw') 
cur = conn.cursor()

sql="""select top 10  Id, LastName, FirstName, Salutation, "Name", OtherStreet, OtherCity,
OtherState, OtherPostalCode, OtherCountry, MailingStreet, MailingCity, MailingState, MailingPostalCode, 
MailingCountry, Phone, Fax, MobilePhone, HomePhone, OtherPhone, AssistantPhone, ReportsToId, Email, Title, 
Department, AssistantName, LeadSource, Birthdate, Description, OwnerId, DoNotCall, CreatedDate, CreatedById,
LastModifiedDate, LastModifiedById, SystemModstamp, LastActivityDate, Agent_ID__c, Alt_Email__c, Alt_Name__c, Zip_Code__c 
FROM sf_raw.dbo.Contact  where Contact_Type__c like '%agent%'"""
res=cur.execute(sql)

lis=[]          
for row in cur:
    lis.append(row)

conn.close()
 
writeDataFile("puma.txt", lis)





