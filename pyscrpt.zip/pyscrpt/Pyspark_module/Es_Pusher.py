# -*- coding: utf-8 -*-
"""
Created on Sat Mar 17 16:58:41 2018

@author: manoj
"""


from multiprocessing.dummy import Pool as ThreadPool
import json
from multiprocessing import Process
from elasticsearch import Elasticsearch
import luigi
import pandas as pd

import datetime
from datetime import date, timedelta
import collections
import requests
from luigi.hive import HiveTableTarget, run_hive_cmd

def assigndict(cur,lis,val,single):
    if len(val)>0:
        if len(lis)==1:
            if (single==0):
                cur[lis[0]]=val[0]
            else:
                cur[lis[0]]=val
            return
        else:
            if not cur.has_key(lis[0]):
                cur[lis[0]]=collections.OrderedDict()
            assigndict(cur[lis[0]],lis[1:],val,single)
            




class EsPush:
    def __init__(self ,host , port, indexname, doctype):
        self.host=host
        self.port=port
        self.indexname=indexname
        self.doctype=doctype

    def esinsert(self, rowlis):
        self.es.index(index=self.indexname, doc_type=self.doctype, body=json.dumps(rowlis))
            
    def es_fetch_data(self,table_name):
        es_select_qry="select agent_id__c, firstname from  brokerage.convexhull_final  limit 10;"
        res=run_hive_cmd(es_select_qry)
        data= """7bc2dd67-7a72-4cf4-936a-bd571c7b7d87\t[[30.205003000000001, -81.629272], [34.373795000000001, -117.28135899999999], [41.633152000000003, -81.467993000000007], [39.372239999999998, -74.451250999999999], [30.212247999999999, -81.379665000000003], [39.488126000000001, -74.688502999999997], [48.748157999999997, -122.452455], [37.725704, -122.457016], [30.205003000000001, -81.629272]]\tFredy\tGonzalez\tEnglish;Spanish\t818-689-3471\tfredycsmia@hotmail.com\tSINGLE_FAMILY_HOUSE\t174000\t670000\t331911.76470588235\t230000.0\n47f9daca-069b-4629-bb40-bb758fc07810\t[[36.848750000000003, -119.761072], [39.637096999999997, -84.648572000000001], [39.025874999999999, -86.506118999999998], [36.195193000000003, -94.170553999999996], [39.342301999999997, -75.038978999999998], [35.685409, -82.571490999999995], [39.385537999999997, -75.022103000000001], [35.539363000000002, -84.779791000000003], [36.457866000000003, -94.342350999999994], [35.826931999999999, -84.179636000000002], [35.100042999999999, -106.500365], [36.366455000000002, -94.297807000000006], [36.848750000000003, -119.761072]]\tJames\tRJ\tEnglish\t770-558-7000\trichard.johnson12@kw.com\tCO
                    NDO\t61500\t770000\t289653.0585106383\t235000.0\n7d37c990-1943-4169-87f5-faf257c901a5\t[[36.848750000000003, -119.761072], [30.205003000000001, 
                    -81.629272], [35.285823000000001, -79.031143], [39.488126000000001, -74.688502999999997], [30.354801999999999, -81.677865999999995], [35.5055090
                    00000004, -82.366454000000004], [47.249220999999999, -122.43465500000001], [41.233091999999999, -74.274158999999997], [47.781644999999997, -122.
                    209425], [39.028790000000001, -86.510597000000004], [36.848750000000003, -119.761072]]\tJohan\tLopez\tEnglish;Spanish;Russian;Arabic\t978-804-7425\tjohan0922@gmail.com\tSINGLE_FAMILY_HOUSE\t57000\t319000\t132804.1958041958\t105000.0\n07c3c67e-e124-4140-ae5b-ae01524dc2c1\t[[35.936087999999998, -84.016108000000003], [37.660724999999999, -122.422096], [36.337805000000003, -94.119073999999998], [35.691595, -82.588048999999998], [34.759200999999997, -117.347734], [41.770803000000001, -93.584785999999994], [36.217461, -94.155422000000002], [35.431600000000003, -82.466442000000001], [39.488126000000001, -74.688502999999997], [36.890858000000001, -119.770326], [41.603033000000003, -93.672505000000001], [36.795751000000003, -119.883342], [39.289805999999999, -86.756743999999998], [35.931961999999999, -84.078112000000004], [39.607545000000002, -84.145146999999994], [35.539617999999997, -97.539153999999996], [35.936087999999998, -84.016108000000003]]\tChristopher\tLadd\tEnglish\t239-898-8113\tchristopher@ckladd.com\tSINGLE_FAMILY_HOUSE\t38000\t550000\t241350.198019802\t219000.0\nf64cc1be-1af3-4102-b4bd-85861c54db17\t[[47.261034000000002, -122.28318400000001], [38.766106000000001, -90.708206000000004], [35.075536999999997, -106.65497999999999], [39.864564999999999, -84.295215999999996], [47.261034000000002, -122.28318400000001]]\tStephanie\tMoss\tEnglish\t949-338-1824\tstephanie@mossglobal.com\tSINGLE_FAMILY_HOUSE\t530000\t530000\t530000.0\t530000.0\nebfc0694-e188-4a9c-993d-9ecf53886e7b\t[[39.762796999999999, -84.103429000000006], [39.359195, -74.580672000000007], [39.029964999999997, -86.519468000000003], [35.399597, -79.159851000000003], [39.528236999999997, -74.641892999999996], [39.346851000000001, -74.462340999999995], [35.499383999999999, -97.627996999999993], [35.495378000000002, -82.557790999999995], [36.195998000000003, -94.107905000000002], [39.888812000000001, -84.203585000000004], [39.784098, -84.215525999999997], [35.124814000000001, -106.561404], [39.607545000000002, -84.145146999999994], [35.278132999999997, -106.699867], [39.762796999999999, -84.103429000000006]]\tGreg\tMaroot\tEnglish\t559-994-0254\tgmaroot@pemproperties.com\tSINGLE_FAMILY_HOUSE\t21500\t2404506\t203970.61321909426\t165000.0\n95e7305f-c0cb-45ab-8b01-c52e4401a658\t[[36.848750000000003, -119.761072], [36.804188000000003, -119.66286599999999], [47.261034000000002, -122.28318400000001], [35.053080999999999, -106.750984], [36.113442999999997, -94.080582000000007], [41.628638000000002, -93.829088999999996], [35.539363000000002, -84.779791000000003], [30.354801999999999, -81.677865999999995], [36.978520000000003, -119.40979900000001], [39.668467, -84.250787000000003], [35.349172000000003, -81.968464999999995], [41.521383999999998, -74.066283999999996], [36.848750000000003, -119.761072]]\tMichelle\tBragg\tEnglish\t661-609-8163\tmichellebraggrealtor@gmail.com\tCONDO\t260000\t1220813\t566639.2867647059\t445000.0\n86fa9eda-a755-42c8-8c26-ff184208b9a2\t[[39.025874999999999, -86.506118999999998], [47.261034000000002, -122.28318400000001], [41.633152000000003, -81.467993000000007], [38.766106000000001, -90.708206000000004], [39.417079000000001, -74.583123999999998], [39.723211999999997, -84.195368000000002], [39.025874999999999, -86.506118999999998]]\tVincent\tChen\tEnglish;Mandarin\t626-354-8180\tvincentchen@remax.net\tSINGLE_FAMILY_HOUSE\t169000\t205000\t185800.0\t169000.0\n689c26dd-5e55-41d3-afce-14d3fce65099\t[[36.901488999999998, -119.75492], [33.707462, -86.659267], [41.626930000000002, -93.623198000000002], [35.114927999999999, -106.709272], [35.290750000000003, -106.595282], [39.762796999999999, -84.103429000000006], [35.352849999999997, -106.68975], [35.326231, -82.421882999999994], [36.890858000000001, -119.770326], [41.690818999999998, -93.804807999999994], [39.132404999999999, -86.506066000000004], [30.164114000000001, -81.62191], [36.901488999999998, -119.75492]]\tMarc\tContreras\tEnglish;Spanish\t512-897-3242\tmarc@buenavistaproperties.net\tSINGLE_FAMILY_HOUSE\t83000\t485000\t213394.95798319328\t190000.0\nc650410d-4d69-4920-b156-fc3b801fec57\t[[36.843370999999998, -119.777987], [36.819482000000001, -119.817003], [39.637096999999997, -84.648572000000001], [35.781063000000003, -83.954329000000001], [39.678162, -84.256478000000001], [39.953336, -84.054813999999993], [35.505509000000004, -82.366454000000004], [47.249220999999999, -122.43465500000001], [37.725704, -122.457016], [34.124209, -80.887478000000002], [41.521383999999998, -74.066283999999996], [36.843370999999998, -119.777987]]\tJohn\tJohnson\tEnglish\t(678) 584-3777\tjohnj@theclient1statl.com\tSINGLE_FAMILY_HOUSE\t60000\t390000\t207684.90566037735\t180000.0\n'
                    """

        ll=map(lambda r : r.split("\t"), data.split("\n"))
        ll.pop()
        for row in ll:pass
            
            
        
    
    def results_to_es(self ,lisdf): 
        rowlis=[]
        for ddict in lisdf:
            print ddict
            row={}
            #row['agent_id__c']= v['agent_id__c']
            #row['convexhull']=  v['convexhull']
            assigndict(row, ["novaId"], [ddict["novaid"]], 0)
            assigndict(row, ["firstName"], [ddict["firstname"]], 0)
            assigndict(row, ["lastName"], [ddict["lastname"]], 0)
            assigndict(row, ["language"], [ddict["language"]], 0)
            assigndict(row, ["mobilephone"], [ddict["mobilephone"]], 0)
            assigndict(row, ["email"], [ddict["email"]], 0)
            assigndict(row, ["listagentrole"], [ddict["listagentcount"]], 0)
            assigndict(row, ["saleagentrole"], [ddict["saleagentcount"]], 0)
            assigndict(row, ["totalTransaction"], [ddict["totaltransaction"]], 0)
            assigndict(row, ["propertyType"], [ddict["property_type"]], 0)
            assigndict(row, ["minSales"], [ddict["min_sales"]], 0)
            assigndict(row, ["maxSales"], [ddict["max_sales"]], 0)
            assigndict(row, ["avgSales"], [ddict["avg_sales"]], 0)
            assigndict(row, ["medianSales"], [ddict["median_sales"]], 0)
            assigndict(row, ["boundary","type"], ["polygon"], 0)
            assigndict(row, ["boundary","coordinates"], [ddict['boundary']], 1)
            rowlis.append(row)
        
        return rowlis
 
    def multiprocess_espush(self, datalis):
        pool = ThreadPool(1)
        pool.map(self.esinsert, datalis)
        pool.close()
        pool.join() 
    
    def elastic_search_pusher(self, payload):
        for datacontent in payload:
            url = "http://%s:%s/%s/%s/%s"%(self.host, self.port, self.indexname, self.doctype, datacontent['novaId'])      
            headers = {    'content-type': "application/json",
                           'cache-control': "no-cache" }
            response = requests.request("PUT", url, data=json.dumps(datacontent), headers=headers)
            print "response" ,response.text
        
        





    def job_status_to_es(self, start_time, end_time, task_successful, error_message, task_name):
        es_host ='192.168.120.21'
        es_host ='192.168.120.17'
        es_port =9200
        jobstatus_index = 'megacorp'
        #/testbulk
                
        es = Elasticsearch([{'host': es_host, 'port': es_port}])
                
        es_doc = dict()
        es_doc['start_time'] = start_time.strftime('%Y-%m-%dT%H:%M:%S.000Z')
        es_doc['end_time'] = end_time.strftime('%Y-%m-%dT%H:%M:%S.000Z')
        es_doc['@timestamp'] = start_time.strftime('%Y-%m-%dT%H:%M:%S.000Z')
        es_doc['year'] = start_time.year
        es_doc['month'] = start_time.month
        es_doc['monthname'] = start_time.strftime('%b')
        es_doc['day'] = start_time.day
        es_doc['runtime'] = (end_time - start_time).seconds
        es_doc['successful'] = 1 if task_successful else 0
        es_doc['error_message'] = error_message
        es_doc['luigi_task_name'] = task_name
        try:
            print es_doc
            es.index(index=jobstatus_index, doc_type=task_name, body=es_doc)
        except Exception as e:
            print e
        #es.index(index=jobstatus_index, doc_type=task_name, body=json.dumps(es_doc), timestamp=es_doc['@timestamp'])
        print "successfull inserted"
    
