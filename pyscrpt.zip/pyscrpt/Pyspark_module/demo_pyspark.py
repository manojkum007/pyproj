# -*- coding: utf-8 -*-
"""
Created on Tue Mar 13 16:00:07 2018

@author: manoj
"""
#from __future__ import print_function
import sys
import os


sys.path.append('/usr/local/spark/python/')
sys.path.append('/usr/local/spark/python/pyspark/')

sys.path.append('/usr/local/spark/python/lib/py4j-0.10.1-src.zip')
sys.path.append('/home/manoj/anaconda2/lib/python2.7/site-packages')
os.environ['SPARK_HOME']='/usr/local/spark/python'
os.environ['PYTHONPATH']='/usr/local/spark/python'
print os.environ

from pyspark import SparkContext, SparkConf
#, HiveContext
#from pyspark.sql.functions import col
#from pyspark.sql.functions import lit
#import pyspark.sql.functions as F
from pyspark.sql import SQLContext
from pyspark.storagelevel import StorageLevel
conf = SparkConf().setAppName('es').setMaster("local[*]")
#sc = SparkContext(conf=conf)
##sqc = SQLContext(sc)
#txtfile=sc.textFile("/home/manoj/logs/test.txt")
#
#txtfile.take(1)

