# -*- coding: utf-8 -*-
"""
Created on Mon Feb 15 11:05:25 2016

@author: manoj
"""

import psycopg2 as mdb
import csv
from luigi.hive import HiveTableTarget, run_hive_cmd
import pymssql

import sys
reload(sys)
sys.setdefaultencoding('utf8')


class DataBaseConnector :
    def __init__(self, host,  usrname, passwrd, database, port, driver):
        self.host=host
        self.username=usrname
        self.password=passwrd
        self.database=database
        self.port=port
        self.command= ""
        self.path=""
        self.con=""
        self.driver=driver
        if (self.connect()==0):
            exit(1)
                      
    def connect(self ):
        
        try:      
            print "trying conected"
            if self.driver=="postgresql":
                self.con = mdb.connect(database=self.database, user=self.username, password=self.password, host=self.host, port=self.port)
                return 1
            elif self.driver=="puma":
                self.con = pymssql.connect(self.host, self.username, self.password, self.database) 
                return 1
            print "connected " ,self.driver
        except Exception as e:
            print "Unable to connect to  %s: %s" %(self.drive,e)
            return 0

    def execQuery(self,command):
        
        try:
            lis=""
            if self.driver=="postgresql":
                self.cur=self.con.cursor()
                self.cur.execute(command)
                lis= self.cur.fetchall()
                self.cur.close()         
                
            elif self.driver=="puma":
                self.cur = self.con.cursor()
                self.cur.execute(command)
                lis=[]          
                for row in self.cur:
                    lis.append(row)
           ## print "lis is ", lis       
            return lis
        except  Exception as e:
            print "error in executing sql statement",e
            #self.con.rollback()
            return 0
    
    def execmanyQuery(self,lis):
        with self.con.cursor() as cursor:
            for i in lis:
                cursor.execute(i)
                yield cursor.fetchall()
                
    def writeDataFile(self,filepath, lisdata, delimiterchar):
        try:
            self.path=filepath
            with open(self.path, 'w') as filwriter:
                writer = csv.writer(filwriter, delimiter=delimiterchar)
                for row in lisdata:
                    writer.writerow(row)
        except Exception as e:
            print "Unable to write row in file ",e
            exit(1)
        
            
 
   
    def loadToStagingTable(self,database, table):
        try:
            if self.path=="":
                raise IOError
            target = HiveTableTarget(table=table,database=database).exists()
            if (target==True):
                loadcommand="""LOAD DATA local INPATH '%s' OVERWRITE INTO TABLE %s.%s;"""%(self.path, database, table)
                run_hive_cmd(loadcommand)
            else:
                raise Exception
        except Exception as e:
            print "Unable to load file to table ",e
            

        
        


#    def __del__(self):
#       # self.con.close()
#        print "closing connection"

#pgres=DataBaseConnector(host='192.168.120.137',  database='Realestate', usrname='census', passwrd='censuspassword',port=5432 ,driver='postgresql')
##
#sql="""	 	 select agent_id_movoto
#	,agent_id_mls
#	,mls
#	,mls_id
#	,list_agent_id
#	,sell_agent_id
#	,sale_price,
#	state_code,
#	city
#	,role_list_agent
#	,role_sale_agent 
#from 
#(
#	SELECT agent_id_movoto
#		,a.agent_id_mls
#		,l.mls
#		,l.mls_id
#		,l.list_agent_id
#		,l.sell_agent_id
#		,l.sale_price,
#		o.state_code,
#		o.city
#		,CASE WHEN (list_agent_id=agent_id_mls) THEN 1 END AS role_list_agent
#		,CASE WHEN (sell_agent_id=agent_id_mls) THEN 1 END AS role_sale_agent
#		,ROW_NUMBER() OVER (PARTITION BY agent_id_movoto ,concat(l.mls,l.mls_id) ORDER BY agent_id_movoto) AS rowid
#	FROM fraud.agents_matched a
#	LEFT JOIN mls_all.listings l
#		ON a.mls_id = l.mls
#		AND ((l.list_agent_id = a.agent_id_mls AND l.list_office_id = a.office_id)
#		OR (l.sell_agent_id = a.agent_id_mls AND l.sell_office_id = a.office_id))
#	LEFT JOIN mls_all.offices o
#		ON a.office_id = o.office_id
#		AND a.mls_id = o.mlsid
#	WHERE o.city = 'fresno'
#	AND o.state_code = 'ca' 
#	AND match_score >= 2
#)  tmp
#where rowid = 1
#""" 
##
#data=pgres.execQuery(sql)
##print "data" ,data
#pgres.writeDataFile("Listing_agent.txt", data ,"\t")



#
#puma=DataBaseConnector('192.168.120.139', 'sa', 'igen', 'sf_raw' ,1433, "puma") 
#
#sql="""select FirstName ,LastName ,Name ,Language_Preference__c ,Phone , MobilePhone ,       HomePhone ,       OtherPhone , Email , Agent_ID__c ,       Alt_Email__c ,       Alt_Name__c ,       Zip_Code__c   FROM sf_raw.dbo.Contact  where Contact_Type__c like '%agent%'""" 
#
#data=puma.execQuery(sql)
#puma.writeDataFile("contact_test.txt", data ,"\t")



