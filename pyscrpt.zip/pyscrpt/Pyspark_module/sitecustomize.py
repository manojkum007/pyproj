# -*- coding: utf-8 -*-
"""
Created on Thu Jun  2 20:43:00 2016

@author: manoj
"""

import sys
sys.setdefaultencoding('utf8')
