# -*- coding: utf-8 -*-
"""
Created on Fri May 20 19:32:25 2016

@author: manoj
"""



import psycopg2




_host= "localhost"
_database="postgres"
_user="postgres"
_password='admin'





conn = psycopg2.connect(host=_host, dbname=_database, user=_user, password=_password)
cur = conn.cursor()
query = "SELECT MAX(deed_id) FROM deeds.all_deeds"


 

for i in range(5):
    try:
        query= "insert into deeds.all_deeds (fips , bkfs_internal_pid,deed_id)  values ('01087',%s,%s)"%(int(i*89),i*56)
        
        cur.execute(query)
        conn.commit()
   # deed_id = cur.fetchall()[0][0] or 0
    except psycopg2.Error as e:
        print "Error in executing database query  : ",e.pgerror
    
    


conn.close()