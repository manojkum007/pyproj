# -*- coding: utf-8 -*-
"""
Created on Sat Feb 17 00:40:59 2018

@author: manoj
"""

ll=[1,2]

def  generatperm(ll):
    if len(ll)==2:
        a=ll[1:]
        b=ll[:1]
        a.extend(b)
        print a
        return None
    else:
        print generatperm(ll[1:]),ll[:1]
        

def  generatperm1(ll,newlis=[]):
    for i in range(len(ll)):
        #newlis.append(ll[:i]+ ll[i+1:])
        a=ll[:i]+ ll[i+1:]
        print a
        newlis.append([ll[i]]+generatperm1(a))
        print newlis
#print ll
print generatperm1(ll)