# -*- coding: utf-8 -*-
"""
Created on Wed Jul 11 15:54:14 2018

@author: manoj
"""

from multiprocessing.dummy import Pool as ThreadPool

def squareNumber(n , something="man"):
    print something
    return n ** 2

# function to be mapped over
def calculateParallel(numbers, something, threads=2):
    pool = ThreadPool(threads)
    results = pool.map(squareNumber,  numbers ,something )

    pool.close()
    pool.join()
    return results

if __name__ == "__main__":
    numbers = [1, 2, 3, 4, 5]
    squaredNumbers = calculateParallel(numbers, "man" , 4)
    for n in squaredNumbers:
        print(n)
        