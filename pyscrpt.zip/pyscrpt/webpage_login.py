# -*- coding: utf-8 -*-
"""
Created on Thu Jun 30 10:44:55 2016

@author: manoj
"""


import re
from mechanize import Browser

br = Browser()
br.open("https://login.uber.com/login")
br.select_form(name="order")
# Browser passes through unknown attributes (including methods)
# to the selected HTMLForm (from ClientForm).
br["cheeses"] = ["mozzarella", "caerphilly"]  # (the method here is __setitem__)
response = br.submit()  # submit current form


https://login.uber.com/login