# -*- coding: utf-8 -*-
"""
Created on Fri Aug  4 16:52:28 2017

@author: manoj
"""
distinctuserid=[12,23,56,89,20,55,89]
print len(distinctuserid)
page=2
def execute_query():
    minoid,maxoid=0,len(distinctuserid)
    for oid in range(minoid,maxoid,page):
        lisqry=distinctuserid[oid:oid+page] 
        print "oid" ,oid
        if oid==2:
            yield lisqry


d=execute_query()

for i in d:
    print i
            