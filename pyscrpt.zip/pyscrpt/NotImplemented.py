# -*- coding: utf-8 -*-
"""
Created on Thu Nov  2 20:25:38 2017

@author: manoj
"""

class BaseClass(object):
    """Defines the interface"""
    def __init__(self):
        super(BaseClass, self).__init__()
    def do_something(self):
        """The interface, not implemented"""
        raise NotImplementedError(self.__class__.__name__ + '.do_something')


class SubClass(BaseClass):
    """Implementes the interface"""
#    def do_something(self):
#        """really does something"""
#        print self.__class__.__name__ + ' doing something!'
        
        
b=SubClass()
#b.do_something()
    