# -*- coding: utf-8 -*-
"""
Created on Sun Jan  8 21:59:50 2017

@author: manoj
"""

def is_called():
    def is_returned():
        print "Hello"
    return is_returned

new = is_called()


print new()
#Outputs "Hello"
#print new 