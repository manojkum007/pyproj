# -*- coding: utf-8 -*-
"""
Created on Mon Aug 14 13:16:14 2017

@author: manoj
"""

try:
    import impyla 
except ImportError:
    print("Installing missing impyla")
    import pip
    pip.main(['install', '--no-deps', 'impyla'])

try:
    import thrift_sasl
except ImportError:
    print("Installing missing thrift_sasl")
    import pip
    # need a patched version of thrift_sasl.  see https://github.com/cloudera/impyla/issues/238
    pip.main(['install', '--no-deps',  'git+https://github.com/snowch/thrift_sasl'])