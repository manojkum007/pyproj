# -*- coding: utf-8 -*-
"""
Created on Sat Jul 29 12:10:52 2017

@author: manoj
"""

class Demo:
    noninst=0
    
    def __init__(self):
        self.inst=12
    
    def display(self):
        print "number",self.inst
        
    @classmethod
    def class_modifier(cls):
        cls.noninst=100
        return cls.noninst
    
    def class_modifier1(self):
        Demo.noninst=100
        return Demo.noninst


#d=Demo()
##print "object",d.__dict__
##print "class",Demo.__dict__
#Demo.noninst=45
#print Demo.noninst
##d.display()
##d.noninst=40
#print d.noninst
#print "before",Demo.noninst
##print Demo.class_modifier()
#d.class_modifier1()
#print "after",Demo.noninst

class UniqueIdentifier(object):

    value = 0

    def __init__(self, name):
        self.name = name

    @classmethod
    def produce(cls):
        cls.value+=1
        return cls.value
#        instance = cls(cls.value)
#        cls.value += 1
#        return instance
        
#u=UniqueIdentifier("mao")      
#print u.value 
#print u.produce()
#print u.value 




class A(object):
    def foo(self,x):
        print "executing foo(%s,%s)"%(self,x)

    @classmethod
    def class_foo(cls,x):
        print "executing class_foo(%s,%s)"%(cls,x)

    @staticmethod
    def static_foo(x):
        print "executing static_foo(%s)"%x    

a=A()
x=23

print a.foo(x)
print a.class_foo(x)



#class Pizza:
#    def __init__(self,s):
#        self.size=s
#    def get_size(self):
#        return self.size
        
        
#print "pizaa size",Pizza.get_size()
#p=Pizza()
#print "instance" ,p.get_size



class Pizza(object):
    pizzacost = 80
    def __init__(self, r):
        self.radius=r

    @classmethod
    def get_radius(cls):
        return cls.pizzacost
        
    @staticmethod
    def retainer(x,y):
        return  x+y
        
        
  
print "pizzabefore ", Pizza.get_radius()      
p=Pizza(40)
#print "pizza", p.get_radius()
#
#p1=Pizza(50)
#print "anathoer pizza", p1.get_radius()
#
#print "pizzaafter", Pizza.get_radius() 

print Pizza.__dict__

print "object",p.__dict__

print p.retainer(5,6)
        