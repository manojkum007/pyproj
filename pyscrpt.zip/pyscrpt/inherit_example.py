# -*- coding: utf-8 -*-
"""
Created on Sun Jul  9 22:25:02 2017

@author: manoj
"""



class Complex:
 
    # Constructor
    def __init__(self, real, imag):
       self.real = real
       self.imag = imag
 
    # For call to repr(). Prints object's information
    def __repr__(self):
       return 'Rational(%s, %s)' % (self.real, self.imag)    
 
    # For call to str(). Prints readable form
    def __str__(self):
       return '{0} + i{1}'.format(self.real, self.imag)    
 
 
# Driver program to test above
t = Complex(10, 20)
 
print str(t)  # Same as "print t"
#print repr(t)



class Parent:
    def __init__(self):
        self.surname="sharma"
        self.__gender=None
    
    def __str__(self):
        return "{0} is {1}".format(self.surname ,self.gender)
    
    @property
    def gender(self):
        return self.__gender
        
    
    @gender.setter
    def gender(self,gen):
        self.__gender=gen
        
        
        
        
#
p=Parent()
#p.setgender='Male'
print p.gender
p.gender ="Male"
print p.gender
print str(p)      
        
class child(Parent):
    
    def __init__(self, name):
        self.cnmae=name
        
        