# -*- coding: utf-8 -*-
"""
Created on Wed Aug  3 17:19:58 2016

@author: manoj
"""
import luigi

class MyTask(luigi.Task):
    def run(self):
        # set a tracking url
        #self.set_tracking_url("http://...")

        # set status messages during the workload
        for i in range(100):
            # do some hard work here
            if i % 10 == 0:
                self.set_status_message("Progress: %d / 100" % i)