# -*- coding: utf-8 -*-
"""
Created on Thu Nov 17 20:06:50 2016

@author: manoj
"""

import json
import gzip
import os

#path='/home/manoj/scripts/tiger_analyatics/rhino/logs/getstat/'

path='/home/mkumar/getstattasks/data/yearly/feb_nov/'
s_data=[]
outfile = open("/home/mkumar/getstattasks/febdata_2015.json", "wb")
json_files=[] 


for f in os.listdir(path):
    with gzip.open(path+f, 'rb') as data_file:    
        input_data = json.loads(data_file.read().decode("ascii"))        
        print "reading file"
    json_files=[] 
    datecnt=0
    print "read completed"
    site_data=input_data["Response"]["Project"]["Site"]
    print type(site_data)
    if isinstance(site_data,dict):
        s_data.append(site_data)
    if isinstance(site_data,list):
        s_data=site_data
        
    
    for site in s_data:
        site_id= site['Id']
        print "site_id",site_id
        print "no of keyword",len(site['Keyword'])
        
        for keyword_data in site["Keyword"]:
            if keyword_data["KeywordTags"] is None:
                keyword_tag=''
            else :
                keyword_tag=keyword_data["KeywordTags"]
            #keyword_data["Keyword"]=keyword_data["Keyword"].replace('"','')
            keyword_details='"site_id" : "'+site_id+'", "key_id" : "'+keyword_data["Id"]+'", "keyword" : "'+keyword_data["Keyword"]+'","keywordTags" : "'+keyword_tag+'"'
            results=keyword_data["Ranking"]
            
            if results["Google"]["Rank"]!="N/A":
                datecnt+=1
#                print results["date"]
                data=json.dumps(results, ensure_ascii=False)
                data2='{"Response" : '+data+','+keyword_details+'}'
                json_files.append(data2)

print json_files[0]  ,datecnt 

#
output_data='\n'.join(json_files)
outfile.write(output_data.encode('latin'))  
outfile.close()
        
#            for site in site_data:
#                if isinstance(site,dict):
#                    site_id= site['Id']
#                    site_keyword=site["Keyword"]
#                if isinstance(site,str):
#                    site_id= site
#                    site_keyword=site["Keyword"]
#                    
#                    
#            for keyword_data in site_["Keyword"]:                    
#                if keyword_data["KeywordTags"] is None:
#                    keyword_tag=''
#                else :
#                    keyword_tag=keyword_data["KeywordTags"]
#                keyword_details='"site_id" : "'+site_id+'", "key_id" : "'+keyword_data["Id"]+'", "keyword" : "'+keyword_data["Keyword"]+'","keywordTags" : "'+keyword_tag+'"'
#                results=keyword_data["Ranking"]
#                
#                if results["Google"]["Rank"]!="N/A":
#                    data=json.dumps(results, ensure_ascii=False)
#                    data2='{"Response" : '+data+','+keyword_details+'}'
#                    json_files.append(data2)
                    

#print data2