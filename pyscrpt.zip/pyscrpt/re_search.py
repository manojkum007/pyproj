# -*- coding: utf-8 -*-
"""
Created on Tue Feb 16 15:31:21 2016

@author: manoj
"""
import re

line = "Query returned successfully with no result in 192 ms.";

matchObj = re.search( r'successfully', line)
if matchObj:
    print "match --> matchObj.group() : ", matchObj.group()
else:
    print "No match!!"
