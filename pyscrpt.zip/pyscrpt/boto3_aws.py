# -*- coding: utf-8 -*-
"""
Created on Tue Aug 22 19:14:21 2017

@author: manoj
"""

import boto3
ACCESS_KEY= 'AKIAIFE3BPFVJ5FGNR3A'
SECRET_KEY= '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'
        
        
#client = boto3.client(
#    's3',
#    aws_access_key_id=ACCESS_KEY,
#    aws_secret_access_key=SECRET_KEY
#)
        
    

#print client.list_objects()

BUCKET = "parsely-dw-mashable"

# s3 client
s3 = boto3.resource('s3')

# s3 bucket
bucket = s3.Bucket(BUCKET)

# all events in hour 2016-06-01T00:00Z
prefix = "events/2016/06/01/00"

# pretty-print the first 3 objects
files = bucket.objects.filter(Prefix=prefix)
print(list(files)[:3])