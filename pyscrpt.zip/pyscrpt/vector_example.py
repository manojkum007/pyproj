# -*- coding: utf-8 -*-
"""
Created on Sun Jun 11 15:12:50 2017

@author: manoj
"""

class vector:
    def __init__(self,x,y):
        self.x=x
        self.y=y
        
    def __repr__(self):
        return 'vector {0} {1}'.format(self.x ,self.y)
        
    def __iter__(self):
        return (repr(i)  for i in (self.x ,self.y))
        
        
        

v=vector(4,5)
#print v
for i in v:
    print i
        