# -*- coding: utf-8 -*-
"""
Created on Tue Aug 22 16:13:47 2017

@author: manoj
"""

import luigi
from luigi.s3 import S3Target, S3Client

#luigi.s3.S
class A(luigi.Task):
    def output(self):pass
#        access_key = 'AKIAIFE3BPFVJ5FGNR3A'
#        access_secret = 'kc8ic228yxxd4gSTQIjhZqjW65BzGVvQp58Ajo1e'
        #client = S3Client(access_key, access_secret, host='localhost', port=4572)
        #return S3Target('s3://fake/test', client=client)

    def run(self):
        access_key = 'AKIAIFE3BPFVJ5FGNR3A'
        access_secret = 'kc8ic228yxxd4gSTQIjhZqjW65BzGVvQp58Ajo1e'
        print "trying to connect S3 bucket"
        client = S3Client(access_key, access_secret, proxy='127.0.0.1', proxy_port=8080, is_secure=False)
        print " path exists" ,client.exists('s3a://recruit-redshift.movoto.com/loading/mls.mls_102/')
        s3a://recruit-redshift.movoto.com/bb-input/20170820/mls.property_history_updated/
             /recruit-redshift.movoto.com/bb-input/20170820/mls.property_history_updated/
        #s3a://recruit-redshift.movoto.com/bb-input/
#        with self.output().open('w') as f:
#            f.write('test')