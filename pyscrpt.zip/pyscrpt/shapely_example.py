# -*- coding: utf-8 -*-
"""
Created on Fri Aug  5 10:34:51 2016

@author: manoj
"""

#import shapely
from shapely.geometry  import *

#from shapely.geometry import MultiPolygon
#
#from shapely.geometry import Polygon

p = Point(0.5, 0.5)

print(p)

poly = Polygon( ((0, 0), (0, 1), (1, 1), (0, 0))   )

mpoly = MultiPolygon( ((0, 0), (0, 1), (1, 1), (0, 0)) ,
                      ((5, 5), (6,5), (6, 6), (5, 5))                     
                    )

#print help(mpoly)
print mpoly.bounds
print p.within(poly)
