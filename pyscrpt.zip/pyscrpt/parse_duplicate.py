# -*- coding: utf-8 -*-
"""
Created on Mon Jun 27 12:41:12 2016

@author: manoj
"""

import re


fw=open('/home/manoj/scripts/tiger_analyatics/deeds_error/output2.csv','w')

with open('/home/manoj/scripts/tiger_analyatics/deeds_error/output1.csv', 'r') as pfile:
    for line in pfile:
        #print line
        #matchObj = re.match(r'(.*) duplicate', line, re.M|re.I)
        #matchObj = re.match(r'(.*)record  totally', line, re.M|re.I)
        matchObj = re.match(r'(.*)/(\d+_Deed.*\.txt)', line, re.M|re.I)
        
        if matchObj:
            #print matchObj.group(2)
            fw.write(matchObj.group(2))
            fw.write("\n")
        
#        if matchObj:pass
#           # print matchObj.group(0)
#        else:
#            fw.write(line)

fw.close()
        #break


#line = "Cats are smarter than dogs"
#
#matchObj = re.match( r'(.*) are (.*?) .*', line, re.M|re.I)
#
#if matchObj:
#   print "matchObj.group() : ", matchObj.group()
#   print "matchObj.group(1) : ", matchObj.group(1)
#   print "matchObj.group(2) : ", matchObj.group(2)
#else:
#   print "No match!!"



