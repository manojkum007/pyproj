# -*- coding: utf-8 -*-
"""
Created on Tue Jun 13 17:03:19 2017

@author: manoj
"""

import os

import json
import datetime

es_host="192.168.120.136"

es_port="9200"
es_port=8080

from elasticsearch import Elasticsearch

es = Elasticsearch([{'host': es_host, 'port': es_port}])

es_doc = dict()



#es.index(index=jobstatus_index, doc_type=task_name, body=json.dumps(es_doc), timestamp=es_doc['@timestamp'])



d=datetime.datetime.now()



import datetime

d=datetime.datetime.now()

def delete_es_type(es, index, type_):
    try:
        count = es.count(index, type_)['count']
        response = es.search(
        index=index,
        filter_path=["hits.hits._id"],
        body={"size": count, "query": { "filtered": {"query": { "match": { "job_name": "attribute_refresh_prod"  }},"filter": { "range": {"all_params.run_date": { "gte": "2017-06-12" , "lte": "2017-06-14" }}} }}})
        
        
#        response = es.search(
#        index=index,
#        filter_path=["hits.hits._id"],
#        body={"size": count, "query": {"filtered" : {"filter" : {
#                  "type" : {"value": type_ }}}}})
        ids = [x["_id"] for x in response["hits"]["hits"]]
        if len(ids) > 0:
            return
        bulk_body = [
            '{{"delete": {{"_index": "{}", "_type": "{}", "_id": "{}"}}}}'
            .format(index, type_, x) for x in ids]
        print "bulk_body",bulk_body
        es.bulk('\n'.join(bulk_body))
        # es.indices.flush_synced([index])
    except Exception as ex:
        print ex
        raise ex
    
print delete_es_type(es, es_host, "RowCountStat")
#es.index(index="new_test", doc_type="testing", body=json.dumps(es_doc), timestamp=d)

#es_doc['luigi_task_name']="hellotask"

#es.index(index="new_test", doc_type="testing", body=json.dumps(es_doc), timestamp=d)
