# -*- coding: utf-8 -*-
"""
Created on Fri Mar 30 00:47:49 2018

@author: manoj
"""

import math
import itertools

X=100
N=2

lis=list(range(1,int(math.sqrt(X))+1))
#print lis

def power_sum(lis ,counter ,N ,X,sumlis=[]):
    addlis=[]
    for  i in itertools.combinations(lis,counter):
        addlis.append(list(i))
    #print addlis
    for  row in addlis:
        if reduce(lambda x,y :x+y ,map(lambda x: math.pow(x,N) ,row)) ==X:
            sumlis.append(row)
    #print sumlis
    if counter<=len(lis):
        return power_sum(lis,counter+1, N ,X)
    else:
        return sumlis
        



def power_sum1(lis ,counter ,N ,X,sumlis=[]):
    for  i in itertools.combinations(lis,counter):
        print i
        if int(reduce(lambda x,y :x+y ,map(lambda x: math.pow(x,N) ,list(i)))) ==X:
            sumlis.append(list(i))
    print sumlis
    if counter<=len(lis):
        print "coming in recurese"
        return power_sum(lis,counter+1, N ,X)
        #return sumlis
    else:
        print "coming to else"
        return sumlis
        

            
   
#reduce(lambda x,y :x+y ,map(lambda x: x*x ,lis))   
sumlis=[]
print power_sum1(lis,1,N,X,sumlis)
