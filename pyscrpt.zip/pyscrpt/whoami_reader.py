# -*- coding: utf-8 -*-
"""
Created on Thu Jun 14 18:33:54 2018

@author: manoj
"""

import argparse
#from Utilities.movoto.logger import MLogger
#from Utilities.movoto import settings
from elasticsearch.helpers import scan
from elasticsearch import Elasticsearch
from elasticsearch.helpers import streaming_bulk
import traceback
import sys

success_count = 0
failed_count = 0

TIMEOUT = 3000
CHUNK_SIZE = 1000

#logger = MLogger().getLogger("MigrateWhoamiParserData", "ALL")


def scan_source_es(source_index):
    es = Elasticsearch(hosts=["10.255.1.252:9200"], timeout=1000)
    results = elasticsearch.helpers.scan(es,
    index="parser_es6",
    doc_type="whoami",
    preserve_order=True,
    query={"query": {"match_all": {}}})
    
    return results
#    args = {'request_timeout': TIMEOUT, 'index': source_index, 'doc_type': 'whoami'}
#    for doc in scan(Elasticsearch(hosts='2.ingest.soa.es6.ng.movoto.net:9200'), scroll='5m', query={'size': CHUNK_SIZE}, **args):
#        # doc['_source']["propertyDateHidden"] = None
#        doc['_source']['_id'] = doc['_id']
#        yield doc['_source']


def scan_source_es1(source_index):
    es = Elasticsearch(hosts=["192.168.120.21:9200"], timeout=1000)
    results = elasticsearch.helpers.scan(es,
    index="jobstatus",
    doc_type="RowCountStat",
    preserve_order=True,
    query={"query": {"match_all": {}}})
    
    return  results
    

def insert_target_es(source_index, target_index):
    for ok, result in streaming_bulk(
            Elasticsearch(hosts=settings.ELASTICSEARCH['serversES6']),
            scan_source_es(source_index),
            index=target_index,
            doc_type='whoami',
            chunk_size=CHUNK_SIZE,
            raise_on_error=False,
            raise_on_exception=False
    ):
        action, result = result.popitem()
        doc_id = '/%s/%s/%s' % (target_index, 'whoami', result['_id'])
        # process the information from ES whether the document has been
        # successfully indexed
        if not ok:
            global failed_count
            failed_count += 1
            logger.error('Failed to %s document %s: %r' % (action, doc_id, result))
        else:
            global success_count
            success_count += 1
            logger.info(doc_id)

        if (success_count + failed_count) % CHUNK_SIZE == 0:
            logger.info("%s prs are processed, %s success, %s failed", (failed_count + success_count),
                        success_count, failed_count)

try:
    for row in  scan_source_es("parser_es6"):
        print row
        break
except Exception, err:
    print 'print_exc():'
    traceback.print_exc(file=sys.stdout)
    


#
#if __name__ == '__main__':
#    parser = argparse.ArgumentParser()
#    parser.add_argument('-source_index', help='Specify source index name', type=str, required=True)
#    parser.add_argument('-target_index', help='Specify target index name', type=str, required=True)
#    args = parser.parse_args()
#    argsdict = vars(args)
#    insert_target_es(argsdict['source_index'], argsdict['target_index'])