# -*- coding: utf-8 -*-
"""
Created on Sat May 14 00:57:58 2016

@author: manoj
"""

import time
d=dict()

def fib1(n):  
    if n<=1:
        return 11
    return fib1(n-1)+fib1(n-2)
    
    

    
def fib(n):
    if n<=1:
        return 1    
    if (d.get(n-1)==None):
        d[n-1]=fib(n-1)
    if (d.get(n-2)==None):
        d[n-2]=fib(n-2)
    return d.get(n-1)+d.get(n-2)

start_time = time.time()
print fib(9)
elapsed_time = time.time()

#print "time difference",elapsed_time -start_time

for k,v in d.iteritems():
    print v,