# -*- coding: utf-8 -*-
"""
Created on Thu Feb 11 17:27:12 2016

@author: manoj
"""

import urllib2
import csv
import logging
import re
import string
import urllib2
# import  requests
import datetime

AUTH_TOKEN = 'c34z7xKwq8e'

DB_SCHEMA = 'mls_updates'

OFFICES_URL = 'http://www.terradatum.com/apis/movoto/movoto/office-data-1.0.csv?authToken=%s&mlsId=%s&fromDate=%s'
columns  = ['mlsid', 'broker_id', 'office_id', 'status_code', 'office_name', 'address1', 'address2', 'city', 'zipcode', 'state_code', 'broker', 'email_address', 'office_phone', 'office_fax', 'street_number', 'street_name_predir', 'street_name_premod', 'street_name_pretype', 'street_name', 'full_street_name', 'street_name_posttype', 'street_name_posttype_normalized', 'street_name_postdir', 'street_name_occupancytype', 'street_name_identifier', 'full_state', 'long_form_address', 'street_number_2', 'street_name_predir_2', 'street_name_premod_2', 'street_name_pretype_2', 'street_name_2', 'full_street_name_2', 'street_name_posttype_2', 'street_name_posttype_normalized_2', 'street_name_postdir_2', 'street_name_occupancytype_2', 'street_name_identifier_2', 'full_state_2', 'long_form_address_2','office_key','created_tstmp','updated_tstmp']
    


mls='BAREIS'
date='1-12-2016'

url = OFFICES_URL % (AUTH_TOKEN, mls, date)

print "url is " ,url
response = urllib2.urlopen(url)
print "response is ",response
csv_reader = csv.reader(response)
headers = csv_reader.next()
#print headers
for in_row in csv_reader:
    try:
        row = map(lambda val: None if val == 'null' else val, in_row)
        #print "row is " ,row
        office_phone = row[headers.index('office_phone')]
        row[headers.index('office_phone')] = ''.join(re.findall('\d+', office_phone)) if office_phone else None

        
        print "office_phone" ,row
        officekey="{0}-{1}".format(row[columns.index('mlsid')] ,row[columns.index('office_id')])
        print "officekey",officekey        
        break
    except :
        print "some error"
        

                