# -*- coding: utf-8 -*-
"""
Created on Wed May 11 12:29:03 2016

@author: manoj
"""
import shapefile
sf = shapefile.Reader("/home/manoj/Downloads/geodatabase/world/US/23424977/23424977.shp")
shapes = sf.shapes()

fields = sf.fields

geomet = sf.shapeRecords()

#print fields
first = geomet[0]
#print first.shape.points
#print first
for name in dir(shapes[3]):
    if not name.startswith('__'):
        print name
print shapes[3].shapeType
print shapes[3].bbox
print shapes[3].points