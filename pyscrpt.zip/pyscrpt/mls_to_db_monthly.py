#python libraries
import os
import csv
import logging
import re
import string
import urllib2
# import  requests
import datetime
from dateutil.relativedelta import relativedelta
import ast

#third-party libraries
# import usaddress
from lxml import etree
import psycopg2
import luigi
from luigi import postgres
from luigi import six

#internal libraries
#import settingsUpdateMlsTables
import address_parser
import address_parse
import names_parser
#from mls_all_sqlscripts import UpdateMlsTables



#from mls_to_db import CopyToMlsTable, get_config

def get_config(section, name):
    luigi_config = luigi.configuration.get_config()
    return luigi_config.get(section, name)


tiger_host=get_config('localmls1', 'db-host')
tiger_database=get_config('localmls1', 'db-name')
tiger_user=get_config('localmls1', 'db-user')
tiger_password=get_config('localmls1', 'db-password')

logger = logging.getLogger('luigi-interface')
errorlogger = logging.getLogger('mlsError')
listinglogger = logging.getLogger('listingerror')



AUTH_TOKEN = 'c34z7xKwq8e'
DB_SCHEMA = 'mls_updates'

MLS_URL = 'http://www.terradatum.com/apis/movoto/movoto/mls-data-2.0.xml?authToken=%s'
LISTINGS_URL = 'http://www.terradatum.com/apis/movoto/movoto/property-data-1.0.csv?authToken=%s&mlsId=%s&fromDate=%s'
AGENTS_URL = 'http://www.terradatum.com/apis/movoto/movoto/agent-data-1.0.csv?authToken=%s&mlsId=%s&fromDate=%s'
OFFICES_URL = 'http://www.terradatum.com/apis/movoto/movoto/office-data-1.0.csv?authToken=%s&mlsId=%s&fromDate=%s'
row_mls=[]

listing_error_path='./mls_error/mls_listings_errors.csv'
listing_failed_path='./mls_error/mls_listings_failed.csv'
common_path="/home/manoj/scripts/python_scripts/mls_download/"



def MlsGetid():
    response_mls = urllib2.urlopen(MLS_URL % (AUTH_TOKEN))
    doc = etree.parse(response_mls)
    root = doc.getroot()
    for MLS in root.findall('MLS'):
        rank = MLS.find('mlsId').text
        if (rank is not None):
          row_mls.append(rank)
    return row_mls


def PrepareRows(columns,row):
    key_value={}
    for column,each_row in zip(columns,row):
        if each_row is None:
            value=None
        elif type(each_row) is int:
            value=str(each_row)
        else:
            value=each_row
        key_value[column]=value
    return key_value


def writeListingsRow(row):
    #row = [e]
    #header=["Time", "mls_category", "mls_id", "import_date", "Error", "Actual_row"]   
    with open(listing_error_path, 'a') as errors_file:
        writer = csv.writer(errors_file, delimiter=',')
        writer.writerow(row)


def writeListingsRowfail(row):  
    with open(listing_failed_path, 'a') as failed_file:
        writer = csv.writer(failed_file, delimiter=',')
        writer.writerow(row)


def fetchUpdates(schema, table, mls ,date,dbaserec,filepath):
    total_record=len(open(filepath).readlines())
    logger.info("For %s mls , date %s  : Out of %s record , totally %s record inserted"%(mls, date, total_record-1,dbaserec))
#    conn = psycopg2.connect(host=tiger_host, dbname=tiger_database, user=tiger_user, password=tiger_password)
#    cur = conn.cursor()
#    if (table=="listings"):
#        mlsid ="mls"
#    else:
#        mlsid ="mlsid"
#    mls=mls.lower()
#    command =  """
#        SELECT count(*) FROM [schema].[table] where 
#        [mlsid] ='%s'  and updated_tstmp >= (now() - interval '2 hour');
#        """.replace('[mlsid]', mlsid).replace('[table]',table).replace('[schema]',schema)
#    
#    command=command%(mls)
#    cur.execute(command)
#    test = cur.fetchall()
#    cur.close()

        
        
    

def upsert(db_cur, table, pk_fields, schema=None, **kwargs):
    """Updates the specified relation with the key-value pairs in kwargs if a
    row matching the primary key value(s) already exists.  Otherwise, a new row
    is inserted.  Returns True if a new row was inserted.
    schema     the schema to use, if any (not sanitized)
    table      the table to use (not sanitized)
    pk_fields  tuple of field names which are part of the primary key
    kwargs     all key-value pairs which should be set in the row
    """
    assert len(pk_fields) > 0, "must be at least one field as a primary key"
    if schema:
        rel = '%s.%s' % (schema, table)
    else:
        rel = table
    
    
    #print "ur key pair" ,kwargs 
    # check to see if it already exists
    where = ' AND '.join('%s=%%s' % pkf for pkf in pk_fields)
    where_args = [kwargs[pkf] for pkf in pk_fields]
    db_cur.execute("SELECT COUNT(*) FROM %s WHERE %s LIMIT 1" % (rel, where), where_args)
    
    #fields = [f for f in kwargs.keys()]
    if db_cur.fetchone()[0] > 0:
        kwargs.pop('created_tstmp')
        fields = [f for f in kwargs.keys()]
        set_clause = ', '.join('%s=%%s' % f for f in fields if f not in pk_fields)
        set_args = [kwargs[f] for f in fields if f not in pk_fields]
#        data="UPDATE %s SET %s WHERE %s" % (rel, set_clause, where)
#        logger.warning(data)
        db_cur.execute("UPDATE %s SET %s WHERE %s" % (rel, set_clause, where), set_args+where_args)
    else:
        fields = [f for f in kwargs.keys()]
        field_placeholders = ['%s'] * len(fields)
        fmt_args = (rel, ','.join(fields), ','.join(field_placeholders))
        insert_args = [kwargs[f] for f in fields]
#        data="INSERT INTO %s (%s) VALUES (%s)" % fmt_args, insert_args
#        logger.warning(data)
        db_cur.execute("INSERT INTO %s (%s) VALUES (%s)" % fmt_args, insert_args)



# these are the escape sequences recognized by postgres COPY
# according to http://www.postgresql.org/docs/8.1/static/sql-copy.html
default_escape = postgres.MultiReplacer([('\\', '\\\\'),
                                         ('\t', '\\t'),
                                         ('\n', '\\n'),
                                         ('\r', '\\r'),
                                         ('\v', '\\v'),
                                         ('\b', '\\b'),
                                         ('\f', '\\f')
                                         ])

class MlsToDbMonthly(luigi.Task):
    #mls = luigi.Parameter()
    #Default the date to the first day of last month
    date = luigi.DateParameter(default=datetime.date.today() - relativedelta(months=1, day=1))
    status=luigi.Parameter(default="initiated")
    
    def run(self):  
        #return {'Office': UpdateMlsTables(self.date)}
        pass

    def requires(self):
#        conn = psycopg2.connect(host=tiger_host, dbname=tiger_database, user=tiger_user, password=tiger_password)
#        cur = conn.cursor()
        #listings_writer=writeListingsRow()
        result=MlsGetid()
        result =['AKMLS','CVRMLS']
        yield [ {
                "listings": MlsListingsMonthly(mls=mls, date=self.date, status=self.status)
#                "agents": MlsAgentsMonthly(mls=mls, date=self.date),
#                "offices": MlsOfficesMonthly(mls=mls, date=self.date)
                } for mls in result ]
    
    
    def output(self):
        pass


class MlsListingsMonthly(luigi.Task):
    mls = luigi.Parameter()
    date = luigi.DateParameter(default=datetime.date.today() - relativedelta(months=1, day=1))
    status=luigi.Parameter(default="initiated")
    table = '%s.listings' % DB_SCHEMA
    columns = ['mls', 'mls_id', 'address', 'address_unit', 'city', 'state_code', 'zip', 'org_price', 'list_price', 'sale_price', 'date_sale', 'list_agent_id', 'list_office_id', 'co_list_agent_id', 'co_list_office_id', 'sell_agent_id', 'sell_office_id', 'co_sell_agent_id', 'co_sell_office_id', 'status_code', 'class_description', 'type_description', 'new_construction', 'tax_id', 'sale_comp_percent', 'square_ft', 'subdivision', 'reo', 'foreclosure', 'short_sale', 'full_baths', 'partial_baths', 'bedrooms', 'street_num', 'street_predir', 'street_premod', 'street_pretype', 'street_name', 'full_street_name', 'street_suffix', 'street_suffix_normalized', 'street_postdir', 'unit_type', 'unit_number', 'state_full', 'full_address','listing_id','remove_flag','transaction_id','created_tstmp' ,'updated_tstmp']
    headers = None
    mlsrepository=""
    head =['mls_id', 'mls_num', 'address', 'address_unit', 'city', 'state_code', 'zip', 'org_price', 'list_price', 'sale_price', 'date_sale', 'list_agent_id', 'list_office_id', 'co_list_agent_id', 'co_list_office_id', 'sell_agent_id', 'sell_office_id', 'co_sell_agent_id', 'co_sell_office_id', 'status_code', 'class_description', 'type_description', 'new_construction', 'tax_id', 'sale_comp_percent', 'square_ft', 'subdivision', 'reo', 'foreclosure', 'short_sale', 'full_baths', 'partial_baths', 'bedrooms']
    failed_counter=0

    def rows(self):
        if (self.status=="initiated"):
            url = LISTINGS_URL % (AUTH_TOKEN, self.mls, self.date.strftime('%m-%d-%Y'))
            listing_path =common_path+"listings/"
            m=mls_copy(listing_path, url, "listings", self.mls, self.date)
            listingcount=len(open(listing_error_path).readlines())
            errorlogger.error("%s, %s, %s, %s, %s, %s"%("Errorlevel" , "Mls", "Date", "Errordescription" , "Errorfilepath" , "Errorline"))
            if (m.create_file()==True): 
                self.mlsrepository=m.get_path()
                urlfile= open(self.mlsrepository, 'r')
                csv_reader = csv.reader(urlfile)
                headers = csv_reader.next()
                self.headers = headers
            else:
                try:
                    response = urllib2.urlopen(url)
                    csv_reader = csv.reader(response)
                except Exception as e:
                    errorlogger.error(self.date.strftime('%Y-%m-%d')+ " :  " + str(e))
                headers = csv_reader.next()
                self.headers = headers
                
        elif (self.status=="failed"):
            self.mlsrepository=listing_error_path
            if not os.path.exists(listing_failed_path):
                writeListingsRowfail(self.head)
            listingcount=len(open(listing_failed_path).readlines())
            urlfailedfile= open(listing_error_path, 'r')
            csv_reader = csv.reader(urlfailedfile)
            headers = csv_reader.next()
            self.headers = headers
            
        
        for in_row in csv_reader:
            try:
                row = map(lambda val: val if (val == None or type(val) == int) else (val.lower().strip() or None), in_row)
                row= map(lambda x: None if x=='null' else x, row)
                
                   
                #Clean up TAX_ID
                tax_id = row[headers.index('tax_id')]
                row[headers.index('tax_id')] = tax_id.translate(None, string.punctuation) if tax_id else None

                org_price = row[headers.index('org_price')]
                list_price = row[headers.index('list_price')]
                sale_price = row[headers.index('sale_price')]

                full_baths = row[headers.index('full_baths')]
                partial_baths = row[headers.index('partial_baths')]
                bedrooms = row[headers.index('bedrooms')]

                # Turn floats to ints
                row[headers.index('org_price')] = int(float(org_price)) if org_price else None
                row[headers.index('list_price')] = int(float(list_price)) if list_price else None
                row[headers.index('sale_price')] = int(float(sale_price)) if sale_price else None
                
                
                #logger.warning(" row fullbath,partial_bedrooms %s " % (full_baths+partial_baths+bedrooms))
                row[headers.index('full_baths')] = int(float(full_baths)) if full_baths else None
                row[headers.index('partial_baths')] = int(float(partial_baths)) if partial_baths else None
                row[headers.index('bedrooms')] = int(float(bedrooms)) if bedrooms else None

                    
                address = row[headers.index('address')].lower()
                city = row[headers.index('city')].lower()
                state = row[headers.index('state_code')].lower()
                #logger.warning(" paresed city  and state  %s" % in_row)  
                
                
                parsed_address = None
                expanded_address = None
                
                
                parsed_address = address_parse.parse_address(address, city, state, logger)
                expanded_address = address_parse.get_long_form_address(address, city, state)
                
                
#                try:
#                    parsed_address = address_parse.parse_address(address, city, state, logger)
#                    expanded_address = address_parse.get_long_form_address(address, city, state)
#                    #parsed_address = address_parse.address_to_dict(address, city, state, logger)
#                    
#                    if not parsed_address:
#                        raise Exception('Failed to parse address: %s' % address)
#                    logger.warning(" came in parsed_address %s" % in_row)  
#                except Exception as e:
#                    logger.warning(" came in parsed_address exception %s  %s" %  parsed_address,e)  
#                    logger.warning(e.message)
#                    with open('mls_errors.csv', 'a') as errors_file:
#                        writer = csv.writer(errors_file, delimiter=',')
#                        writer.writerow(row)
#                    continue
                for val in parsed_address:
                    row.append(val)

                row.append(expanded_address)
                row.append(None)
                row.append(None)
                row.append(None)
                row.append(str(datetime.datetime.now()))
                row.append(str(datetime.datetime.now()))
                #logger.warning(" successfully  parsed  this row %s" % in_row)
            except Exception as e:
                logger.warning("""
                        Failed to process row.
                        Job: MlsListingsMonthly
                        MLS: %s
                        Date: %s
                        row: %s
                        Error: %s
                """ % (self.mls, self.date.strftime('%Y-%m-%d'),row, e))
                #for line in open(m.get_path()): listingcount += 1
                if (self.status=="initiated"):
                    listingcount += 1
                    writeListingsRow(in_row)
                    errorlogger.error("%s, %s, %s, %s, %s"%(self.mls, self.date.strftime('%Y-%m-%d'), str(e), str(listing_error_path), str(listingcount)))
                elif(self.status=="failed"):
                    listingcount += 1
                    writeListingsRowfail(in_row)
                    errorlogger.error("%s, %s, %s, %s %s"%(self.mls, self.date.strftime('%Y-%m-%d'), str(e), str(listing_failed_path), str(listingcount)))
                yield None           
            yield row
        if (self.status=="initiated"):
            urlfile.close()
        elif (self.status=="failed"):
            urlfailedfile.close()
                
            
        pass
    
    def run(self):
        #connect to db
        conn = psycopg2.connect(host=tiger_host, dbname=tiger_database, user=tiger_user, password=tiger_password)
        cur = conn.cursor()
        #list_fields=[]
        key_value={}
        for row in self.rows():
            if not row: continue
            key_value=PrepareRows(self.columns,row)
            try:        
                upsert(cur, 'listings', ('mls','mls_id',), DB_SCHEMA,**key_value )
                self.failed_counter+=1
                logger.warning(" successfully  inserted this row %s" %row)
            except Exception as e:
                logger.warning('Failed to upsert row: %s\n Error: %s' % (key_value, e))
        conn.commit()
        fetchUpdates(DB_SCHEMA, "listings",self.mls,self.date, self.failed_counter, self.mlsrepository)
        #listing_error_path1='/home/manoj/analytics/Jobs/src/luigitasks/mls_error/mls_listings_failed2.csv' 
        if  (self.status=="failed"):
            #pass
            os.rename(listing_failed_path, listing_error_path)
            
        if  (self.status=="initiated"):
            self.output().touch()
        
    


    def output(self):
        pass
#        return luigi.postgres.PostgresTarget(
#                                             host=tiger_host,
#                                             database=tiger_database,
#                                             user=tiger_user,
#                                             password=tiger_password,
#                                             table='table_updates',
#                                             update_id='%s_listings_%s' % (self.mls, self.date.strftime('%Y%m%d')))



class MlsOfficesMonthly(luigi.Task):
    mls = luigi.Parameter()
    date = luigi.DateParameter(default=datetime.date.today() - relativedelta(months=1, day=1))
    table = '%s.listings' % DB_SCHEMA
    
    columns  = ['mlsid', 'broker_id', 'office_id', 'status_code', 'office_name', 'address1', 'address2', 'city', 'zipcode', 'state_code', 'broker', 'email_address', 'office_phone', 'office_fax', 'street_number', 'street_name_predir', 'street_name_premod', 'street_name_pretype', 'street_name', 'full_street_name', 'street_name_posttype', 'street_name_posttype_normalized', 'street_name_postdir', 'street_name_occupancytype', 'street_name_identifier', 'full_state', 'long_form_address', 'street_number_2', 'street_name_predir_2', 'street_name_premod_2', 'street_name_pretype_2', 'street_name_2', 'full_street_name_2', 'street_name_posttype_2', 'street_name_posttype_normalized_2', 'street_name_postdir_2', 'street_name_occupancytype_2', 'street_name_identifier_2', 'full_state_2', 'long_form_address_2','office_key','created_tstmp',' updated_tstmp']
    
    headers = None

    def rows(self):
        url = OFFICES_URL % (AUTH_TOKEN, self.mls, self.date.strftime('%m-%d-%Y'))
        response = urllib2.urlopen(url)
        csv_reader = csv.reader(response)
        headers = csv_reader.next()
        self.headers = headers
        
        for in_row in csv_reader:
            try:
                row = map(lambda val: val if (val == None or type(val) == int) else (val.lower().strip() or None), in_row)
                row= map(lambda x: None if x=='null' else x, row)
                #clean phone numbers
                office_phone = row[headers.index('office_phone')]
                row[headers.index('office_phone')] = ''.join(re.findall('\d+', office_phone)) if office_phone else None

                office_fax = row[headers.index('office_fax')]
                row[headers.index('office_fax')] = ''.join(re.findall('\d+', office_fax)) if office_fax else None

                #append parsed addresses
                address1 = None if row[headers.index('address1')] is None else row[headers.index('address1')].lower()
                address2 = None if row[headers.index('address2')] is None else row[headers.index('address2')].lower()
                city = None if row[headers.index('city')] is None else row[headers.index('city')].lower()
                state = None if row[headers.index('state_code')] is None else row[headers.index('state_code')].lower()

                row += self.get_parsed_address(address1, city, state)

                row += self.get_parsed_address(address2, city, state)
                office_key="{0}-{1}".format(row[0],row[2])
                row.append(str(office_key))
                row.append(str(datetime.datetime.now()))
                row.append(str(datetime.datetime.now()))
            except Exception as e:
                logger.warning("""
                    Failed to process row.
                    Job: MlsOfficesMonthly
                    MLS: %s
                    Date: %s
                    row : %s
                    Error: %s
                """ % (self.mls, self.date.strftime('%Y-%m-%d'),row, e))
                yield None
            yield row


    def get_parsed_address(self, address, city, state):
        row = []
        parsed_address = None
        expanded_address = None
        try:
            parsed_address = address_parse.parse_address(address, city, state, logger)
            expanded_address = address_parse.get_long_form_address(address, city, state)
            if not parsed_address:
                raise Exception('Failed to parse address: %s' % address)
        except Exception as e:
            logger.warning(e.message)
            with open('mls/errors.csv', 'a') as errors_file:
                writer = csv.writer(errors_file, delimiter=',')
                writer.writerow(row)
            parsed_address = [None] * 12
            expanded_address = None
        for val in parsed_address:
            row.append(val)

        row.append(expanded_address)

        return row

    def run(self):
        
        #connect to db
        conn = psycopg2.connect(host=tiger_host, dbname=tiger_database, user=tiger_user, password=tiger_password)
        cur = conn.cursor()
        #for each row:
        key_value={}
        for row in self.rows():
            if not row: continue
            key_value=PrepareRows(self.columns,row)
            try:
                upsert(cur, 'offices', ('mlsid','broker_id','office_id',), DB_SCHEMA,**key_value )
            except Exception as e:
                logger.warning('Failed to upsert row: %s\n Error: %s' % (row, e))

        self.output().touch()
        conn.commit()
        pass
        
    
    def output(self):
        return luigi.postgres.PostgresTarget(
                                             host=tiger_host,
                                             database=tiger_database,
                                             user=tiger_user,
                                             password=tiger_password,
                                             table='table_updates',
                                             update_id='%s_offices_%s' % (self.mls, self.date.strftime('%Y%m%d')))




class MlsAgentsMonthly(luigi.Task):
    mls = luigi.Parameter()
    date = luigi.DateParameter(default=datetime.date.today() - relativedelta(months=1, day=1))
    table = '%s.agents' % DB_SCHEMA
    
    columns = ['mlsid', 'agent_id', 'status_code', 'first_name', 'last_name', 'office_id', 'email_address', 'phones', 'full_name', 'clean_fname', 'clean_lname', 'clean_full_name', 'clean_phones','created_tstmp','updated_tstmp','external_id']
    headers = None
    
    def rows(self):

        url = AGENTS_URL % (AUTH_TOKEN, self.mls, self.date.strftime('%m-%d-%Y'))
        response = urllib2.urlopen(url)
        csv_reader = csv.reader(response)
        headers = csv_reader.next()

        for in_row in csv_reader:
            row = in_row
            try:
                row = map(lambda val: val if (val == None or type(val) == int) else (val.lower().strip() or None), row)
                row= map(lambda x: None if x=='null' else x, row)
                #clean fname and lname
                fname = row[headers.index('first_name')]
                lname = row[headers.index('last_name')]

                #handle names that are 'not supplied by mls'
                if fname == 'not suppllied by mls':
                    fname = None
                    lname = None

                full_name = (fname + ' ' + (lname or '')).strip() if fname else lname

                row.append(full_name)
                row.append(names_parser.name_norm(fname))
                row.append(names_parser.name_norm(lname))
                row.append(names_parser.name_norm(full_name))
                #clean phone number
                #phone numbers are separated by commas
                row.append(self._get_clean_numbers(row[headers.index('phones')]))
                row.append(str(datetime.datetime.now()))
                row.append(str(datetime.datetime.now()))
                row.append(None)
            except Exception as e:
                logger.warning("""
                    Failed to process row.
                    Job: MlsAgentsMonthly
                    MLS: %s
                    Date: %s
                    row: %s
                    Error: %s
                """ % (self.mls, self.date.strftime('%Y-%m-%d'),row, e))
                yield None
            yield row


    def map_column(self, value):
        """
        Applied to each column of every row returned by `rows`.

        Default behaviour is to escape special characters and identify any self.null_values.
        """
        if value in self.null_values:
            return r'\N'
        elif six.PY3:
            return default_escape(str(value))
        elif isinstance(value, unicode):
            return default_escape(value).encode('utf8')
        elif type(value) == list:
            return default_escape(str(value).replace('[', '{').replace(']', '}'))
        else:
            return default_escape(str(value))


    def _get_clean_numbers(self, phones_string):
        if not phones_string:
            return None
        phones = phones_string.split(',')
        ret_list = []
        for phone in phones:
            ret_list.append(''.join(re.findall('\d+', phone)))
        return ret_list
    
    def run(self):
        #connect to db
        conn = psycopg2.connect(host=tiger_host, dbname=tiger_database, user=tiger_user, password=tiger_password)
        cur = conn.cursor()
        #for each row:
        for row in self.rows():
            if not row: continue
            key_value=PrepareRows(self.columns,row)
            try:
                upsert(cur, 'agents', ('mlsid','agent_id',), DB_SCHEMA,**key_value )
            except Exception as e:
                logger.warning('Failed to upsert row: %s\n Error: %s' % (row, e))

        self.output().touch()
        conn.commit()
        pass
    
    def output(self):
        return luigi.postgres.PostgresTarget(
                                             host=tiger_host,
                                             database=tiger_database,
                                             user=tiger_user,
                                             password=tiger_password,
                                             table='table_updates',
                                             update_id='%s_agents_%s' % (self.mls, self.date.strftime('%Y%m%d')))



class mls_copy:
    
    def __init__(self,path, url, mlstable, mls, date):
        self.mlspath=path
        self.mlsurl=url
        self.mlstabletype=mlstable
        self.mls=mls
        self.mlsdate=date
        format="%m%d%Y"
        self.mod_date=self.mlsdate.strftime(format)
        self.mlsfilepath=""
        
        
    
    def get_path(self):
        return self.mlsfilepath
    
    
    def create_file(self):
        format ="%b"
        month=self.mlsdate.strftime(format)
        office_month = self.mlspath+month 
        if not os.path.exists(office_month):
            os.makedirs(office_month)
        path=office_month+"/{0}_".format(self.mls)+self.mlstabletype+"data_{0}.csv".format(self.mod_date)
        self.mlsfilepath=path
        if (os.path.isfile(path)==False):
            try:
                response = urllib2.urlopen(self.mlsurl)
                logger.info("downloading url")
            except Exception as e:
                logger.info("error in operning url %s"% e)
            
            try:
                urlFile=open(path ,'w+')
            except Exception as e:
                logger.info("error in operning file %s"% e)
        
            try:
                urlFile.write(str(response.read()))
                urlFile.close()
                #print path
                logger.warning("success in  creating file %s"% path)
                return True
            except Exception as e:
                #print "sorry"
                #logger.info("Error in saving as writing as csv %s"% e)
                logger.info("error in creating file %s"% e)
                return False
        else:
            return True
            #print "file already exits",path
    

if __name__ == '__main__':
    luigi.run()             

