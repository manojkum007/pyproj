# -*- coding: utf-8 -*-
"""
Created on Mon Feb 15 11:48:49 2016

@author: manoj
"""

{
movoto:{
    database:{ 
        postgres: {
            host='172.24.0.95',
            database='realestate_dev',
            user='census',
            password='censuspassword',     
            }
        }
    }
}