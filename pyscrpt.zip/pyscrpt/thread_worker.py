# -*- coding: utf-8 -*-
"""
Created on Fri Jun  9 01:51:57 2017

@author: manoj
"""

import threading

def worker():
    print "worker"
    return
    
    
threads = []
for i in range(5):
    t = threading.Thread(target=worker)
    threads.append(t)
    t.start()
    
    