# -*- coding: utf-8 -*-
"""
Created on Fri Feb 16 23:11:06 2018

@author: manoj
"""

import sys


def modf(x):
    if (x)>0:
        return x
    else :
        return (-x)
        
        
def diagonalDifference(a,n):
    first_dia=0
    sec_dia=0
    for row in range(len(a)):
        for col in range(len(a[row])):
            if row==col:
                first_dia+=a[row][col]
            if row+col==n-1:
                sec_dia+=a[row][col]
    #print first_dia,sec_dia           
    return modf(first_dia-sec_dia)
                

if __name__ == "__main__":
    #n = int(raw_input().strip())
    n=4
    a=[[-1 ,1 ,-7 ,-8],[-10, -8 ,-5 ,-2],[0 ,9 ,7, -1],[4, 4, -2, 1]]
#    for a_i in xrange(n):
#        a_temp = map(int,raw_input().strip().split(' '))
#        a.append(a_temp)
    result = diagonalDifference(a ,n)
    print result