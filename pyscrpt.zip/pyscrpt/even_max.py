# -*- coding: utf-8 -*-
"""
Created on Sun Dec 24 10:44:01 2017

@author: manoj
"""

dlist= [4,5,9,3,5,1,8,22,1,5,19,6]

emax=0
for i in dlist:
    if i>emax and i%2==0:
        emax=i

print "even max" ,emax
    