# -*- coding: utf-8 -*-
"""
Created on Wed Aug 23 18:59:46 2017

@author: manoj
"""

import luigi
import datetime
import boto
import boto.s3.connection
from boto.s3.key import Key

import  movoto_logger 
from urllib2 import *
from S3GenericLuigi import *
import ssl
if hasattr(ssl, '_create_unverified_context'):
   ssl._create_default_https_context = ssl._create_unverified_context
   
aws_folder='s3file'




logger = movoto_logger.get_logger('recruit_daily_stat.log')

   
class S3connector:
    def __init__(self, aws_access_key, aws_access_secret):
        try:
            self.client= S3GenericLuigi(aws_access_key, aws_access_secret)
            logger.info(" connected")
        except Exception as e:
            logger.info( "Unable to connect to s3 %s"%e)
    
    def  S3listfiles(self , s3DirectoryPath):
        return self.client.listdir(s3DirectoryPath)

    def  S3putfiles(self , s3path, localpath):
        return self.client.get(s3path, localpath) 
        
    def parse_files(self, s3DirectoryPath , uploadate):
        try:
            for path in self.S3listfiles("{0}/{1}".format(s3DirectoryPath, uploadate)):
                if path.endswith(".txt"):
                    #self.S3putfiles(path, './'+aws_folder+'/'+uploadate+'_'+re.search(uploadate+'/(\S+)/',path).group(1)+'_metadata.txt')   
                    self.S3putfiles(path, "./{0}/{1}_{2}_metadata.txt".format(aws_folder, uploadate, re.search(uploadate+'/(\S+)/',path).group(1)))
        except Exception as e:
            logger.info( "Unable to parse files %s"%e)


    
    
    
    
    
class RecruitDailystat(luigi.Task):
    run_date = luigi.DateParameter(default = datetime.date.today()-datetime.timedelta(days=1))
    get_all = luigi.Parameter(default = 'yes')
    table_list=['delete_property', 'property_history_updated', 'mls_public_record_association', 'mls_listing', 'address']
    
    def requires(self):pass
        #return ImportParTable(self.object_name, self.run_date, self.get_all)
    def run(self):
        luigi_config = luigi.configuration.get_config()
        access_key1=luigi_config.get('aws','access_key')
        access_secret1=luigi_config.get('aws','access_secret')
        
        awsobj=S3connector(access_key1, access_secret1)  
        awsobj.parse_files(s3DirectoryPath, self.run_date.strftime('%Y%m%d')) 
        
        with self.output().open('w') as f:
            f.write('{word}\n'.format(word='SqoopExportTask'))
    
    def output(self):
        return luigi.LocalTarget(path='target/RecruitDailystat_%s.txt'%(self.run_date.strftime('%Y-%m-%d')))

    