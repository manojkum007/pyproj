# -*- coding: utf-8 -*-
"""
Created on Wed Dec 14 16:04:02 2016

@author: manoj
"""
import luigi
import luigi.contrib





class SchoolDataloading(luigi.Task):
 
    def requires(self):pass

    def run(self):
       self.output().touch()

    def output(self):
        return luigi.contrib.mysqldb.MySqlTarget(
                                             host='192.168.120.130',
                                             database='school_v2',
                                             user='admin',
                                             password='school123',
                                             table='table_updates',
                                             update_id='AllDeedsToDb.Task.' 
                                             )