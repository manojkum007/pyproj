# -*- coding: utf-8 -*-
"""
Created on Tue Mar 28 19:32:55 2017

@author: manoj
"""





def readlinebyline():
    with open('/home/manoj/scripts/tiger_analyatics/deedsError_old.csv' ,'r') as f:
        for line in f:
            yield line 
    f.close()
            
#    while True:
#        a=f.readline()
#        print "line", a
#        if a==None:
#            break
#        yield a

    
    
    
d=readlinebyline()

print type(d)
for i in d:
    print i
    #break


#print "next iteration"
#for i in d:
#    print i

#d.next()
#d.next()
#
#d.next()
#d.next()
#d.next()
#d.next()
#d.next()
#d.next()



