# -*- coding: utf-8 -*-
"""
Created on Wed Feb 24 17:57:49 2016

@author: manoj
"""
import re
path="/home/manoj/scripts/python scripts/luigi_data.py"
path="/home/manoj/scripts/python scripts/deeds_errors.csv"
filepath="/home/manoj/scripts/python scripts/failed_deeds.csv"
f=open(path, 'r+') 
f1=open(filepath, 'w+') 
data =f.read()
file_lis=[]
lis =data.split("\n")
#print lis
file_lis=[]
for i in lis:
    try:
        m = re.search('(/opt/deeds_2012\S+txt)', i)
        file_lis.append(m.group(0))
    except:
        pass
f.close()




print len(file_lis)
row =set(file_lis)
data_lis =list(row)
print len(data_lis)

for j in data_lis:
    f1.write(j)
    f1.write("\n")
f1.close()


#print file_lis