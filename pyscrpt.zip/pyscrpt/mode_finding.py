# -*- coding: utf-8 -*-
"""
Created on Sun Aug 19 00:16:18 2018

@author: manoj
"""

lis=[4,5,65,56,1,5,1,4,1,4,5,6,1,56,1,54,1,54,2,154,1,2,5,5,5,8,7]

modevar=0

modedict={}
for i in lis:
    if modedict.get(i)==None:
        modedict[i]=1
    else:
        modedict[i]+=1


print sorted(modedict)
print [(key ,value) for (key, value) in sorted(modedict.items())]
    