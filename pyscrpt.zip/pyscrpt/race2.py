# -*- coding: utf-8 -*-
"""
Created on Thu Aug 17 18:38:22 2017

@author: manoj
"""

import threading

x = 0     # A shared value

COUNT = 10000000
def foo(lock):
    global x
    for i in xrange(COUNT):
        with lock:
            x += 1

def bar(lock):
    global x
    for i in xrange(COUNT):
        with lock:
            x -= 1

lock = threading.Lock()
t1 = threading.Thread(target=foo, args=(lock,))
t2 = threading.Thread(target=bar,  args=(lock,))
t1.start()
t2.start()
t1.join()
t2.join()
print x
