# -*- coding: utf-8 -*-
"""
Created on Fri Dec  9 18:21:02 2016

@author: manoj
"""

class Celsius:
    def __init__(self, temperature = 0):
        self.set_temperature(temperature)

    def to_fahrenheit(self):
        return (self._temperature * 1.8) + 32
    
    def get_temperature(self):
        return self._temperature
        
    def set_temperature(self, value):
        if value < -273:
            raise ValueError("Temperature below -273 is not possible")
        self._temperature = value


c=Celsius(-210)
#print c.to_fahrenheit()
#print c.__dict__
c._temperature=12
print c._temperature
print c.get_temperature()


class Celsius:
    def __init__(self, temperature = 0):
        self.temperature = temperature

    def to_fahrenheit(self):
        return (self.temperature * 1.8) + 32

    def get_temperature(self):
        print("Getting value")
        return self._temperature

    def set_temperature(self, value):
        if value < -273:
            raise ValueError("Temperature below -273 is not possible")
        print("Setting value")
        self._temperature = value

    temperature = property(get_temperature,set_temperature)