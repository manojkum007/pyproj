# -*- coding: utf-8 -*-
"""
Created on Mon Oct 30 12:38:42 2017

@author: manoj
"""

class newException(Exception):
    def __init__(self ,message):
        #print "passing error message"
        Exception.__init__(self, message)
        pass

a=0

if a==0:
    raise newException("raising exception")