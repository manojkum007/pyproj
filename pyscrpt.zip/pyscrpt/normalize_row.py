# -*- coding: utf-8 -*-
"""
Created on Mon Sep 26 12:02:39 2016

@author: manoj
"""
import luigi
from luigi import postgres
from luigi.hive import HiveTableTarget, run_hive_cmd
import ast

avro_query="""select 
                                    visitorid	,
                                    visitnumber	,
                                    visitid	,
                                    visitstarttime	,
                                    datevalue	,
                                    visits	,
                                    totalhits	,
                                    pageviews	,
                                    timeonsite	,
                                    bounces	,
                                    transactions	,
                                    transactionrevenue	,
                                    newvisits	,
                                    screenviews	,
                                    uniquescreenviews	,
                                    timeonscreen	,
                                    totaltransactionrevenue	,
                                    referralpath	,
                                    campaign	,
                                    source	,
                                    medium	,
                                    keyword	,
                                    adcontent	,
                                    campaignid	,
                                    adgroupid	,
                                    creativeid	,
                                    criteriaid	,
                                    page	,
                                    slot	,
                                    criteriaparameters	,
                                    gclid	,
                                    customerid	,
                                    adnetworktype	,
                                    targetingcriteria.boomuserlistid ,
                                    isvideoad	,
                                    istruedirect	,
                                    browser	,
                                    browserversion	,
                                    operatingsystem	,
                                    operatingsystemversion	,
                                    ismobile	,
                                    mobiledevicebranding	,
                                    flashversion	,
                                    javaenabled	,
                                    language	,
                                    screencolors	,
                                    screenresolution	,
                                    devicecategory	,
                                    continent	,
                                    subcontinent	,
                                    country	,
                                    region	,
                                    metro	,
                                    hits.customdimensions	,
                                    hits ,
                                    hits.hitnumber ,
                                    hits.time ,
                                    hits.hour ,
                                    hits.minute ,
                                    hits.issecure ,
                                    hits.isinteraction ,
                                    hits.isentrance ,
                                    hits.isexit ,
                                    hits.referer ,
                                    hits.page.pagepath ,
                                    hits.page.hostname ,
                                    hits.page.pagetitle ,
                                    hits.page.searchkeyword ,
                                    hits.page.searchcategory ,
                                    hits.transaction.transactionid ,
                                    hits.transaction.transactionrevenue ,
                                    hits.transaction.transactiontax ,
                                    hits.transaction.transactionshipping ,
                                    hits.transaction.affiliation ,
                                    hits.transaction.currencycode ,
                                    hits.transaction.localtransactionrevenue ,
                                    hits.transaction.localtransactiontax ,
                                    hits.transaction.localtransactionshipping ,
                                    hits.transaction.transactioncoupon ,
                                    hits.item.transactionid ,
                                    hits.item.productname ,
                                    hits.item.productcategory ,
                                    hits.item.productsku ,
                                    hits.item.itemquantity ,
                                    hits.item.itemrevenue ,
                                    hits.item.currencycode ,
                                    hits.item.localitemrevenue ,
                                    hits.contentinfo.contentdescription ,
                                    hits.appinfo.name ,
                                    hits.appinfo.version ,
                                    hits.appinfo.id ,
                                    hits.appinfo.installerid ,
                                    hits.appinfo.appinstallerid ,
                                    hits.appinfo.appname ,
                                    hits.appinfo.appversion ,
                                    hits.appinfo.appid ,
                                    hits.appinfo.screenname ,
                                    hits.appinfo.landingscreenname ,
                                    hits.appinfo.exitscreenname ,
                                    hits.appinfo.screendepth ,
                                    hits.exceptioninfo.description ,
                                    hits.exceptioninfo.isfatal ,
                                    hits.eventinfo.eventcategory ,
                                    hits.eventinfo.eventaction,
                                    hits.eventinfo.eventlabel ,
                                    hits.eventinfo.eventvalue ,
                                    hits.type ,
                                    hits.social.socialinteractionnetwork ,
                                    hits.social.socialinteractionaction ,
                                    fullvisitorid,
                                    userid		
                        FROM bqaug.mob_session_hit_avro_orc where datevalue='20160912'
                        """
                        

avro_res=run_hive_cmd(avro_query)        
                           
avro_res_lis=avro_res.split("\n") 
avro_res_lis.pop()


#print "preparing file"
#
#data='NULL""3""1474303107""1474303107""20160919""1""3""1""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""/""NULL""google.com""referral""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""true""Chrome""42.0.2311.154""Android""6.0.1""true""Alcatel""(not set)""true""es-419""32-bit""360x640""mobile""Americas""Northern America""United States""Texas""San Antonio TX""NULL""{hitnumber:2,time:0,hour:9,minute:38,issecure:null,isinteraction:false,isentrance:null,isexit:null,referer:http://www.google.com,page:null,transaction:null,item:null,contentinfo:null,appinfo:null,exceptioninfo:null,eventinfo:null,product:null,promotion:null,promotionactioninfo:null,refund:null,ecommerceaction:null,experiment:null,publisher:null,customvariables:null,customdimensions:null,custommetrics:null,type:null,social:null}""2""0""9""38""NULL""false""NULL""NULL""http://www.google.com""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL""NULL'
#data=['NULL','3','1474303107','1474303107','20160919','1','3','1','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','/','NULL','google.com','referral','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','true','Chrome','42.0.2311.154','Android','6.0.1','true','Alcatel','(not set)','true','es-419','32-bit','360x640','mobile','Americas','Northern America','United States','Texas','San Antonio TX','NULL','{hitnumber:2','time:0','hour:9','minute:38','issecure:null','isinteraction:false','isentrance:null','isexit:null','referer:http://www.google.com','page:null','transaction:null','item:null','contentinfo:null','appinfo:null','exceptioninfo:null','eventinfo:null','product:null','promotion:null','promotionactioninfo:null','refund:null','ecommerceaction:null','experiment:null','publisher:null','customvariables:null','customdimensions:null','custommetrics:null','type:null','social:null}','2','0','9','38','NULL','false','NULL','NULL','http://www.google.com','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL','NULL']
#print data[53]
#d=dict()
#try:
#    rlis=ast.literal_eval(data[53])
#    if len(rlis)>0:
#        for j in rlis:
#            d[j.get('index')]=j.get('value')
#except Exception as e:
#    print "error in forming row",e,d.get
#         for c in col:        
#            row.append(c.replace('"','').replace('\t',''))
       
def writesplittedfile(logfile,row):
    with open(logfile, 'a') as errors_file:
        writer = csv.writer(errors_file, delimiter='\t')
        writer.writerow(row)

           
for i in avro_res_lis:
    try:
        row=[]
        st=''
        col=i.split("\t")
        d=dict()
        try:
            rlis=ast.literal_eval(col[53])
            
            if len(rlis)>0:
                for j in rlis:
                    d[j.get('index')]=j.get('value')
        except Exception as e:
            print "error in forming row",e
        
        for c in col:        
            row.append(c.replace('"','').replace('\t',''))
                    
        row.append(str(d.get(1)))
        row.append(str(d.get(2)))
        row.append(str(d.get(3)))
        row.append(str(d.get(4)))
        row.append(str(d.get(5)))
        row.append(str(d.get(6)))
        row.append(str(d.get(7)))
        row.append(str(d.get(8)))
    except Exception as e:
        with open('/home/mkumar/bigquery/logs/avro_splitted_test12sep.txt', 'a') as errors_file:
            errors_file.write(i)
        
        

