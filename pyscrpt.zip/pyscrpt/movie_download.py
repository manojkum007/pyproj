# -*- coding: utf-8 -*-
"""
Created on Tue Jun  6 18:19:49 2017

@author: manoj
"""

import urllib2
response = urllib2.urlopen('http://185.176.192.40/vids/the_man_who_knew_infinity_2015___57d47902188d4.mp4')
html = response.read()
print  html