
# -*- coding: utf-8 -*-
"""
Created on Fri Dec 23 00:01:31 2016

@author: manoj
"""


import sys
import pymongo
import datetime


SEED_DATA = [
    {
        'decade': '1970s',
        'artist': 'Debby Boone',
        'song': 'You Light Up My Life',
        'weeksAtOne': 10
    },
    {
        'decade': '1980s',
        'artist': 'Olivia Newton-John',
        'song': 'Physical',
        'weeksAtOne': 10
    },
    {
        'decade': '1990s',
        'artist': 'Mariah Carey',
        'song': 'One Sweet Day',
        'weeksAtOne': 16
    }
]



MONGODB_URI = 'mongodb://user:pass@host:port/db' 
MONGODB_URI ="localhost:27017"


def mongo():

    client = pymongo.MongoClient(MONGODB_URI)
    db=client.temp
    print "default database",db
    agent_test = db['Agent_test1']
    cursor = agent_test.find({'userId.id': '42324913-b43b-4e6f-95e9-91056d2c1ffe','userId.idType':"NOVA"})
    
    if cursor!=None:
        print "found"
    else:
        print "notfound"
    
    query = {'userId.id': '08ef9f81-31e2-49d3-9f3c-bff24fd4109fjxfjfj6'}

    data=agent_test.update_one(query, {'$set': {'licenses': [{"licenseNumber":"678684","state":"FL","validDate":datetime.datetime.strptime("2014-01-16", "%Y-%m-%d")}]}})
    
    data=agent_test.update_one(query, { '$pullAll': { 'licences': [ 0, 5 ] } } )

    data=agent_test.update_one(query, {'$set': {'score': "licenseNumber"}})
    print "update test ", data.raw_result

    client.close()


mongo()

#if __name__ == '__main__':
#    main(sys.argv[1:])