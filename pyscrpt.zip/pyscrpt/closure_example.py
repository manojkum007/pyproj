# -*- coding: utf-8 -*-
"""
Created on Thu Mar 15 10:50:21 2018

@author: manoj
"""

def transmit_to_space(message):
    print "This is the enclosing function"
    def data_transmitter():
        "The nested function"
        print(message)

    data_transmitter()

print(transmit_to_space("Test message"))