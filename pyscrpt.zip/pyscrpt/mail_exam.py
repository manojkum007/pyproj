# -*- coding: utf-8 -*-
"""
Created on Thu Mar 31 11:18:31 2016

@author: manoj
"""

import smtplib

#sender = 'manojk.softengineer@gmail.com'
sender ='mkumar@movoto.com'
receivers = ['mkumar@movoto.com']

message = """From: From Person manojk.softengineer@gmail.com
To: To Person manojk.softengineer@gmail.com
Subject: SMTP e-mail test

This is a test e-mail message.
"""
def mail_old():
    try:
#        smtpObj = smtplib.SMTP('smtp.gmail.com', 587)
#        smtpObj.starttls()
#        smtpObj.set_debuglevel(True)
#        smtpObj.login('manojk.softengineer@gmail.com ', 'developerneeri')



        smtpObj = smtplib.SMTP('172.24.0.11', 25)
        smtpObj.starttls()
        smtpObj.login('mkumar@movoto.com', '1111@Laptop')
    
        smtpObj.sendmail(sender, receivers, message)         
        print "Successfully sent email"
    except Exception as e:
        print "Error: unable to send email",e
   
   
def mail():
    try:
        s=smtplib.SMTP()
        s.connect("172.24.0.11",25)
        s.ehlo()
        s.starttls()
        s.ehlo()
        s.login('mkumar@movoto.com', '1111@Laptop')
        
        
        s.sendmail(sender, receivers, message)
        print "Successfully sent email"
    except Exception,R:
            print "Error: unable to send email", R
            
mail_old()