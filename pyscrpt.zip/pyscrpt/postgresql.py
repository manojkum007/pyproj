# -*- coding: utf-8 -*-
"""
Created on Mon Feb 15 11:05:25 2016

@author: manoj
"""

import psycopg2 as mdb
import sys
import csv
import psycopg2.extras
reload(sys)
sys.setdefaultencoding('utf-8')


class postgresqlconnector :
    def __init__(self, host,  usrname, passwrd, database, port):
        self.host=host
        self.username=usrname
        self.password=passwrd
        self.database=database
        self.port=port
        self.command= ""
        if (self.connect()==0):
            exit(1)
    def connect(self):
              
        try:           
            self.con = mdb.connect(database=self.database, user=self.username, password=self.password, host=self.host, port=self.port)
            #self.cur=self.con.cursor()
            return 1
        except mdb.Error as e:
            print "postgresql Error : %s" % (e.pgerror)
            return 0
    

#    def setQuery(self ,command):
#        self.command=command

    def execQuery(self,command):
        print "njljndbf"
        try:
            self.cur=self.con.cursor(cursor_factory=psycopg2.extras.DictCursor)
            self.cur.execute(command)
#            for row in self.cur:
#                print row
            data= self.cur.fetchall()
            print "data",data
            self.cur.close()         
            return data        
        except mdb.Error as e:
            print "error in executing sql statement",e.pgerror
            self.con.rollback()
            return 0
    
    def execmanyQuery(self,lis):
        with self.con.cursor() as cursor:
            for i in lis:
                cursor.execute(i)
                yield cursor.fetchall()
    
    def insertquery(self, sql ,valueList):
        #print self.con.cursor().executemany(sql, valueList) 
        try:
            self.con.cursor().executemany(sql, valueList) 
            self.con.commit()
        except Exception as e:
            print "in error",e
        finally:
            print "inserted successfully"
         

        
#        try:
#            self.cur=self.con.cursor()
#            for i in lis:
#                self.cur.execute(i)
#                yield self.cur.fetchall()
#        except mdb.Error as e:
#            print "error in executing sql statement",e.pgerror
#            yield 0

#    def fetchResults(self): 
#        try:
#           return self.cur.fetchall()          
#        except mdb.Error as e:
#            print "error in fetching results",e.pgerror
       
        

#    def fetchSingleResults(self):
#        return self.cur.fetchone()

    def __del__(self):
        #self.con.commit()
        #self.cur.close()
        self.con.close()
        print "closing connection"


#pgres=postgresqlconnector(host='172.24.0.95',  database='Realestate', usrname='census', passwrd='censuspassword',port=5432)

#pgres=postgresqlconnector(host='192.168.120.137',  database='Realestate', usrname='census', passwrd='censuspassword',port=5432)

#pgres=postgresqlconnector(host='127.0.0.1',  database='postgres', usrname='postgres', passwrd='admin',port=5432)




sql="SELECT filter_type, state_name, total_listing FROM mlstat.mlstat  limit 10;"

sql1="""select mls, mls_id,last_name, clean_lname, agent_id, type_description, list_price, 
 street_pretype, foreclosure, address_unit, street_name, transaction_id,
 clean_phones, full_baths, list_office_id, street_predir, full_name, date_sale, 
 phones, partial_baths, mlsid, property_id, l.updated_tstmp, clean_phones_old, city,
 listing_id, co_sell_office_id, zip, state_full, street_postdir, sale_comp_percent, 
 unit_type, co_sell_agent_id, email_address, street_suffix, reo, remove_flag, 
 l.status_code, sale_price, street_num, tax_id, unit_number, new_construction, office_id, street_premod,
bedrooms, co_list_agent_id, full_address, sell_agent_id, street_suffix_normalized, address, state_code,
sell_office_id, class_description, subdivision, l.created_tstmp, co_list_office_id, org_price, list_agent_id, full_street_name, 
 clean_fname, first_name, external_id, clean_full_name, short_sale, square_ft  from mls_all.listings l 
inner join mls_all.agents a  on l.list_agent_id =a.agent_id where city like '%fresno%' limit 100;""" 


#sql1="SELECT * FROM mls_movototmp.offices limit 1"
#sql3="CREATE SCHEMA emp AUTHORIZATION postgres"
lis=[]
#lis.append(sql3)
lis.append(sql)
#pgres=postgresqlconnector('127.0.0.1', 'postgres','admin', 'postgres',5432)
#print pgres.execQuery(sql)

#t="휀"
#insertlis=[('unknown2', t, 215284), ('unknown1', t, 14003)]
#insertqry="insert into  mlstat.mlstat(  filter_type, state_name, total_listing )  VALUES (%s, %s, %s);"
#pgres.insertquery(insertqry,insertlis )




#for i in lis: 
#    print pgres.execQuery(sql)

    
    
#data=pgres.execmanyQuery(lis)
#print data.next()


#data=pgres.execQuery(sql)
def sanity(lis):
    try:
         lis=map(lambda t: t.encode('utf-8') if (type(t)==str or type(t)==unicode) else t,lis)
         return lis
    except Exception as e:
        return  e
        
        
        

def writeDataFile(mlsFile,lisdata):
    with open(mlsFile, 'w') as log_file:
        writer = csv.writer(log_file, delimiter='\t')
        for row in lisdata:
            writer.writerow(row)

#print data
#
#writeDataFile("/home/manoj/scripts/python_scripts/Pyspark_module/sample.txt", data)


pgres=postgresqlconnector(host='192.168.120.118',  database='movotogeo', usrname='postgres', passwrd='igen4movoto',port=5432)
#sql="""SELECT csafp, cbsafp, "name", lsad, memi, mtfcc, relver FROM census.maponics_cbsas_us_current limit 1;"""
#data=pgres.execQuery(sql)
#print data

invalid=[('', '', 'locality0', '6318572', 'B', None, 4, '*RS', 'Brasil', 'S3O PEDRO DO BUTI\\xed\\xbe\\x93', '', '4319372', None, '*', '', '', '', '', 'Brazil', 'BR', 'ABrasil IBGE', '', '', '43', 'Centro Local', '', '', 'S\xc3\xa3o Pedro do Buti\xc3\xa1', '', None, '*', 'POLYGON ((-54.8862376247 -28.1203382684 ,-54.8862538439 -28.1229507381 ,-54.885172899 -28.1229232741 ,-54.8846125651 -28.1229256901 ,-54.884604232 -28.124462155 ,-54.8835784591 -28.1244859312 ,-54.8835731619 -28.126705434 ,-54.8850987295 -28.1266895427 ,-54.8850902421 -28.1273387125 ,-54.8861781135 -28.1273718872 ,-54.8861620721 -28.1287192362 ,-54.8897390361 -28.1287395368 ,-54.8918737844 -28.1287183482 ,-54.8960069956 -28.1285761194 ,-54.898857597 -28.1284780267 ,-54.8988615732 -28.1256411221 ,-54.902984339 -28.1256807937 ,-54.9029354588 -28.1239931479 ,-54.9028865786 -28.122305502 ,-54.8948472464 -28.1222267749 ,-54.8948210988 -28.1214027055 ,-54.8939245683 -28.1214186364 ,-54.8919055698 -28.1214234375 ,-54.8919055674 -28.1214188855 ,-54.8897562728 -28.1214158028 ,-54.8897449158 -28.1212745059 ,-54.8886069524 -28.1212663946 ,-54.8885986482 -28.1199682669 ,-54.8873473451 -28.1199758548 ,-54.886248219 -28.1199939541 ,-54.8862323311 -28.1200100629 ,-54.8862376247 -28.1203382684 ))')]

    
#insertlis=[('', '', 'locality0', '6318572', 'B', None, 4, '*RS', 'Brasil', 'S3O PEDRO DO BUTI\\xed\\xbe\\x93'.encode('utf-8') , '', '4319372', None, '*', '', '', '', '', 'Brazil', 'BR', 'ABrasil IBGE', '', '', '43', 'Centro Local', '', '', 'S\xc3\xa3o Pedro do Buti\xc3\xa1', '', None, '*', 'POLYGON ((-54.8862376247 -28.1203382684 ,-54.8862538439 -28.1229507381 ,-54.885172899 -28.1229232741 ,-54.8846125651 -28.1229256901 ,-54.884604232 -28.124462155 ,-54.8835784591 -28.1244859312 ,-54.8835731619 -28.126705434 ,-54.8850987295 -28.1266895427 ,-54.8850902421 -28.1273387125 ,-54.8861781135 -28.1273718872 ,-54.8861620721 -28.1287192362 ,-54.8897390361 -28.1287395368 ,-54.8918737844 -28.1287183482 ,-54.8960069956 -28.1285761194 ,-54.898857597 -28.1284780267 ,-54.8988615732 -28.1256411221 ,-54.902984339 -28.1256807937 ,-54.9029354588 -28.1239931479 ,-54.9028865786 -28.122305502 ,-54.8948472464 -28.1222267749 ,-54.8948210988 -28.1214027055 ,-54.8939245683 -28.1214186364 ,-54.8919055698 -28.1214234375 ,-54.8919055674 -28.1214188855 ,-54.8897562728 -28.1214158028 ,-54.8897449158 -28.1212745059 ,-54.8886069524 -28.1212663946 ,-54.8885986482 -28.1199682669 ,-54.8873473451 -28.1199758548 ,-54.886248219 -28.1199939541 ,-54.8862323311 -28.1200100629 ,-54.8862376247 -28.1203382684 ))')]
#
#insertlis=['', '', 'locality0', '6318572', 'B', None , 4, '*RS', 'Brasil', 'S3O PEDRO DO BUTI\\xed\\xbe\\x93', '', '4319372', None, '*', '', '', '', '', 'Brazil', 'BR', 'ABrasil IBGE', '', '', '43', 'Centro Local', '', '', 'S\xc3\xa3o Pedro do Buti\xc3\xa1', '', None, '*', 'POLYGON ((-54.8862376247 -28.1203382684 ,-54.8862538439 -28.1229507381 ,-54.885172899 -28.1229232741 ,-54.8846125651 -28.1229256901 ,-54.884604232 -28.124462155 ,-54.8835784591 -28.1244859312 ,-54.8835731619 -28.126705434 ,-54.8850987295 -28.1266895427 ,-54.8850902421 -28.1273387125 ,-54.8861781135 -28.1273718872 ,-54.8861620721 -28.1287192362 ,-54.8897390361 -28.1287395368 ,-54.8918737844 -28.1287183482 ,-54.8960069956 -28.1285761194 ,-54.898857597 -28.1284780267 ,-54.8988615732 -28.1256411221 ,-54.902984339 -28.1256807937 ,-54.9029354588 -28.1239931479 ,-54.9028865786 -28.122305502 ,-54.8948472464 -28.1222267749 ,-54.8948210988 -28.1214027055 ,-54.8939245683 -28.1214186364 ,-54.8919055698 -28.1214234375 ,-54.8919055674 -28.1214188855 ,-54.8897562728 -28.1214158028 ,-54.8897449158 -28.1212745059 ,-54.8886069524 -28.1212663946 ,-54.8885986482 -28.1199682669 ,-54.8873473451 -28.1199758548 ,-54.886248219 -28.1199939541 ,-54.8862323311 -28.1200100629 ,-54.8862376247 -28.1203382684 ))']
#
#newlis=[]
#ll=map(lambda r :  r if r==None else "%r"%r ,insertlis)
#
#newlis.append(tuple(ll))
#print newlis

insertqry="SET client_encoding = 'UTF8'; insert into  quattroshapes.qs_localities ( qs_a1_alt,qs_a2r,qs_level,qs_gn_id,qs_iso_cc,qs_pop,qs_id,qs_a1,qs_a0,qs_a2,qs_a2_alt,qs_a2_lc,qs_scale,qs_la_lc,qs_a0_lc,qs_a1r_lc,qs_a2r_lc,qs_loc_alt,qs_adm0,qs_adm0_a3,qs_source,qs_la,qs_la_alt,qs_a1_lc,qs_type,qs_a1r_alt,qs_loc_lc,qs_loc,qs_a2r_alt,qs_woe_id,qs_a1r,geom)  VALUES (%s , %s , %s , %s , %s , %s , %s , %s , %s , %s , %s , %s , %s , %s , %s , %s , %s , %s , %s , %s , %s , %s , %s , %s , %s , %s , %s , %s , %s , %s , %s , %s);"

pgres.insertquery(insertqry,invalid )


#sql="""SELECT qs_a2 FROM quattroshapes.qs_localities;"""
#print pgres.execQuery(sql)
#    
#conn=mdb.connect(database='postgres', user='postgres', password='admin', host='127.0.0.1', port=5432)
#cur = conn.cursor()
#try:
#    for i in lis: 
#        cur.execute (i)
#        print cur.fetchall()
#    conn.commit()
#except Exception, e:
#    conn.rollback()
           
           
           
#####calling procedure#########
#conn=mdb.connect(database='postgres', user='postgres', password='admin', host='127.0.0.1', port=5432)
#cur = conn.cursor()
#number=54
#city='varanasi'
#code ='vr'
##data=cur.callproc('public.add_city', [city,code])
##cur.callproc('public.increment',[number])
##data=cur.fetchone()
#data=cur.fetchall()
#conn.commit()
#cur.close()
#conn.close()
#print "data is",data
