# -*- coding: utf-8 -*-
"""
Created on Thu Aug 17 02:12:27 2017

@author: manoj
"""

import multiprocessing

#def worker():
#    """worker function"""
#    print 'Worker'
#    return
#
#if __name__ == '__main__':
#    jobs = []
#    for i in range(5):
#        p = multiprocessing.Process(target=worker)
#        jobs.append(p)
#        p.start()
#        
#        
#        



####################with argument########################3
#import multiprocessing
#
#def worker(num):
#    """thread worker function"""
#    print 'Worker:', num
#    return
#
#if __name__ == '__main__':
#    jobs = []
#    for i in range(5):
#        p = multiprocessing.Process(target=worker, args=(i,))
#        jobs.append(p)
#        p.start()






##########################3using pool method ####################


def do_calculation(data):
    return data * 2

def start_process():
    print 'Starting', multiprocessing.current_process().name
    
    
    
if __name__ == '__main__':
    inputs = list(range(10))
    print 'Input   :', inputs
    
    builtin_outputs = map(do_calculation, inputs)
    print 'Built-in:', builtin_outputs
    
    pool_size = multiprocessing.cpu_count() * 2
    pool = multiprocessing.Pool(processes=pool_size,
                                initializer=start_process,
                                )
    pool_outputs = pool.map(do_calculation, inputs)
    pool.close() # no more tasks
    pool.join()  # wrap up current tasks

    print 'Pool    :', pool_outputs