# -*- coding: utf-8 -*-
"""
Created on Mon Oct 30 17:01:13 2017

@author: manoj
"""

#Python libraries
import logging
import os
import subprocess
import datetime
import json
import time
#import thrift

#Internal libraries
import luigi_properties
from movoto_task import MovotoTask
from movoto_task import MovotoEsTarget

import movoto_logger

#Third-party libraries
import luigi
from luigi.contrib.hdfs.hadoopcli_clients import HdfsClient
from luigi.contrib.hdfs.target import HdfsTarget
from luigi.contrib.hive import *
from luigi.hive import HiveTableTarget, run_hive_cmd
from luigi import notifications
import pymssql
import sys

try:
    import _mssql
except ImportError as e:
    logger.warning("Loading MSSQL module without the python package pymssql. \
        This will crash at runtime if SQL Server functionality is used.")


logger = movoto_logger.get_logger('luigi daily run.log')


class PantherDataImport(luigiTask):
    job_name = luigi.Parameter()
    run_date = luigi.DateParameter(default = datetime.date.today()-datetime.timedelta(days=0))
    get_all = luigi.Parameter(default = False)
		
        
    def requires(self):pass
        #yield PrimaryCheck(self.run_date ,self.logger)
        
        

    @property
    def spark_submit(self):
        return configuration.get_config().get('spark', 'spark-submit', 'spark-submit')

    @property
    def master(self):
        return configuration.get_config().get("spark", "master", None)


    @property
    def executor_memory(self):
        return configuration.get_config().get("spark", "executor-memory", None)

    @property
    def driver_cores(self):
        return configuration.get_config().get("spark", "driver-cores", None)

    @property
    def total_executor_cores(self):
        return configuration.get_config().get("spark", "total-executor-cores", None)

    @property
    def driver_memory(self):
        return configuration.get_config().get("spark", "driver-memory", None)
    
    @property
    def num_executors(self):
        return configuration.get_config().get("spark", "num-executors", None)
    
    @property
    def jars(self):
        return configuration.get_config().get("spark", "jars", None)

    
    def app_options(self):
        jdbc_property_file = str(self.luigi_config.get('spark', 'jdbc_property_file'))
        job_property_file = str(self.luigi_config.get('spark', 'job_property_file'))
        run_date = str(self.run_date.strftime('%Y-%m-%d'))    
        self.params = [jdbc_property_file, job_property_file, run_date]
        return self.params

       

    def run(self):
        spark = PantherDataImport(self.run_date)
        
        spark.app = self.luigi_config.get('spark', 'app')
        spark.entry_class = self.luigi_config.get('spark', 'entry_class')
        spark.name = self.luigi_config.get('spark', 'name')
        self.app_options()
        try:
            #sparkcommand = SparkSubmitTask.run(self)
            self.logger.info("result of job %s"%sparkcommand)
        except Exception as e:
            self.logger.info("Error while running spark submit %s "%e)
            



    def output(self):pass
#        return luigi.LocalTarget(path='target/VerifyData_%s_%s.txt'%(self.job_name,self.run_date.strftime('%Y-%m-%d')))                      

        #return MovotoEsTarget(self.job_name, self.__class__.__name__, self.run_date, 'daily')


class DataCheck(MovotoTask):
    job_name = luigi.Parameter()
    run_date = luigi.DateParameter(default = datetime.date.today()-datetime.timedelta(days=0))
    get_all = luigi.Parameter(default = False)
    record_count=luigi.Parameter(default=0)

		
    def requires(self):
	return PantherJobHistoryCheck(job_name=self.job_name, run_date=self.run_date, get_all=self.get_all)


    def DBConnection(self):
	luigi_config = luigi.configuration.get_config()
	conn = pymssql.connect(host=luigi_config.get('MlsCheck','Host'), user=luigi_config.get('MlsCheck','User'), password=luigi_config.get('MlsCheck','Password'), database=luigi_config.get('MlsCheck','Database'),as_dict=True)
        return conn


    def run_task(self):
        try:
            luigi_config = luigi.configuration.get_config()
            connection=self.DBConnection()
            cur = connection.cursor()
            
            if(self.job_name=="mls_listing"):
                queryExec = str(luigi_config.get('MlsCheck','mls_listing_query')%(self.run_date.strftime('%Y-%m-%d') ,self.run_date.strftime('%Y-%m-%d')))
            elif(self.job_name=="mls_public_record_association"):
                queryExec = str(luigi_config.get('MlsCheck','mls_public_record_association_query')%(self.run_date.strftime('%Y-%m-%d') ,self.run_date.strftime('%Y-%m-%d')))
            elif(self.job_name=="mls_address"):
                queryExec = str(luigi_config.get('MlsCheck','mls_address_query')%(self.run_date.strftime('%Y-%m-%d') ,self.run_date.strftime('%Y-%m-%d')))
            elif(self.job_name=="attribute_history"):
                queryExec = str(luigi_config.get('MlsCheck','attribute_query')%(self.run_date.strftime('%Y-%m-%d') ,self.run_date.strftime('%Y-%m-%d')))
            elif(self.job_name=="mls_image_downloader_status_history"):
                queryExec = str(luigi_config.get('MlsCheck','mls_image_downloader_query')%(self.run_date.strftime('%Y-%m-%d') ,self.run_date.strftime('%Y-%m-%d')))

            
            if self.get_all=='True':
                queryExec=None
                
            logger.info(queryExec)
            if queryExec is not None:
                cur.execute(queryExec)
                self.record_count=cur.fetchone()['cnt']
                logger.info(self.record_count)
                
            	if self.record_count<=0:
                 logger.info("Could not Find update for the day")
                 sys.exit()
                 
#            	if queryExec is not None:
#            		for row in cur:
#                		if row is not None or row!='':
#                    			if datetime.datetime.strptime(row['max_created_at'],'%Y-%m-%d')<datetime.datetime.strptime(str(self.run_date-datetime.timedelta(days=1)),'%Y-%m-%d'):
#                        			logger.info('No loaded_at data found for the day %s',str(self.run_date))
#						sys.exit()
#                    			elif datetime.datetime.strptime(row['max_created_at'],'%Y-%m-%d')==datetime.datetime.strptime(str(self.run_date-datetime.timedelta(days=1)),'%Y-%m-%d'):
#                        			logger.info("True")
#						pass
#                		else:
#                    			logger.info("Could not Find update for the day")
#		    			sys.exit()

            connection.close()

        except _mssql.MSSQLDatabaseException as e:
            # Error number for table doesn't exist
            logger.info("Job Failed With Error:"+e)


    def output(self):
        return MovotoEsTarget(self.job_name, self.__class__.__name__, self.run_date, 'daily')


if __name__ == "__main__":
    luigi.run()


