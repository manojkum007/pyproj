# -*- coding: utf-8 -*-
"""
Created on Mon May 29 17:34:36 2017

@author: manoj
"""

import re
dd="""94.102.63.11 - - [21/Jul/2009:02:48:13 -0700] "GET / HTTP/1.1" 200 18209 "http://acme.com/foo.php" "Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)"""


ob=re.match("(\d+\.){3}\d+\s+-\s+-\s+\[\S+\s+-\d+\]",dd)

if ob:
    print ob.group(0)