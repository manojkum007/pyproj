import luigi
import os

class BadlyCodedTask(luigi.Task):

    def output(self):
        #return True
        file_path="/home/manoj/logs/log_127.txt"
        return fileTarget(file_path)
        #return  os.path.exists(file_path)
        #pass
        #return luigi.LocalTarget("BadlyCodedTask")

    def run(self):
        print "*" * 60
        print "BadlyCodedTask.run" 
#        with self.output().open('w') as out_file:
#            out_file.write("intial")
    
#    def exists(self):
#        pass
#        file_path="/home/manoj/logs/log_127.txt"
#        return  os.path.exists(file_path)
class fileTarget(luigi.target.Target):
    path = luigi.Parameter()
    
    def __init__(self, path):
        self.file_path =path

    def exists(self):
        return  os.path.exists(self.file_path)
        
class RunAll(luigi.Task):

    def requires(self):
        #pass
        return BadlyCodedTask()

    def output(self):
        return luigi.LocalTarget("RunAll")

    def run(self):
        with self.output().open('w') as out_file:
            out_file.write("Done")


if __name__ == '__main__':
    luigi.run(main_task_cls=RunAll)