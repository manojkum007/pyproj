# -*- coding: utf-8 -*-
"""
Created on Wed Mar  2 14:40:58 2016

@author: manoj
"""

import psycopg2
import datetime


tiger_host="172.24.0.95"
tiger_database="realestate_dev"
tiger_user="census"
tiger_password="censuspassword"

tiger_host="127.0.0.1"
tiger_database="postgres"
tiger_user="postgres"
tiger_password="admin"

conn = psycopg2.connect(host=tiger_host, dbname=tiger_database, user=tiger_user, password=tiger_password)
cur = conn.cursor()
command = """
            select table_name
from information_schema.tables
where 
 table_schema in ('[table]')
  and table_type='BASE TABLE'
            """.replace('[table]', 'mls_updates')


command= "select * from mls_updates.listings limit 5;"
            
#command= """
#			INSERT INTO mls_updates.listings1(
#            mls, mls_id, address, address_unit, city, state_code, zip, org_price, 
#            list_price, sale_price, date_sale, list_agent_id, list_office_id, 
#            co_list_agent_id, co_list_office_id, sell_agent_id, sell_office_id, 
#            co_sell_agent_id, co_sell_office_id, status_code, class_description, 
#            type_description, new_construction, tax_id, sale_comp_percent, 
#            square_ft, subdivision, reo, foreclosure, short_sale, full_baths, 
#            partial_baths, bedrooms, street_num, street_predir, street_premod, 
#            street_pretype, street_name, full_street_name, street_suffix, 
#            street_suffix_normalized, street_postdir, unit_type, unit_number, 
#            state_full, full_address, listing_id, remove_flag, transaction_id, 
#             created_tstmp, updated_tstmp) VALUES 
#          """            
row_lis=[('crisnet', 'iv16005385', '11773 holly st', 'None', 'grand terrace', 'ca', '92313', 349900, 349900, 'None', 'None', 'ispavgeo', 'ivspav', 'None', 'None', 'None','None', 'None', 'None', 'a', 'residential', 'single family residence', 'None', '276284100000', '0.0225', '2160', 'None', 'None', 'None', 'None', 2, 'None', 4, '11773', '', '', '', 'holly', 'holly', 'st', 'street', '', '', '', 'california', '11773 holly street', 'None', 'None', 'None', '2016-03-05 00:42:42.537737', '2016-03-05 00:42:42.537758'), ('crisnet', 'jt16005235', '60740 lutz', 'None', 'landers', 'ca', '92284', 75000, 75000, 73000, '2016-02-11 00:00:00', 'dc50814', 'dc5831', 'None', 'None', 'panonmember', 'panon-member', 'None', 'None','s', 'residential', 'single family residence', 'None', '630271390000', '0.03', '780', 'None', 'None', 'None', 'None', 1, 'None', 1, '60740', '', '', '', 'lutz', 'lutz', '', '', '', '', '', 'california', u'60740 lutz', 'None', 'None', 'None', '2016-03-05 00:42:42.538502', '2016-03-05 00:42:42.538514')]


#command+='{0},{1}'.format(row_lis[0],row_lis[1])

##prepare query 
prepare_query ="""PREPARE salinsert (int, text, numeric, text[]) AS
    INSERT INTO employeedb.salary VALUES($1, $2, $3 ,$4 );"""



#print prepare_query
cur.execute(command)
res=cur.fetchall()
#conn.close()
#data=res.split("\n")
for i in res:
    print i[0]
    break

#cur.execute(prepare_query)
#
#
#
#for i in range(3,8):
#    com ="EXECUTE salinsert(%s, '%s', %s, '%s')"%(i*50 ,'sanmateo',200.00*float(i*23),'{"yvonn", "saarinen"}')
#    print com
#    cur.execute(com)




#pr_qry='PREPARE deedinsrt (text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,int,text,numeric,numeric,numeric,text,text,int,text,text,numeric,text,int,text,text,text,int,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,int,text,text,date,date,date,timestamp,timestamp) AS INSERT INTO deeds.all_deeds VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35,$36,$37,$38,$39,$40,$41,$42,$43,$44,$45,$46,$47,$48,$49,$50,$51,$52,$53,$54,$55,$56,$57,$58,$59,$60,$61,$62,$63,$64,$65,$66,$67,$68,$69,$70,$71,$72,$73,$74,$75,$76,$77,$78,$79,$80,$81,$82,$83,$84,$85,$86,$87,$88,$89,$90,$91,$92,$93,$94,$95,$96,$97,$98,$99,$100,$101,$102,$103,$104,$105);'
#print cur.execute(pr_qry)
#comm="EXECUTE deedinsrt ("+ ', '.join(['%s']*105)+")"
#import datetime
#today = datetime.datetime.today()
#row='05027,1541 COLUMBIA ROAD 30,MAGNOLIA,AR,71753,9159,,,1541         ,,COLUMBIA ROAD 30,,,R005,20130506,371       ,821       ,,SW,00-08022-001,,,DAVID W,COMPTON,HW,BETTY L,COMPTON,KACEY LYNN,WILSON,SW,,,,,,,,,,,,,,,,,NW4 NW4 S30 T17S R20W,,,,,,,,20130416,82000,D,0,0,0,0,,0,,0,56,,5172,,,,96,,,,,,,,,,,,,1001,1,0,0,0,0,0,0,0,1,2410 brothers drive,,2410 brothers drive,99,2014-02-18,,2014-02-18,2016-03-17 11:54:33.332339,2016-03-17 11:54:33.332339,2016-03-14 18:22:52.49147,2016-03-14 18:22:52.491478'
#rowlis=row.split(",")
#rowlis=['02176', '3061 n lazy aurora cir', None, 'ak', None, None, None, None, '3061', 'n', 'lazy aurora', 'cir', None, None, datetime.date(2015, 4, 13), None, None, '20150068650', 'wd', '7250000l008', None, None, None, 'selway corp', 'co', None, None, 'glen', 'price', 'sp', None, None, None, '20150068660', 'palmer', 'ak', '99645', '1491', None, '8', None, None, None, None, None, None, 'lazy aurora', None, None, None, None, 'pl2013123', None, 'mfd', datetime.date(2015, 4, 10), None, None, None, None, None, 'homestate mortgage company llc', 'l', '255676', 'n', None, None, datetime.date(2045, 5, 1), None, 'po box 1491', None, None, '196532', None, 'atga', 'y', None, None, None, None, None, None, None, None, None, None, None, None, None, '1110', '1', None, None, None, None, None, None, None, 906805, u'3061 north lazy aurora circle', '', datetime.date(2015, 4, 13), datetime.date(2015, 4, 10), datetime.date(2045, 5, 1), datetime.datetime(2016, 3, 17, 12, 10, 24, 848003), datetime.datetime(2016, 3, 17, 12, 10, 24, 848022)]
#cur.execute(comm,rowlis)
#rowlis=['02177', '3061 n lazy aurora cir', None, 'ak', None, None, None, None, '3061', 'n', 'lazy aurora', 'cir', None, None, datetime.date(2015, 4, 13), None, None, '20150068650', 'wd', '7250000l008', None, None, None, 'selway corp', 'co', None, None, 'glen', 'price', 'sp', None, None, None, '20150068660', 'palmer', 'ak', '99645', '1491', None, '8', None, None, None, None, None, None, 'lazy aurora', None, None, None, None, 'pl2013123', None, 'mfd', datetime.date(2015, 4, 10), None, None, None, None, None, 'homestate mortgage company llc', 'l', '255676', 'n', None, None, datetime.date(2045, 5, 1), None, 'po box 1491', None, None, '196532', None, 'atga', 'y', None, None, None, None, None, None, None, None, None, None, None, None, None, '1110', '1', None, None, None, None, None, None, None, 906805, u'3061 north lazy aurora circle', '', datetime.date(2015, 4, 13), datetime.date(2015, 4, 10), datetime.date(2045, 5, 1), datetime.datetime(2016, 3, 17, 12, 10, 24, 848003), datetime.datetime(2016, 3, 17, 12, 10, 24, 848022)]
#
#cur.execute(comm,rowlis)

#################buyer_seller#########
#buyer_seller_query ='PREPARE buyer_sellerinsrt (int,text,date,text,text,text,text[],text[],text[],text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text[],text[],text[]) AS INSERT INTO deeds.buyer_seller_names VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33);'
#cur.execute(buyer_seller_query)
#buyerow=[906808, 'seller2', datetime.date(2012, 7, 24), 'yvonne j', 'saarinen', 'yvonne j saarinen', ['yvonne'], ['saarinen'], ['yvonne', 'saarinen'], None, None, 'yvonne', None, None, 'j', 'saarinen', None, None, None, None, None, None, None, None, None, None, None, None, 'ak', '99654', 'yvonne j', 'saarinen', 'yvonne j saarinen']
#comm="EXECUTE buyer_sellerinsrt ("+ ', '.join(['%s']*33)+")"
#comm = 'EXECUTE buyer_sellerinsrt  (' + ', '.join(['%s']*30) + ", " + ', '.join(['array[public.soundex(%s)]']*3) + ');'
#cur.execute(comm,buyerow)


##############parsed_names_addresses##########
#parsed_names_qry='PREPARE parsed_namesinsrt (int,text,text,text,date,date,int,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text,text[],text[],text[],text,text,text,text[],text[],text[],text,text,text,text[],text[],text[],text,text,text,text[],text[],text[]) AS INSERT INTO deeds.parsed_names_addresses VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35,$36,$37,$38,$39,$40,$41,$42,$43,$44,$45,$46,$47,$48,$49,$50,$51,$52,$53,$54,$55,$56,$57,$58,$59,$60,$61,$62,$63);'
#cur.execute(parsed_names_qry)
#parsed_row=[906813, '02875', datetime.date(2012, 7, 24), datetime.date(2012, 7, 23), datetime.date(2012, 7, 24), datetime.date(2012, 7, 23), None, '150 e leota st', 'wasilla', 'ak', u'150 east leota street', '150', 'e', '', '', 'leota', 'leota', 'st', 'street', '', '', '', 'alaska', '601 n shadowood cir', 'wasilla', 'ak', u'601 north shadowood circle', '601', 'n', '', '', 'shadowood', 'shadowood', 'cir', 'circle', '', '', '', 'alaska', 'casey', 'mcmanus', 'casey mcmanus', ['casey'], ['mcmanus'], ['casey', 'mcmanus'], 'jennifer', 'mcmanus', 'jennifer mcmanus', ['jennifer'], ['mcmanus'], ['jennifer', 'mcmanus'], 'walter l', 'saarinen', 'walter l saarinen', ['walter'], ['saarinen'], ['walter', 'saarinen'], 'yvonne j', 'saarinen', 'yvonne j saarinen', ['yvonne'], ['saarinen'], ['yvonne', 'saarinen']]
#comm="EXECUTE parsed_namesinsrt ("+ ', '.join(['%s']*63)+")"
#cur.execute(comm,parsed_row)

#print cur.fetchall()
conn.commit()
conn.close()