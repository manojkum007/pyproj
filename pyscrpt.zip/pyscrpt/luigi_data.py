
Luigi Task Status
Toggle navigation

    Task List
    Dependency Graph
    Workers

    TASK FAMILIES
    2561 DeedsToDb
    47 CopySchemaToHdfs
    47 SqoopToHive
    47 ParquetHive
    47 SqoopImportTask
    47 GetAvroSchema
    47 AvroToParquetTask
    1 LastVisitToDb
    1 MergeLastVisitUpdates
    1 LastVisitsToCheetah
    1 GetDailyData
    1 AllDeedsToDb

Pending Tasks 69
Running Tasks 1
Done Tasks 2643
Failed Tasks 134
Upstream Failure 1
Disabled Tasks 0
Upstream Disabled 0
Displaying RUNNING, FAILED, tasks of family DeedsToDb .
Show
entries
Filter table:
	Name	Details	Priority	Time	Actions
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/22101_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/21103_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/48281_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/28059_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/01091_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/21205_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/42021_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/29221_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/23029_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/20161_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/31145_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/54011_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/22105_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/54039_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/21063_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/26141_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/35061_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/01095_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/20169_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/26011_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/29161_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/18153_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/06067_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/01071_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/39145_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/17075_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/45019_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/18095_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/55027_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/20015_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/01049_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/26129_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/55055_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/21005_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/35029_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/22103_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/29107_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/01081_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/26007_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/28075_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/05149_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/42013_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/08103_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/41057_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/01089_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/21069_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/17149_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/23005_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/20095_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/21223_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/42077_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/41067_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/05017_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/18155_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/42087_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/23001_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/22091_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/22001_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/26051_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/22077_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/21009_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/37077_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/01061_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/08003_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/08043_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/17129_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/21041_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/37179_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/23027_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/29051_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/23025_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/01001_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/18013_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/23017_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/01109_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/21193_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/01013_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/28049_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/23023_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/54009_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/21227_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/17097_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/26137_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/17031_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/17005_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/21095_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/18101_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/56025_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/26033_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/48203_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/23031_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/54107_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/26031_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/21073_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/17173_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/21239_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/17043_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/18059_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/23011_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
Showing 1 to 100 of 135 entries (filtered from 2,848 total entries)
Previous12Next
