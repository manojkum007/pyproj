
Luigi Task Status
Toggle navigation

    Task List
    Dependency Graph
    Workers

    TASK FAMILIES
    2561 DeedsToDb
    47 CopySchemaToHdfs
    47 SqoopToHive
    47 ParquetHive
    47 SqoopImportTask
    47 GetAvroSchema
    47 AvroToParquetTask
    1 LastVisitToDb
    1 MergeLastVisitUpdates
    1 LastVisitsToCheetah
    1 GetDailyData
    1 AllDeedsToDb

Pending Tasks 69
Running Tasks 1
Done Tasks 2643
Failed Tasks 134
Upstream Failure 1
Disabled Tasks 0
Upstream Disabled 0
Displaying RUNNING, FAILED, tasks of family DeedsToDb .
Show
entries
Filter table:
	Name	Details	Priority	Time	Actions
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/26057_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/20041_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/42075_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/01007_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/23021_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/54069_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/05019_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/21215_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/26113_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/23015_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/01045_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/49019_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/17123_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/23019_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/21081_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/56039_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/21079_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/40027_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/01015_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/21077_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/01031_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/41059_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/41041_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/21169_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/01069_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/32033_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/51067_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/21167_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/41071_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/18071_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/10005_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/18117_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/12101_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
FAILED	DeedsToDb	
(deeds_file=/opt/deeds_2012/48053_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm	
RUNNING	DeedsToDb	
(deeds_file=/opt/deeds_2012/06059_Deed_Refresh_20151007.txt)
	0	22/2/2016 3:46:02 pm | 0 minutes	
Showing 101 to 135 of 135 entries (filtered from 2,848 total entries)
Previous12Next
