# -*- coding: utf-8 -*-
"""
Created on Fri Jul 28 15:50:14 2017

@author: manoj
"""

import pandas as pd



url = 'http://bit.ly/drinksbycountry'
drinks = pd.read_csv(url)

print drinks.head()

print drinks.dtypes
drinks['beer_servings'] = drinks.beer_servings.astype(str)

print  "aftre" ,drinks.dtypes