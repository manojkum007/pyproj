# -*- coding: utf-8 -*-
"""
Created on Mon Mar 27 13:08:47 2017

@author: manoj
"""
import datetime
import luigi
from elasticsearch import Elasticsearch
import sys
import os


offset=5000



  
class elastic_search_fetch(luigi.Task):
    sdate=luigi.DateParameter(default=datetime.date.today() - datetime.timedelta(days=1))
          
    def run(self):
#        es = Elasticsearch([{'host': '172.24.0.90'}] ,port= 9200)    
        es = Elasticsearch([{'host': '192.168.120.136'}] ,port= 8080) 
        es_index="jobstatus_prod"
        basevalue=0
        bdy= {  
                       "query":{  
                          "filtered":{  
                             "query":{  
                                "query_string":{  
                                   "query":"_type:RowCountStat",
                                   "analyze_wildcard":True
                                }
                             },
                             "filter":{  
                                "bool":{  
                                   "must":[  
                                      {  
                                         "range":{  
                                            "@timestamp":{  
                                               "gte":self.sdate,
                                               "lte":self.sdate + datetime.timedelta(days=0)
                                            }
                                         }
                                      }
                                   ],
                                   "must_not":[  
                    
                                   ]
                                }
                             }
                          }
                       },
                       "from":basevalue,
                       "size":offset
             }   
        try:   
            while True:
                bdy["from"]=basevalue  
#                self.log.info(" es query  %s"%bdy)
                response = es.search( index=es_index,body=bdy)
                responselis=response.get('hits').get('hits')
                
                print "elastic result",responselis
                if len(responselis)==0:
                    break 
                basevalue +=offset
                ids=[]
                for i in responselis:
                    ids.append(i.get("_id"))
                    
                bulk_body = ['{{"delete": {{"_index": "{}", "_type": "{}", "_id": "{}"}}}}' .format(es_index, "RowCountStat", x) for x in ids]
                print "bulk_body",bulk_body
                res=es.bulk('\n'.join(bulk_body))
                
                print "after delete",res
        
                #self.log.info("result returned %s" ,responselis)   
                #save_results(responselis, new_es_index,  new_doc_type, self.log)
                                                      
        except Exception as e:
            self.log.info("Problem with elastic search Fetching :  %s"%e)
            sys.exit()
        
#        with self.output().open('w') as f:
#            f.write('{word}\n'.format(word='SitemapUpdate'))


#    def output(self):pass
#        path = os.path.join('/home/manoj/scripts/python_scripts', 'elastic_search_fetch_'%self.sdate.strftime('%Y%m%d'))
#        return luigi.LocalTarget(path=path)
#    