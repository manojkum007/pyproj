# -*- coding: utf-8 -*-
"""
Created on Mon Feb 22 14:48:50 2016

@author: manoj
"""

f=open("/home/manoj/scripts/python_scripts/deeds_2012/log.txt" ,"r+")
f1=open("//home//manoj//scripts//python_scripts//deed_lis2.txt" ,"w+")
st= f.read()
data=st.split("\n")
print data
data.pop()
for i in range(len(data)):
    data[i]="/home/manoj/scripts/python_scripts/deeds_2012/"+data[i]
    f1.write(str(data[i]))
    f1.write("\n")
f.close()
f1.close()