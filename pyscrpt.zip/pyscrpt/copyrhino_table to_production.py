# -*- coding: utf-8 -*-
"""
Created on Sun Jan 15 10:22:11 2017

@author: manoj
"""



class loader():
    def requires():
        pass
    def run():
        address_schema=""" CREATE TABLE bkfs.address_cluster (id VARCHAR(36),subpremise VARCHAR(32),street_number VARCHAR(32),street_direction VARCHAR(16),street_name VARCHAR(128),street_direction_suffix VARCHAR(16),street_designator VARCHAR(16),city VARCHAR(64),state VARCHAR(32),county VARCHAR(128),neighborhood_r VARCHAR(255),neighborhood_m VARCHAR(255),neighborhood_n VARCHAR(255),neighborhood_s VARCHAR(255),neighborhood VARCHAR(500),address VARCHAR(255),zip_code VARCHAR(5),zip_plus_4 VARCHAR(4),latitude decimal(9,6),longitude decimal(9,6),type VARCHAR(20),source_type VARCHAR(20),county_geo_id INT,city_geo_id INT,neighborhood_r_geo_id INT,neighborhood_m_geo_id INT,neighborhood_n_geo_id INT,neighborhood_s_geo_id INT,created_at TIMESTAMP,updated_at TIMESTAMP,addr_source_flag VARCHAR(1),unit_type VARCHAR(4),unit_num VARCHAR(11),addr_carrier_route VARCHAR(4),addr_census_tract VARCHAR(16),data_ver VARCHAR(15)
                            ) clustered by (id) into 499 buckets 
                            stored as orc TBLPROPERTIES ('transactional'='true');
                            """
        addess_qry="insert into  temp.address select * from  mls.address_snapshot"
        
        distcp_command="""hadoop distcp -D mapreduce.map.memory.mb=5120 -D mapreduce.reduce.memory.mb=5120 -D mapred.tasktracker.map.tasks.maximum=30 -D mapred.tasktracker.reduce.tasks.maximum=20 -D mapred.reduce.child.java.opts=-Xmx2048m -D mapred.map.child.java.opts=-Xmx2048m hdfs://rhino.san-mateo.movoto.net:9000/user/hive/warehouse/mls.db/mls_listing_parquet_3 hdfs://analytics-p05.svcolo.movoto.net:9000/tmp"""


"""hadoop distcp  -Dmapreduce.map.memory.mb=24096 -pb -Dmapreduce.reduce.memory.mb=24096 -D mapred.tasktracker.map.tasks.maximum=30 -D mapred.tasktracker.reduce.tasks.maximum=20 -D mapred.reduce.child.java.opts=-Xmx23686m -D mapred.map.child.java.opts=-Xmx23686m hdfs://rhino.san-mateo.movoto.net:9000/user/hive/warehouse/mls.db/mls_listing_snapshot_orc hdfs://analytics-p05.svcolo.movoto.net:9000/tmp/mls_list"""

        
        
        show create schema mls.mls_listing_snapshot_orc;
        

address
attribute
mls_listing
mls_image_downloader_status
mls_public_record_association



mls_listing_snapshot_orc
mls_public_record_association_snapshot_orc
mls_image_downloader_status
address_snapshot_orc
attribute