# -*- coding: utf-8 -*-
"""
Created on Tue Mar  8 19:23:51 2016

@author: manoj
"""

import os
print  os.getcwd()
file_lis=os.chdir('/home/manoj/scripts/python_scripts/mls_download/agents')
for i in file_lis:
    name=i.replace("listings" ,"agents")
    os.rename(i,name)