# -*- coding: utf-8 -*-
"""
Created on Wed Jun 29 19:29:09 2016

@author: manoj
"""

import threading
# 
#list_of_items = ["cat", "banana", "house", "phone"]
# 
#def thread_test(item):
#    print "I am a " + item
#    return
# 
#threads = []
#for word in list_of_items:
#    t = threading.Thread(target = thread_test, args = (word,))
#    threads.append(t)
#    t.start()
#    


lock = threading.Lock()
 
def thread_test(num):
    phrase = "I am number " + str(num)
    with lock:
        print phrase
        f.write(phrase + "\n")
 
threads = []
f = open("text.txt", 'w')
for i in range (100):
    t = threading.Thread(target = thread_test, args = (i,))
    threads.append(t)
    t.start()
 
while threading.activeCount() > 1:
    pass
else:
    f.close()