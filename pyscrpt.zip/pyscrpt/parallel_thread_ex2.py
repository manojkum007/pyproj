# -*- coding: utf-8 -*-
"""
Created on Sat Jun 25 23:43:11 2016

@author: manoj
"""

from multiprocessing import Pool

def even(x,y):
    if (x%2==0):
        return x
    else :
        return -1
 

#def even(x):
#    rlis=[]
#    for i in lis:
#        if (i%2==0):
#            rlis.append(i)
#    return rlis
 

lis=[12,3,6,1,5,8,9] 

p = Pool(5)  
print p.map(even,lis,lis)
#print even(lis)
            