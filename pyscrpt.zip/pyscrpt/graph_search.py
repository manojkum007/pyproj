# -*- coding: utf-8 -*-
"""
Created on Thu Mar  8 23:45:02 2018

@author: manoj
"""

graph = {'A': ['B', 'C'],
             'B': ['C', 'D'],
             'C': ['D'],
             'D': ['C'],
             'E': ['F'],
             'F': ['C']}