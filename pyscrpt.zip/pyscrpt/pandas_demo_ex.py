# -*- coding: utf-8 -*-
"""
Created on Fri Jul 21 22:22:35 2017

@author: manoj
"""

import pandas as pd
from datetime import datetime, timedelta


data = {'name': ['Jason', 'Molly', 'Tina', 'Jake', 'Amy'],
        'year': [2012, 2012, 2013, 2014, 2014],
        'reports': [4, 24, 31, 2, 3],
        'coverage': [25, 94, 57, 62, 70]}
df = pd.DataFrame(data, index = ['Cochice', 'Pima', 'Santa Cruz', 'Maricopa', 'Yuma'])


#print df

#print df[df['coverage']>50]

print df[df['year'] >int((datetime.today()- timedelta(days=1825)).strftime('%Y'))]