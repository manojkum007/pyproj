# -*- coding: utf-8 -*-
"""
Created on Fri Mar  9 11:44:51 2018

@author: manoj
"""


from collections import defaultdict


class Graph:  
    def __init__(self):
        self.graph=defaultdict(list)
    
    def addnode(self,nodelis):
        for node in nodelis:
            self.graph[node]=[]
    
    def addedge(self,node ,edges):
        self.graph[node]=edges
        
    
    def showgraph(self):
        return self.graph
        
g=Graph() 
g.addnode(['A','B','C','D','E','F'])      
g.addedge('A',['B', 'C']) 
g.addedge('B',['C', 'D']) 
g.addedge('C',['D']) 
g.addedge('D',['c']) 
g.addedge('E',['F']) 
g.addedge('F',['C']) 

#print g.showgraph()    

graph = {'A': ['B', 'C'],
             'B': ['A', 'C', 'D'],
             'C': ['D' ,'F'],
             'D': ['C'],
             'E': ['F'],
             'F': ['C']
        }
             

graph = { "a" : ["c"],
          "b" : ["c", "e"],
          "c" : ["a", "b", "d", "e"],
          "d" : ["c"],
          "e" : ["c", "b"],
          "f" : []
        } 
         
#graph =g.showgraph() 
#for k,v in  graph.items():        
#    print k,v

#traversed_list=[]

def graph_connectedness(graph , source , destination ,path=[]):
    #print "destination" ,graph.get(source)
    if  destination in graph.get(source):
        path.append(source)
        path.append(destination)
        #print "final key",source ,"path" ,path
        return path
        
    else:
        for key in graph.get(source) :
            #print "key",key ,"path" ,path
            if key not in path:
                path.append(source)
                return graph_connectedness(graph , key, destination)
            #break


def graph_connectedness_modified(graph , source , destination ,path=[]):
    #print "destination" ,graph.get(source)
    if  destination in graph.get(source):
        path.append(destination)
        return path
        
    else:
        for key in graph.get(source) :
            #print "key",key
            if key not in path:
                path.append(key)
                return graph_connectedness(graph , key, destination)
            #break



def graph_connectedness_allpath(graph , source , destination ,path=[] ,allpath=[]):
    path=path+[source]
    if (source==destination):
        return path
    
    if (graph.get(source))==None:
        return None

    for key in graph.get(source) :
        if key not in path:
            newpaths=graph_connectedness_allpath(graph , key, destination,path ,allpath)
            if newpaths:
                allpath.append(newpaths)
                #print allpath
    return allpath
#            for newpath in newpaths:
#                path.append(newpath)
#    return path
#            
                
def graph_bfs_search(graph ,start, visited=[]):
    fringe=[]
    cnt=0
    while len(fringe)>0:
        cnt+=1
        keys=graph.get(fringe[0])
        print "printing" ,keys
        visited.append(fringe.pop(0))
        if keys!=None:
            newkeys=[i for i in keys if i not in visited]
            fringe.extend(newkeys) 
            print "new kys %s fringe %s ,visited %s"%(newkeys,fringe,visited)
            if cnt>10:break
    print "visited graph" ,visited

#graph_bfs_search(graph ,'A')


def bfs(graph, root):
    visited, queue = [], [root]
    while queue:
        vertex = queue.pop(0)
        #visited.append(vertex)
        for w in graph[vertex]:
            if w not in visited:
                visited.append(w)
                queue.append(w)
    print "visited" ,visited

#graph = {0: [1, 2], 1: [2], 2: []}


#bfs(graph, 'A')


print graph
for k in graph_connectedness_allpath(graph ,'a' ,'d'):
    print k

#print "path returned" ,graph_connectedness(graph ,'a' ,'c')

bipartitegraph={
             'A': ['E', 'C', 'F', 'G'],
             'B': ['C', 'E' ,'F'],
             'C': ['B' ,'A' ,'D'],
             'D': ['C' ,'E', 'F' ,'G'],
             'E': ['B' ,'A'],
             'F': ['A' ,'B' , 'D'],
             'G' :['A' ,'D']
        }
        
        
   
def findbipartitie(bipartitegraph ,lis1 ,lis2):
    for node in bipartitegraph:
        print "visiing " ,node ,lis1 ,lis2
        if node not in lis1 and  node not in lis2:
            lis1.append(node)
            #print "lis1",lis1
        for conn_node in bipartitegraph.get(node):
            if conn_node  not in lis2 and conn_node  not in lis1:
                lis2.append(conn_node)
        #print "lis2:lis1" ,lis2 ,lis1
        #break
        
    return  "lis1" ,lis1 , "lis2" ,lis2

lis1=[]
lis2=[]  
    
#print findbipartitie(bipartitegraph ,lis1 ,lis2)


def checkBipartitie(bipartitegraph ,buck1 ,buck2):pass
    
    
