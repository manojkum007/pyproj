# -*- coding: utf-8 -*-
"""
Created on Thu Jan 12 18:09:48 2017

@author: manoj
"""

if __name__ == '__main__':
    d = dict()
    if (d.get('a')) == None:
        print 'No key'
    else:
        print 'Error!'