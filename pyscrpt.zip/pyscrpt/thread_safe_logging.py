# -*- coding: utf-8 -*-
"""
Created on Wed Jun 29 19:23:44 2016

@author: manoj
"""

import logging
import threading
import time


FORMAT = '[%(levelname)s] (%(threadName)-10s) %(message)s'

logging.basicConfig(level=logging.DEBUG,
                    format=FORMAT)

file_handler = logging.FileHandler('results.log')
file_handler.setFormatter(logging.Formatter(FORMAT))
logging.getLogger().addHandler(file_handler)


def worker():
    logging.info('Starting')
    time.sleep(2)
    logging.info('Exiting')


t1 = threading.Thread(target=worker)
t2 = threading.Thread(target=worker)

t1.start()
t2.start()