# -*- coding: utf-8 -*-
"""
Created on Wed Aug  9 23:35:42 2017

@author: manoj
"""

#import multiprocessing

#from pathos.multiprocessing import ProcessingPool as Pool

#def calculate(x):
#    def domath(y):
#        return x * y
#
#
#pool = multiprocessing.Pool(3)
#final= pool.map(domath, range(3))
#
#calculate(2)

#def calculate(x):
#    def domath(y):
#        return x*y
#    return Pool().map(domath, range(3))
#
#calculate(2)

import multiprocessing



def working():
    vals = [1,2,3]
    def test(x):
        return x

    pool = multiprocessing.Pool()
    output = pool.map(test, vals)
    print output

working()