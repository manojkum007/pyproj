# -*- coding: utf-8 -*-
"""
Created on Sun Mar 11 23:14:50 2018

@author: manoj
"""

function* algorithm() {

    // radius of vertex markers
    var kR = 12,
    // number of points to generate
        kN = 25,
    // generate a random point set within the surface bounds. We store the x/y location of each
    // points along with the element that represents it in an object with properties x, y and e
    //=pointset
        Q = algo.BOUNDS.inflate(-(kR * 2), -(kR * 2)).pointSet(kN, _.bind(function (x, y) {
            return {
                x: x,
                y: y,
                e: new algo.render.Circle({
                    x       : x,
                    y       : y,
                    radius  : kR,
                    fontSize: 16,
                    text    : '?'
                })
            };
        }));

    // the following functions implement the scan

    function cartesian_angle(x, y) {
        if (x > 0 && y > 0)
            return Math.atan(y / x);
        else if (x < 0 && y > 0)
            return Math.atan(-x / y) + Math.PI / 2;
        else if (x < 0 && y < 0)
            return Math.atan(y / x) + Math.PI;
        else if (x > 0 && y < 0)
            return Math.atan(-x / y) + Math.PI / 2 + Math.PI;
        else if (x === 0 && y > 0)
            return Math.PI / 2;
        else if (x < 0 && y === 0)
            return Math.PI;
        else if (x === 0 && y < 0)
            return Math.PI / 2 + Math.PI;
        else return 0;
    }

    function calculate_angle(p1, p2) {
        return cartesian_angle(p2.x - p1.x, p2.y - p1.y);
    }

    function calculate_polar_angles(p0, Q) {
        for (var i = 0; i < Q.length; i++) {
            Q[i].polar = calculate_angle(p0, Q[i]);
        }
    }

    //=minimum
    function minimum(Q) {
        // Find minimum y point (in case of tie select leftmost)         
        // Sort by y coordinate to ease the left most finding
        Q.sort(function (a, b) {
            return a.y - b.y;
        });

        var y_min = 1000000;
        var smallest = 0;
        for (var i = 0; i < Q.length; ++i) {
            var p = Q[i];
            if (p.y < y_min) {
                y_min = p.y;
                smallest = i;
            } else if (p.y == y_min) { // Select left most 
                if (Q[i - 1].x > p.x) {
                    smallest = i;
                }
            }
        }
        return smallest;
    }

    // Three points are a counter-clockwise turn 
    // if ccw > 0, clockwise if ccw < 0, and collinear if ccw = 0 
    function ccw(p1, p2, p3) {
        return (p2.x - p1.x) * (p3.y - p1.y) - (p2.y - p1.y) * (p3.x - p1.x);
    }

    // 
    var minIndex = minimum(Q);
    var p0 = Q[minIndex];
    Q.splice(minIndex, 1);

    // highlight P
    p0.e.set({
        state : algo.render.kS_RED,
        radius: kR * 2,
        text  : 'P'
    });

    yield ({
        step: "From a set of points, select the point (P) with lowest y coordinate (using x as the tie breaker).",
        line: "minimum"
    });

    //=polarSort, sort by polar angle from/to P
    calculate_polar_angles(p0, Q);
    Q.sort(function (a, b) {
        return a.polar - b.polar;
    });

    var clockhand = new algo.render.Arrow({
        startArrow: false,
        endArrow  : true
    });

    // highlight the order of each each element now that we have sorted
    // them with respect to P
    var i;
    for (i = 0; i < Q.length; i += 1) {

        var p = Q[i];

        p.e.set({
            text : i,
            state: algo.render.kS_BLUE
        });

        p.e.set({
            radius: p.e.radius + 4
        });

        clockhand.set({
            shape: algo.layout.Line.getConnector(p0.e, p.e)
        });

        yield ({
            step     : "Label each point according to its sorted position in the array.",
            line     : 'polarSort',
            variables: {
                Point: i
            }
        });

        p.e.set({
            radius: p.e.radius - 4
        });
    }

    clockhand.destroy();

    yield ({
        step: "The points are now ordered and labeled according to the polar angle formed between P and the point."
    });

    // used to display the HULL as it is discovered. We use a poly line constructed of lines
    // to represent the hull (H) which we keep synchronized to S
    var H = [];

    function updateHull(S) {

        // create/update elements to match the list S
        var i;
        for (i = 0; i < S.length - 1; i += 1) {
            if (!H[i]) {
                H[i] = new algo.render.Arrow({
                    startArrow: false,
                    endArrow  : true
                });
            }

            H[i].set({
                shape: algo.layout.Line.getConnector(S[i].e, S[i + 1].e)
            });
        }

        // destroy elements that are no longer needed
        for (i = S.length - 1; i < H.length; i += 1) {
            H[i].destroy();
        }
        H.length = S.length - 1;

    }

    // draw the three points are testing for counter clockwise-ness. Show them in green is ccw or red
    // if clockwise or co-linear
    var triplet;

    // display ( created as needed ) two lines to display the clockwise relationship between three points.
    // If the points are clockwise we color green, otherwise the are colored red.
    function testCCW(p1, p2, p3) {

        // get result of counter clockwise test
        var result = ccw(p1, p2, p3);

        triplet = {
            start: triplet ? triplet.start : new algo.render.Line({
                z          : 1000,
                strokeWidth: 2
            }),
            end  : triplet ? triplet.end : new algo.render.Line({
                z          : 1000,
                strokeWidth: 2
            })
        };

        var l1 = algo.layout.Line.getConnector(p1.e, p2.e),
            l2 = algo.layout.Line.getConnector(p2.e, p3.e);

        var color = result <= 0 ? algo.Color.iRED : algo.Color.iGREEN;

        triplet.start.set({
            shape : l1,
            fill  : color,
            stroke: color
        });
        triplet.end.set({
            shape : l2,
            fill  : color,
            stroke: color
        });

        return result;
    }

    // Graham scan, start with the first two points from our sorted list of points, then add the next point in
    // list. Test the last three points on the stack to see if they clockwise. If they are continue to add points
    // to the hull. Whenever, the last three points are counter clockwise, remove them from the hull.
    var S = [];
    S.push(p0);
    S.push(Q[0]);
    S.push(Q[1]);
    updateHull(S);
    for (i = 2; i < Q.length; ++i) {
        var pi = Q[i];
        //=ccw
        while (testCCW(S[S.length - 2], S[S.length - 1], pi) <= 0) {
            yield ({
                step: "The current end of the hull line is counter clockwise",
                line: "ccw"
            });
            S.pop();
        }
        S.push(pi);
        updateHull(S);
        //=continue
        yield ({
            step: "The last three points of the hull are now clockwise orientated. Add the next point to the hull and continue",
            line: "continue"
        });
    }

    // remove the red/green triplet markers
    triplet.start.destroy();
    triplet.end.destroy();

    // to show the final link from the last point back to the first push P onto the end of the list and redraw.
    // If you wanted to return just the convex hull you would return S now.
    // We also turn all the points on the hull red
    S.push(p0);
    _.each(S, function (p) {
        p.e.set({state: algo.render.kS_RED});
    });
    updateHull(S);

    //=done
    yield ({
        step: "The convex hull is complete.",
        line: "done"
    });
}