# -*- coding: utf-8 -*-
"""
Created on Sun May 21 22:51:59 2017

@author: manoj
"""

from abc import ABCMeta

class MyABC:
    __metaclass__ = ABCMeta

MyABC.register(tuple)

print assert issubclass(tuple, MyABC)
print assert isinstance((), MyABC)