# -*- coding: utf-8 -*-
"""
Created on Fri Mar 10 01:24:4@author: manoj
"""

from fact import factorial
__all__ = [factorial, ]