# -*- coding: utf-8 -*-
"""
Created on Sat Feb 17 17:12:50 2018

@author: manoj
"""

def fact(n,mem):
    if n==1:
        return mem
    else:
        #print  " n-1" ,n-1 ,mem*n
        return fact(n-1 ,mem*n)
        
print fact(8,1)

