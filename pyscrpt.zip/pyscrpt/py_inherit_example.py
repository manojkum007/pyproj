# -*- coding: utf-8 -*-
"""
Created on Tue Jul 11 14:50:24 2017

@author: manoj
"""

class A:
    def f(self):
        return self.g()

    def g(self):
        return 'A'

class B(A):
    def g(self):
        return 'B'

a = A()
b = B()
print b.__doc__
print a.f(), b.f()
'A','A'
print a.g(), b.g()
'A' ,'B'