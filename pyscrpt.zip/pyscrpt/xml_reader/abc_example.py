# -*- coding: utf-8 -*-
"""
Created on Mon Jun 11 20:12:12 2018

@author: manoj
"""

#
#<data>
#    <country name="Liechtenstein">
#        <rank>1</rank>
#        <year>2008</year>
#        <gdppc>141100</gdppc>
#        <neighbor name="Austria" direction="E"/>
#        <neighbor name="Switzerland" direction="W"/>
#    </country>
#    <country name="Singapore">
#        <rank>4</rank>
#        <year>2011</year>
#        <gdppc>59900</gdppc>
#        <neighbor name="Malaysia" direction="N"/>
#    </country>
#    <country name="Panama">
#        <rank>68</rank>
#        <year>2011</year>
#        <gdppc>13600</gdppc>
#        <neighbor name="Costa Rica" direction="W"/>
#        <neighbor name="Colombia" direction="E"/>
#    </country>
#</data>

import xml.etree.ElementTree as ET
tree = ET.parse('country.xml')
root = tree.getroot()

#for child in root:
#    print child.tag , child.attrib
    

for neighbor in root.iter('country'):
    for subchild in neighbor:
        print child.tag , subchild.tag , "content=5" ,subchild.text 