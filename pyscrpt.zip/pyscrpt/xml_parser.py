# -*- coding: utf-8 -*-
"""
Created on Tue Mar  6 19:34:24 2018

@author: manoj
"""


from lxml import etree

data="""<data>
    <items>
        <item name="item1"></item>
        <item name="item2"></item>
        <item name="item3"></item>
        <item name="item4"></item>
    </items>
</data>"""


#
#from xml.dom import minidom
#xmldoc = minidom.parse('xml_demo.xml')
#itemlist = xmldoc.getElementsByTagName('item')
#print(len(itemlist))
#print(itemlist[0].attributes['name'].value)
#for s in itemlist:
#    print(s.attributes['name'].value)
#    
#    
    
xmldata="""<group>
  <group>
    <group>
       <parameter name="this" value="shit"/>
       <parameter name="always" value="happens"/>
       <parameter name="to" value="me"/>
    </group>
  </group>
</group>"""


context = etree.iterparse('/home/manoj/scripts/python_scripts/xml_doc.xml', tag='result')
group_nesting = 0
for event, elem in etree.iterparse('/home/manoj/scripts/python_scripts/xml_doc.xml', events=('start', 'end')):
    print "evnt" ,event
    if event == 'start':
        if elem.tag == 'group':
            print "text" , elem.items()
            group_nesting += 1
    if event == 'end':
        if elem.tag == 'group':
            #print "tag",elem.tag
            elem.clear()
        group_nesting -= 1
 