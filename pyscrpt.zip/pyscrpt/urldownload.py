# -*- coding: utf-8 -*-
"""
Created on Wed Aug 16 23:19:17 2017

@author: manoj
"""

import urllib2

# file to be written to
#filenmae = "downloaded_file1.html"
#
#url = "http://www.pythonforbeginners.com/"
#url = "http://www.oreillynet.com/"

urlist=['http://pymotw.com/2/urllib2/', 'http://www.kentsjohnson.com/', 'http://www.voidspace.org.uk/python/articles/urllib2.shtml', 'http://techmalt.com/', 'http://www.hacksparrow.com/', 'http://docs.python.org/2/howto/urllib2.html', 'http://www.stackoverflow.com', 'http://www.oreillynet.com/']


def downloader(url, filename):
    try:
        response = urllib2.urlopen(url)
        fh = open(filename, "w")
        fh.write(response.read())
        fh.close()
    except Exception as e:
        print "Unable to download file as ",e 

for i in range(len(urlist)):
    print "downloading",urlist[i]
    downloader(urlist[i], "downloaded_file%s.html"%i)
    