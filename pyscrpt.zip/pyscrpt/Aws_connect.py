# -*- coding: utf-8 -*-
"""
Created on Tue Aug 22 15:45:53 2017

@author: manoj
"""

import boto
import boto.s3.connection
from boto.s3.key import Key
from urllib2 import *
from S3GenericLuigi import *
import ssl
if hasattr(ssl, '_create_unverified_context'):
   ssl._create_default_https_context = ssl._create_unverified_context


access_key1='AKIAJYFQEFWLXAUPE6TQ'
access_secret1='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'
s3DirectoryPath='s3://logs.movoto.com/lb-access-logs/'



access_key1 = 'AKIAIFE3BPFVJ5FGNR3A'
access_secret1 = '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'
s3DirectoryPath='s3a://recruit-redshift.movoto.com/bb-input/20170820/mls.property_history_updated/'
s3DirectoryPath='s3a://recruit-redshift.movoto.com/bb-input'

#def ConnectionS3():
#    access_key =access_key1
#    access_secret = access_secret1
#    client = S3GenericLuigi(access_key, access_secret)
#    return client
#    
#
#
#
#client = ConnectionS3()
##S3date = formatDateS3(self.run_date)
#fileExist = client.exists(str(s3DirectoryPath))
#ll=[]
#if (fileExist):
#    print "yes connected"
#    paths=client.listdir(s3DirectoryPath)
#    for p in paths:
#        if p.endswith(".txt"):
#            ll.append(p)
#            client.get(p, './'+re.search('20170820/(\S+)/',p).group(1)+'_metadata.txt')
#
#else:
#    print 'Node logs not uploaded for the day %s' , self.run_date
#    sys.exit()
#print "ll" ,ll   
    
    

class S3connector:
    def __init__(self, aws_access_key, aws_access_secret):
        try:
            self.client= S3GenericLuigi(aws_access_key, aws_access_secret)
            print" connected"
        except Exception as e:
            print "Unable to connect to s3 ",e
    
    def  S3listfiles(self , s3DirectoryPath):
        return self.client.listdir(s3DirectoryPath)

    def  S3putfiles(self , s3path, localpath):
        return self.client.get(s3path, localpath) 
        
    def parse_files(self, s3DirectoryPath , uploadate):
        try:
            for path in self.S3listfiles("{0}/{1}".format(s3DirectoryPath, uploadate)):
                print "path " ,path
                if path.endswith(".txt"):
                    print self.S3putfiles(path, './s3file/'+uploadate+'_'+re.search(uploadate+'/(\S+)/',path).group(1)+'_metadata.txt')   
        except Exception as e:
            print "Unable to parse files ",e


    
 
print "connection initiated"
awsobj=S3connector(access_key1, access_secret1)  
awsobj.parse_files(s3DirectoryPath, '20170819')  
    