# -*- coding: utf-8 -*-
"""
Created on Tue Oct 31 16:22:18 2017

@author: manoj
"""
import re

def property_file_reader(pfile, section):
    f=open(pfile ,'r')
    for line in f:
        match_pattern="{0}\s?=\s?({1})".format(section ,'\S+\s+.*')
        obj=re.match(match_pattern, line)
        if obj:
            print obj.group(1)
        
property_file_reader('/home/manoj/scripts/tiger_analyatics/rhino/mlsrefresh_spark/refreshjobs/mls_listing.properties' ,
'mls.refresh.final.bkptable')

#'mls.refresh.schema.value')

