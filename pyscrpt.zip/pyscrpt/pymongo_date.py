# -*- coding: utf-8 -*-
"""
Created on Fri Dec 23 12:49:02 2016

@author: manoj
"""

import datetime
import os

t1=datetime.datetime.now()
t1=int(datetime.datetime.now().strftime("%s")) * 1000

datetest={}


datetest["name"]="manojkumar"

datetest["created"]={"$date": t1}

print datetest

res=os.system("mongoimport -d temp -c pyjson '/home/manoj/movoto_project/input_data/datetest1.json'")
print res