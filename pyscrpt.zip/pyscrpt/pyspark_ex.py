# -*- coding: utf-8 -*-
"""
Created on Wed Mar 14 23:32:37 2018

@author: manoj
"""

import time
from pyspark import SparkContext, SparkConf
import logging
import json


def sleep_mapper(seconds):
    time.sleep(seconds)


if __name__ == "__main__":
    logging.getLogger("py4j").setLevel(logging.ERROR)

    with open("go_to_sleep.in") as f_in:
        data = json.load(f_in)

    conf = SparkConf().setAppName("sleep_mapper")
    sc = SparkContext(conf=conf)
    sc.\
        parallelize(
            [data.get("duration") for number in xrange(10000)]
        ).\
        map(sleep_mapper)

    with open("go_to_sleep.out", "w") as f:
        f.write("Congratulations!")
        f.write("\n")