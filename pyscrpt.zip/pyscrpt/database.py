# -*- coding: utf-8 -*-
"""
Created on Mon Feb 15 10:50:56 2016

@author: manoj
"""

import MySQLdb as mdb
import sys

class mysqlconnector :
    def __init__(self, host, port, usrname, passwrd, database):
        self.host=host
        self.port=port
        self.usrname=usrname
        self.password=passwrd
        self.database=database
        self.command= ""
        self.connect()
    def connect(self):
        try:
            self.con = mdb.connect(self.host, int(self.port), self.usrname,self.password, self.database)
        except mdb.Error, e:
            print "MySQL Error [%d]: %s" % (e.args[0], e.args[1])
            #exit(1)

    def setQuery(self ,command):
        self.command=command

    def execQuery(self):
        self.cur=self.con.cursor()
        self.cur.execute(self.command)

    def fetchResults(self): 
        return self.cur.fetchall()

    def fetchSingleResults(self):
        return self.cur.fetchone()

    def __del__(self):
        self.con.close()
        print "closing connection"


sql="SELECT * FROM city where id <5"
mysql=mysqlconnector('localhost','3306', 'root', 'admin', 'world')
mysql.setQuery(sql)
mysql.execQuery()
print mysql.fetchResults()