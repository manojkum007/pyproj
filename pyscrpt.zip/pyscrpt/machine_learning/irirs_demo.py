# -*- coding: utf-8 -*-
"""
Created on Thu Apr 26 00:31:08 2018

@author: manoj
"""

from sklearn import datasets
iris = datasets.load_iris()
print iris.DESCR