# -*- coding: utf-8 -*-
"""
Created on Tue Apr 17 00:00:09 2018

@author: manoj
"""
import pandas as pd
import numpy as np

import matplotlib.pyplot as plt
import numpy as np
from matplotlib import colors

N_points = 10
n_bins = 5

# Generate a normal distribution, center at x=0 and y=5
x = np.random.randn(N_points)

y = .4 * x + np.random.randn(N_points) + 5
print x,y
fig, axs = plt.subplots(1, 2)
print axs[0]    
# We can set the number of bins with the `bins` kwarg
axs[0].hist(x, bins=n_bins)
axs[1].hist(y, bins=n_bins)