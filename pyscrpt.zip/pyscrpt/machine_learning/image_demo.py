# -*- coding: utf-8 -*-
"""
Created on Wed Apr 25 19:53:08 2018

@author: manoj
"""

from scipy import ndimage
from scipy import misc
import matplotlib.pyplot as plt


f = misc.face()
misc.imsave('face.png', f) # uses the Image module (PIL)


face = misc.imread('face.png')

print face.shape, face.dtype

#print face[0][0]

f = misc.face(gray=True)
print f

plt.imshow(f, cmap=plt.cm.gray)  
plt.imshow(f, cmap=plt.cm.gray, vmin=30, vmax=200)  

#plt.imshow(f)
#plt.show()
