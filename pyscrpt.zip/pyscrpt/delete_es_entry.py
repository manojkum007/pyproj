# -*- coding: utf-8 -*-
"""
Created on Mon Oct  9 11:08:38 2017

@author: manoj
"""
import luigi
import datetime
from elasticsearch import Elasticsearch



import  movoto_logger 

logger = movoto_logger.get_logger('es_entry_logger.log')

class RhinoEsEntryDelete(luigi.Task):
    job_name=luigi.Parameter()
    run_date = luigi.DateParameter(default = datetime.date.today()-datetime.timedelta(days=1))
    #servername=luigi.Parameter()
      
    def requires(self):pass
        
    def run(self):
        config = luigi.configuration.get_config()
        es_host = config.get('movoto', 'es-host')
        es_port = int(config.get('movoto', 'es-port'))
        jobstatus_index = config.get('movoto', 'job-status-index')
        es = Elasticsearch([{'host': es_host, 'port': es_port}])          
         
        commom_task_list=['ExistingDataDelete','PartitionDataInsert']
        commom_delta_task_list=['AvroToParquetTask','CopySchemaToHdfs','GetAvroSchema','ParquetHive','SqoopImportTask','DataCheck','PantherJobHistoryCheck','SqoopToHive']
         
        ###################Rhino Address delete###############3333
        address_name_list={}
        address_name_list['mls_address_refresh']=commom_task_list
        address_name_list['mls_address']=commom_delta_task_list
        
        ###################Rhino listing delete###############3333
        listing_name_list={}
        listing_name_list['mls_listing_refresh']=commom_task_list
        listing_name_list['mls_listing']=commom_delta_task_list
        
        
        ###################Rhino listing delete###############3333
        
        attribute_name_list={}
        attribute_name_list['mls_attribute_refresh']=commom_task_list
        attribute_name_list['mls_attribute_history']=commom_delta_task_list
        
        
        
        ###################Rhino mls_public_record_association_refresh delete###############3333
        
        public_record_name_list={}
        public_record_name_list['mls_public_record_association_refresh']=commom_task_list
        public_record_name_list['mls_public_record_association']=commom_delta_task_list
        
        
        
        ###################Rhino mls_image_downloader_refresh delete###############3333
        
        image_download_name_list={}
        image_download_name_list['mls_image_downloader_status_refresh']=commom_task_list
        image_download_name_list['mls_image_downloader_status_history']=commom_delta_task_list
        
        
        #es_entry_checker=listing_name_list
        #es_entry_checker=attribute_name_list
        #es_entry_checker=image_download_name_list
        
        if(self.job_name=="mls_public_record_association_refresh"):
            es_entry_checker=public_record_name_list
        elif (self.job_name=="mls_image_downloader_status_refresh"):
            es_entry_checker=image_download_name_list
        elif (self.job_name=="mls_attribute_refresh"):
            es_entry_checker=attribute_name_list
        elif (self.job_name=="mls_listing_refresh"):
            es_entry_checker=listing_name_list
        elif (self.job_name=="mls_address_refresh"):
            es_entry_checker=address_name_list
        
        for job_name,v in es_entry_checker.iteritems():
            if type(v)==list:
                for task_name in v:
                    self.search_delete(es, es_host, es_port , jobstatus_index, task_name , job_name,  self.run_date.strftime('%Y-%m-%d') )
   
        with self.output().open('w') as f:
            f.write('{word}\n'.format(word='DistinctLoad')) 
    
    
    def search_delete(self, es, es_host, es_port, jobstatus_index, doctype , jobname, run_date):
        basevalue=0
        bdy= {  	"query": {
                    	"bool": {
                    	"must": [
                                    {
                                        "match": {
                                            "job_name": "%s"%jobname
                                        }
                                    },
                                   
                                    {
                                        "match": {
                                            "all_params.run_date": "%s"%run_date
                                        }
                                    },
                                    {   "match": {
                                            "luigi_task_name": "%s"%doctype
                                        }
                                    }
                                ]
                            }
                            },
                           "from":basevalue,
                           "size":5000
                 }
        #print " bidy for search",bdy
        try:   
            while True:
                bdy["from"]=basevalue  
                response = es.search( index=jobstatus_index,body=bdy)
                responselis=response.get('hits').get('hits')
                    
                logger.info("reponse from task_name  :%s  and job_name  : %s   , result is  %s"%(doctype, jobname, responselis))
                if len(responselis)==0:
                    break 
                basevalue +=100
                ids=[]
                for i in responselis:
                    ids.append(i.get("_id"))
                        
                bulk_body = ['{{"delete": {{"_index": "{}", "_type": "{}", "_id": "{}"}}}}' .format(jobstatus_index, doctype, x) for x in ids]
                logger.info("bulk_body %s"%bulk_body)
                es.bulk('\n'.join(bulk_body))
                break
                                                          
        except Exception as e:
            logger.info("deleting Entries %s"%e)
     

    
    
    def output(self):
        return luigi.LocalTarget(path='target/RhinoEsEntryDelete_%s_%s.txt'%(self.job_name,self.run_date.strftime('%Y-%m-%d'))) 
        





















class ProductionEsEntryDelete(luigi.Task):
    job_name=luigi.Parameter()
    run_date = luigi.DateParameter(default = datetime.date.today()-datetime.timedelta(days=1))
    #servername=luigi.Parameter()
      
    def requires(self):pass
        
    def run(self):
        config = luigi.configuration.get_config()
        es_host = config.get('movoto', 'es-host')
        es_port = int(config.get('movoto', 'es-port'))
        jobstatus_index = config.get('movoto', 'job-status-index')
        es = Elasticsearch([{'host': es_host, 'port': es_port}])          
         

        commom_task_list=['ExistingDataDelete','PartitionDataInsert']
        commom_delta_task_list=['AvroToParquetTask','CopySchemaToHdfs','GetAvroSchema','ParquetHive','SqoopImportTask','SqoopToHive']
        commom_delta_data_check_list=['DataCheck','PantherJobHistoryCheck']
        

        address_name_list={}
        address_name_list['mls_address_refresh_prod']=commom_task_list
        address_name_list['mls_address_history']=commom_delta_task_list
        address_name_list['mls_address']=commom_delta_data_check_list
        
        
        
        listing_name_list={}
        listing_name_list['mls_listing_refresh_prod']=commom_task_list
        listing_name_list['mls_listing_history']=commom_delta_task_list
        listing_name_list['mls_listing']=commom_delta_data_check_list
        
            
            
        image_name_list={}
        image_name_list['mls_image_downloader_status_refresh_prod']=commom_task_list
        image_name_list['mls_image_downloader_status_history']=commom_delta_task_list
        #.extend(commom_delta_data_check_list)
               
        mls_public_record_name_list={}
        mls_public_record_name_list['mls_public_record_association_refresh_prod']=commom_task_list
        mls_public_record_name_list['mls_public_record_association_history']=commom_delta_task_list
        mls_public_record_name_list['mls_public_record_association']=commom_delta_data_check_list
        
        
        
        attribute_name_list={}
        attribute_name_list['attribute_refresh_prod']=commom_task_list
        attribute_name_list['attribute_history']=commom_delta_task_list.extend(commom_delta_data_check_list)


        if(self.job_name=="attribute_refresh_prod"):
            prod_es_entry_checker=attribute_name_list
        elif (self.job_name=="mls_public_record_association_refresh_prod"):
            prod_es_entry_checker=mls_public_record_name_list
        elif (self.job_name=="mls_image_downloader_status_refresh_prod"):
            prod_es_entry_checker=image_name_list
        elif (self.job_name=="mls_address_refresh_prod"):
            prod_es_entry_checker=address_name_list
        elif (self.job_name=="mls_listing_refresh_prod"):
            prod_es_entry_checker=listing_name_list
        
    
        for job_name,v in prod_es_entry_checker.iteritems():
            if type(v)==list:
                for task_name in v:
                    self.search_delete(es, es_host, es_port , jobstatus_index, task_name , job_name,  self.run_date.strftime('%Y-%m-%d'))
                    
            
        with self.output().open('w') as f:
            f.write('{word}\n'.format(word='DistinctLoad')) 
    
    
    def search_delete(self, es, es_host, es_port, jobstatus_index, doctype , jobname, run_date):
        basevalue=0
        bdy= {  	"query": {
                    	"bool": {
                    	"must": [
                                    {
                                        "match": {
                                            "job_name": "%s"%jobname
                                        }
                                    },
                                   
                                    {
                                        "match": {
                                            "all_params.run_date": "%s"%run_date
                                        }
                                    },
                                    {   "match": {
                                            "luigi_task_name": "%s"%doctype
                                        }
                                    }
                                ]
                            }
                            },
                           "from":basevalue,
                           "size":5000
                 }
        #print " bidy for search",bdy
        try:   
            while True:
                bdy["from"]=basevalue  
                response = es.search( index=jobstatus_index,body=bdy)
                responselis=response.get('hits').get('hits')
                    
                logger.info("reponse from task_name  :%s  and job_name  : %s   , result is  %s"%(doctype, jobname, responselis))
                if len(responselis)==0:
                    break 
                basevalue +=100
                ids=[]
                for i in responselis:
                    ids.append(i.get("_id"))
                        
                bulk_body = ['{{"delete": {{"_index": "{}", "_type": "{}", "_id": "{}"}}}}' .format(jobstatus_index, doctype, x) for x in ids]
                logger.info( "bulk_body  %s"%bulk_body)
                es.bulk('\n'.join(bulk_body))
                break
                                                          
        except Exception as e:
            logger.info( "deleting Entries %s"%e)
     

    
    
    def output(self):
        return luigi.LocalTarget(path='target/ProductionEsEntryDelete_%s_%s.txt'%(self.job_name,self.run_date.strftime('%Y-%m-%d'))) 
        
          