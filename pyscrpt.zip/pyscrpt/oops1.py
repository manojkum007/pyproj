# -*- coding: utf-8 -*-
"""
Created on Thu May 18 15:14:53 2017

@author: manoj
"""

class parent:
    pname=''
    psurname=''
    
#    def __init__(self,name,sname):
#        self.pname=name
#        self.psurname=sname
        
        
    def getname(self):
        print "Ur full name",(self.pname+" " +self.psurname)


class kid(parent):
    kname=''
    def __init__(self,parentnme,name,srname):
        self.pname=parentnme
        self.kname=name
        self.psurname=srname
    
    def getname(self):
        print "Ur full name",(self.pname+" " +self.psurname)

        
#p=parent("manoj", "kumar")
#
#p.getname()

k=kid("dine", "manoj", "kumar")
k.getname()