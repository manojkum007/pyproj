# -*- coding: utf-8 -*-
"""
Created on Tue Feb  6 23:15:45 2018

@author: manoj
"""
m=3
k=0

def myrange(m):
    return map(lambda x :x+1 ,range(m))
    

 

for i in myrange(m):
    #print "i",i
    for j in myrange(i):
        for l in myrange(i):
            k+=1

print k