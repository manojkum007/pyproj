# -*- coding: utf-8 -*-
"""
Created on Sat Jan 14 12:15:39 2017

@author: manoj
"""
import collections

import json

path='/home/manoj/scripts/tiger_analyatics/rhino/dev_rhino/production/cityreport/citystat_22150dec_0.json'

path="/home/manoj/scripts/tiger_analyatics/rhino/dev_rhino/production/agentsfinalMigration/finalagents_209125551jan_0.json"
json_data=open(path).read()
dd=json.loads(json_data)
#print dd[0].get('inactiveUrls'
#print dd[0].get('licenses') 
#print dd[0]['contact']['homeAddress']['state']
#print dd



path="/home/manoj/scripts/tiger_analyatics/rhino/dev_rhino/production/agentsMigration/agents_104071jan_1.json"
json_data=open(path).read()
dd1=json.loads(json_data)

def traverse(obj,dictkey=''):
    if isinstance(obj, dict):
        for key, value in obj.iteritems():
            #print('dict_key', key)
#            dictkey+="."+key
            dictkey=key
            traverse(value,dictkey)
    elif isinstance(obj, list):
        for value in obj:
            traverse(value,dictkey)
    else:
        print('key is',dictkey,'value', obj)


#print traverse(dd)


#print dd  #from  file
#print dd1
def sanity(lis):
     lis=[x for x in lis if x is not None]
     lis=[x for x in lis if x is not u""]
     lis=[x for x in lis if x is not ""]
     lis=[x for x in lis if x is not  "null"]
     return lis

def merge_lis(lis1,lis2,clean=0):
    if clean==0:
        return list(set().union(lis1,lis2))
    else:
        return sanity(list(set().union(lis1,lis2)))
    
    
#        "userId": {
#            "id": "a6ead88d-b81e-41b3-8b88-ab060adface9", 
#            "idType": "NOVA"
#        }, 
    
def assigndict(cur,lis,val,single):
    if len(val)>0:
        if len(lis)==1:
            if (single==0):
                cur[lis[0]]=val[0]
            else:
                cur[lis[0]]=val
            return
        else:
            if not cur.has_key(lis[0]):
                cur[lis[0]]=collections.OrderedDict()
            assigndict(cur[lis[0]],lis[1:],val,single)
            
            
def callmerge(cur ,cur1 ,lis,single=0,clean=0):
    print "lis" ,lis
    if (len(lis)>0):
        if  cur1.has_key(lis[0]) or ( cur.has_key(lis[0]) and  cur1.has_key(lis[0])) :
#        if  cur1.has_key(lis[0]) and  cur.has_key(lis[0]) :
            if (isinstance(cur.get(lis[0]), dict) and  isinstance(cur1.get(lis[0]), dict) ):
                if len(lis[1:])>0:
                    callmerge(cur[lis[0]],cur1[lis[0]],lis[1:])
                else:  
                    if single==0:
                        cur[lis[0]]=cur1.get(lis[0])
                    else:
                        cur[lis[0]]=merge_lis(cur.get(lis[0]),cur1.get(lis[0]),0)
            elif isinstance(cur.get(lis[0]), list) and isinstance(cur1.get(lis[0]), list):
                if len(lis[1:])>0:
                    callmerge(cur[lis[0]],cur1[lis[0]],lis[1:])
                else:
                    if single==0:
                        cur[lis[0]]=cur1.get(lis[0])
                    else:
                        cur[lis[0]]=merge_lis(cur.get(lis[0]),cur1.get(lis[0]),0)     
            else:
                print "sinle value"
                if (cur.get(lis[0])!=None):
                    if cur1.get(lis[0])!=None:
                            cur[lis[0]]=cur1[lis[0]]
                        
                else:
                    if cur1.get(lis[0])!=None:
                        cur[lis[0]]=cur1[lis[0]]
                        
            
        
                        

                        
                    
    
#    if  d2.get(keylist1)!=None:
#        if d1.get(keylist1)!=None :
#            pass
#        else :
#            return d1
    
#print dd       
#callmerge(dd[0], dd1[0],['contact','homeAddress','state'])    


         
for dictfile,dictprg in [(x,y) for x in dd for y in dd1]:
#    print dictfile.get('inactiveUrls' ) ,dictprg.get('inactiveUrls' ) 
#    print merge_lis(dictfile.get('inactiveUrls' ),dictprg.get('inactiveUrls' ) )
#    print "before merger", dictfile['inactiveUrls']
#    print "before merger another", dictprg['inactiveUrls']
#    callmerge(dictfile, dictprg,['inactiveUrls'],1,0) 
#    print "after merge", dictfile['inactiveUrls']

#    print "before merger", dictfile['userId']['id']
#    print "before merger another", dictprg['userId']['id']  
#    callmerge(dictfile, dictprg,['userId','id'],0,0) 
#    print "after merge", dictfile['userId']['id']

    try: 
        #print "before merger", dictfile["contact"]["phones"]["displayPhone"]
        print "before merger another", dictprg["contact"]["phones"]["displayPhone"]
#        callmerge(dictfile, dictprg,["contact", "phones" ,"displayPhone"],0,0) 
#        print "after merge", dictfile["contact"]["phones"]["displayPhone"]
    except Exception as e:
        print e


    
#    callmerge(dictfile, dictprg,['contact','homeAddress','state','stateCode'])
#    print dictfile['contact']['homeAddress']['state']['stateCode']


#for i,j in [(x,y) for x in ll for y in ll1]:
#    if ( i.get('licenseNumber') !=j.get('licenseNumber') or i.get('state')!=j.get('state')):
#        ll.append(j)