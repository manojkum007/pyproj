# -*- coding: utf-8 -*-
"""
Created on Mon Jun 27 15:07:35 2016

@author: manoj
"""

import re


fw=open('/home/manoj/scripts/tiger_analyatics/deeds_error/output4.csv','w')

inputlis=[]
with open('/home/manoj/scripts/tiger_analyatics/deeds_error/deeds_list.txt', 'r') as infile:
    for line in infile:
        matchObj = re.match(r'(.*)/(\d+_Deed.*\.txt)', line, re.M|re.I)       
        if matchObj:
            inputlis.append(matchObj.group(2).lower())

inputlis2=[]
with open('/home/manoj/scripts/tiger_analyatics/deeds_error/output2.csv', 'r') as infile:
    for line in infile:
        matchObj = re.match(r'(\d+_Deed.*\.txt)', line, re.M|re.I)       
        if matchObj:
            inputlis2.append(matchObj.group(0).lower())
            
            
#print inputlis2
for i in inputlis:
    if not i in inputlis2 :
        fw.write(i)
        fw.write("\n")
    
fw.close()
