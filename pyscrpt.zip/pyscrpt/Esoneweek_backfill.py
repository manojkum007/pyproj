# -*- coding: utf-8 -*-
"""Created on Fri Dec 15 11:30:56 2017

@author: manoj
"""
from elasticsearch import Elasticsearch
import sys
import time
import  datetime 
from datetime import timedelta
import os
import luigi
import movoto_logger

logger = movoto_logger.get_logger('mls_aggs_.log')


pattern= '%Y-%m-%d'


def get_config(section, name):
    luigi_config = luigi.configuration.get_config()
    return luigi_config.get(section, name)





class Mls_agg_Backfill(luigi.Task):
    start_date = luigi.DateParameter(default = datetime.date.today()-datetime.timedelta(days=7))
    end_date = luigi.DateParameter(default = datetime.date.today()+datetime.timedelta(days=1))
    
    def requires(self):
        pass
    
    def run(self):
        es_host= get_config('mls_agg_es', 'es-host')
        es_port= int(get_config('mls_agg_es', 'es-port'))
        job_status_index= get_config('mls_agg_es', 'job-status-index')
        es_timeout=int(get_config('mls_agg_es', 'es-timeout'))
        es = Elasticsearch([{'host': es_host, 'port': es_port ,'timeout':es_timeout}])
        
        try :
            mls_agg_missinglis=self.search_missing_data(es, es_host, es_port, job_status_index)
            
            print "length of lis" ,mls_agg_missinglis
            for startdate in mls_agg_missinglis:
                print "startdate",startdate
        
        except Exception as e:
            logger.critical("Error while searching mls_agg elastic search entry due to  %s"%e)
            sys.exit(0)

        
        with self.output().open('w') as f:
            f.write('{word}\n'.format(word='Mls_agg_Backfill_'))
            
            
            
    
    def search_missing_data(self, es, es_host, es_port, jobstatus_index):
        es_found_dates_lis=[]
        original_dates=[]
        date_range = int((self.end_date - self.start_date).days)
        for dt in range(date_range):
            original_dates.append((self.start_date + datetime.timedelta(dt)).strftime('%Y-%m-%d'))
            
            
        bdy= 	{
                          "size": 0,
                          "query": {
                            "bool": {
                              "must": [
                                {
                                  "query_string": {
                                    "query": "*",
                                    "analyze_wildcard": True
                                  }
                                },
                                {
                                  "range": {
                                    "@timestamp": {
                                    "gte":self.start_date.strftime('%Y-%m-%d'),
                                    "lte":self.end_date.strftime('%Y-%m-%d'),
                                    "format":"yyyy-MM-dd"
                                    }
                                  }
                                }
                              ],
                              "must_not": []
                            }
                          },
                          "_source": {
                            "excludes": []
                          },
                          "aggs": {
                            "2": {
                              "date_histogram": {
                                "field": "@timestamp",
                                "interval": "1d",
                                "time_zone": "UTC",
                                "min_doc_count": 1
                              }
                            }
                          }
                        }
                                     
                 
        print " bidy for search",bdy
        
        response = es.search( index=jobstatus_index,body=bdy)
        #print "response", response
        
        responselis=response.get('aggregations').get('2').get('buckets')
        for doc_elem in responselis:
            if doc_elem.get('doc_count')>0:
                tt=doc_elem.get('key_as_string') 
                es_found_dates_lis.append(datetime.datetime.strptime(tt, '%Y-%m-%dT%H:%M:%S.%fZ').strftime('%Y-%m-%d'))
                
        
        return [dates for dates in original_dates if dates  not in es_found_dates_lis]
        
            

    def output(self):
        path1 = os.path.join('./target', ('Mls_agg_Backfill_%s_%s.txt')%(self.start_date.strftime('%Y-%m-%d') , self.end_date.strftime('%Y-%m-%d')))
        return luigi.LocalTarget(path=path1)        
        



