# -*- coding: utf-8 -*-
"""
Created on Wed Dec 14 17:48:39 2016

@author: manoj
"""

#import MySQLdb
#
##db = MySQLdb.connect(host="192.168.120.130",    # your host, usually localhost
##                     user="admin",         # your username
##                     passwd="school123",  # your password
##                     db="school_v2")   
#                     
#db= MySQLdb.connect("192.168.120.130","admin","school123","school_v2" )
#
#
#cur = db.cursor()
#db.autocommit(1)
#
#
#cur.execute("SELECT * FROM school_v2.census_info limit 10")
#
#db.close()



import MySQLdb as mdb
import sys

con = None

try:

    con = mdb.connect('192.168.120.130', 'admin', 
        'school123', 'school_v2');

    cur = con.cursor()
    cur.execute("SELECT VERSION()")

    data = cur.fetchone()
    
    print "Database version : %s " % data
    
except mdb.Error, e:
  
    print "Error %d: %s" % (e.args[0],e.args[1])
    sys.exit(1)
    
finally:    
        
    if con:    
        con.close()