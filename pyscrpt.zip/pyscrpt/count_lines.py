# -*- coding: utf-8 -*-
"""
Created on Wed Jul 27 15:41:57 2016

@author: manoj
"""

sum1=0
mar_mls_file='/home/manoj/scripts/python_scripts/jan_data.txt'
import os
os.chdir("/home/manoj/scripts/python_scripts/mls_download/listings")
with open(mar_mls_file, 'r') as infile:
    for line in infile:
        listingcount=len(open(line.strip()).readlines())
        print line.strip() ,listingcount
        sum1+=listingcount
        
print "total no of record" ,sum1
11,673,151  for db jan