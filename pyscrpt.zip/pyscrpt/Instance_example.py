# -*- coding: utf-8 -*-
"""
Created on Sun Jun 18 11:21:37 2017

@author: manoj
"""

class A:
   message = "class message"

   @classmethod
   def cfoo(cls):
      print(cls.message)

   def foo(self, msg):
      self.message = msg
      print(self.message)

   def __str__(self):
      return self.message+"stringhello"

   def __repr__(self):
      return self.message+"hello"
      

a=A()
a.foo("jhjljh")
A.foo(a,"manoj")
#print a

#print str(a)
