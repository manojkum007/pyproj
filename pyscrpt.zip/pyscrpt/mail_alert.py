
import smtplib

from email.mime.text import MIMEText
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate


def send_email_with_attachment(smtp_host, subject, body_text, to_emails, cc_emails, bcc_emails , html_tag):
    host = smtp_host
    from_addr = 'mlsuploader@movoto.com'
    msg = MIMEMultipart()
    msg["From"] = from_addr
    msg["Subject"] = subject
    msg["Date"] = formatdate(localtime=True)
    html=html_tag
    if body_text:
        part2 = MIMEText(html, 'html')
        msg.attach( part2 )
 
    msg["To"] = ', '.join(to_emails)
    msg["cc"] = ', '.join(cc_emails) 
    emails = to_emails + cc_emails
    server = smtplib.SMTP(host)
    server.sendmail(from_addr, emails, msg.as_string())
    server.quit()
 

def table_row(run_date, tablename  , yrowcount, trowcount, threshold):
    table_row="""<tr><td>"""+str(run_date)+"""</td>"""
    table_row+="""<td>"""+str(tablename)+"""</td>"""
    table_row+="""<td>"""+str(yrowcount)+"""</td>"""
    table_row+="""<td>"""+str(trowcount)+"""</td>"""
    change=((float(trowcount)- float(yrowcount))/float(yrowcount))*100
    if change>=threshold or -change>=threshold:
        table_row+="""<td><font color="red">"""+str("%.2f" % change)+ """</font></td></tr>"""
    else:
        table_row+="""<td>"""+str("%.2f" % change)+ """</td></tr>"""
        
    return table_row
    

def Emailrow_header():
    email_row="""<h3><b>Recruit Daily Load Status</b></h3>
                    <table>
                    	<tr>
                    		<th>Run-date</th>
                    		<th>Table name</th>
                    		<th>Yesterday Rowcount</th>
                    		<th>today Rowcount</th>
                    		<th>Percentage Variation</th>
                </tr>"""
    return email_row
    

def tabletag():
    return "</table>"
    


def composebody(datalis):
    body=Emailrow_header()
    #datalis=['mls_image_downloader_status\t12387528\t12387558', 'mls_public_record_association\t108163513\t108163593', 'mls_listing\t65782293\t65782193', 'attribute\t1864\t1864', 'address\t313603801\t313603851']
    for row in datalis:
        col=row.split("\t")
        body+=table_row("2017-05-23", col[0], col[1], col[2], 15)
    body+=tabletag()
    #print body
        
table_dict={'delete_property': {'20170819': '57436', '20170820': '50244'}, 'property_history_updated': {'20170820': '241503', '20170819': '276441'}, 'mls_public_record_association': {'20170819': '27762', '20170820': '14697'}, 'mls_listing': {'20170820': '43224', '20170819': '88953'}, 'address': {'20170819': '17019', '20170820': '7495'}}

def composebodydict(table_dict):
    body=Emailrow_header()
    for tablename  ,datevalue in table_dict.iteritems():
        body+=table_row("2017-05-23", tablename, str(table_dict.get(tablename).get(sorted(datevalue)[0])) , str(table_dict.get(tablename).get(sorted(datevalue)[1])), 15)
    
    body+=tabletag()  
    print body     
    
    
    
        
##    
if __name__ == "__main__":
    #emails = ['mkumar@movoto.com','pmishra@movoto.com','adesai@movoto.com','rpalraj@movoto.com','adas@movoto.com', 'UPidathala@movoto.com']
    emails    = ['mkumar@movoto.com'] 
    cc_emails = ['mkumar@movoto.com']
    bcc_emails = ['mkumar@movoto.com']
    genheader="""<h3><b>MLS Daily Load Status</b></h3><table><tr><th>Table name</th><th>HiveRowcount</th>
<th>PantherRecordscount</th><th>%success</th></tr><tr><tr><td>mls_image_downloader_status</td><td>12387568</td><td>12387568</td><td>100.0</td></
tr><tr><td>mls_public_record_association</td><td>108163513</td><td>108163513</td><td>100.0</td></tr><tr><td>mls_listing</td><td>65782293</td><td
>65782293</td><td>100.0</td></tr><tr><td>attribute</td><td>1864</td><td> <font color="red">1864</font> </td><td>100.0</td></tr><tr><td>address</td><td>313603801</td><td>31
3603801</td><td>100.0</td></tr>"""
    subject = "MLS Daily Upload status"
    body_text = "This email contains an attachment!"
    file_to_attach="sample2.csv"
    html_tag= genheader
    print composebodydict(table_dict)
    #send_email_with_attachment("localhost",subject, body_text, emails, cc_emails, bcc_emails, html_tag)


