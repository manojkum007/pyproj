# -*- coding: utf-8 -*-
"""
Created on Mon Apr  9 19:19:48 2018

@author: manoj
"""

lis=[-1,0,5,6,8,2,12]

ll=[]
for i in range(min(lis) ,max(lis)):
    if (i  not in lis):
        ll.append(i)


biggest_sum_diff=0
max_biggest_sum_diff=0
for i in range(len(ll)-1):
    if ll[i+1]-ll[i]==1:
        biggest_sum_diff+=1
        if max_biggest_sum_diff<biggest_sum_diff:
            max_biggest_sum_diff=biggest_sum_diff
    else:
        biggest_sum_diff=0
    
    
print (max_biggest_sum_diff/2)+1
        
        
    