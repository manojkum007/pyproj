# -*- coding: utf-8 -*-
"""
Created on Fri May 13 10:11:43 2016

@author: manoj
"""

from elasticsearch import Elasticsearch
import json
import datetime
import luigi
from luigi import postgres
from luigi import six
import datetime
from datetime import date, timedelta
import psycopg2


es_index="actor"

def get_config(section, name):
    luigi_config = luigi.configuration.get_config()
    return luigi_config.get(section, name)

_host= get_config('localmls1', 'db-host')
_database=get_config('localmls1', 'db-name')
_user=get_config('localmls1', 'db-user')
_password=get_config('localmls1', 'db-password')




start_date="2016-06-22"
start_date = datetime.datetime.strptime(start_date, '%Y-%m-%d').strftime('%Y-%m-%dT00:00:00.000Z')


end_date="2016-06-2"
end_date = datetime.datetime.strptime(end_date, '%Y-%m-%d').strftime('%Y-%m-%dT00:00:00.000Z')
      
     




#print json.dumps(response ,indent=4 ,separators=(",",":"))
    
class Es_To_State(luigi.Task):
    sdate=luigi.DateParameter(default=datetime.date.today() - timedelta(days=1))
    edate=luigi.DateParameter(default=datetime.date.today())
    
    
    def fetchReponse(self):
        es = Elasticsearch([{'host': '172.24.0.18'}] ,port= 8080) 
        
        es_index="realestate"
        
        body= {
                                          "query": {
                                        "filtered": {
                                          "query": {
                                            "query_string": {
                                              "query": "_type:mls_aggregates AND new_listing:1",
                                              "analyze_wildcard": True
                                            }
                                          },
                                          "filter": {
                                            "bool": {
                                              "must": [
                                                {
                                                  "query": {
                                                    "query_string": {
                                                      "analyze_wildcard": True,
                                                      "query": "*"
                                                    }
                                                  }
                                                },
                                                {
                                                  "range": {
                                                    "@timestamp": {
                                                      "gte": self.date,
                                                      "lte": self.sdate
                                                    }
                                                  }
                                                }
                                              ],
                                              "must_not": []
                                            }
                                          }
                                        }
                                      },
                                      "size": 0,
                                      "aggs": {
                                        "2": {
                                          "terms": {
                                            "field": "state_name",
                                            "size": 65,
                                            "order": {
                                              "1": "desc"
                                            }
                                          },
                                          "aggs": {
                                            "1": {
                                              "sum": {
                                                "field": "listing_count"
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                    
        response = es.search(
                index=es_index,
                body=body
           )
           
        response=response.get("aggregations").get("2").get("buckets")
        
        responselis=[]
        for i in range(len(response)):
            rowlis=[]
            rowlis.append(response[i].get("key"))
            rowlis.append(response[i].get("1").get("value"))
            responselis.append(rowlis)
        
        
        print responselis
        
        
    
    def db_insert(self,rowlis):
        conn = psycopg2.connect(host=_host, dbname=_database, user=_user, password=_password)
        cur = conn.cursor()
        command = 'INSERT INTO deeds.states VALUES (' + ', '.join(['%s']*3) + ');'
        
        for row in rowlis:
            try:
                cur.execute(command, row)
            except psycopg2.Error as e:
                print "logging",e
            
    


if __name__ == '__main__':
    luigi.run()             
                

