# -*- coding: utf-8 -*-
"""
Created on Thu Mar 17 12:22:55 2016

@author: manoj
"""

table_schema="""
CREATE TABLE deeds.parsed_names_addresses
(
  deed_id integer NOT NULL,
  fips character varying(5),
  recording_date character varying(10),
  original_date_of_contract character varying(10),
  recording_date_date date,
  original_date_of_contract_date date,
  sales_price integer,
  property_street_address character varying(60),
  property_city character varying(50),
  property_state character varying(2),
  property_long_form_address character varying(150),
  property_street_number character varying(30),
  property_street_name_predir character varying(50),
  property_street_name_premod character varying(60),
  property_street_name_pretype character varying(60),
  property_street_name character varying(50),
  property_full_street_name character varying(80),
  property_street_name_posttype character varying(50),
  property_street_name_posttype_normalized character varying(50),
  property_street_name_postdir character varying(30),
  property_street_name_occupancytype character varying(30),
  property_street_name_identifier character varying(30),
  property_full_state character varying(40),
  buyer_mail_street_address character varying(60),
  buyer_mail_city character varying(50),
  buyer_mail_state character varying(2),
  buyer_mail_long_form_address character varying(150),
  buyer_mail_street_number character varying(30),
  buyer_mail_street_name_predir character varying(30),
  buyer_mail_street_name_premod character varying(60),
  buyer_mail_street_name_pretype character varying(60),
  buyer_mail_street_name character varying(60),
  buyer_mail_full_street_name character varying(80),
  buyer_mail_street_name_posttype character varying(50),
  buyer_mail_full_street_posttype_normalized character varying(50),
  buyer_mail_street_name_postdir character varying(30),
  buyer_mail_street_name_occupancytype character varying(30),
  buyer_mail_street_name_identifier character varying(30),
  buyer_mail_full_state character varying(40),
  buyer1_fname character varying(60),
  buyer1_lname character varying(60),
  buyer1_full_name character varying(80),
  buyer1_fname_norm character varying(60)[],
  buyer1_lname_norm character varying(60)[],
  buyer1_full_name_norm character varying(60)[],
  buyer2_fname character varying(60),
  buyer2_lname character varying(60),
  buyer2_full_name character varying(80),
  buyer2_fname_norm character varying(60)[],
  buyer2_lname_norm character varying(60)[],
  buyer2_full_name_norm character varying(60)[],
  seller1_fname character varying(60),
  seller1_lname character varying(60),
  seller1_full_name character varying(80),
  seller1_fname_norm character varying(60)[],
  seller1_lname_norm character varying(60)[],
  seller1_full_name_norm character varying(60)[],
  seller2_fname character varying(60),
  seller2_lname character varying(60),
  seller2_full_name character varying(80),
  seller2_fname_norm character varying(60)[],
  seller2_lname_norm character varying(60)[],
  seller2_full_name_norm character varying(60)[]
)
"""

import re

lis=table_schema.split("\n")
#print lis
lis1=[]
for i in range(len(lis)):
    lis1.append("")
    if  lis[i].find("character varying")>0:
        lis1[i]="text"
    elif  lis[i].find("character varying")>0:
        lis1[i]="text"
    elif lis[i].find(" date")>0:
        lis1[i]="date"
    elif lis[i].find("timestamp")>0:
        lis1[i]="timestamp"
    elif lis[i].find("integer")>0:
        lis1[i]="int"
    elif lis[i].find("real")>0:
        lis1[i]="numeric"
    elif lis[i].find("double")>0:
        lis1[i]="numeric"
    elif lis[i].find("text[]")>0:
        lis1[i]="text[]"
    if (re.search("character varying\(\d+\)\[\]" ,lis[i])):
        lis1[i]="text[]"


#print "lis1" ,lis1
for i in lis1:
    if i=='':
        lis1.pop(lis1.index(i))
        
data='PREPARE deedinsrt ('+",".join(lis1)+')'

print data