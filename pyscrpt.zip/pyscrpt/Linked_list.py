# -*- coding: utf-8 -*-
"""
Created on Thu Jan  4 23:04:38 2018

@author: manoj
"""

class Link:
    def __init__(self ,data):
        self.data=data
        self.next=None
    
    

class Linked_List:
    
    def __init__(self ):
        self.head= None
    
    def append(self,data):
        if self.head==None:
            self.head=Link(data)
            
        else:    
            node=Link(data)
#            temp=self.head
#            print "firsst temp" ,temp.data
#            while(temp):
#                print "temp data" ,temp.data
#                temp=temp.next        
#            temp=node
                
            #print "head data" ,self.head.data
            self.head.next=node
            node.next=self.head
            self.head=node
            
            while (self.head):
                print "current data",self.head.data
                self.head=self.head.next
                
            self.head=Link(data)
            #print "current data",self.head.data
    
    def displaynodes(self):
#        if self.head!=None:
#            while (self.head.next!=None):
#                print "data",self.head.data,"\t"
        temp = self.head
        while (temp):
            print "printing data",temp.data
            temp = temp.next
                
        
    


#Link_tree=Linked_List()
#Link_tree.append(78)
#Link_tree.append(48)
#Link_tree.append(8)
#Link_tree.displaynodes()



class Node(object):

    def __init__(self, data=None, next=None):
        self.data = data
        self.next = next

    def get_data(self):
        return self.data

    def get_next(self):
        return self.next

    def set_next(self, new_next):
        self.next = new_next


class LinkedList(object):

    def __init__(self, head=None):
        self.head = head

    def insert(self, data):
        new_node = Node(data)
        new_node.set_next(self.head)
        self.head = new_node

    def size(self):
        current = self.head
        count = 0
        while current:
            count += 1
            current = current.get_next()
        return count

    def search(self, data):
        current = self.head
        while current:
            if current.get_data() == data:
                return current
            else:
                current = current.get_next()
        return None

    def delete(self, data):
        current = self.head
        prev = None
        while current:
            if current.get_data() == data:
                if current == self.head:
                    self.head = current.get_next()
                else:
                    prev.set_next(current.get_next())
                return current
            prev = current
            current = current.get_next()
        return None

    def __str__(self):
        lst = []
        current = self.head
        while current:
            lst.append(str(current.get_data()))
            current = current.get_next()
        return '->'.join(lst)
        
        
     

Link_tree=LinkedList()
Link_tree.insert(56)
Link_tree.insert(6)
Link_tree.insert(2)

print Link_tree
        