# -*- coding: utf-8 -*-
"""
Created on Thu Mar 31 11:36:07 2016

@author: manoj
"""

#SMTPserver = 'smtp.gmail.com'
SMTPserver = '192.168.120.128'
sender =     'mkumar@movoto.com'
destination = ['mkumar@movoto.com']


USERNAME = "manojk.softengineer@gmail.com"
PASSWORD = "Popli26topli"

USERNAME = "mkumar@movoto.com"
PASSWORD = "1111Laptop"

# typical values for text_subtype are plain, html, xml
text_subtype = 'plain'


content="""\
Test message
"""

subject="Sent from Python"

import sys
import smtplib

#from smtplib import SMTP_SSL as SMTP       # this invokes the secure SMTP protocol (port 465, uses SSL)
# from smtplib import SMTP                  # use this for standard SMTP protocol   (port 25, no encryption)

# old version
# from email.MIMEText import MIMEText
from email.mime.text import MIMEText

try:
    msg = MIMEText(content, text_subtype)
    msg['Subject']=       subject
    msg['From']   = sender # some SMTP servers will do this automatically, not all

#    conn = smtplib.SMTP(SMTPserver, 587)
    conn = smtplib.SMTP(SMTPserver, 25)

    #conn = smtplib.SMTP_SSL(SMTPserver, 465)
    
    conn.ehlo()
    conn.starttls()
    conn.ehlo()
    conn.set_debuglevel(True)
    conn.login(USERNAME, PASSWORD)
    try:
        conn.sendmail(sender, destination, msg.as_string())
        print " mail sent, pls check ur inbox"
    finally:
        conn.quit()

except Exception, exc:
    sys.exit( "mail failed; %s" % str(exc) ) # give a error message
