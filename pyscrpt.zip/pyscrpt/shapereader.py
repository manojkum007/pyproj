# -*- coding: utf-8 -*-
"""
Created on Tue Jul  3 22:35:20 2018

@author: manoj
"""
import shapefile 
import sys
#ssys.path.append('/home/manoj/postprpcessor/postprocessors/great_school')
#import geo_quatroshape



path="/home/manoj/movoto_project/geonames/quatroshapes/ne_adm1/ne_10m_admin_1_states_provinces.shp"




def featureLength():
    count=0
    for rec in shp.iterShapeRecords():
        print rec.shape.__geo_interface__ 
        print rec.record
        print rec.shape.shapeType
        count+=1
        break
    print "total no of feature",count



#featureLength()   
#for field in shp.fields:
#    st=field[0] +" "
#    if field[1]=='C':
#        st+="character varying(%s) DEFAULT NULL::character varying"
#        st=st%(field[2])
#    elif field[1]=='F':
#        st+="numeric(%s,%s) DEFAULT NULL::numeric"
#        st=st%(field[2] ,field[3])
#    elif field[1]=='N':
#        st+="bigint"
#    print st,","
    #break

def geoRowFormer(geotype, geocoordlis):
    polystr=""
    #print geotype ,geocoordlis
    if geotype=='MultiPolygon':
        polystr="MULTIPOLYGON ((("
        cnt=0
        for georow in  geocoordlis:
            for j in range(len(georow[0])):
                polystr+="{0} {1} ".format(georow[0][j][0] , georow[0][j][1])
                if j<len(georow[0])-1:
                    polystr+=","
                else :
                    polystr+=")"
            if cnt<len(geocoordlis)-1:
                polystr+=",("
            cnt+=1
            #break
        polystr+="))"
        
        
    if geotype=='Polygon':
        polystr="POLYGON (("
        geolis=geocoordlis[0]
        for j in range(len(geolis)):
            polystr+="{0} {1} ".format(geolis[j][0] ,geolis[j][1])
            if j<len(geolis)-1:
                polystr+=","
        polystr+="))"


    return polystr


def ShapetoLisconvertor(path):
    shp= shapefile.Reader(path)

    reclis=[]
    for rec in shp.iterShapeRecords():
        if rec.record[0]=='AGO-1893' or rec.record[0]=='ABW-5150' or rec.record[0]!='':
            geolis =rec.shape.__geo_interface__ 
            #print geolis
            #polystr='{0}(('.format(geolis.get('type'))
            #geocoordlis=geolis.get('coordinates')
            geometrystr=geoRowFormer(geolis.get('type') , geolis.get('coordinates'))
            tlis=rec.record
            tlis.extend([geometrystr])
            reclis.append(tuple(tlis))
        #break
#        for j in range(len(geocoordlis)):
#            polystr+="{0} {1} ".format( geocoordlis[j][0] , geocoordlis[j][1])
#            if j<len(geocoordlis)-1:
#                polystr+=","
#        polystr+="))"
    #print polystr
    #break    
    print reclis[0]
#    ob=geo_quatroshape.Insertintopublic_record()
#    ob.execute_lis(reclis)
#    


path="adm2/qs_adm2_region.shpp"
ShapetoLisconvertor(path)
#print reclis

#reclis=[]
#for rec in shp.iterShapeRecords():
#    if (rec.shape.shapeType!=5):
#        print "not in polygon"
#    else:
#        st='POLYGON(('
#        geolis=rec.shape.points
#        if geolis[0] !=geolis[len(geolis)-1]:
#            print "no"
#            print rec.record
#            print geolis
#            continue
#        polystr='POLYGON(('
#        for j in range(len(geolis)):
#            polystr+="{0} {1} ".format(geolis[j][0] ,geolis[j][1])
#            if j<len(geolis)-1:
#                polystr+=","
#        polystr+="))"
#        #print polystr
#        tlis=rec.record
#        tlis.extend([polystr])
#        reclis.append(tuple(tlis))
#            
        
       # print rec
    #break

#print reclis



#
