# -*- coding: utf-8 -*-
"""
Created on Sat Mar 19 09:59:36 2016

@author: manoj
"""

permute_string ="abc"

def