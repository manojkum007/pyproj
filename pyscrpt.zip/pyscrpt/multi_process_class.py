# -*- coding: utf-8 -*-
"""
Created on Wed Aug  9 23:49:38 2017

@author: manoj
"""

from multiprocessing import Pool
import threading
import time

class IntegerNumber:

    def __init__(self, n):
        self.num = n

    def increment(self):
        self.num += 1


class MultiProc:

    def __init__(self):
        self.numbers = list()

    def set_numbers(self, n):
        for x in range(n):
            self.numbers.append(IntegerNumber(x))

    def parallel_increment(self):
        pool = Pool()
        ns = pool.map(self.handler, self.numbers)
        for n in ns:
            print(n.num)

    @staticmethod
    def handler(inum):
        inum.increment()        
        return inum


if __name__ == '__main__':
    m = MultiProc()
    m.set_numbers(10)
    m.parallel_increment()
