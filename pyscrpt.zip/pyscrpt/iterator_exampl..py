# -*- coding: utf-8 -*-
"""
Created on Thu Jul 21 18:44:30 2016

@author: manoj
"""

class iterator:
    def __init__(self,lis):
        self.lis=lis
        self.index=0

    def __iter__(self):
        return self

    def next(self):
        if (self.index<len(self.lis)):
            cur=self.index
            self.index+=1
            return self.lis[cur]
        else:
            raise StopIteration()  

#it=iterator([12,22,66,89])
#print sum(it)
#for i in it:
#    print i
#    
    
class zrange_iter:
    def __init__(self, n):
        self.i = 0
        self.n = n

    def __iter__(self):
        # Iterators are iterables too.
        # Adding this functions to make them so.
        return self

    def next(self):
        if self.i < self.n:
            i = self.i
            self.i += 1
            return i
        else:
            raise StopIteration()


class zrange:
    def __init__(self, lis):
        self.lis = lis

    def __iter__(self):
        for i in self.lis:
            return zrange_iter(i)
        
        
#z=zrange([15,56,12])
#for i in z:
#    print i
    
    
    
def yrange(n):
    i = 0
    print "i=" ,i
    while i < n:
        print "i in while =" ,i
        yield i
        print "i after yoeld =" ,i
        i += 1
        
        
y =yrange(2)
#y.next()
#y.next()
for i in y:
    print "iteration ",i