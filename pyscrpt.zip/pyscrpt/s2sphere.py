# -*- coding: utf-8 -*-
"""
Created on Fri Aug 31 14:20:23 2018

@author: manoj
"""

import s2sphere
from elasticsearch2 import Elasticsearch
import csv
from collections import OrderedDict
row = OrderedDict()
cell = s2sphere.CellId.from_lat_lng(s2sphere.LatLng.from_degrees(37.3860517,-122.0838511))
for x in range(30, 4, -1):
    if x > 18:
        continue
    row[('cell_id_%s' % str(x).zfill(2))] = cell.to_token()
            if x > 0:
                cell = cell.parent()
            
            pass

        if not headers:
            w = csv.DictWriter(f, row.keys())
            w.writeheader()
            headers = True
        w.writerow(row)
        listings.append(row)

