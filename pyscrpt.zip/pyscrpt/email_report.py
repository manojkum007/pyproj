# -*- coding: utf-8 -*-
"""
Created on Thu Sep 15 11:53:02 2016

@author: manoj
"""
import psycopg2
import csv

#conn = psycopg2.connect(host="192.168.120.137", dbname="realestate_dev", user="census", password="censuspassword")
conn = psycopg2.connect(host="localhost", dbname="postgres", user="postgres", password="admin")

conn.set_isolation_level(psycopg2.extensions.ISOLATION_LEVEL_AUTOCOMMIT)
command = 'select file_name, recs_in_file, recs_loaded_to_db, start_time,  end_time from public.file_upload_status;'
cur = conn.cursor()
cur.execute(command)
res=cur.fetchall()
#x.strftime('%Y-%m-%d')

# <tr>
#    <td>Alfreds Futterkiste</td>
#    <td>Maria Anders</td>
#    <td>Germany</td>
#  </tr>
data=""
tFilecnt=0
tdbrowcnt=0
percent=0.0

for i in res:
    data+="<tr>"
    tFilecnt+=i[1]
    tdbrowcnt+=i[2]
    for j in i:
        data+="<td>"+str(j)+"</td>"+"\n"
    data+="</tr>"

print tFilecnt, tdbrowcnt ,(tdbrowcnt/float(tFilecnt))*100.0
    #print i[3].strftime('%Y-%m-%d')
deedsfile ='/home/manoj/scripts/tiger_analyatics/rhino/dev_rhino/sample.csv'


class mlsRec():
    def __init__(self):
        self.mlsrow=[]
    def  addrow(self, mls, filecnt, dbcnt ):
        percent=(dbcnt/float(filecnt))*100.0
        self.mlsrow.append([mls,filecnt,dbcnt,percent])
        
    def writefile(self, deedsFile ,filetype):
        with open(deedsFile, 'w') as errors_file:
            writer = csv.writer(errors_file, delimiter='\t')
            if(filetype=="listings"):
                writer.writerow(["MLS LISTINGS"])
            elif(filetype=="offices"):
                writer.writerow(["MLS OFFICES"])
            elif(filetype=="agents"):
                writer.writerow(["MLS AGENTS"])     
            header=[]
            header.append("MLS")
            header.append("Filecount")
            header.append("Dbrecord")
            header.append("success%")
            writer.writerow(header)
            for row in self.mlsrow:
                writer.writerow(row)
                
    def totalsuceess(self):
        tfilecnt=0
        tdbrow=0
        percent=0.0
        for i in self.mlsrow:
            tfilecnt+=i[1]
            tdbrow+=i[2]
        percent=(tdbrow/float(tfilecnt))*100.0
        return tfilecnt, tdbrow, percent
        


m=mlsRec()

m.addrow('akmls' ,45 ,23)
m.addrow('bar' ,145 ,123)

#m.writefile(deedsfile ,'offices')
print m.totalsuceess()