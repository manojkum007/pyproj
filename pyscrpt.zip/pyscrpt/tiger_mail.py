# -*- coding: utf-8 -*-
"""
Created on Thu Sep 15 18:09:20 2016

@author: manoj
"""

import smtplib

# Import the email modules we'll need
from email.mime.text import MIMEText

# Open a plain text file for reading.  For this example, assume that
# the text file contains only ASCII characters.
#fp = open( "/home/mkumar/treasure-hunter/Data_loading/MLS/logging_config.ini", 'rb')
# Create a text/plain message
msg = MIMEText("gcgjcjh,cvhk,vkhv")
#fp.close()

# me == the sender's email address
# you == the recipient's email address
msg['Subject'] = 'The contents of %s' % "hello"
msg['From'] = 'mkumar@movoto.com'
msg['To'] = 'mkumar@movoto.com'

# Send the message via our own SMTP server, but don't include the
# envelope header.
s = smtplib.SMTP('192.168.120.128')
s.sendmail('mkumar@movoto.com', ['mkumar@movoto.com',], msg.as_string())
s.quit()
