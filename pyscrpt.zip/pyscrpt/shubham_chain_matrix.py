# -*- coding: utf-8 -*-
"""
Created on Thu Feb 15 23:25:11 2018

@author: manoj
"""

ll=[{0:(20,40,70,80)}]


#ll=[{800: (60, 70, 80)}, {2800: (20, 10, 80)}, {5600: (20, 40, 50)}]
#
#ll=[{5000: (30, 80)}]
#ll=[{7400: (10,)}]

#ans  5400


def calcnoise(dictionary):
    comlis=[]
    for k,v in dictionary.iteritems():
        v=list(v)
        if len(v)==1:
            return []
        for i in range(len(v)-1):
            tlis=[]
            noise= k+(v[i]*v[i+1])
            newelement=(v[i]+v[i+1])%100
            l1,l2=v[:], v[:]
            l1.pop(i)
            l2.pop(i+1)
            tlis.extend([ele for ele in l1 if ele in l2 ])
            tlis.insert(i,newelement)
            comlis.append({noise :tuple(tlis)})
    return comlis
        


lis=[]
cnt=0
k=cnt
print "Level {0}=".format(k),ll
while (len(ll[0][ll[0].keys()[0]])>1):
    lis.extend(calcnoise(ll[cnt]))
    cnt+=1
    if (cnt==len(ll)):
        ll=lis[:]
        k+=1
        print "Level {0}=".format(k),ll
        lis=[]
        cnt=0
    


def findminimum(ll):
    minlis=[]
    for dictionary in ll:
        for k,v  in dictionary.iteritems():
            minlis.append(k)
    return min(minlis)
            
            
print "minimum value  of noise is " ,findminimum(ll)


