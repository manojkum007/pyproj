# -*- coding: utf-8 -*-
"""
Created on Wed Jun 22 23:27:39 2016

@author: manoj
"""

from multiprocessing import Process, Lock


def f(l, i,t):   
    l.acquire()
    print 'hello world', i,  
    t+=1
    print "total",t
    l.release()
    

if __name__ == '__main__':
    lock = Lock()
    #global TOTAL
    TOTAL =1
    for num in range(10):
        p=Process(target=f, args=(lock, num,TOTAL))
        p.start()
        p.join()