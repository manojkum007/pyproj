# -*- coding: utf-8 -*-
"""
Created on Tue May 15 09:55:50 2018

@author: manoj
"""
from datetime import date, timedelta
start_date=datetime.datetime.strptime( "2017-10-01",'%Y-%m-%d')

end_date=datetime.datetime.strptime( "2018-03-01",'%Y-%m-%d')

def daterange(start_date, end_date):
    if start_date == end_date:
        yield start_date
    else:
        for n in range(int ((end_date - start_date).days)):
            yield start_date + datetime.timedelta(n)

#for i in  range(225):
#    print datetime.datetime.strptime( "2017-10-01",'%Y-%m-%d')+datetime.timedelta(i)


for i in daterange(start_date, end_date):
    print i