# -*- coding: utf-8 -*-
"""
Created on Tue Aug  8 19:35:23 2017

@author: manoj
"""

import os
import time
#
#pid=os.fork()
#print "pid",pid
#if pid:
#    # parent
#    while True:
#        print("I'm the parent")
#        time.sleep(0.5)    
#        break
#else:
#    # child
#    while True:
#        print("I'm just a child")
#        time.sleep(0.5)
#        break
#    
#    
 






#   
#i=0
#def child():
#   print '\nA new child ',  os.getpid()
#   os._exit(0)  
#
#def parent():
#    print "before starrting loop"
#
#    while True:
#        i=+1
#        print " now in loop",i
#        newpid = os.fork()
#        print "newpid",newpid
#        if newpid == 0:
#            child()
#        else:
#            pids = (os.getpid(), newpid)
#            print("parent: %d, child: %d\n" % pids)
#            reply = raw_input("q for quit / c for new fork")
#            if reply == 'c': 
#                continue
#            else:
#                break
#        break
#
#parent()










 
from multiprocessing import Process
 
#def doubler(number):
#    """
#    A doubling function that can be used by a process
#    """
#    result = number * 2
#    proc = os.getpid()
#    print('{0} doubled to {1} by process id: {2}'.format(
#        number, result, proc))
# 
#if __name__ == '__main__':
#    numbers = [5, 10, 15, 20, 25]
#    procs = []
# 
#    for index, number in enumerate(numbers):
#        proc = Process(target=doubler, args=(number,))
#        procs.append(proc)
#        proc.start()
# 
#    for proc in procs:
#        proc.join()
 
 
 
#import multiprocessing
#
#def f(x):
#    return x*x
#
#def go():
#    pool = multiprocessing.Pool(processes=4)        
#    print pool.map(f, range(100))
#
#
#if __name__== '__main__' :
#    go()
# 
#
 
import multiprocessing as mp

class Foo():
    @staticmethod
    def work(self):
        print "doing sometning"

pool = mp.Pool()
foo = Foo()
 pool.apply_async(foo.work)
pool.close()
pool.join()

 
 
# 
#from multiprocessing import Pool
# 
#def doubler(numberlist):
#    print "in numberslist",numberlist
#    return map(lambda x : x*2 ,numberlist)
#    
#    
#if __name__ == '__main__':
#    numbers = [5, 10, 20,50 ,60]
#    data=numbers
#    chunks = [data[x:x+2] for x in range(0, len(data), 2)]
#    print chunks
#    pool = Pool(processes=3)
#    print pool.map(doubler, chunks)