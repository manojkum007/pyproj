# -*- coding: utf-8 -*-
"""
Created on Thu Mar 31 15:05:06 2016

@author: manoj
"""
from twilio.rest import TwilioRestClient

auth_token = "b2dd8fa4f2d88093b795c4cf71ee1b71"
account_sid = "ACc2fe8171ecfef91a9b89afff996cfc97"
client = TwilioRestClient(account_sid, auth_token)
#message = client.messages.create(to="+919677148563", from_="+12568417328",body="Hi how r u")

call = client.calls.create(to="+919677148563",  # Any phone number
                           from_="+12568417328", # Must be a valid Twilio number
                           url="http://twimlets.com/holdmusic?Bucket=com.twilio.music.ambient")
print call.sid