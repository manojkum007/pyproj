# -*- coding: utf-8 -*-
"""
Created on Wed Dec 14 19:49:33 2016

@author: manoj
"""

import os 
from Utilities.movoto.SqlHelper import SqlHelper

os.getcwd()


os.chdir('/home/manoj/postprpcessor/postprocessors/great_school')



sqlHelper = SqlHelper('school_new', use_connection_pool=True)

sqlHelper.getAllBySql('select distinct(state_code) from school;')

