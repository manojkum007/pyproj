# -*- coding: utf-8 -*-
"""
Created on Thu Apr 13 15:32:24 2017

@author: manoj
"""
"""
alter table  test_bq_nova_desktop.new_sessions_hits_parquet_test CHANGE  trafficsource  trafficsource struct<
referralPath:binary,campaign:binary,source:binary,medium:binary,keyword:binary,
adContent:binary,adwordsClickInfo:struct<campaignId:bigint,adGroupId:bigint,creativeId:bigint,
criteriaId:bigint,page:bigint,slot:binary,criteriaParameters:binary,gclId:binary,customerId:bigint,
adNetworkType:binary,targetingCriteria:struct<boomUserlistId:bigint>,
isVideoAd:boolean>,isTrueDirect:boolean,campaignCode:binary>;
"""



  
  
dd="""/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-09-02
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-09-03
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-09-04
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-09-05
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-09-06
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-09-07
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-09-08
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-09-09
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-09-10
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-09-11
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-09-12
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-09-13
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-09-14
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-09-15
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-09-21
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-09-22
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-09-23
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-09-24
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-09-25
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-09-26
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-09-27
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-09-28
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-09-29
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-09-30
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-10-01
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-10-02
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-10-03
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-10-04
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-10-05
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-10-06
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-10-07
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-10-08
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-10-09
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-10-10
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-10-11
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-10-12
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-10-13
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-10-14
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-10-15
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-10-16
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-10-17
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-10-18
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-10-19
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-10-20
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-10-21
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-10-22
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-10-23
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-10-24
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-10-25
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-10-26
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-10-27
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-10-28
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-10-29
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-10-30
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-10-31
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-12-01
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-12-02
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-12-03
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-12-04
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-12-05
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-12-06
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-12-07
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-12-08
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-12-09
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-12-10
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-12-11
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-12-12
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-12-13
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-12-14
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-12-15
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-12-16
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-12-17
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-12-18
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-12-19
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-12-20
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-12-21
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-12-22
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-12-23
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-12-24
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-12-25
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-12-26
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-12-27
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-12-28
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-12-29
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-12-30
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2016-12-31
/user/hive/warehouse/bq_nova.db/desktop_sessions_hits_parquet_historical/updated_date=2017-02-20"""


ll=dd.split("\n")


ldqry="""
load data inpath '%s' into table bq_nova.desktop_sessions_hits_parquet_historical_newschema
  PARTITION(updated_date="%s");"""


for i in ll:
    update_date= i.split("/").pop()
    print ldqry%(i, update_date)
    #break
    
    

