# -*- coding: utf-8 -*-
"""
Created on Mon Oct 15 15:50:26 2018

@author: manoj
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Feb 15 11:05:25 2016

@author: manoj
"""

import psycopg2 as mdb
import sys
import csv
import psycopg2.extras
reload(sys)
sys.setdefaultencoding('utf-8')


class postgresqlconnector :
    def __init__(self, host,  usrname, passwrd, database, port):
        self.host=host
        self.username=usrname
        self.password=passwrd
        self.database=database
        self.port=port
        self.command= ""
        if (self.connect()==0):
            exit(1)
    def connect(self):
              
        try:           
            self.con = mdb.connect(database=self.database, user=self.username, password=self.password, host=self.host, port=self.port)
            #self.cur=self.con.cursor()
            return 1
        except mdb.Error as e:
            print "postgresql Error : %s" % (e.pgerror)
            return 0
    

#    def setQuery(self ,command):
#        self.command=command

    def execQuery(self,command):
        #print "njljndbf"
        try:
            self.cur=self.con.cursor(cursor_factory=psycopg2.extras.DictCursor)
            self.cur.execute(command)
#            for row in self.cur:
#                print row
            data= self.cur.fetchall()
            #print "data",data
            self.cur.close()         
            return data        
        except mdb.Error as e:
            print "error in executing sql statement",e.pgerror
            self.con.rollback()
            return 0
    
    def execmanyQuery(self,lis):
        with self.con.cursor() as cursor:
            for i in lis:
                cursor.execute(i)
                yield cursor.fetchall()
    
    def insertquery(self, sql ,valueList):
        #print self.con.cursor().executemany(sql, valueList) 
        try:
            self.con.cursor().executemany(sql, valueList) 
            self.con.commit()
        except Exception as e:
            print "in error",e
        finally:
            print "inserted successfully"
         

        
#        try:
#            self.cur=self.con.cursor()
#            for i in lis:
#                self.cur.execute(i)
#                yield self.cur.fetchall()
#        except mdb.Error as e:
#            print "error in executing sql statement",e.pgerror
#            yield 0

#    def fetchResults(self): 
#        try:
#           return self.cur.fetchall()          
#        except mdb.Error as e:
#            print "error in fetching results",e.pgerror
       
        

#    def fetchSingleResults(self):
#        return self.cur.fetchone()
    def distinctresult(self ,prmykey ,tablename):
        try:
            sql="""select distinct %s from %s limit 10"""%(prmykey, tablename)
            distinctlis=self.execQuery(sql)
            
            return distinctlis
        except Exception as e:
            return  e
    
    def queryfetcher(self, columns, prykey, tablename, distinctlis):
        sfquery="""select  %s from %s  where   %s in ("""%(columns, tablename ,prykey)
        #lisqry=distinctlis[oid:oid+page]  
        qry=""
        for j in range(len(distinctlis)):   
            if type(distinctlis[j])  ==str:
                qry+="'{0}'".format(distinctlis[j])
            else:
                qry+="{0}".format(distinctlis[j])
            if j !=len(distinctlis)-1:
                qry+=","
            else:
                qry+=""
        qry+=");"     
        sfquery+=qry
            
        return  sfquery

    def __del__(self):
        #self.con.commit()
        #self.cur.close()
        self.con.close()
        print "closing connection"

def sanity(lis):
    try:
         lis=map(lambda t: t.encode('utf-8') if (type(t)==str or type(t)==unicode) else t,lis)
         return lis
    except Exception as e:
        return  e
        
        
        

def writeDataFile(mlsFile,lisdata):
    with open(mlsFile, 'w') as log_file:
        writer = csv.writer(log_file, delimiter='\t')
        for row in lisdata:
            writer.writerow(row)

#print data
#
#writeDataFile("/home/manoj/scripts/python_scripts/Pyspark_module/sample.txt", data)


pgres=postgresqlconnector(host='192.168.120.118',  database='movotogeo', usrname='postgres', passwrd='igen4movoto',port=5432)

sql="""SELECT keyword, geo_id, geo_type, geo_name, "state" FROM whoami.keyword_geo_mapping limit 10;"""
#sql="""SELECT qs_a2 FROM quattroshapes.qs_localities;"""
#sql="""select * from whoami.keyword_geo_mapping"""
print pgres.execQuery(sql)
