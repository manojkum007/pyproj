# -*- coding: utf-8 -*-
"""
Created on Thu Jun  7 17:15:05 2018

@author: manoj
"""

from time import sleep



import time


def timing_function(some_function):

    """
    Outputs the time a function takes
    to execute.
    """

    def wrapper(*args):
        t1 = time.time()
        some_function(*args)
        t2 = time.time()
        return "Time it took to run the function: " + str((t2 - t1)) + "\n"
    return wrapper


@timing_function
def my_function(lis):
    print "lis" , lis
    num_list = []
    for num in (range(0, 100000)):
        num_list.append(num)
    print("\nSum of all the numbers: " + str((sum(num_list))))


print(my_function([4,54,7]))



#
#def sleep_decorator(function):
#
#    """
#    Limits how fast the function is
#    called.
#    """
#
#    def wrapper(*args, **kwargs):
#        sleep(1)
#        return function(*args, **kwargs)
#    return wrapper
#
#
#@sleep_decorator
#def print_number(num):
#    return num
#
##print(print_number(222))
#
#for num in range(1, 6):
#    print(print_number(num))

