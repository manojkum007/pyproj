# -*- coding: utf-8 -*-
"""
Created on Fri Jul 22 15:12:59 2016

@author: manoj
"""
import re
import csv

lis=[]
with open('/home/manoj/scripts/python_scripts/response_data.txt', 'r') as infile:
    for line in infile:
        matchObj4=re.match( r'(.*)_id\": \"(\S+)\"', line)
        if(matchObj4):
            lis.append(matchObj4.group(2))
            

print len(lis)

for i in lis:
    with open('/home/manoj/scripts/tiger_analyatics/chimpanzee/delete_data.txt', 'a') as errors_file:
        writer = csv.writer(errors_file, delimiter='\t')
        row=["curl -XDELETE 'localhost:9200/webmaster_tools/search_analytics_by_page/"+i+"'"]
        writer.writerow(row)
