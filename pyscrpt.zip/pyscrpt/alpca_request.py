# -*- coding: utf-8 -*-
"""
Created on Tue Jan 24 18:00:23 2017

@author: manoj
"""

import requests

url = "http://192.168.14.60:3002/agentdirectory/agents/url/diana-monroy-4/"

headers = {
    'x-mdata-key': "CHUMAGATHUQ9VE7AYEBR",
    'cache-control': "no-cache",
    'postman-token': "208d07cc-795f-9ca6-ef05-9e5bb08cdc8b"
    }

response = requests.request("GET", url, headers=headers)

print(response.text)