# -*- coding: utf-8 -*-
"""
Created on Wed Apr  4 12:25:20 2018

@author: manoj
"""

def convex_hull(points):
    """Computes the convex hull of a set of 2D points.

    Input: an iterable sequence of (x, y) pairs representing the points.
    Output: a list of vertices of the convex hull in counter-clockwise order,
      starting from the vertex with the lexicographically smallest coordinates.
    Implements Andrew's monotone chain algorithm. O(n log n) complexity.
    """

    # Sort the points lexicographically (tuples are compared lexicographically).
    # Remove duplicates to detect the case we have just one unique point.
    points = sorted(set(points))

    # Boring case: no points or a single point, possibly repeated multiple times.
    if len(points) <= 1:
        return points

    # 2D cross product of OA and OB vectors, i.e. z-component of their 3D cross product.
    # Returns a positive value, if OAB makes a counter-clockwise turn,
    # negative for clockwise turn, and zero if the points are collinear.
    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])

    # Build lower hull 
    lower = []
    for p in points:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)

    # Build upper hull
    upper = []
    for p in reversed(points):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)

    # Concatenation of the lower and upper hulls gives the convex hull.
    # Last point of each list is omitted because it is repeated at the beginning of the other list. 
    return lower[:-1] + upper[:-1]

# Example: convex hull of a 10-by-10 grid.

ll=[
 (41.637464, -81.448483),
 (47.160921, -122.590413),
 (36.86493, -119.766169),
 (30.248401, -81.390134),
 (30.209865, -81.545033),
 (48.98071, -123.04399),
 (39.270607, -74.978999),
 (34.528638, -117.307954),
 (41.637464, -81.448483)
 ]

ll=[(-97.80368616,30.18577698),(-97.80368616,30.18917997),(-97.79996448,30.18917997),(-97.79996448,30.18577698),(-97.80368616,30.18577698)]




lis= map(lambda x: list(x) ,convex_hull(ll))
lis.append(lis[0])
#print ll
print lis

#lis1=[]
#for d in lis:
#    print d[0]
#    lis1.append([d[1],d[0]])

#print lis1


#for  row in  convex_hull(ll):
#    data.append(list(row))
#data.append(data[0])
#print data
#assert convex_hull([(i//10, i%10) for i in range(100)]) == [(0, 0), (9, 0), (9, 9), (0, 9)]
#

#convex_hull(points)
