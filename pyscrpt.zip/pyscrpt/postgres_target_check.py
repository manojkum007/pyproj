# -*- coding: utf-8 -*-
"""
Created on Sun Aug  6 09:57:06 2017

@author: manoj
"""
import luigi
import datetime
import json
import time 
import psycopg2
#import luigi.postgres.PostgresTarget

from luigi.contrib.external_program import ExternalProgramTask



#luigi.postgres.PostgresTarget

#luigi.postgres.PostgresTarget

class TaskA1(luigi.Task):
    def run(self):
        with self.output().open('w') as f:
            f.write('{word}\n'.format(word='createSchema_'))
        
    def output(self):
        return MlsSchemaTarget()
        #return luigi.LocalTarget('/home/manoj/scripts/results.log1')


class dbtargetchecker(luigi.Task):
    def run(self):      
        print "in target checker class"
        self.output().touch()
        
    def output(self):
        return  MlsSchemaTarget(hostname='127.0.0.1', dbname='postgres', user='postgres', password='admin' ,table='mls_schema',update_id=13)
        
        #return luigi.LocalTarget('/home/manoj/scripts/results.log1')


        

class MlsSchemaTarget(luigi.Target):   
    
    def __init__(self , hostname, dbname , user,  password, table, update_id ):
        self.hostname=hostname
        self.dbname =dbname  
        self.user=user 
        self.password=password
        self.marker_table='table_updates'
        self.update_id=update_id
        self.table=table
        self.use_db_timestamps=False
        self.conn=psycopg2.connect(host=self.hostname, dbname=self.dbname ,  user=self.user, password=self.password )
    
    def create_marker_table(self):
        """
        Create marker table if it doesn't exist.

        Using a separate connection since the transaction might have to be reset.
        """
        connection = self.connect()
        connection.autocommit = True
        cursor = connection.cursor()
        if self.use_db_timestamps:
            sql = """ CREATE TABLE {marker_table} (
                      update_id TEXT PRIMARY KEY,
                      target_table TEXT,
                      inserted TIMESTAMP DEFAULT NOW())
                """.format(marker_table=self.marker_table)
        else:
            sql = """ CREATE TABLE {marker_table} (
                      update_id TEXT PRIMARY KEY,
                      target_table TEXT,
                      inserted TIMESTAMP);
                  """.format(marker_table=self.marker_table)
        try:
            cursor.execute(sql)
        except psycopg2.ProgrammingError as e:
            if e.pgcode == psycopg2.errorcodes.DUPLICATE_TABLE:
                pass
            else:
                raise
        connection.close()
        
        
    
    def touch(self, connection=None):
        """
        Mark this update as complete.

        Important: If the marker table doesn't exist, the connection transaction will be aborted
        and the connection reset.
        Then the marker table will be created.
        """
        #self.create_marker_table()

        if connection is None:
            # TODO: test this
            connection = self.conn
            connection.autocommit = True  # if connection created here, we commit it here

        if self.use_db_timestamps:
            connection.cursor().execute(
                """INSERT INTO {marker_table} (update_id, target_table)
                   VALUES (%s, %s)
                """.format(marker_table=self.marker_table),
                (self.update_id, self.table))
        else:
            connection.cursor().execute(
                """INSERT INTO {marker_table} (update_id, target_table, inserted)
                         VALUES (%s, %s, %s);
                    """.format(marker_table=self.marker_table),
                (self.update_id, self.table,
                 datetime.datetime.now()))

        # make sure update is properly marked
        #assert self.exists()
        return self.exists()
        
    def exists(self):
        #conn = psycopg2.connect(host=tiger_host, dbname=tiger_database, user=tiger_user, password=tiger_password)
        
        
        cur = self.conn.cursor()  
#        command = """
#        SELECT schema_name FROM information_schema.schemata WHERE schema_name in ('mls_[mls]' ,'mls_[intermediate_table]') ;
#        """.replace('[mls]', self.mls).replace('[intermediate_table]',intermediate_schema)
        
        command="""SELECT update_id, target_table, inserted FROM table_updates where update_id='%s';"""%self.update_id
        
        cur.execute(command)
        test = cur.fetchall()
        print " got result",test
        if (len(test)>0):
            print "yes got resullt"         
            return True 
        else:
            print "not yet entry is there"
            return False
    def __del__(self):
        self.conn.close()
    