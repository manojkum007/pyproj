# -*- coding: utf-8 -*-
"""
Created on Mon Aug 22 18:20:58 2016

@author: manoj
"""
import luigi
from luigi.contrib.hdfs.target import HdfsTarget


class SchemaToHdfs(luigi.Task):
    def requires(self):
        pass

    def run(self):
        print "hello downloader"
        print "trying to write"
        with self.output().open('w') as f:
            f.write('{word}\n'.format(word='demo'))
        self.output().touch()
        
        print "written sucessfully"

    def output(self):
        return HdfsTarget(path="/data/bigquery/files/test/demo.txt")
