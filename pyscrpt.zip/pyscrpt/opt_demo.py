# -*- coding: utf-8 -*-
"""
Created on Fri Jun  9 20:58:14 2017

@author: manoj
"""


import sys, getopt
#
#def main(argv):
#   inputdate = ''
#   try:
#      opts, args = getopt.getopt(argv,"h:date:o:")
#   except getopt.GetoptError:
#      print 'warmer.py --date '
#      sys.exit(2)
#   for opt, arg in opts:
#      if opt == '-h':
#         print 'warmer.py -date '
#         sys.exit()
#      elif opt in ("--date"):
#         inputdate = arg
#
#   print 'Input file is "', inputdate



def main(argv):
   inputfile = ''
   outputfile = ''
   try:
      opts, args = getopt.getopt(argv,"hi:o:",["ifile=","ofile="])
   except getopt.GetoptError:
      print 'test.py -i <inputfile> -o <outputfile>'
      sys.exit(2)
   for opt, arg in opts:
      if opt == '-h':
         print 'test.py -i <inputfile> -o <outputfile>'
         sys.exit()
      elif opt in ("-i", "--ifile"):
         inputfile = arg
      elif opt in ("-o", "--ofile"):
         outputfile = arg
   print 'Input file is "', inputfile
   print 'Output file is "', outputfile

if __name__ == "__main__":
   main(sys.argv[1:])
if __name__ == "__main__":
   main(sys.argv[1:])
