# -*- coding: utf-8 -*-
"""
Created on Tue Aug  8 19:23:43 2017

@author: manoj
"""
import os

from multiprocessing.dummy import Pool as ThreadPool

from multiprocessing import Process

class Double:
    def doubler(self,number):
        def doubledoubler():
            result = number * 2
            proc = os.getpid()
            print('{0} doubled to {1} by process id: {2}'.format(number, result, proc))
        return doubledoubler()
        
        
    def multiprocess(self):
        numbers = [5, 10, 15, 20, 25]
        pool = ThreadPool(3)
        pool.map(self.doubler, numbers)
        pool.close()
        pool.join()   

        #procs = []
#        for index, number in enumerate(numbers):
#            proc = Process(target=self.doubler , args=(number,))
#            procs.append(proc)
#            proc.start()
#     
#        for proc in procs:
#            proc.join()


d=Double()
d.multiprocess()



#if __name__ == '__main__':
