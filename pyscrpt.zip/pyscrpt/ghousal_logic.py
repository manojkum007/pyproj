# -*- coding: utf-8 -*-
"""
Created on Wed Sep 14 17:51:42 2016

@author: manoj
"""

data1=[]
#data1=[0,0]
#data1=[0,1]
#data1=[1,1]


lis=[]

for i in data1:
    if (i==1):
        lis.append(i)
        break

if len(lis)==0:
    if (len(data1)!=0):
        lis.append(data1[0])
        
print "length of lis" ,lis
