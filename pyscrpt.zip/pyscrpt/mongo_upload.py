# -*- coding: utf-8 -*-
"""
Created on Sat Jan  7 11:02:05 2017

@author: manoj
"""

       
def mongoload(mongodblis, mongoid, fileprefix):
    global og_dir
    global mongohostname
    global mongoport
    global username
    global password
    global database
    global collectioname
    global logger
    global platform
    global mongopath
    global counter
    for docindex in range(len(mongodblis)):
        mongodb=[mongodblis[docindex]]
        path='./%s/%s_%sdec_%s.json'%(og_dir, fileprefix, mongoid[docindex],counter)
        jsonob=open(path,'w')
        json.dump(mongodb,jsonob, indent=4)
        jsonob.close() 
        if platform!='win32':
            fpath=mongopath+" -h "+mongohostname+" --port "+str(mongoport)+"  -u '"+username+"' -p '"+password+"' -d "+database+" -c "+collectioname +"  --type json '"+path+"' --jsonArray" 
            print "fpath" ,fpath
            p = subprocess.Popen([fpath], stdout=subprocess.PIPE, stderr=subprocess.PIPE,shell=True)
            out, err = p.communicate()
            flag=1
            mongomess=err.split("\n")
            for i in mongomess:
                matchObj=re.match( r'(.*)error inserting documents', i)
                if  matchObj:      
                    flag=-1
                matchObj1=re.match( r'(.*)imported 1 document', i)
                if  matchObj1:      
                    flag=0                   
            if (flag==0):
                print "sucess"
                logger.info("loading successfull %s"%mongomess)
            else:
                print "error"
                logger.info("loading Failed %s"%mongomess)
                try:
                    copyfile(path, './%s/%s_%s_%s.json'%(og_errdir, fileprefix, mongoagentid[docindex], counter))
                except Exception as e:
                    logger.info("error in copying %s"%path)
        else:
            try:
                fpath=mongopath+" -h "+mongohostname+" --port "+str(mongoport)+"  -u '"+username+"' -p '"+password+"' -d "+database+" -c "+collectioname +"  --type json '"+path+"' --jsonArray"                 
                cmdList=shlex.split(fpath) 
                print "fpath" ,fpath
                result = subprocess.check_output(cmdList, stderr=subprocess.STDOUT, shell=True)
                flag=1
                err=result
                print result
                logger.info("output %s"%result)
                mongomess=err.split("\n")
                for i in mongomess:
                    matchObj=re.match( r'(.*)error inserting documents', i)
                    if  matchObj:      
                        flag=-1
                    matchObj1=re.match( r'(.*)imported 1 document', i)
                    if  matchObj1:      
                        flag=0              
                    if (flag==0):
                        logger.info("loading successfull %s"%mongomess)
                    else:
                        print "error"
                        logger.info("loading Failed %s"%mongomess)
                    try:
                        copyfile(path, './%s/%s_%s_%s.json'%(og_errdir, fileprefix, mongoid[docindex], counter))
                    except Exception as e:
                        logger.info("error in copying %s"%path)
            except subprocess.CalledProcessError, ex: 
                logger.info("--------error------")
                logger.info("ex.cmd%s"%ex.cmd)
                logger.info("ex.message%s"%ex.message)
                logger.info("ex.returncode%s"%ex.returncode)
                logger.info("ex.output%s"%ex.output) 
        counter=counter+1