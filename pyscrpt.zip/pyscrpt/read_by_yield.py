# -*- coding: utf-8 -*-
"""
Created on Wed Jul 13 16:52:40 2016

@author: manoj
"""
import psycopg2

def read_file():
    with open('/home/manoj/scripts/python_scripts/text.txt', 'r') as read_file:      
        for line in read_file:
            yield line


r=read_file()


                
def read_database():
    conn = psycopg2.connect(host='localhost', dbname='postgres', user='postgres', password='admin')
    cur = conn.cursor()
    cur.execute("select * from  deeds.all_deeds limit 5 ;" )
    lis= cur.fetchall()
    for row in lis:
        yield row
    
    


 
for i in read_database():
    print i[0] ,i[71]