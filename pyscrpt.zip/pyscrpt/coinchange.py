# -*- coding: utf-8 -*-
"""
Created on Mon Jan 29 14:41:33 2018

@author: manoj
"""

lis=[10,5,3,2,1]

lis=[1]
amnt=4


changedict={}
for i in lis:
    changedict[i]=0
    
    
#    ={lis[0]:0,lis:0,2:0,1:0}

#print changedict


inc=0
while amnt>0:
    #print lis[inc] ,amnt/lis[inc]
    changedict[lis[inc]]=amnt/lis[inc]
    amnt=amnt%lis[inc]
    #print " chnagelis",changedict[lis[inc]]
    inc+=1

print changedict

print "these r following change"
for k,v in changedict.iteritems():
    if v>0:
        print k ," ruppes change is " ,v