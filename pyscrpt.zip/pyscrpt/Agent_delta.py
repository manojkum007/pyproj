# -*- coding: utf-8 -*-
"""
Created on Fri Jan 27 23:55:31 2017

@author: manoj
"""

# -*- coding: utf-8 -*-
"""
Created on Fri Dec 23 00:01:31 2016

@author: manoj
"""

# Written with pymongo-3.2 
# Documentation: http://api.mongodb.org/python/
# A python script connecting to a MongoDB given a MongoDB Connection URI.

import sys
import pymongo

MONGODB_URI = 'mongodb://user:pass@host:port/db' 
MONGODB_URI ="localhost:27017"

collection_name='Agent'


def mongo():

    client = pymongo.MongoClient(MONGODB_URI)
    db=client.temp
    coll_name = db[collection_name]
    query = {'userId.id': 'b6ef3371-d9ce-469d-b0ca-8e4112dc2b51'}

    coll_name.update_one(query, {'$set': {'url': 'manoj-kumar/'}})
#
    cursor = coll_name.find({'userId.id': 'b6ef3371-d9ce-469d-b0ca-8e4112dc2b51'})
#    -1 descending
#    1 asending

    for doc in cursor:
        print doc
#        print ('In the %s, %s by %s topped the charts for %d straight weeks.' %
#               (doc['decade'], doc['song'], doc['artist'], doc['weeksAtOne']))
#    
    ### Since this is an example, we'll clean up after ourselves.

    #db.drop_collection('songs')

    ### Only close the connection when your app is terminating

    client.close()


mongo()

#if __name__ == '__main__':
#    main(sys.argv[1:])