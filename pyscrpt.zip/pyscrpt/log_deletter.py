# -*- coding: utf-8 -*-
"""
Created on Thu Aug 17 17:57:23 2017

@author: manoj
"""

import shutil
import os
import re
import datetime
threshold_date=7

path='/home/manoj/scripts/tiger_analyatics/rhino/dev_rhino/production/logs'

d=datetime.datetime.today()

def logdeletter(logpath , date):
    try:
#        beyond_days=(date-datetime.timedelta(days=threshold_date)).strftime('%Y-%m-%d')
        for filepath in os.listdir(logpath): 
            datefilter=re.search('(\d+-\d+-\d+)\.log',filepath)
            filedate=datetime.datetime.strptime(datefilter.group(1), '%Y-%m-%d')
            if (date-filedate).days>threshold_date:
                os.remove("{0}/{1}".format(logpath, filepath))
    except Exception as e:
        print e


logdeletter(path, d)