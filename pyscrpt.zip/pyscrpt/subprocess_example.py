# -*- coding: utf-8 -*-
"""
Created on Thu Dec 29 20:49:37 2016

@author: manoj
"""

import subprocess
try:
    path=''
    fpath="mongoimport -d temp -c reviewagent  --type json '"+path+"' --jsonArray"

    result = subprocess.check_output("echo manoj", stderr=subprocess.STDOUT, shell=True)
    print result
    #causes error and merges stdout and stderr
except subprocess.CalledProcessError, ex: # error code <> 0 
    print "--------error------"
    print ex.cmd
    print ex.message
    print ex.returncode
    print ex.output