# -*- coding: utf-8 -*-
"""
Created on Thu Apr 28 17:05:09 2016

@author: manoj
"""

import pymssql
try:


    #conn = pymssql.connect('172.24.0.80', 'sa', 'igen', 'MovotoDashboards')  
    #conn = pymssql.connect('172.24.0.79', 'sa', 'igen', 'mlstat')  
    print "connecting"
    conn = pymssql.connect('192.168.120.139', 'sa', 'igen', 'sf_raw') 
    cursor = conn.cursor()
    cursor.execute("""select top 10 Hot_Lead_Id__c 
  from  sf_raw.dbo.LeadInfo__c  where Marketing_Campaign__c is null and Marketing_Medium__c is null 
  and   Marketing_source__c is null and Hot_Lead_Id__c is not null;""")
    #rows = cursor.fetchall()
    print "executed"
    for row in cursor:
        print row[0]
    
    conn.close()
except Exception as e:
    print "due to " ,e
    

