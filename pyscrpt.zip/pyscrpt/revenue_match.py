-- Function: sp_nt_match_deed_address_to_mls(date)

-- DROP FUNCTION sp_nt_match_deed_address_to_mls(date);

CREATE OR REPLACE FUNCTION sp_nt_match_revenue_address_to_mls(start_date date)
  RETURNS void AS
$BODY$
DECLARE
BEGIN 
   
  TRUNCATE TABLE matches.addresses_matched;

  DROP INDEX IF EXISTS matches.ix_addresses_matched_deed_id;
  DROP INDEX IF EXISTS matches.ix_addresses_matched_listing_id;

  INSERT INTO matches.addresses_matched
    (deed_id,
     listing_id,
     mls,
     mls_id,
     full_address_deed,
     full_address_mls,
     tax_id_deed,
     tax_id_mls,
     street_num_deed,
     street_num_mls,
     street_name_deed,
     street_name_mls,
     similarity,
     difference,
     city_deed,
     city_mls,
     state_deed,
     state_mls,
     zip_deed,
     zip_mls,
     unit_num_deed,
     unit_num_mls,
     sale_price_deed,
     sale_price_mls,
     deed_date,
     contract_date_deed,
     sale_date_mls)
   SELECT
     d.deed_id,
     l.listing_id,
     l.mls,
     l.mls_id,
     d.deed_long_form_address AS full_address_deed,
     l.full_address AS full_address_mls,
     d.assessors_parcel_number_apn_pin AS tax_id_deed,
     l.tax_id AS tax_id_mls,
     d.property_house_number AS street_num_deed,
     l.street_num AS street_num_mls,
     d.property_street_name AS street_name_deed,
     l.street_name AS street_name_mls,
     public.similarity(d.deed_long_form_address, l.full_address),
     public.difference(d.deed_long_form_address, l.full_address),
     d.property_city_name AS city_deed,
     l.city AS city_mls,
     d.property_state AS state_deed,
     l.state_code AS state_mls,
     d.property_zip_code AS zip_deed,
     l.zip AS zip_mls,
     d.property_unit_number AS unit_num_deed,
     l.unit_number as unit_num_mls,
     d.sales_price AS sale_price_deed,
     l.sale_price AS sale_price_mls,
     d.recording_date as deed_date,  
     d.original_date_of_contract_date AS contract_date_deed,  
     l.date_sale AS sale_date_mls
FROM deeds.all_deeds d, 
     mls_all.listings l  
WHERE 
    -- Geo match
    ((d.assessors_parcel_number_apn_pin = l.tax_id AND COALESCE(l.tax_id, '') <> '' AND d.property_state = l.state_code) 
	 OR (d.property_state = l.state_code 
	     AND d.property_house_number = l.street_num  
		 AND (d.property_zip_code = l.zip
		      OR public.difference(d.property_city_name, l.city) = 4
             )
		 AND (public.similarity(d.deed_long_form_address, l.full_address) >= .5  
			  OR (public.difference(d.deed_long_form_address, l.full_address) = 4 
			      AND LEFT(l.full_address, 1) NOT IN ('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')
                 )
             ) 
	    ) 
    )
    -- Date Match
    AND d.recording_date_date >= l.date_sale
    AND d.recording_date_date >= start_date;
     
  CREATE INDEX ix_addresses_matched_deed_id
  ON matches.addresses_matched
  USING btree (deed_id);

  CREATE INDEX ix_addresses_matched_listing_id
  ON matches.addresses_matched
  USING btree (listing_id);

END;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION sp_nt_match_deed_address_to_mls(date)
  OWNER TO census;
