# -*- coding: utf-8 -*-
"""
Created on Wed Jan 11 00:22:50 2017

@author: manoj
"""



#import random
#
#@retry(Exception, tries=4)
#def test_random(text):
#    x = random.random()
#    if x < 0.5:
#        raise Exception("Fail")
#    else:
#        print "Success: ", text
#
#test_random("it works!")



def get_web_text(name):
    return "hello it is webpage tag {0}".format(name)


def p_decorate(func):
   def func_wrapper(name):
       return "<p>{0}</p>".format(func(name))
   return func_wrapper


#def dec_webpage():
#    get_web_text
my_get_text = p_decorate(get_web_text)

print my_get_text("ankita")