# -*- coding: utf-8 -*-
"""
Created on Sat Jul 22 10:19:46 2017

@author: manoj
"""
from itertools import izip, izip_longest
 
cnt=0

def recurlis(count ,lis):
    print lis
    count+=1
    print "count" ,count
    if (len(lis[count:])>1):
        return recurlis(count ,lis[count:])
        


def permute(count ,lis):
    print lis
    count+=1
    print "count" ,count
    if (len(lis[count:])>1):
        return recurlis(count ,lis[count:])     



def permute_new(lis):
    newlis=[] 
    for  i in range(len(lis)):
        newlis=lis[:]
        count=i
        while count >0:
            newlis[count],newlis[count-1]=newlis[count-1],newlis[count]
            count-=1
        print "".join(map(str,newlis[:]))
        for j in range(1,len(lis)-1):
            if newlis[j]<newlis[j+1]:
                 newlis[j],newlis[j+1]=newlis[j+1],newlis[j]
                 print "".join(map(str,newlis[:])) 
       
                
                
def permute2(lis):
    if len(lis)<=2:
        if len(lis)==1:
            return [lis[:]]
        elif len(lis)==2:
            return [[lis[0],lis[1]] ,[lis[1],lis[0]] ]
        else: [lis]
    else:
        for  i in range(len(lis)-1):
            #print lis[:i+1],lis[i+1:]
            aa=permute2(lis[:i+1])
            print i,aa
#            bb=permute2(lis[i+1:])
#            print bb
#            for m in aa:
#                for n in bb:
#                    aaa=m[:]
#                    aaa.exte.....nd(n[:])
#                    print aaa


lis=[1,2,3]
lis=[1,2]


#print permute2(lis)   
#lis=['a','b','c']
#permute(0,lis)
#permute_new(lis)

#recurlis(cnt,lis)
   
   
   
def permutation(lis):
    if len(lis)==0:
        return []
    if len(lis)==1:
        return [lis]
    
    ll=[]
    for i in range(len(lis)):
        m=lis[i]
        remlist= lis[:i]+lis[i+1:]
        print lis[:i],lis[i+1:], remlist,i
        #ll.append([lis[i]]+remlist)
        #print "final ll", ll
        print "calling permutation again",remlist
        for ele in permutation(remlist):
            print "printing ele" ,ele
            ll.append([m]+ele)
            print "ll" ,ll
            break
        break
    return ll
#        for j in remlist:
#            print [j]


print permutation(lis)

        