# -*- coding: utf-8 -*-
"""
Created on Wed Jun 13 11:21:00 2018

@author: manoj
"""

import json
import collections
from  elasticsearch  import Elasticsearch
import requests



"""
{
  "parser_es6": {
    "mappings": {
      "whoami": {
        "properties": {
          "index_time": {
            "type": "long"
          },
          "keyword": {
            "type": "keyword"
          },
          "meaning": {
            "type": "keyword"
          },
          "meanings": {
            "properties": {
              "meaning": {
                "properties": {
                  "geo_id": {
                    "type": "text"
                  },
                  "geo_name": {
                    "type": "text"
                  },
                  "geo_type": {
                    "type": "text"
                  }
                }
              },
              "state": {
                "type": "text"
              }
            }
          }
        }
      }
    }
  }
}
"""

movoto_parser_data={
        "_index": "parser_es6",
        "_type": "whoami",
        "_id": "terramere tempe",
        "_score": 1,
        "_source": {
          "index_time": 1470637361,
          "meanings": [
            {
              "state": "az",
              "meaning": [
                {
                  "geo_type": "neighborhood",
                  "geo_id": "92672",
                  "geo_name": "terramere"
                },
                {
                  "geo_type": "city",
                  "geo_id": "65251",
                  "geo_name": "tempe"
                }
              ]
            }
            ,
             {
              "state": "ca",
              "meaning": [
                {
                  "geo_type": "zipcode",
                  "geo_id": "56672",
                  "geo_name": "bar"
                },
                {
                  "geo_type": "city",
                  "geo_id": "89251",
                  "geo_name": "kundala"
                }
              ]
            }
          ],
          "keyword": "terramere tempe"
        }
}



movoto_parser_data1= {
        "_index": "parser_es6",
        "_type": "whoami",
        "_id": "flagtown 08821",
        "_score": 1,
        "_source": {
          "index_time": 1470637361,
          "meanings": [
            {
              "state": "de",
              "meaning": [
                {
                  "geo_type": "city",
                  "geo_id": "13618",
                  "geo_name": "woodside"
                }
                , {
                  "geo_type": "city_1",
                  "geo_id": "1856",
                  "geo_name": "woodside_1"
                }
              ]
            },
            {
              "state": "ny",
              "meaning": [
                {
                  "geo_type": "city",
                  "geo_id": "6209",
                  "geo_name": "woodside"
                }
              ]
            },
            {
              "state": "ca",
              "meaning": [
                {
                  "geo_type": "city",
                  "geo_id": "176411",
                  "geo_name": "woodside"
                }
              ]
            },
            {
              "state": "md",
              "meaning": [
                {
                  "geo_type": "neighborhood",
                  "geo_id": "75584",
                  "geo_name": "woodside"
                }
              ]
            },
            {
              "state": "fl",
              "meaning": [
                {
                  "geo_type": "neighborhood",
                  "geo_id": "88704",
                  "geo_name": "woodside"
                }
              ]
            },
            {
              "state": "fl",
              "meaning": [
                {
                  "geo_type": "neighborhood",
                  "geo_id": "141249",
                  "geo_name": "woodside"
                }
              ]
            },
            {
              "state": "oh",
              "meaning": [
                {
                  "geo_type": "neighborhood",
                  "geo_id": "116597",
                  "geo_name": "woodside"
                }
              ]
            },
            {
              "state": "wi",
              "meaning": [
                {
                  "geo_type": "neighborhood",
                  "geo_id": "144532",
                  "geo_name": "woodside"
                }
              ]
            },
            {
              "state": "mo",
              "meaning": [
                {
                  "geo_type": "neighborhood",
                  "geo_id": "117759",
                  "geo_name": "woodside"
                }
              ]
            },
            {
              "state": "ks",
              "meaning": [
                {
                  "geo_type": "neighborhood",
                  "geo_id": "130236",
                  "geo_name": "woodside"
                }
              ]
            },
            {
              "state": "tx",
              "meaning": [
                {
                  "geo_type": "neighborhood",
                  "geo_id": "124867",
                  "geo_name": "woodside"
                }
              ]
            },
            {
              "state": "co",
              "meaning": [
                {
                  "geo_type": "neighborhood",
                  "geo_id": "109275",
                  "geo_name": "woodside"
                }
              ]
            },
            {
              "state": "nv",
              "meaning": [
                {
                  "geo_type": "neighborhood",
                  "geo_id": "108093",
                  "geo_name": "woodside"
                }
              ]
            },
            {
              "state": "ca",
              "meaning": [
                {
                  "geo_type": "neighborhood",
                  "geo_id": "86441",
                  "geo_name": "woodside"
                }
              ]
            },
            {
              "state": "ca",
              "meaning": [
                {
                  "geo_type": "neighborhood",
                  "geo_id": "133500",
                  "geo_name": "woodside"
                }
              ]
            },
            {
              "state": "ca",
              "meaning": [
                {
                  "geo_type": "neighborhood",
                  "geo_id": "162281",
                  "geo_name": "woodside"
                }
              ]
            },
            {
              "state": "wa",
              "meaning": [
                {
                  "geo_type": "neighborhood",
                  "geo_id": "134779",
                  "geo_name": "woodside"
                }
              ]
            }
          ],
          "keyword": "flagtown 08821"
        }
      }



movoto_parser_data=[{u'hits': {u'hits': [{u'sort': [0], u'_type': u'whoami', u'_source': {u'index_time': 1470637361, u'meanings': [{u'state': u'nj', u'meaning': [{u'geo_type': u'city', u'geo_name': u'flagtown', u'geo_id': u'5482'}, {u'geo_type': u'zipcode', u'geo_name': u'08821', u'geo_id': u'08821'}]}], u'keyword': u'flagtown 08821'}, u'_score': None, u'_index': u'parser_es6', u'_id': u'flagtown 08821'}, {u'sort': [0], u'_type': u'whoami', u'_source': {u'index_time': 1470637361, u'meanings': [{u'state': u'pa', u'meaning': [{u'geo_type': u'city', u'geo_name': u'north springfield', u'geo_id': u'10876'}, {u'geo_type': u'zipcode', u'geo_name': u'16430', u'geo_id': u'16430'}]}], u'keyword': u'north springfield 16430'}, u'_score': None, u'_index': u'parser_es6', u'_id': u'north springfield 16430'}, {u'sort': [0], u'_type': u'whoami', u'_source': {u'index_time': 1470637361, u'meanings': [{u'state': u'tx', u'meaning': [{u'geo_type': u'neighborhood', u'geo_name': u'bellaire heights', u'geo_id': u'124935'}, {u'geo_type': u'city', u'geo_name': u'houston', u'geo_id': u'59807'}]}], u'keyword': u'bellaire heights houston'}, u'_score': None, u'_index': u'parser_es6', u'_id': u'bellaire heights houston'}, {u'sort': [0], u'_type': u'whoami', u'_source': {u'index_time': 1470637361, u'meanings': [{u'state': u'ok', u'meaning': [{u'geo_type': u'neighborhood', u'geo_name': u'lazy circle acres', u'geo_id': u'101327'}, {u'geo_type': u'city', u'geo_name': u'tulsa', u'geo_id': u'57445'}]}], u'keyword': u'lazy circle acres tulsa'}, u'_score': None, u'_index': u'parser_es6', u'_id': u'lazy circle acres tulsa'}, {u'sort': [0], u'_type': u'whoami', u'_source': {u'index_time': 1470637361, u'meanings': [{u'state': u'co', u'meaning': [{u'geo_type': u'city', u'geo_name': u'aurora', u'geo_id': u'62298'}, {u'geo_type': u'neighborhood', u'geo_name': u'highpoint', u'geo_id': u'121004'}]}], u'keyword': u'aurora highpoint'}, u'_score': None, u'_index': u'parser_es6', u'_id': u'aurora highpoint'}, {u'sort': [1], u'_type': u'whoami', u'_source': {u'index_time': 1470637361, u'meanings': [{u'state': u'oh', u'meaning': [{u'geo_type': u'neighborhood', u'geo_name': u'the delscamp loft condominiums', u'geo_id': u'163736'}]}], u'keyword': u'the delscamp loft condominiums'}, u'_score': None, u'_index': u'parser_es6', u'_id': u'the delscamp loft condominiums'}, {u'sort': [1], u'_type': u'whoami', u'_source': {u'index_time': 1470637361, u'meanings': [{u'state': u'wa', u'meaning': [{u'geo_type': u'zipcode', u'geo_name': u'98837', u'geo_id': u'98837'}]}], u'keyword': u'98837'}, u'_score': None, u'_index': u'parser_es6', u'_id': u'98837'}, {u'sort': [1], u'_type': u'whoami', u'_source': {u'index_time': 1470637361, u'meanings': [{u'state': u'az', u'meaning': [{u'geo_type': u'city', u'geo_name': u'flagstaff', u'geo_id': u'65654'}, {u'geo_type': u'neighborhood', u'geo_name': u'ridge crest coyote springs', u'geo_id': u'83280'}]}], u'keyword': u'flagstaff ridge crest coyote springs'}, u'_score': None, u'_index': u'parser_es6', u'_id': u'flagstaff ridge crest coyote springs'}, {u'sort': [1], u'_type': u'whoami', u'_source': {u'index_time': 1470637361, u'meanings': [{u'state': u'in', u'meaning': [{u'geo_type': u'neighborhood', u'geo_name': u'deerfield', u'geo_id': u'129364'}, {u'geo_type': u'city', u'geo_name': u'carmel', u'geo_id': u'33930'}]}], u'keyword': u'deerfield carmel'}, u'_score': None, u'_index': u'parser_es6', u'_id': u'deerfield carmel'}], u'total': 445974, u'max_score': None}, u'_shards': {u'successful': 5, u'failed': 0, u'skipped': 0, u'total': 5}, u'took': 2, u'_scroll_id': u'DnF1ZXJ5VGhlbkZldGNoBQAAAAAADaRKFjFRWmZJVk5nUjdLVi1XSzQwYlE3a3cAAAAAAA2kSxYxUVpmSVZOZ1I3S1YtV0s0MGJRN2t3AAAAAAAIxqMWeWY1LXhEMHNSSnlua0tRbzRNcVJvQQAAAAAACMakFnlmNS14RDBzUkp5bmtLUW80TXFSb0EAAAAAAAjDlBYyQzFVTWRSQ1JYS2g3cVUzMzhRVDNR', u'timed_out': False}]


#data=movoto_parser_data["_source"]
result=""
final_row=[]
parent_row=[]
derived_row=[]
data=movoto_parser_data
#print data


def build_query():
    query = {    "query": {
    "bool": {
      "must": [
        {
          "query_string": {
            "query": "keyword:flagtown 08821",
            "analyze_wildcard": True  }}
      ],
      "must_not": []
    }
  }
  }
    return query
 
 
def getESUpstreamJobStatus(es_host,es_port,job_status_index):
    es = Elasticsearch([{'host': es_host, 'port': es_port}])
    query_body=build_query()
    response = es.search(index=job_status_index, body=query_body)
    print "response",response
    if len(response['hits']['hits'])==0:
        return False
    else:
        return response 
            
#getESUpstreamJobStatus('10.255.1.252', 9200, "parser_es6")


#url = "http://2.ingest.soa.es6.ng.movoto.net:9200/parser_es6/_search"
#
#payload = "{ \"query\": { \"bool\": {\n      \"must\": [\n        {\n          \"query_string\": {\n            \"query\": \"*\",\n            \"analyze_wildcard\": true\n          }\n        }\n      ],\n      \"must_not\": []\n    }\n},\n\"from\":9000,\n\"size\":5000\n}\n"
#
##payload = ""
#headers = {
#    'content-type': "application/json",
#    'cache-control': "no-cache"
#    }

#response = requests.request("POST", url, data=payload, headers=headers)
#
#
#dd=json.loads(response.text)

#print len(dd['hits']['hits'])
#for row in dd['hits']['hits']:
#    print row["_source"] 


def source_whoami_parser():
    whoamilis=[]
    url = "http://2.ingest.soa.es6.ng.movoto.net:9200/parser_es6/_search"
    querystring = {"scroll":"5m"}
    headers = {
        'content-type': "application/json",
        'cache-control': "no-cache"}
    payload = "{\n    \"query\": { \"match_all\": {}},\n    \"sort\" : [\"_doc\"], \n    \"size\":  9\n}\n"
    
    print "putting request"
    response = requests.request("POST", url, data=payload, headers=headers, params=querystring)
    dd=json.loads(response.text)
    whoamilis.append(dd)
    counter=0
    counter+=len(dd['hits']['hits'])
    print dd['_scroll_id']
    #print whoamilis
    print "first  request finished"
    url = "http://2.ingest.soa.es6.ng.movoto.net:9200/_search/scroll"
    payload = "{\n    \"scroll\" : \"5m\", \n    \"scroll_id\" : \"%s\"\n \n}"%dd['_scroll_id']
    print "next data",
    while True:
        response = requests.request("POST", url, data=payload, headers=headers)
        res=json.loads(response.text)
        whoamilis.append(res)
        counter+=len(res['hits']['hits'])
        print "next" ,counter
        if len(res['hits']['hits'])==0:
            break
        #if counter>445974:
        if counter>10:
            print "last  iter" ,len(res['hits']['hits'])
            break
        
    return whoamilis
    
    

def meaning_dict(meaningslis):
    
    finalgeolis=[]
    for geob in meaningslis:
        #tempobj=collections.OrderedDict()
        tempobj={}
        stateobj={}
        geolis=[]
        for key,value in geob.iteritems():
            if type(value)==list:      
                for val in value:
                    for subkey,subvalue in val.iteritems():
                        tempobj[subkey]=subvalue
                    geolis.append(tempobj)
                    tempobj={}
            else:
                stateobj[key]=value
                #print stateobj
        for row in geolis:
            row.update(stateobj)  
        stateobj={}
        finalgeolis.extend(geolis)
        #break
    return finalgeolis
            
        
    
def parser_reader(data , parent=""):
    
    for key ,value in data.iteritems():
        if type(value)==dict:
            parser_reader(data.get(key),key+"."+parent)
            
        elif type(value)==list:
            for index in range(len(value)):
                parser_reader(value[index] ,parent+key+"."+str(index)+".")
        else:
            if parent=="":
                print "key=",key , " value=",value
                parent_row.append((key ,value))
            else:
                #print "key=",parent+key , " value=",value
                derived_row.append((parent+key,value))
    final_row.extend(derived_row)
#        for subrow in derived_row:
#            final_row.extend((parent_row ,[subrow]))
    return final_row

#def parser_reader(data):
#    for key ,value in data.iteritems():

#print meaning_dict(data['meanings'])

flattenlis=[]
for row in source_whoami_parser(): 
    for r in row['hits']['hits']:
        for t in meaning_dict(r['_source']['meanings']):
            t['keyword']=r['_source']['keyword']
            flattenlis.append(t)
    
print flattenlis        

#   if (key=='meanings'):
#       for  subdata in  value:
#           print type(subdata)
#           for subkey ,subvalue in subdata.iteritems():
#               if subkey=='meaning':
#                   for subsubobj in subvalue:
#                       print  subsubobj
# with open('%s/config/%s.json' % (tasks_path, profile_name), 'r') as f:
        
#data = json.load(movoto_parser_data)
#print data