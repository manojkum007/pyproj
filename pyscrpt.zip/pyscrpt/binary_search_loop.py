# -*- coding: utf-8 -*-
"""
Created on Sat Jan  6 00:50:58 2018

@author: manoj
"""


def binary_search(ll ,ele):
    first=0
    last=len(ll)
    location=-1
    while first+1<last:
        mid=(first+last)/2
        print "first" ,first ,"last",last, "mid" ,mid ,"mid element" ,ll[mid]
        #leftlis=ll[:mid]
        #rightlis=ll[mid:]
        if ll[mid]==ele:
            location=mid
            first=mid
            last=mid
        if ll[mid]<ele:
            first=mid
        else :
            last=mid
    
    print " at end first" ,first ,"last",last, "mid" ,mid ,"mid element" ,ll[mid]
    if ll[first]==ele:
        location=first
    if (location>-1):
        print" location of element is",location+1
    else:
        print" notfound"
    

def binary_search_ds(ll ,ele):
    first=0
    last=len(ll)
    loc=-1
    while first <last:
        mid=(first+last)/2
        if ele>ll[mid]:
            first=mid+1
        else:
            last=mid
        print " at end first" ,first ,"last",last, "mid" ,mid ,"mid element" ,ll[mid]
        
        if ele==ll[first]:
            loc=first
            break
            

        
    if (loc>-1):
        print" location of element is",loc+1
    else:
        print" notfound"


lis=[4,6,9,12,45,56,88,99,125,225,258]
lis = [1, 3, 20, 4, 1, 0]
searchelement=88

#print lis,  searchelement
#binary_search_ds(lis, searchelement)           
        
#binary_search(lis, searchelement)            
    
    
    

def binary_search_rec( lis ,ele ,first ,last):
    mid=(first+last)/2
    print "mid " ,mid
    if mid<=0  or lis[mid]==ele:
        return first,mid,last
    else:
        if (lis[mid]>ele):
            return binary_search_rec(lis ,ele, first , mid)
        else:
            return binary_search_rec(lis, ele ,mid ,last)
        
first=0
last=len(lis)      
#print "final index" ,binary_search_rec(lis, searchelement , first, last)  
    
    


def findingpeak(lis):
    first=0
    last=len(lis)
    mid=(first+last)/2
    print "mid,last,lis " ,mid,last,lis
    if mid ==0 or mid>=last-1:
        return lis[mid]
    if   lis[mid]>=lis[mid-1] and lis[mid]>=lis[mid+1]:
        return "peak is ",lis[mid]
    else:
        if mid>0 and  (lis[mid]<lis[mid-1]) :
            return findingpeak(lis[:mid])
        else:
            return findingpeak(lis[mid:])
    
print "finding peak" ,findingpeak(lis)





