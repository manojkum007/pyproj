# -*- coding: utf-8 -*-
"""
Created on Mon Jan  8 23:56:56 2018

@author: manoj
"""

pstr="abcbad"

mid=len(pstr)/2
flag=1
for i in range(mid):
    left=mid-i
    right=mid+i
    if pstr[left]!= pstr[right]:
        flag=0



if flag==0:
    print "string is not palindrome"
else:
    print "string is palindrome"

