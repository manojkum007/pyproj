# -*- coding: utf-8 -*-
"""
Created on Thu May 12 23:45:39 2016

@author: manoj
"""
import json
import httplib2
import uuid
from apiclient import errors
from apiclient.discovery import build
from elasticsearch import Elasticsearch
from oauth2client.service_account import ServiceAccountCredentials


def get_service(scopes, service_name, service_version):
    # Load the key in PKCS 12 format that you downloaded from the Google API
    # Console when you created your Service account.
    f = file('/home/manoj/analytics/Jobs/src/ga_jobs/AnalyticsApi-e6d952cb8cd2.p12', 'rb')

    client_email = '862960943904-ksklo0esmabtrgs79mfkicrerehkhlva@developer.gserviceaccount.com'
    credentials = ServiceAccountCredentials.from_p12_keyfile_buffer(client_email, f, scopes=scopes)
    http_auth = credentials.authorize(httplib2.Http())
    return build(service_name, service_version, http=http_auth)


scopes = ['https://www.googleapis.com/auth/webmasters.readonly']
service_name = 'webmasters'
service_version = 'v3'
es_index="sitemapdata"
doc_type_value="movtomap"


    
movoto_data={
    "sitemap": [
        {
            "contents": [
                {
                    "indexed": "8378",
                    "submitted": "10854",
                    "type": "web"
                }
            ],
            "errors": "0",
            "isPending": 0,
            "isSitemapsIndex": 1,
            "lastDownloaded": "2016-05-12T11:56:25.841Z",
            "lastSubmitted": "2016-05-06T07:08:12.853Z",
            "path": "http://www.movoto.com/agents/sitemap.xml",
            "warnings": "0"
        },
        {
            "contents": [
                {
                    "indexed": "1602",
                    "submitted": "2856",
                    "type": "web"
                },
                {
                    "indexed": "1109",
                    "submitted": "3711",
                    "type": "image"
                }
            ],
            "errors": "0",
            "isPending": 0,
            "isSitemapsIndex": 1,
            "lastDownloaded": "2016-05-10T18:37:01.214Z",
            "lastSubmitted": "2015-08-18T21:51:59.713Z",
            "path": "http://www.movoto.com/blog/sitemap_index.xml",
            "warnings": "0"
        },
        {
            "contents": [
                {
                    "indexed": "53228",
                    "submitted": "83335",
                    "type": "web"
                },
                {
                    "indexed": "20637",
                    "submitted": "83335",
                    "type": "androidApp"
                }
            ],
            "errors": "0",
            "isPending": 0,
            "isSitemapsIndex": 1,
            "lastDownloaded": "2016-05-11T19:19:02.268Z",
            "lastSubmitted": "2016-05-09T17:02:48.546Z",
            "path": "http://www.movoto.com/detail-activehouses/new-sitemap.xml",
            "warnings": "0"
        },
        {
            "contents": [
                {
                    "indexed": "1057288",
                    "submitted": "1242363",
                    "type": "web"
                },
                {
                    "indexed": "628700",
                    "submitted": "1242363",
                    "type": "androidApp"
                }
            ],
            "errors": "0",
            "isPending": 0,
            "isSitemapsIndex": 1,
            "lastDownloaded": "2016-05-12T11:13:00.467Z",
            "lastSubmitted": "2016-05-06T07:08:12.853Z",
            "path": "http://www.movoto.com/detail-activehouses/sitemap.xml",
            "warnings": "0"
        },
        {
            "contents": [
                {
                    "indexed": "9",
                    "submitted": "22",
                    "type": "web"
                },
                {
                    "indexed": "1",
                    "submitted": "1",
                    "type": "androidApp"
                }
            ],
            "errors": "0",
            "isPending": 0,
            "isSitemapsIndex": 0,
            "lastDownloaded": "2016-05-06T07:08:21.974Z",
            "lastSubmitted": "2016-05-06T07:08:21.697Z",
            "path": "http://www.movoto.com/static.xml.gz",
            "type": "sitemap",
            "warnings": "0"
        }
    ]
}    


#print movoto_data

def save_results(all_results):  
    has_data = False
    data=all_results.get('sitemap')
    res=[]
    if (data):
        d = dict()
        for row in data:   
            d["lastDownloaded"]=row.get("lastDownloaded")
            d["warnings"]=row.get("warnings")  
            d["isSitemapsIndex"]=int(row.get("isSitemapsIndex"))
            d["lastSubmitted"]=row.get("lastSubmitted")
            d["isPending"]=int(row.get("isPending"))
            d["type"]=row.get("type")
            d["path"]=row.get("path")
            d["error"]=row.get("error")
            contentrow=row.get("contents")
            if (contentrow):
                d["contents"]=[]
                for crow in contentrow:
                    crowdict=dict()
                    crowdict["indexed"]=crow.get("indexed")
                    crowdict["type"]=crow.get("type")
                    d["contents"].append(crowdict)
            res.append(d)
            
    #return res
    es = Elasticsearch([{'host': 'localhost'}])
    #es_data= save_results(movoto_data)  

    for x in  res: 
        row_id=uuid.uuid1()
        #print "in es_data",x
        es.index(index=es_index, doc_type=doc_type_value, id=row_id, body=json.dumps(x)) 
               
#                res = []              
#                has_data = True 
#                d = dict()  
#                d['lastDownloaded'] =rows[0]
#                d['device'] = rows[1]
#                d['page'] = rows[2]            
#                d['@timestamp']= datetime.datetime.strptime(processing_day, '%Y-%m-%d').strftime('%Y-%m-%dT%H:%M:%S')                                                          
#                res.append(d) 
#                #es_log.info("rows_results %s and coulmn %s"%(rows ,d))
#                for x in  res: 
#                    keys_string = ''.join([x['country'],x['device'],x['page']])
#                    keys_string=keys_string.encode("ascii")
#                    row_id = uuid.uuid3(uuid.NAMESPACE_DNS, keys_string)      
#                    #es_log.info("Put data into index = %s doc_type = %s id  =%s  and dumps are %s"% (es_index, doc_type_value, keys_string,x)) 
#                    es.index(index=es_index, doc_type=doc_type_value, id=row_id, body=json.dumps(x)) 
#        except Exception:
#            if not has_data:
#                print "error"
                
 

svc=get_service(scopes, service_name,service_version)



siteindex="http://www.movoto.com/detail-activehouses/new-sitemap.xml"
site_url="http://www.movoto.com/"
#site=svc.sitemaps().list(siteUrl=site_url, sitemapIndex=siteindex, fields='sitemap')


sitemap=svc.sitemaps().list(siteUrl=site_url).execute()
res=[]


#f=open('sitemap_result1.txt','w+')
#
for i in range(len(sitemap["sitemap"])):
    if (sitemap["sitemap"][i]["isSitemapsIndex"]):
        sitmapxml=sitemap["sitemap"][i]["path"]
        site=svc.sitemaps().list(siteUrl=site_url, sitemapIndex=sitmapxml).execute()
        try:        
            save_results(site)
            print "completed data  for",sitmapxml
        except Exception as e:
            print "exception is ",e
        #break
        
        #print "for sitemapindex",sitmapxml, site["sitemap"][0]["contents"] ,"\n\n\\n"
#        res.append(site)
#        f.write(str(json.dumps(site, sort_keys=1,indent=4, separators=(',', ': '))))
#        f.write("\n\n\n")
#
#f.close()
    
#siteindex="http://www.movoto.com/list-city-beds/sitemap.xml"
#site=svc.sitemaps().list(siteUrl=site_url, sitemapIndex=siteindex).execute()

#print site
#weblist=site.list(siteUrl=site_url, sitemapIndex=siteindex, fields='sitemap')
#print weblist.to_json()
#print site
#print site.to_json()
   

         
