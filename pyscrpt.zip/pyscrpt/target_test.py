# -*- coding: utf-8 -*-
"""
Created on Tue May  2 18:04:21 2017

@author: manoj
"""

import luigi

class MyTarget(luigi.Target):

    def exists(self):
        """
        Does this Target exist?
        """
        return True