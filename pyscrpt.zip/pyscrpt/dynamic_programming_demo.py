# -*- coding: utf-8 -*-
"""
Created on Sun Mar 11 08:35:38 2018

@author: manoj
"""
import sys

p={1:4,2:5, 3:7,4:8}

def cut_rod(p,n ,max_val):
    if n==0:
        return 0
    for i in range(0,n):
        print i+1,n-i-1,max_val
        #break
        max_val=max(max_val,p[i+1]+cut_rod(p,n-i-1, max_val))
        
    return max_val
            


def cutRod(price, n):
    if(n <= 0):
        return 0
    max_val = -sys.maxsize-1
     
    # Recursively cut the rod in different pieces  
    # and compare different configurations
    for i in range(0, n):
        print i,n-i,max_val
        max_val = max(max_val, price[i] +
                      cutRod(price, n - i - 1))
    return max_val


def cutRod(price, n):
    val = [0 for x in range(n+1)]
    val[0] = 0
 
    # Build the table val[] in bottom up manner and return
    # the last entry from the table
    for i in range(1, n+1):
        max_val = -32767
        for j in range(i):
             max_val = max(max_val, price[j] + val[i-j-1])
        val[i] = max_val
 
    return val[n]


    
    
max_val=-sys.maxsize

print cut_rod(p,3 ,max_val)
#arr = [1, 5, 8, 9, 10, 17, 17, 20]
#print cutRod(arr, len(arr))