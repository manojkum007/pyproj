# -*- coding: utf-8 -*-
"""
Created on Wed Feb  8 18:44:59 2017

@author: manoj
"""
import luigi
import datetime
import json
import os



class DownloadsfUpdates(luigi.Task):
    run_date = luigi.DateParameter(default=datetime.date.today() - datetime.timedelta(days=1))
    mongoload_dict=luigi.Parameter()
    
    def requires(self):
        pass
    def run(self):
        userid=self.mongoload_dict.get('userId').get('id')
        path='/home/manoj/scripts/tiger_analyatics/rhino/dev_rhino/production/agentsMigration_og_test/%s_%s.json'%(userid, self.run_date.strftime('%Y-%m-%d'))
        jsonob=open(path,'w')
        json.dump(self.mongoload_dict,jsonob, indent=4)
        jsonob.close() 
        with self.output().open('w') as f:
            f.write('{word}\n'.format(word='DownloadSessions'))
        
        
    def output(self):
       # path = os.path.join('/home/manoj/scripts/python_scripts','DownloadsfUpdates_%s'%self.run_date.strftime('%Y-%m-%d'))
        return luigi.file.LocalTarget(path='/home/manoj/scripts/python_scripts/ttt.txt')
        