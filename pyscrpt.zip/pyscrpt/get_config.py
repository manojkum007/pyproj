import csv
import logging
import re
import string

#third-party libraries
import usaddress
import psycopg2
import luigi
from luigi import postgres
from luigi import six

#internal libraries
#import settings
import address_parser
import address_parse
import names_parser

logger = logging.getLogger('luigi-interface')


# these are the escape sequences recognized by postgres COPY
# according to http://www.postgresql.org/docs/8.1/static/sql-copy.html
default_escape = postgres.MultiReplacer([('\\', '\\\\'),
                                ('\t', '\\t'),
                                ('\n', '\\n'),
                                ('\r', '\\r'),
                                ('\v', '\\v'),
                                ('\b', '\\b'),
                                ('\f', '\\f')
                                ])

#do we need to create a marker target for mls jobs?
def get_config(section, name):
    luigi_config = luigi.configuration.get_config()
    return luigi_config.get(section, name)


class CopyToMlsTable(postgres.CopyToTable):
    """
    Our implementation of Luigi's CopyToTable task.
    This task sets the DB connection parameters, and acts as the parent
    for other MLS-related copy to DB jobs.
    
    It is still up to each child task to define the table names
    and columns, however.
    """
    host = get_config('mls', 'db-host')
    database = get_config('mls', 'db-name')
    user = get_config('mls', 'db-user')
    password = get_config('mls', 'db-password')
