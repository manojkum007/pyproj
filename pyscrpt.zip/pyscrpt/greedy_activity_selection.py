# -*- coding: utf-8 -*-
"""
Created on Sat Aug 18 21:21:02 2018

@author: manoj
"""

lis=[(1,4),(3,5),(0,6),(5,7),(3,9),(5,9),(9,10),(8,11),(8,12),(2,14),(12,16)]


def selection(lis) :
    startlis=[lis[0]]
    for r in lis:
        last=startlis[:].pop()[1]
        if r[0]>=last:
            startlis.append(r)
    
    return startlis


def selection_dynamic(lis) :
    for s in range(len(lis)):
        startlis=[lis[s]]
        for r in range(s, len(lis)):
            last=startlis[:].pop()[1]
            if lis[r][0]>=last:
                startlis.append(lis[r])
        print startlis
    
print selection_dynamic(lis)
            
        
    