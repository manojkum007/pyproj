# -*- coding: utf-8 -*-
"""
Created on Thu Mar 22 21:42:44 2018

@author: manoj
"""

import json



with open('/home/manoj/scripts/python_scripts/Pyspark_module/convex_nova_id.json') as json_data:
    d = json.load(json_data)
    
    
f=open('test.txt' ,'w')
for k ,v in  d.iteritems():
    f.write(k+str(v)

f.close()