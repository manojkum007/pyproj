# -*- coding: utf-8 -*-
"""
Created on Thu Jan  5 22:37:17 2017

@author: manoj
"""
#class Celsius:
#    def __init__(self, temperature = 0):
#        self.temperature = temperature
#
#    def to_fahrenheit(self):
#        return (self.temperature * 1.8) + 32



#class Celsius:
#    def __init__(self, temperature = 0):
#        self.set_temperature(temperature)
#
#    def to_fahrenheit(self):
# 
# 
#    def get_temperature(self):
#        return self._temperatureclass 
        
        
class Celsius:
    def __init__(self, temperature = 0):
        self.set_temperature(temperature)

    def to_fahrenheit(self):
        return (self._temperature * 1.8) + 32
    
    def get_temperature(self):
        return self._temperature

    def set_temperature(self, value):
        if value < -273:
            raise ValueError("Temperature below -273 is not possible")
        self._temperature = value
        
        
#class Celsius:
#    def __init__(self, temperature = 0):
#        self._temperature = temperature
#
#    def to_fahrenheit(self):
#        return (self.temperature * 1.8) + 32
#
#    @property
#    def temperature(self):
#        print("Getting value")
#        return self._temperature
#
#    @temperature.setter
#    def temperature(self, value):
#        if value < -273:
#            raise ValueError("Temperature below -273 is not possible")
#        print("Setting value")
#        self._temperature = value
#        
        
c=Celsius(100)
#c.temperature=-292
#c._temperature=45
print c.get_temperature()
#c.temperature(100)
print c.to_fahrenheit()      