# -*- coding: utf-8 -*-
"""
Created on Fri Aug 11 15:58:55 2017

@author: manoj
"""

>>> import pyhs2
>>> conn = pyhs2.connect(host='192.168.120.140', port=10000, authMechanism=auth, user='huser', password='', database='bq_nova')
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'auth' is not defined
>>> conn = pyhs2.connect(host='192.168.120.140', port=10000, authMechanism='PLAIN', user='huser', password='', database='bq_nova')              
>>> cur = conn.cursor()
>>> qry="select min(`date`) from agentbehaviour.nova_agent_dpp_historical;"
>>> cur.execute(qry)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
  File "/usr/local/lib/python2.7/dist-packages/pyhs2/cursor.py", line 64, in execute
    raise Pyhs2Exception(res.status.errorCode, res.status.errorMessage)
pyhs2.error.Pyhs2Exception: "Error while compiling statement: FAILED: ParseException line 1:64 cannot recognize input near ';' '<EOF>' '<EOF>' in table source"
>>> qry="select min(`date`) from agentbehaviour.nova_agent_dpp_historical"                                                                      
>>> cur.execute(qry)
>>> cur.fetchone()
['20170221']
>>> conn = pyhs2.connect(host='192.168.120.131', port=10000, authMechanism='PLAIN', user='huser', password='', database='mlstemp')              
>>> qry="select * from mlstemp.mls_image_downloader_status  limit "                                                                       
>>> qry="select * from mlstemp.mls_image_downloader_status  limit 1"
>>> cur.execute(qry)
>>> cur.fetchone()
['00000539-cd5b-4d76-93ef-2c46a8ac2ab3', 431, 14, 14, 1477166721000, 1477166119000, 1477140919705, 'S']
>>> 
