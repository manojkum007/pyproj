# -*- coding: utf-8 -*-
"""
Created on Fri Mar  4 18:15:50 2016

@author: manoj
"""

import luigi


class CheckFileOk(luigi.Task):
    def run (self):
        with self.output().open('w') as out_file:
            out_file.write("no transform")
            
    def output(self):
        return luigi.LocalTarget("basic_file")
    


class TransformTask(luigi.Task):
    param = luigi.Parameter(default=42)

    def require(self):
        #print "value of file " ,[CheckFileOk(self.param)]
        return [CheckFileOk1()]

    def run(self):
        with self.output().open('w') as out_file:
            out_file.write("transform")
    

    def output(self):
        return luigi.LocalTarget("row_input_file_" + self.param + "_transformed")
