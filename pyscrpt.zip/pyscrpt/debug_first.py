# -*- coding: utf-8 -*-
"""
Created on Fri May 13 14:12:06 2016

@author: manoj
"""

import pdb
a = "aaa"
pdb.set_trace()
b = "bbb"
c = "ccc"
final = a + b + c
print final