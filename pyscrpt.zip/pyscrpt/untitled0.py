# -*- coding: utf-8 -*-
"""
Created on Wed Feb 17 12:35:34 2016

@author: manoj
"""

import postgresql