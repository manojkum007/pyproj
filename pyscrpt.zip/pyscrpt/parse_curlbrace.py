# -*- coding: utf-8 -*-
"""
Created on Tue Jun 21 16:50:23 2016

@author: manoj
"""
import re


data=""""curl -i -XGET http://localhost:9200/megacorp/employee/ -d '
{
    "query" : {
        "constant_score" : { 
            "filter" : {
                "term" : { 
                    "month" : 4
                }
            }
        }
    }
}'"""

fdata=''
with open('/home/manoj/scripts/tiger_analyatics/chimpanzee/out.txt', 'r') as pfile:
    fdata=pfile.read()
    
#print fdata[0]"
matchObj = re.match(r'mapping.:', fdata, re.M|re.I)

if matchObj:
    print matchObj.group(0)
else:
    print "not found"


print " file name" ,__file__
