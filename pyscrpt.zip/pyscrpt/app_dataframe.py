# -*- coding: utf-8 -*-
"""
Created on Wed Jul 19 23:03:36 2017

@author: manoj
"""

import pandas as pd
import collections
import json

def assigndict(cur,lis,val,single):
    if len(val)>0:
        if len(lis)==1:
            if (single==0):
                cur[lis[0]]=val[0]
            else:
                cur[lis[0]]=val
            return
        else:
            if not cur.has_key(lis[0]):
                cur[lis[0]]=collections.OrderedDict()
            assigndict(cur[lis[0]],lis[1:],val,single)

#df=pd.read_csv('/home/manoj/movoto_project/agent_app/zipcode_searched_data.csv')
df=pd.read_csv('/home/manoj/movoto_project/agent_app/webout_dimen.csv')
total_rows = df.count
#print total_rows 

#print "original length",len(df)
#Total = df.groupby['zipcode'].count()

#grouper = df.groupby('zipcode')

grouper = df.groupby(['Nova_id'])

#print grouper
nova_id_group={}
for name, group  in grouper: 
    for row in group.iterrows():
        if nova_id_group.get(row[1]['Nova_id'])==None:
            nova_id_group[row[1]['Nova_id']]=1
        else:
            nova_id_group[row[1]['Nova_id']]= nova_id_group.get(row[1]['Nova_id'])+1
            
        #print len(group)
            #print row[1]['zipcode']
#print nova_id_group.get('018c0a46-43d7-4460-bca1-2a1a6eb0879b')
print nova_id_group.get('00035907-8671-419e-ac34-776f60f7d7fa')




#print grouper.count()

#print len(grouper['zipcode'])



def month_zipcode_stat(zipcode_3mon_df):
    nova_user_list=[]
    for name, group  in zipcode_3mon_df: 
        if name=="0135391a-095f-4fea-b93a-1dbb778a7f4d":
            print group
        last3Monthjson=collections.OrderedDict()
        assigndict(last3Monthjson,["novaId"], [name], 0)
        zipcode_dict=collections.OrderedDict()
        for row in group.iterrows():
            assigndict(last3Monthjson,["last3Months","zipcodeSearchStats","totalZipcodeSearch"], [len(group)], 0)
            key="{0}".format(row[1]['zipcode'])
            if name=="0135391a-095f-4fea-b93a-1dbb778a7f4d":
                print " key" ,key
            if zipcode_dict.get(key)==None:
                assigndict(zipcode_dict,[key,"zipcode"], [key], 0)
                assigndict(zipcode_dict,[key,"searchCount"], [1], 0)
            else:
                assigndict(zipcode_dict,[key,"searchCount"], [zipcode_dict.get(key).get("searchCount")+1], 0)
        assigndict(last3Monthjson,["last3Months","zipcodeSearchStats","zipcodeSearchHistogram"], zipcode_dict.get(key), 1)
        nova_user_list.append(last3Monthjson)
        #break
        
    return nova_user_list


#total_nova_user_list=month_zipcode_stat(grouper)    


#print  len(total_nova_user_list)

#print total_nova_user_list[0]


#
#for statobj in total_nova_user_list: 
#    path='%s/%s.json'%('/home/manoj/movoto_project/agent_app/novaid', statobj.get('novaId'))
#    jsonob=open(path,'w')
#    json.dump(statobj,jsonob, indent=4)
#    jsonob.close()
    
    
    
    
#print grouper.size()
