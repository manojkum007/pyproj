# -*- coding: utf-8 -*-
"""
Created on Wed Jun 22 18:50:54 2016

@author: manoj
"""

from elasticsearch import Elasticsearch
import json
import datetime
import luigi
from luigi import postgres
from luigi import six
import datetime
from datetime import date, timedelta
import psycopg2

start_date="2016-05-20"
start_date = datetime.datetime.strptime(start_date, '%Y-%m-%d').strftime('%Y-%m-%dT00:00:00.000Z')


end_date="2016-06-2"
end_date = datetime.datetime.strptime(end_date, '%Y-%m-%d').strftime('%Y-%m-%dT00:00:00.000Z')
      
      
es = Elasticsearch([{'host': '172.24.0.18'}] ,port= 8080) 
        
es_index="realestate"
        
body= {
                  "query": {
                    "filtered": {
                      "query": {
                        "query_string": {
                          "query": "_type:mls_aggregates AND new_listing:1",
                          "analyze_wildcard": True
                        }
                      },
                      "filter": {
                        "bool": {
                          "must": [
                            {
                              "query": {
                                "query_string": {
                                  "analyze_wildcard": True,
                                  "query": "*"
                                }
                              }
                            },
                            {
                              "range": {
                                "@timestamp": {
                                  "gte": start_date,
                                  "lte": end_date
                                }
                              }
                            }
                          ],
                          "must_not": []
                        }
                      }
                    }
                  },
                  "size": 0,
                  "aggs": {
                    "2": {
                      "terms": {
                        "field": "dma.raw",
                        "size": 60,
                        "order": {
                          "1": "desc"
                        }
                      },
                      "aggs": {
                        "1": {
                          "sum": {
                            "field": "listing_count"
                          }
                        }
                      }
                    }
                  }
                }
                                    
response = es.search(
    index=es_index,
    body=body
           )
           
           
#print "your response is " ,response


response=response.get("aggregations").get("2").get("buckets")


#print "your response is " ,response

for i in range(len(response)):
    print response[i].get("key") , " ," ,response[i].get("1").get("value")