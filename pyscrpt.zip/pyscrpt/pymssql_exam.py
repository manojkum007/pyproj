# -*- coding: utf-8 -*-
"""
Created on Mon Mar 20 21:03:57 2017

@author: manoj
"""

import pymssql

db_host="192.168.120.139"
db_username="sa"
db_password="igen"
db_name="AgentDirectory"

conn = pymssql.connect(db_host, db_username, db_password, db_name)

cursor = conn.cursor()


procedure="EXEC AgentDirectory.dbo.usp_DeltaLoadToAgentsCollection '2017-03-19','2017-03-20'"

cursor.execute(procedure)
conn.commit()


cursor1 = conn.cursor()

query="select count(distinct NovaId)  FROM AgentDirectory.dbo.AgentsCollection"

cursor1.execute(query)

for row in cursor1:
    print row

conn.close()

