# -*- coding: utf-8 -*-
"""
Created on Wed Jun 29 17:54:23 2016

@author: manoj
"""

import threading
import time
import MySQLdb

Num_Of_threads =1

class myThread(threading.Thread):

    def __init__(self, conn, cur, data_to_deal):
        threading.Thread.__init__(self)
        #self.threadID = threadID
        self.conn = conn
        self.cur = cur
        self.data_to_deal=data_to_deal

    def run(self):

        # add your sql 
        sql = "insert into test.mls_school values ('{0}' ,'{1}' ,'{2}');"
        for i in self.data_to_deal:
            self.cur.execute(sql.format(i[0] ,i[1],i[2]))
            self.conn.commit()

threads = []
data_list = [(23,'manpoj', 'kum') ,(45,'sonal', 'garg'),(45,'sonal', 'garg'),(23,'manpoj', 'kum') ,(45,'sonal', 'garg')]

for i in range(Num_Of_threads):
    conn = MySQLdb.connect(host='172.24.0.95',user='sa',passwd='igen',db='test')
    cur = conn.cursor()
    new_thread = myThread(conn, cur, data_list)

for th in threads:
    th.start()

for t in threads:
    t.join()