# -*- coding: utf-8 -*-
"""
Created on Fri Jul 29 01:36:03 2016

@author: manoj
"""


import csv
urlfailedfile="/home/manoj/scripts/tiger_analyatics/mls_error/property-data-15july.csv"
csv_reader = csv.reader(open(urlfailedfile, 'r'))
lis15=[]
count=0
for in_row in csv_reader:
    lis15.append((in_row[1],in_row[10]))
    #print in_row
#    if count==3:break
#    count+=1
    


urlfailedfile="/home/manoj/scripts/tiger_analyatics/mls_error/property-data-20july.csv"
csv_reader = csv.reader(open(urlfailedfile, 'r'))
lis20=[]
for in_row in csv_reader:
    lis20.append((in_row[1],in_row[10]))
#print lis20

#print lis15

for i in lis15:
    if i  not in lis20:
        print i

#
#for i in lis20:
#    if i  not in lis15:
#        print i