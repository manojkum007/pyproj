# -*- coding: utf-8 -*-
"""
Created on Tue Sep 11 11:46:33 2018

@author: manoj
"""
import urllib2

#req = urllib2.Request('http://www.python.org/fish.html')

#req = urllib2.Request("http://192.168.120.149:9200/")

#try:
#    res=urllib2.urlopen(req)
#    print res.read()
#except urllib2.HTTPError, e:
#    print e.code
#except Exception as e:
#    print e
#    #print e.read()
    
    
    

#req = urllib2.Request('http://www.voidspace.org.uk')
#response = urllib2.urlopen(req)
#the_page = response.read()
#print the_page[:100]

import socket
import time


# timeout in seconds
timeout = 10
socket.setdefaulttimeout(timeout)

# this call to urllib2.urlopen now uses the default timeout
# we have set in the socket module

for i in range(1000):
    req = urllib2.Request('https://www.google-analytics.com/collect?v=1&t=event&tid=UA-88501729-1&cid=1297873010.1533098896&uid=ed97b6f1-6cd5-4a70-9f37-17cb8bff3e77&qt=41578353&ec=lead&ea=billable_lead_test&ev=75000&el=ListingAgentQuestionResponsiveDPPMobile&ua=Mozilla%2F5.0+%28Linux%3B+Android+8.0.0%3B+LM-G710+Build%2FOPR1.170623.032%29+AppleWebKit%2F537.36+%28KHTML%2C+like+Gecko%29+Chrome%2F67.0.3396.87+Mobile+Safari%2F537.36&ni=1&uip=172.58.21.47&cd1=website&cd2=detail-property-page&cd3=buy&cd4=es&cd5=Mobile&cd6=1297873010.1533098896&cd14=471&cd15=f68f4294-f749-4b4a-a150-adb56994479b&cd16=75000.0&cd17=1&cd18=3.0&cd19=2.0&cd20=1104.0&cd21=59&cd23=ACTIVE&cd24=0&cd25=Phoenix&cd26=AZ&cd27=85009&cd28=Northwest+Homesites&cd32=694d835d-336b-4d99-a183-ba576c4b9172&cd36=ListingAgentQuestionResponsiveDPPMobile&cd61=8eb55ffe-b7e1-4830-bcc3-7a75a1b40bb6&cd62=2018-09-10+14%3A27%3A02.000000&cd65=Mozilla%2F5.0+%28Linux%3B+Android+8.0.0%3B+LM-G710+Build%2FOPR1.170623.032%29+AppleWebKit%2F537.36+%28KHTML%2C+like+Gecko%29+Chrome%2F67.0.3396.87+Mobile+Safari%2F537.36&cd66=5022_2&cd69=Phoenix+AZ&cd71=5022&cd72=&cd73=172.58.21.47&cd78=Cj0KCQjwiJncBRC1ARIsAOvG-a5PlF4A6Y-NKN9pvKshTh4YOho7Hf7d5LDdnQIDvDSr9nepmYdK8nwaAojmEALw_wcB&cd92=Property&cd93=Opcity+Production')
    print "sending request"
    response = urllib2.urlopen(req)
    print response.read()[:500]
    response_code = response.getcode()
    print response_code
    #response.close()
    #time.sleep(1)
    
    
    
#import socket
#f.fp._sock.fp._sock.shutdown(socket.SHUT_RDWR)
#
#
#fdurl = urllib2.urlopen(req,timeout=3000)
##realsock = fdurl.fp._sock.fp._sock** # we want to close the "real" socket later 
##req = urllib2.Request(url, header)
#req = urllib2.Request('https://www.google-analytics.com/collect?v=1&t=event&tid=UA-88501729-1&cid=1297873010.1533098896&uid=ed97b6f1-6cd5-4a70-9f37-17cb8bff3e77&qt=41578353&ec=lead&ea=billable_lead_test&ev=75000&el=ListingAgentQuestionResponsiveDPPMobile&ua=Mozilla%2F5.0+%28Linux%3B+Android+8.0.0%3B+LM-G710+Build%2FOPR1.170623.032%29+AppleWebKit%2F537.36+%28KHTML%2C+like+Gecko%29+Chrome%2F67.0.3396.87+Mobile+Safari%2F537.36&ni=1&uip=172.58.21.47&cd1=website&cd2=detail-property-page&cd3=buy&cd4=es&cd5=Mobile&cd6=1297873010.1533098896&cd14=471&cd15=f68f4294-f749-4b4a-a150-adb56994479b&cd16=75000.0&cd17=1&cd18=3.0&cd19=2.0&cd20=1104.0&cd21=59&cd23=ACTIVE&cd24=0&cd25=Phoenix&cd26=AZ&cd27=85009&cd28=Northwest+Homesites&cd32=694d835d-336b-4d99-a183-ba576c4b9172&cd36=ListingAgentQuestionResponsiveDPPMobile&cd61=8eb55ffe-b7e1-4830-bcc3-7a75a1b40bb6&cd62=2018-09-10+14%3A27%3A02.000000&cd65=Mozilla%2F5.0+%28Linux%3B+Android+8.0.0%3B+LM-G710+Build%2FOPR1.170623.032%29+AppleWebKit%2F537.36+%28KHTML%2C+like+Gecko%29+Chrome%2F67.0.3396.87+Mobile+Safari%2F537.36&cd66=5022_2&cd69=Phoenix+AZ&cd71=5022&cd72=&cd73=172.58.21.47&cd78=Cj0KCQjwiJncBRC1ARIsAOvG-a5PlF4A6Y-NKN9pvKshTh4YOho7Hf7d5LDdnQIDvDSr9nepmYdK8nwaAojmEALw_wcB&cd92=Property&cd93=Opcity+Production')
# 
#try:
#    fdurl = urllib2.urlopen(req,timeout=self.timeout)
#except urllib2.URLError,e:
#    print "urlopen exception", e
#    
#    
#realsock.close() 
#fdurl.close()