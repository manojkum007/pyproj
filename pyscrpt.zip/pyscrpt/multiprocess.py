# -*- coding: utf-8 -*-
"""
Created on Wed Jun 22 15:32:39 2016

@author: manoj
"""

from multiprocessing import Process

#def f(name):
#    print 'hello', name
#
#if __name__ == '__main__':
#    p = Process(target=f, args=('bob',))
#    p.start()
#    p.join()
#    
#


#import os
#
#def info(title):
#    print title
#    print 'module name:', __name__
#    if hasattr(os, 'getppid'):  # only available on Unix
#        print 'parent process:', os.getppid()
#    print 'process id:', os.getpid()
#
#def f(name):
#    info('function f')
#    print 'hello', name
#
#if __name__ == '__main__':
#    info('main line')
#    p = Process(target=f, args=('bob',))
#    p.start()
#    p.join()
#    
    


from multiprocessing import Process, Queue   

def f(q):
    q.put([42, None, 'hello'])

if __name__ == '__main__':
    q = Queue()
    p = Process(target=f, args=(q,))
    p.start()
    print q.get()    # prints "[42, None, 'hello']"
    p.join()