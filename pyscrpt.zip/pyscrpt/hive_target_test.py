# -*- coding: utf-8 -*-
"""
Created on Wed Sep 27 11:09:16 2017

@author: manoj
"""

import luigi

from luigi.hive import HiveTableTarget



#class CreateBaseTable(luigi.hive.HiveQueryTask):
#  def query(self):
#    return """
#      create table jmeagher.TestTable(something int, something_else double)
#      partitioned by (rdate string)
#      stored as TEXT
#    """
#
#  def output(self):
#    return luigi.hive.HiveTableTarget("TestTable", database="jmeagher") 
    
    
class CreateBaseTable(luigi.Task):
    def run(self):
        print "testing something new"
#        return """
#        create table jmeagher.TestTable(something int, something_else double)
#        partitioned by (rdate string)
#        stored as TEXT
#        """
    
    def output(self):
        return HiveTableTarget("dummy12", database="default") 