# -*- coding: utf-8 -*-
"""
Created on Wed Dec 27 16:22:51 2017

@author: manoj
"""

ll=[2,5,3,9,8,78,62,12,5,40]

for i in range(len(ll)):
    for j in range(i+1):
        #print "i=",i ,"j=",j,
        if ll[i]<ll[j]:
            #print "swap",
            ll[i],ll[j]=ll[j],ll[i]
    #print "\n"

#print ll
        
#ll=[2,5,3,9,8,78,62,12,5,40]
#ll=[8,11,9,1,4,6,12,10,5,7]
#
#        
#for i in range(len(ll)):
#    sublis=[]
#    current=ll[i]
#    sublis.append(current)
#    for j in range(i,len(ll)):
#        if ll[j]-current>0:
#            sublis.append(ll[j])
#            current=ll[j]
#    print sublis
#            
        
l1=[1, 2, 2, 3, 5, 7, 8, 8, 28]
l2=[0, 2, 4, 4, 4, 5, 6]


def mergelist(l1,l2):
    left=0
    right=0
    commonlis=[]
    while (left <len(l1) and right < len(l2)):
        print "left" , left ,"right" ,right
        print "l1" , l1 ,"l2" ,l2
        if (l1[left]<l2[right]):
            commonlis.append(l1[left])
            left+=1
        else:
            commonlis.append(l2[right])
            right+=1
    
    if left<len(l1):
        commonlis.extend(l1[left:])
    if right<len(l2):
        commonlis.extend(l2[right:])
        
    print "commonlis" ,commonlis

#mergelist(l1,l2)

def mergesort(l1):
    if len(l1)>0:
        #print "lis " ,l1
        if (len(l1)/2)>0:
            leftarr=l1[0:len(l1)/2]
            rightarr=l1[len(l1)/2:]
            mergesort(leftarr)
            mergesort(rightarr)
            
            mergelist(sorted(leftarr),sorted(rightarr))
            
           # mergelist(mergesort(l1[0:len(l1)/2]), mergesort(l1[len(l1)/2:]))
        
l1=[1, 12, 8, 13, 5, 7, 18, 8, 10]

mergesort(l1)  
        

