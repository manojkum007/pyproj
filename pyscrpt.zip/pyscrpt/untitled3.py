# -*- coding: utf-8 -*-
"""
Created on Thu Feb  9 18:34:21 2017

@author: manoj
"""

dd=[["agentStatus"],["movotoAgentSince"], ["agentSince"],["contact","firstName"],["contact","middleName"],["contact","lastName"],["contact","phones","displayPhone"] ,["contact","phones","homePhone"] ,["contact","phones","officePhone"] ,["contact","phones","cellPhone"],["contact","email"],["contact","altEmail"],["contact","linkedInProfile"],["contact","facebookProfile"],["contact","twitterProfile"],["contact","blog"],["contact","website"],["contact","homeAddress","streetAddress"],["contact","homeAddress","streetAddress"],["contact","homeAddress","streetAddress"],["contact","homeAddress","zipcode"],["contact","homeAddress","state","stateCode"],["contact","homeAddress","state","name"],["contact","homeAddress","city","cityId"],["contact","homeAddress","city", "cityName"],["contact","homeAddress","county","countyId"],["contact","homeAddress","county","countyName"],["brokerage","name"],["contact","website"]]

print dd
