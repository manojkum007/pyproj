# -*- coding: utf-8 -*-
"""
Created on Thu Jun 30 16:48:37 2016

@author: manoj
"""

import logging
import threading
import time

logging.basicConfig(level=logging.DEBUG,
                    format='[%(levelname)s] (%(threadName)-10s) %(message)s',
                    )

def worker():
    logging.debug('Starting')
    time.sleep(5)
    logging.debug('Exiting')

def my_service():
    logging.debug('Starting')
    time.sleep(3)
    logging.debug('Exiting')

#s = threading.Thread(name='my_service', target=my_service)
#s.setDaemon(True)
#w = threading.Thread(name='worker', target=worker)
#w2 = threading.Thread(target=worker) # use default name
##
#
#s.start()
#w.start()
#w2.start()
#s.join()
#w.join()


#main_thread = threading.currentThread()
#for t in threading.enumerate():
#    if t is main_thread:
#        continue
#    logging.debug('joining %s', t.getName())
#    t.join()


class fibre(threading.Thread):
    def __init__(self, group=None, target=None, name=None,
                 args=(), kwargs=None, verbose=None):
        threading.Thread.__init__(self, group=group, target=target, name=name,
                                  verbose=verbose)
        self.args = args
        self.kwargs = kwargs
        return
        
        
    def run(self):
        logging.debug('running with %s and %s', self.args, self.kwargs)
        return
        #logging.debug('Starting inhertited thread %s'%threading.currentThread().getName())


help(fibre)
#for i in range(10):    
#    f=fibre(name='my_service'+ str(i*8),args=(i,), kwargs={'a':'A', 'b':'B'})
#    f.start()
        
