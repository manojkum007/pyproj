# -*- coding: utf-8 -*-
"""
Created on Thu Aug  3 12:18:24 2017

@author: manoj
"""



class Celsius:
    def __init__(self, temperature = 0):
        self.temperature = temperature

    def to_fahrenheit(self):
        return (self.temperature * 1.8) + 32
        
        
        
        


class Celsius:
    def __init__(self, temperature = 0):
        self.set_temperature(temperature)

    def to_fahrenheit(self):
        return (self.get_temperature() * 1.8) + 32

    # new update
    def get_temperature(self):
        return self._temperature

    def set_temperature(self, value):
        if value < -273:
            raise ValueError("Temperature below -273 is not possible")
        self._temperature = value
        
        
        
        
#c = Celsius(58)
#
#c.set_temperature(78)
#print c.get_temperature()
        


#In Python, property() is a built-in function that creates and returns a property object. 
#The signature of this function is
#property(fget=None, fset=None, fdel=None, doc=None)
        
#class Foo(object):
#     def __init__(self):
#         self._bar = 0
#     def set_bar(self ,v):
#         self._bar=v
#         
#     bar = property(lambda self: self._bar+5,set_bar)
#
#       
#
#
#
#cc=Foo()
#print cc.bar
#cc.bar=89
#
#print cc.bar
#print type(cc).bar.__get__(cc, type(cc))





#class Foo(object):
#    def __init__(self):
#        self._bar = 0
#
#    @property
#    def bar(self):
#        return self._bar + 5      
#    @bar.setter
#    def bar(self, val):
#        self._bar=val
#        
#        
#
#
#
#cc=Foo()
#print cc.bar
#cc.bar=100
#
#print cc.bar








class Celsius(object):
    def __init__(self, temperature = 0):
        self._temperature = temperature

    def to_fahrenheit(self):
        return (self.temperature * 1.8) + 32

    @property
    def temperature(self):
        print("Getting value")
        return self._temperature

    @temperature.setter
    def temperature(self, value):
        if value < -273:
            raise ValueError("Temperature below -273 is not possible")
        print("Setting value")
        self._temperature = value
        
        

#
c = Celsius(158)
#print c.__dict__
#print c._temperature
#
c.temperature=56
print c.to_fahrenheit()
#print c.__dict__
#print c._temperature

       
        
        
#class Celsius:
#    def __init__(self, temperature = 0):
#        self._temperature = temperature
#
#    def to_fahrenheit(self):
#        return (self.temperature * 1.8) + 32
#
#    def get_temperature(self):
#        print("Getting value")
#        return self._temperature
#
#    def set_temperature(self, value):
#        if value < -273:
#            raise ValueError("Temperature below -273 is not possible")
#        print("Setting value")
#        self._temperature = value
#
#    temperature = property(get_temperature,set_temperature)   
#    
#
#
#c = Celsius(58)
#
#print c.get_temperature()
#
#c.temperature=89
#
#print c.get_temperature()