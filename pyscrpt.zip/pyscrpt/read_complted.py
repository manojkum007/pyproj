# -*- coding: utf-8 -*-
"""
Created on Fri May 20 15:15:53 2016

@author: manoj
"""

import csv
import re

path='/home/mkumar/pyscripts/6111.csv'
path='/home/manoj/scripts/python_scripts/6111.csv'

lis=[]
with open(path ,'rb') as csvfile:
    reader=csv.reader(csvfile)
    for row in reader:
        lis.append(row[1])
        
#print lis  
#path1='/data/bkfs/extracts/06111_Deed_Refresh_20160509.txt'

path1='/home/manoj/scripts/tiger_analyatics/06111_Deed_Refresh_20160509.txt'
path1='/home/manoj/scripts/python_scripts/6111_sample.csv'


lis2=[]
cnt=0
with open(path1 ,'rb') as csvfile:
    reader=csv.reader(csvfile)
    for row in reader:
        res=row[0].split("\t")
        try:
           if  (res[71] not in lis):
               pass
               #lis2.append(res)
               #break

        except Exception as e :
            cnt+=1
            pass
            #print "srry",e
#        break
        #lis2.append(row)
#print lis2
#path2='/home/manoj/scripts/tiger_analyatics/06017_new.txt'

path2="/home/mkumar/pyscripts/6111_uncopied.txt"
path2="/home/manoj/scripts/python_scripts/6112_uncopied.csv"
#fp= open(path2 ,'w')
#    fp.write(str(i)

#with open(path2, 'wb') as csvfile:
#    spamwriter = csv.writer(csvfile, delimiter='\t',
#                            quotechar='"', quoting=csv.QUOTE_MINIMAL)
#    for i in lis2:
#        spamwriter.writerow(i)
#    
    
print cnt
#print len(lis2)
#for i in lis2:
#    print i
    #if (re.search( r, line)
        
