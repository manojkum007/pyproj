# -*- coding: utf-8 -*-
"""
Created on Fri Aug  4 13:17:33 2017

@author: manoj
"""

a=5
try:
    print a
except Exception as e:
    print "aa"
else:
    print "zx.bn,sd"
