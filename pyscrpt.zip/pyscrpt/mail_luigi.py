# -*- coding: utf-8 -*-
"""
Created on Thu Jun 16 17:46:07 2016

@author: manoj
"""

def generate_email(sender, subject, message, recipients, image_png):
    import email
    import email.mime
    import email.mime.multipart
    import email.mime.text
    import email.mime.image

    msg_root = email.mime.multipart.MIMEMultipart('related')

    msg_text = email.mime.text.MIMEText(message, email_type())
    msg_text.set_charset('utf-8')
    msg_root.attach(msg_text)

    if image_png:
        with open(image_png, 'rb') as fp:
            msg_image = email.mime.image.MIMEImage(fp.read(), 'png')
        msg_root.attach(msg_image)

    msg_root['Subject'] = subject
    msg_root['From'] = sender
    msg_root['To'] = ','.join(recipients)

    return msg_root

def send_email_smtp( sender, subject, message, recipients, image_png):
    import smtplib

    smtp_ssl = False
    smtp_without_tls = False
    smtp_host = '172.24.0.11'
    smtp_host = '127.0.0.1'
    smtp_port = 25
    smtp_local_hostname = None
    smtp_timeout = 10
    kwargs = dict(host=smtp_host, port=smtp_port, local_hostname=smtp_local_hostname)
    if smtp_timeout:
        kwargs['timeout'] = smtp_timeout

    smtp_login = None
    smtp_password = None
    smtp = smtplib.SMTP(**kwargs) if not smtp_ssl else smtplib.SMTP_SSL(**kwargs)
    smtp.ehlo_or_helo_if_needed()
    if smtp.has_extn('starttls') and not smtp_without_tls:
        smtp.starttls()
    if smtp_login and smtp_password:
        smtp.login(smtp_login, smtp_password)

    msg_root = generate_email(sender, subject, message, recipients, image_png)

    smtp.sendmail(sender, recipients, msg_root.as_string())
    print "mailsent"
    


send_email_smtp('mkumar@movoto.com','sdfsf','sdf' ,'mkumar@movto.com',None)
