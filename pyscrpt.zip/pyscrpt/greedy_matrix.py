# -*- coding: utf-8 -*-
"""
Created on Sat Mar 10 21:10:34 2018

@author: manoj
"""
import datetime
import time

#lis=[]
#for i in range(3):
#    lis.append([])
#    for j in range(3):
#        time.sleep(1/4)
#        lis[i].append(int(datetime.datetime.now().strftime('%s'))%2)
#        
#


rowcount=2
colcount=2


def indexsearcher(lis,x,y,rowcount ,colcount):
    left,right,up,down=0,0,0,0
    if x==0:
        left=0
    else:
        left=lis[x][y-1]
        
    if x==rowcount:
        right=0
    else:
        right=lis[x][y+1]
        
    if y==0:
        up=0
    else:
        up=lis[x-1][y]
        
    if y==rowcount:
        down=0
    else:
        down=lis[x+1][y]
        
    print (left,right,up,down)    
    return (left,right,up,down)

        
    
def greedy_search(lis):
    i=0
    j=0
    left,right,up,down= indexsearcher(lis,i,j,rowcount,colcount)
    while (i<rowcount and j<colcount) :
        print i ,j
        i+=1
        j+=1
 
lis =[[1, 1, 0], [0, 0, 1], [1, 0, 1]]  
#1 1 0
#0 0 1
#1 0 1


print greedy_search(lis)
        