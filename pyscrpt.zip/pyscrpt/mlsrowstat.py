# -*- coding: utf-8 -*-
"""
Created on Tue Nov 29 14:58:54 2016

@author: manoj
"""
import luigi
from luigi import postgres
from luigi import six
import datetime
from datetime import date, timedelta
import os
import uuid
import json
import re
from luigi.contrib import sqla
from luigi.contrib.hdfs.hadoopcli_clients import HdfsClient
import  movoto_logger 
from luigi.hive import HiveTableTarget, run_hive_cmd
import re


import pymssql
import ast
import csv
#from es_queries import  *
logger=movoto_logger.get_logger('mls_stat.log')

Pantherip='172.24.0.80'
username='sa'
password='igen'
database='mls_raw'



class RowCountComparison(luigi.Task):
    panther_table_name =luigi.Parameter()
    hive_table =luigi.Parameter()
    database=luigi.Parameter(default="mls")
    
    def run(self): 
        self.tablerowcount=0
        self.hiverowcount=0
        try:
            conn = pymssql.connect(Pantherip, username, password, database)  
            cursor = conn.cursor()
            logger.info("running panther row count  for %s"%self.panther_table_name)
            query="SELECT  count(*)  FROM "+self.panther_table_name
            cursor.execute(query)
            for row in cursor:
                self.tablerowcount= int(row[0])
        except Exception as e:
            logger.info("Problem in getting row count due to  %s"%e)
            return 0
            
        try:
            target = HiveTableTarget(table=self.hive_table,database=self.database).exists()
            if (target!=True):
                #orc_stat="ANALYZE TABLE [table_name] COMPUTE STATISTICS;"
                logger.info("running hive  row count  for %s"%self.hive_table)
                orc_stat="select count(*) from [table_name];"
                orc_stat=orc_stat.replace('[table_name]',self.hive_table)
                result=run_hive_cmd(orc_stat)
                self.hiverowcount=int(result)
#                res=result.split("\n")
#                for row in res:
#                    ob=re.search('numRows=(\d+)',row)
#                    if(ob):
#                        self.hiverowcount=int(ob.group(1))
#                        break
        except Exception as e:
            logger.critical("Unable to get stat for table %s"%e)
            return 0
            
        if (self.tablerowcount==self.hiverowcount):
            logger.info("count between tables are matching  %s"%self.tablerowcount)
        else:
            logger.critical("count mismatch pathertbale=%s andd hive table =%s"%(self.tablerowcount,self.hiverowcount))
        
        column_list=["property_id"]
        self.columnpercent(column_list)
        
        with self.output().open('w') as f:
            f.write('{word}\n'.format(word='DownloadSessions'))
        
    
    def output(self):
        path = os.path.join('./logs', 'table_%s'%self.table_name)
        return luigi.file.LocalTarget(path=path)
    
    def columnpercent(self ,columns):
        column_null_count=[]
        try: 
            for col in columns:
                colquery="select count(*) from [table_name] where %s is NULL;"%col
                colquery=colquery.replace('[table_name]',self.hive_table)
                logger.info("running column count for %s"%col)
                result=run_hive_cmd(colquery)
                logger.info("running finished for column %s"%col)
                column_null_count.append(int(result))
            return column_null_count
        except Exception as e:
             logger.critical("Unable to get null for column %s"%e)
             return 0
                
            
        
        
        
#    
#
#class CheckRow(luigi.Task):
#    sessions_date = luigi.DateParameter(default=datetime.date.today() - datetime.timedelta(days=1))
#    profile_name = luigi.Parameter()
#    config = None
#
#    def __init__(self, *args, **kwargs):
#        super(ExportSessionsData, self).__init__(*args, **kwargs)
#        self.config = get_job_config(self.profile_name)
#
#    def run(self):
#
#        service = luigi_config.get('bigquery', 'service-name')
#        version = luigi_config.get('bigquery', 'service-version')
#        scopes = luigi_config.get('bigquery', 'service-scopes')
#        project_id = luigi_config.get('bigquery', 'project-id')
#
#        # Get BQ Service
#        bq = google_utils.get_service(service, version, scopes)
#        if not bq:
#            logger.critical('Failed to get BigQuery service')
#            return
#
#        cloudstorage_path = 'gs://%s/%s' % (self.config['gcs_bucket'], (self.config['gcs_file'] % (self.sessions_date.strftime('%Y%m%d'),'*')))
#        project_id = project_id
#        dataset_id = self.config['profile_id']
#        table_id = self.config['bigquery_table_id'] % self.sessions_date.strftime('%Y%m%d')
#
#        export_job = google_utils.export_table(bq, cloudstorage_path, project_id, dataset_id, table_id)
#        google_utils.poll_job(bq, export_job)
#
#        # Mark this job as done
#        self.output().touch()
##        with self.output().open('w') as f:
##            f.write('{word}\n'.format(word='ExportSessionsData'))
#        pass
#
#    def output(self):
#        return puma_target('ExportSessionsData_%s'%self.profile_name, self.profile_name, self.sessions_date)
##        path = os.path.join(self.config['local_path'], 'ExportSessionsData_'+self.config['avro_file_name'] % self.sessions_date.strftime('%Y%m%d'))
##        return luigi.file.LocalTarget(path=path)
#      
