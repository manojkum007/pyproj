# -*- coding: utf-8 -*-
"""
Created on Wed Jan  4 12:53:27 2017

@author: manoj
"""

from PIL import Image
import glob, os

size = 128, 128

for infile in glob.glob("/home/manoj/Pictures/hive_error.png"):
    file, ext = os.path.splitext(infile)
    im = Image.open(infile)
    im.thumbnail(size)
    im.save(file + ".thumbnail", "JPEG")