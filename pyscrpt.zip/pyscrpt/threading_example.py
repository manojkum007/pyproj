# -*- coding: utf-8 -*-
"""
Created on Sun Feb 21 10:00:42 2016

@author: manoj
"""

import threading
import time
import logging
import random
logging.basicConfig(level=logging.DEBUG,
                    format='(%(threadName)-10s) %(message)s',
                    )





#def worker(num):
#    """thread worker function"""
#    thread_name=threading.currentThread().getName()
#    print thread_name , 'Starting'
#    time.sleep(2)
#    print 'Worker  of %s with %d'%(thread_name, num)
#    print thread_name , 'Existing'
#    return
#
#
#
#threads = []
#for i in range(5):
#    t = threading.Thread(target=worker, args=(i,))
#    threads.append(t)
#    t.start()
#    print " no of thread" ,len(threads)
#



#########################logging###################

def worker():
    logging.info("%s Starting"%threading.currentThread().getName())
    time.sleep(2)
    logging.info("%s Exiting"%threading.currentThread().getName())

def my_service():
    logging.info("%s Starting"%threading.currentThread().getName())
    time.sleep(3)
    logging.info("%s Exiting"%threading.currentThread().getName())

def daemon():
    logging.info("%s Starting"%threading.currentThread().getName())
    time.sleep(50)
    logging.info("%s Exiting"%threading.currentThread().getName())
    

t = threading.Thread(name='my_service', target=my_service)
w = threading.Thread(name='worker', target=worker)
w2 = threading.Thread(name='Daemon thread', target=daemon) # use default name
w2.setDaemon(True)
w.start()
w2.start()
t.start()




#########################join example###########################

#def daemon():
#    logging.debug('Starting')
#    time.sleep(10)
#    logging.debug('Exiting')
#
#d = threading.Thread(name='daemon', target=daemon)
#d.setDaemon(True)
#
#def non_daemon():
#    logging.debug('Starting')
#    logging.debug('Exiting')
#
#t = threading.Thread(name='non-daemon', target=non_daemon)
#
#d.start()
#
#t.start()
#logging.debug("some message")
#d.join()




##############################enumerate Example################################

#def worker():
#    """thread worker function"""
#    t = threading.currentThread()
#    pause = random.randint(1,5)
#    logging.debug('sleeping %s', pause)
#    time.sleep(pause)
#    logging.debug('ending')
#    return
#
#for i in range(3):
#    t = threading.Thread(target=worker)
#    t.setDaemon(True)
#    t.start()
#
#main_thread = threading.currentThread()
#for t in threading.enumerate():
#    if t is main_thread:
#        continue
#    logging.debug('joining %s', t.getName())
#    t.join()
#







####################################subclass thread ##################################


#class MyThread(threading.Thread):
#    pass
#    def run(self):
#        logging.debug('running')
#        return
#
#for i in range(5):
#    t = MyThread()
#    t.start()




###############################with constructor##########################3333




#class MyThreadWithArgs(threading.Thread):
#
#    def __init__(self, group=None, target=None, name=None,
#                 args=(), kwargs=None, verbose=None):
#        threading.Thread.__init__(self, group=group, target=target, name=name, verbose=verbose)
#        self.args = args
#        self.kwargs = kwargs
#        return
#
#    def run(self):
#        logging.debug('running with %s and %s', self.args, self.kwargs)
#        return
#
#for i in range(5):
#    t = MyThreadWithArgs(args=(i,), kwargs={'a':'A%s'%i, 'b':'B%s'%i})
#    t.start()
#




####################signalling between thread######################





#logging.basicConfig(level=logging.DEBUG,
#                    format='(%(threadName)-10s) %(message)s',
#                    )
#                    
#def wait_for_event(e):
#    """Wait for the event to be set before doing anything"""
#    logging.debug('wait_for_event starting')
#    event_is_set = e.wait()
#    logging.debug('event set: %s', event_is_set)
#
#def wait_for_event_timeout(e, t):
#    """Wait t seconds and then timeout"""
#    while not e.isSet():
#        logging.debug('wait_for_event_timeout starting')
#        event_is_set = e.wait(t)
#        logging.debug('event set: %s', event_is_set)
#        if event_is_set:
#            logging.debug('processing event')
#        else:
#            logging.debug('doing other work')
#
#
#e = threading.Event()
#t1 = threading.Thread(name='block', 
#                      target=wait_for_event,
#                      args=(e,))
#t1.start()
#
#t2 = threading.Thread(name='non-block', 
#                      target=wait_for_event_timeout, 
#                      args=(e, 2))
#t2.start()
#
#logging.debug('Waiting before calling Event.set()')
#time.sleep(3)
#e.set()
#logging.debug('Event is set')
#




################################cotrolled access#############################





#class Counter(object):
#    def __init__(self, start=0):
#        self.lock = threading.Lock()
#        self.value = start
#    def increment(self, workername):
#        logging.debug(' %s  is Waiting for lock'%workername)
#        self.lock.acquire()
#        try:
#            logging.debug(' %s Acquired lock'%workername)
#            self.value = self.value + 1
#        finally:
#            time.sleep(5)
#            self.lock.release()
#            logging.debug(' %s Released lock'%workername)
#            
#    def showvalue(self , workername):
#        logging.info(" current value %s"%(self.value))
#
#
#
#def worker(c):
#    for i in range(2):
#        pause = random.random()
#        logging.debug('Sleeping %0.02f', pause)
#        time.sleep(pause)
#        c.increment(threading.currentThread().getName())
#        c.showvalue(threading.currentThread().getName())
#    logging.debug('Done')
#
#counter = Counter()
#for i in range(2):
#    t = threading.Thread(name='worker%s'%i, target=worker, args=(counter,))
#    t.start()
#
#logging.debug('Waiting for worker threads')
#main_thread = threading.currentThread()
#for t in threading.enumerate():
#    if t is not main_thread:
#        t.join()
#logging.debug('Counter: %d', counter.value)
#
#
#
#










##################################################lock wait###########################

#def lock_holder(lock):
#    logging.debug('Starting')
#    while True:
#        lock.acquire()
#        try:
#            logging.debug('Holding')
#            time.sleep(0.5)
#        finally:
#            logging.debug('Not holding')
#            lock.release()
#        time.sleep(0.5)
#        logging.debug('in lock holder')
#    return
#                    
#def worker(lock):
#    logging.debug('Starting')
#    num_tries = 0
#    num_acquires = 0
#    while num_acquires < 3 and num_tries < 20:
#        time.sleep(0.5)
#        logging.debug('Trying to acquire')
#        have_it = lock.acquire(0)
#        try:
#            num_tries += 1
#            if have_it:
#                logging.debug('Iteration %d: Acquired',  num_tries)
#                num_acquires += 1
#            else:
#                logging.debug('Iteration %d: Not acquired', num_tries)
#        finally:
#            if have_it:
#                lock.release()
#        have_it = lock.acquire(0)
#    logging.debug('Done after %d iterations', num_tries)
#
#
#lock = threading.Lock()
#
##holder = threading.Thread(target=lock_holder, args=(lock,), name='LockHolder')
##holder.setDaemon(True)
##holder.start()
##holder.join(10)
#worker = threading.Thread(target=worker, args=(lock,), name='Worker')
#worker.start()
#
#
#








##################################locks as context Manager###############################


#def worker_with(lock):
#    with lock:
#        logging.debug('Lock acquired via with')
#        
#def worker_no_with(lock):
#    lock.acquire()
#    try:
#        logging.debug('Lock acquired directly')
#    finally:
#        lock.release()
#
#lock = threading.Lock()
#w = threading.Thread(target=worker_with, args=(lock,))
#nw = threading.Thread(target=worker_no_with, args=(lock,))
#
#w.start()
#nw.start()






####################################Synchronizing Threads###########################33
#
#
#def consumer(cond):
#    """wait for the condition and use the resource"""
#    logging.debug('Starting consumer thread')
#    t = threading.currentThread()
#    with cond:
#        cond.wait()
#        logging.debug('Resource is available to consumer')
#
#def producer(cond):
#    """set up the resource to be used by the consumer"""
#    logging.debug('Starting producer thread')
#    with cond:
#        logging.debug('Making resource available')
#        #cond.notifyAll()
#        cond.notify(2)
#
#condition = threading.Condition()
#c1 = threading.Thread(name='c1', target=consumer, args=(condition,))
#c2 = threading.Thread(name='c2', target=consumer, args=(condition,))
#p = threading.Thread(name='p', target=producer, args=(condition,))
#
#
#c1.start()
#time.sleep(2)
#c2.start()
#time.sleep(2)
#p.start()
#
#





####################Using Queue for producer and consumer problem##############################

#import Queue
#def consume(q):
#    while(True):
#        name = threading.currentThread().getName()
#        logging.debug("Thread: {0} start get item from queue[current size = {1}] at time = {2} \n".format(name, q.qsize(), time.strftime('%H:%M:%S')))
#        item = q.get()
#        time.sleep(3)  # spend 3 seconds to process or consume the tiem
#        logging.debug( "Thread: {0} finish process item from queue[current size = {1}] at time = {2} \n".format(name, q.qsize(), time.strftime('%H:%M:%S')))
#        q.task_done()
# 
# 
#def producer(q):
#    # the main thread will put new items to the queue
#    for i in range(2):
#        name = threading.currentThread().getName()
#        logging.debug( "Thread: {0} start put item into queue[current size = {1}] at time = {2} \n".format(name, q.qsize(), time.strftime('%H:%M:%S')))
#        item = "item-" + str(i)
#        q.put(item)
#        logging.debug( "Thread: {0} successfully put item into queue[current size = {1}] at time = {2}  with item {3} \n".format(name, q.qsize(), time.strftime('%H:%M:%S') ,item))
#    q.join()
# 
#if __name__ == '__main__':
#    q = Queue.Queue(maxsize = 3)
# 
#    threads_num = 3  # three threads to consume
#    for i in range(threads_num):
#        t = threading.Thread(name = "ConsumerThread-"+str(i), target=consume, args=(q,))
#        t.setDaemon(True)
#        t.start()
# 
#    #1 thread to procuce
#    p = threading.Thread(name = "ProducerThread", target=producer, args=(q,))
#    p.start()
# 
#    q.join()
