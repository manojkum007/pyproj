
import smtplib

from email.mime.text import MIMEText
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate


def send_email_with_attachment(smtp_host, from_addr, subject, body_text, to_emails, cc_emails, bcc_emails , html_tag):
    host = smtp_host
    
    msg = MIMEMultipart()
    msg["From"] = from_addr
    msg["Subject"] = subject
    msg["Date"] = formatdate(localtime=True)
    html=html_tag
    if body_text:
        part2 = MIMEText(html, 'html')
        msg.attach( part2 )
 
    msg["To"] = ', '.join(to_emails)
    msg["cc"] = ', '.join(cc_emails) 
    emails = to_emails + cc_emails
    server = smtplib.SMTP(host)
    server.sendmail(from_addr, emails, msg.as_string())
    server.quit()
 

def tableRow( tablename  , yrowcount, trowcount, s3path, threshold):
    #table_row="""<tr><td>"""+str(run_date)+"""</td>"""
    table_row="""<td>"""+str(tablename)+"""</td>"""
    table_row+="""<td>"""+str(yrowcount)+"""</td>"""
    table_row+="""<td>"""+str(trowcount)+"""</td>"""
    
    
    if int(yrowcount)!=0:
        change=((float(trowcount)- float(yrowcount))/float(yrowcount))*100
    else:
        change=0
        
    if (change>=threshold or -change>=threshold )  or change==0:
        table_row+="""<td><font color="red">"""+str("%.2f" % change)+ """</font></td>"""
    else:
        table_row+="""<td>"""+str("%.2f" % change)+ """</td>"""
    
    if int(trowcount)==0:
        table_row+="""<td><font color="red">Job Failed</font></td>"""
    else:
        table_row+="""<td><font color="green">Job Success</font></td>"""
    
    table_row+="""<td>"""+str(s3path)+"""</td></tr>"""
    print table_row
    return table_row
    

def Emailrow_header(headerlist):
    email_row="""<h3><b>%s</b></h3><table border=1><tr><th>Table name</th><th>%s Rowcount</th><th>%s Rowcount</th><th>Percentage Variation</th><th>JobStatus</th><th>S3 Folder Path</th></tr>"""
    
#    email_row="""<h3><b>Recruit S3 Daily Load Status</b></h3>
#                    <table border=1>
#                    	<tr>
#                    		<th>Table name</th>
#                    		<th>Yesterday Rowcount</th>
#                    		<th>today Rowcount</th>
#                    		<th>Percentage Variation</th>
#                </tr>"""
    
    return email_row%tuple(headerlist)
    

def tabletag():
    return "</table>"
    

def composebodydict(table_dict ,  headerlist, threshold):
    body=Emailrow_header(headerlist)
    for tablename  ,datevalue in table_dict.iteritems():
        s3path=datevalue.pop('s3folder')
        print "s3 path",s3path
        body+=tableRow(tablename, str(table_dict.get(tablename).get(sorted(datevalue)[0])) , str(table_dict.get(tablename).get(sorted(datevalue)[1])), s3path, threshold)
    body+=tabletag()  
    return body     
    



def generate_mail(email_list, cc_list,  from_address, subject , table_dict,headerlist, threshold):
    emails    = email_list
    cc_emails=cc_list
    #cc_emails = ['pmishra@movoto.c'aagarwal@movoto.com']
    bcc_emails =cc_emails
    body_text = "This email contains an attachment!"
    html_tag=composebodydict(table_dict, headerlist, threshold)
    
    print "html tag" ,html_tag
    
#    f=open('log.txt','w')
#    f.write(html_tag)
#    f.close()
    
    send_email_with_attachment("localhost",from_address, subject, body_text, emails, cc_emails, bcc_emails, html_tag)
    
    
        
##    
#if __name__ == "__main__":
#    #emails = ['mkumar@movoto.com','pmishra@movoto.com','adesai@movoto.com','rpalraj@movoto.com','adas@movoto.com', 'UPidathala@movoto.com']
#    emails    = ['mkumar@movoto.com'] 
#    cc_emails = ['mkumar@movoto.com']
#    bcc_emails = ['mkumar@movoto.com']
#    from_address='RecruitDailyS3@movoto.com'
#    genheader="""<html>
#                <head>
#                <style>
#                table {
#                    font-family: arial, sans-serif;
#                    border-collapse: collapse;
#                    width: 100%;
#                }
#                
#                td, th {
#                    border: 1px solid #dddddd;
#                    text-align: left;
#                    padding: 8px;
#                }
#                
#                tr:nth-child(even) {
#                    background-color: #dddddd;
#                }
#                </style>
#                </head>
#                <body>
#                <h3><b>Recruit S3 Daily Load Status</b></h3>
#                                    <table border=1>
#                                    	<tr>
#                                    		<th>Table name</th>
#                                    		<th>2017-08-26 Rowcount</th>
#                                    		<th>2017-08-27 Rowcount</th>
#                                    		<th>Percentage Variation</th>
#                                          <th>S3 Path <br>s3a://recruit-redshift.movoto.com/bb-input/2017-08-27</th>
#                                </tr><td><b>ADDRESS</b><br>Address information about property</td><td>16758</td><td><font color="red">Job Failed</font></td><td><font color="red">-100.00</font></td><td>bkfs.address</td></tr><td><b>MLS_PUBLIC_RECORD_ASSOCIATION</b><br>Official record of property having sales and tax information</td><td>30625</td><td><font color="red">Job Failed</font></td><td><font color="red">-100.00</font></td><td>mls.mls_public_record_association</td></tr><td><b>PROPERTY_HISTORY_UPDATED</b><br>Property with updated information</td><td>320192</td><td><font color="red">Job Failed</font></td><td><font color="red">-100.00</font></td><td>mls.property_history_updated</td></tr><td><b>MLS_LISTING</b><br>MLS provided information about listing</td><td>81294</td><td><font color="red">Job Failed</font></td><td><font color="red">-100.00</font></td><td>mls.mls_listing</td></tr><td><b>DELETE_PROPERTY</b><br>Property that are has to be deleted </td><td>65032</td><td><font color="red">Job Failed</font></td><td><font color="red">-100.00</font></td><td>mls.delete_property</td></tr></table>"""
#


#    subject = "MLS Daily Upload status"
#    body_text = "This email contains an attachment!"
#    file_to_attach="sample2.csv"
#    html_tag= genheader
#    #print composebodydict(table_dict)
#    send_email_with_attachment("localhost",from_address, subject, body_text, emails, cc_emails, bcc_emails, html_tag)
#    

