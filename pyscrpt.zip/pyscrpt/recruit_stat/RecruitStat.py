# -*- coding: utf-8 -*-
"""
Created on Wed Aug 23 18:59:46 2017

@author: manoj
"""

import luigi
import datetime
import boto
import boto.s3.connection
from boto.s3.key import Key

import  movoto_logger 
from urllib2 import *
from S3GenericLuigi import *
import ssl
if hasattr(ssl, '_create_unverified_context'):
   ssl._create_default_https_context = ssl._create_unverified_context
   
aws_folder='s3file'
from settings import *
from  mail_alert import generate_mail



logger = movoto_logger.get_logger('recruit_daily_stat.log')

   
class S3connector:
    def __init__(self, aws_access_key, aws_access_secret):
        try:
            self.client= S3GenericLuigi(aws_access_key, aws_access_secret)
            logger.info(" connected")
        except Exception as e:
            logger.critical( "Unable to connect to s3 %s"%e)
            sys.exit()
    
    def  S3listfiles(self , s3DirectoryPath):
        #print "no of files",self.client.listdir(s3DirectoryPath)
        #print "existemse check" ,self.client.exists(s3DirectoryPath)
        if self.client.exists(s3DirectoryPath):
            return self.client.listdir(s3DirectoryPath)
        else :
            logger.critical("No files for given path %s"%s3DirectoryPath)
            sys.exit(0)

    def  S3putfiles(self , s3path, localpath):
        return self.client.get(s3path, localpath) 
        
    def parse_files(self, s3DirectoryPath , uploadate ,tablelist):
        try:
            for path in self.S3listfiles("{0}/{1}".format(s3DirectoryPath, uploadate)):
                for tables in tablelist:
                    s3ob=re.search("{0}/{1}/\S+.{2}".format(s3DirectoryPath, uploadate,tables), path)
                    if s3ob:
                        logger.info( "path %s"%path)
                        if path.endswith(".txt"):
                            self.S3putfiles(path, "./{0}/{1}_{2}_metadata.txt".format(aws_folder, uploadate, re.search(uploadate+'/(\S+)/',path).group(1)))
            return path
        except Exception as e:
            logger.critical( "Unable to parse files %s"%e)
            sys.exit()
            return None


    
    
    
    
    
class RecruitDownload(luigi.Task):
    run_date = luigi.DateParameter(default = datetime.date.today()-datetime.timedelta(days=1))
    last_date=luigi.DateParameter(default = datetime.date.today()-datetime.timedelta(days=1))
    table_list=luigi.Parameter()
    frequency=luigi.Parameter(default='daily')
        
    def requires(self):pass
               
    def run(self):
        try:
            luigi_config = luigi.configuration.get_config()
            access_key1=luigi_config.get('aws','access_key')
            access_secret1=luigi_config.get('aws','access_secret')
            s3DirectoryPath=luigi_config.get('aws','s3DirectoryPath')
            
            awsobj=S3connector(access_key1, access_secret1)  
            today=awsobj.parse_files(s3DirectoryPath, self.run_date.strftime('%Y%m%d'), self.table_list) 
            yesterday= awsobj.parse_files(s3DirectoryPath, self.last_date.strftime('%Y%m%d') ,self.table_list) 
            
            if (today==None and yesterday==None):
                sys.exit()
        except Exception as e:
            logger.critical( "Unable to download files %s"%e)
            sys.exit()
            
        with self.output().open('w') as f:
            f.write('{word}\n'.format(word='SqoopExportTask'))
    
    def output(self):
        return luigi.LocalTarget(path='target/RecruitDailystat_%s_%s.txt'%(self.run_date.strftime('%Y-%m-%d') , self.frequency))







class GenerateReport(luigi.Task):
    run_date = luigi.DateParameter(default = datetime.date.today()-datetime.timedelta(days=1))
    daily_table_list=[ 'mls_public_record_association', 'mls_listing', 'address', 'delete_property', 'property_history_updated']
    daily_table_description={ 'mls_public_record_association':'table that relates listing and public record', 'mls_listing':'MLS provided data about listing' , 'address':'Address information about property', 'delete_property': "Property that are has to be deleted ", 'property_history_updated' : "Property with updated information"}
    frequency=luigi.Parameter(default='daily')
#    monthly_table_list=['public_record', 'pr_assigned_school', 'pr_assigned_school_district', 'avm', 'deeds', 'sam', 'pr_avm', 'price_history']
#    monthly_table_description={ 'public_record':'Official record of property having sales and tax information', 'pr_assigned_school':'Table that relates school and public record' , 'pr_assigned_school_district':'Table that relates school and public record', 'avm': "Pricing Model for Property ", 'deeds' : "Property that got Registered in legal office" ,'sam' : "Property that got Registered in legal office", 'pr_avm':"public Record avm", 'price_history': "Historical data of price for property "}
#    
    monthly_table_list=['public_record', 'pr_assigned_school', 'pr_assigned_school_district', 'pr_avm', 'deeds', 'sam']
    monthly_table_description={ 'public_record':'Official record of property having sales and tax information', 'pr_assigned_school':'Table that relates school and public record' , 'pr_assigned_school_district':'Table that relates school and public record', 'pr_avm': "Pricing Model for Property ", 'deeds' : "Property that got Registered in legal office" ,'sam' : "Property borrower and lender information"}
    day=30

    
    def requires(self):
        if self.frequency=='daily':
            last_date=self.run_date-datetime.timedelta(days=1)
            return RecruitDownload(self.run_date, last_date, self.daily_table_list ,self.frequency)
        else:
            last_date=(self.run_date-datetime.timedelta(days=self.day)).strftime('%Y-%m')+'-15'
            self.run_date=datetime.datetime.strptime(((self.run_date-datetime.timedelta(days=0)).strftime('%Y-%m')+'-15'),'%Y-%m-%d')
            return RecruitDownload(self.run_date, datetime.datetime.strptime(last_date,'%Y-%m-%d'), self.monthly_table_list ,self.frequency)
            
        
        
    def run(self):
        luigi_config = luigi.configuration.get_config()
        if self.frequency=='daily':
            s3DirectoryPath=luigi_config.get('aws','s3DirectoryPath')
            today_date=(self.run_date-datetime.timedelta(days=0)).strftime('%Y%m%d')
            last_date=(self.run_date-datetime.timedelta(days=1)).strftime('%Y%m%d')
            table_list=self.daily_table_list
            table_description=self.daily_table_description
            headerlist=['Recruit S3 Daily Load Status ( S3root_path = %s )'%(s3DirectoryPath+'/'+today_date),  (self.run_date-datetime.timedelta(days=1)).strftime('%Y-%m-%d'), (self.run_date-datetime.timedelta(days=0)).strftime('%Y-%m-%d')]
            from_address='RecruitDailyS3@movoto.com'
            subject = "Recruit S3 Daily Load Report"
            
        else:
            
            s3DirectoryPath=luigi_config.get('aws_monthly','s3DirectoryPath')
            #s3DirectoryPath_sanghai=luigi_config.get('aws_monthly','s3DirectoryPath_sanghai')
            today_date=(self.run_date-datetime.timedelta(days=0)).strftime('%Y%m%d')   
            last_date=(self.run_date-datetime.timedelta(days=self.day)).strftime('%Y%m')+'15'
            table_list=self.monthly_table_list
            table_description=self.monthly_table_description
            headerlist=['Recruit S3 Monthly Load Status ( S3root_path = %s )'%(s3DirectoryPath+'/'+today_date),  (self.run_date-datetime.timedelta(days=self.day)).strftime('%Y-%m')+'-15', (self.run_date-datetime.timedelta(days=0)).strftime('%Y-%m-%d')]
            from_address='RecruitMonthlyS3@movoto.com'
            subject = "Recruit S3 Monthly Load Report"



            
        try:
            s3filelist=os.listdir(aws_folder)
            table_stat={}                  
            for p in s3filelist:
                ob=re.search('(\d+)_(\S+)_metadata.txt',p)
                if ob:
                    date=ob.group(1)
                    s3folder=ob.group(2)
                    tablekey=ob.group(2).split(".")[1]
                    rowcount=self.parse_rowcount(aws_folder+'/'+p)
                    if (table_stat.get(tablekey))==None:
                        table_stat[tablekey]={}
                        table_stat[tablekey][date]=rowcount
                        print "s3folder" ,s3folder
                        table_stat[tablekey]["s3folder"]=s3folder
                    else:
                        table_stat[tablekey][date]=rowcount     
                os.remove(aws_folder+'/'+p)
            
            print "table_stat from aws",table_stat                    
            for key in table_list:
                if key not in table_stat.keys() :
                    table_stat[key]={ last_date: 0 ,today_date: 0 ,'s3folder':''}
                elif table_stat.get(key).get(today_date)==None:
                    table_stat[key][today_date]=0
                elif table_stat.get(key).get(last_date)==None:
                    table_stat[key][last_date]=0
                else:pass
            
            
            table_stat_description={}
            for tablename,description in table_description.iteritems():
                table_stat_description["<b>{0}</b><br>{1}".format(tablename.upper(), table_description.get(tablename))]  =table_stat[tablename]
                table_stat_description["<b>{0}</b><br>{1}".format(tablename.upper(), table_description.get(tablename))]["s3folder"]  =table_stat[tablename]["s3folder"]
               
               
        except Exception as e:
            logger.critical( "Unable to create stat  from files %s"%e)
            sys.exit()
            
        print "table dictionary", table_stat_description  

        generate_mail(TO_ADDRESS,CC_ADDRESS, from_address, subject ,table_stat_description , headerlist, 15)
              
        with self.output().open('w') as f:
            f.write('{word}\n'.format(word='GenerateReport'))



    def parse_rowcount(self, path):
        try:
            contentlis=open(path).readlines()
            for content in contentlis:
                ob=re.search('Total\s+Row\s+Count\s+=\s+(\d+)',content)
                if ob:
                    return ob.group(1)
            return 0
        except Exception as e:
            logger.critical( "Unable to get row count form file %s"%e)
            sys.exit()
            return 0 
    
    def output(self):
        return luigi.LocalTarget(path='target/GenerateReport_%s_%s.txt'%(self.run_date.strftime('%Y-%m-%d'), self.frequency))

    
