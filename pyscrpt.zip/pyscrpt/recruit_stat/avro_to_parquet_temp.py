#Python librarie
import os
import subprocess
import datetime
import json
import re
#import thrift

#Internal libraries
import luigi_properties
#from movoto_task import MovotoTask
#from movoto_task import MovotoEsTarget
#Third-party libraries
import luigi
from luigi.contrib.hdfs.hadoopcli_clients import HdfsClient
from luigi.hive import HiveTableTarget, run_hive_cmd
#import  movoto_logger 





#logger = logging.getLogger('luigi-interface')

def get_job_config(job_name):
    luigi_config = luigi.configuration.get_config()
    tasks_path = (luigi_config.get('movoto', 'tasks-path'))
    
    config = None
    if "novamobile" in job_name:
        with open('%s/config/novamobile/%s.json' % (tasks_path, job_name), 'r') as f:
        	config = json.load(f)
    elif "novadesktop" in job_name:
        with open('%s/config/novadesktop/%s.json' % (tasks_path, job_name), 'r') as f:
            config = json.load(f)
    elif "mls" in job_name:
        with open('%s/config/mls/%s.json' % (tasks_path, job_name), 'r') as f:
            config = json.load(f)   
    elif "user_mart" in job_name:
        with open('%s/config/user_mart/%s.json' % (tasks_path, job_name), 'r') as f:
            config = json.load(f)
    #elif "geo/" in job_name:
    #    job_path, job_name = job_name.split('/')
    #    with open('%s/config/geo/%s.json' % (tasks_path, job_name), 'r') as f:
    #            config = json.load(f)
    else:
        with open('%s/config/mls/%s.json' % (tasks_path, job_name), 'r') as f:
                config = json.load(f)
    return config

class GetDailyData(luigi.Task):
    jobs_list = luigi.Parameter(default = 'pr_tables')
    run_date = luigi.DateParameter(default = datetime.date.today()-datetime.timedelta(days=0))
    get_all = luigi.Parameter(default = 'no')
    
    def requires(self):
        #read the jobs_list file. return a job for each job in the file for today
        jobs = []
        with open(self.jobs_list + '.txt', 'r') as file:
            jobs = file.read().splitlines()
        return [ImportParTable(job_name=job, run_date=self.run_date, get_all=self.get_all) for job in jobs]

    def run(self):
        with self.output().open('w') as f:
            f.write('{word}\n'.format(word='GetDailyData_'))
    
    def output(self):
        return luigi.LocalTarget(path='target/GetDailyData_%s_%s.txt'%(self.jobs_list,self.run_date.strftime('%Y-%m-%d')))                          


class ImportParTable(luigi.Task):
    job_name = luigi.Parameter()
    run_date = luigi.DateParameter(default = datetime.date.today()-datetime.timedelta(days=1))
    #logger = luigi.Parameter(default =movoto_logger.get_logger('panther_to_hive_daily.log'))
    logger = luigi.Parameter(default ='')
    get_all = luigi.Parameter(default = 'no')
    database=luigi.Parameter(default = 'bkfs')
    temptable=luigi.Parameter(default = '')
    parquetable=luigi.Parameter(default = '')
#    
#    def __init__(self, *args, **kwargs):
#        super(ImportParTable, self).__init__(*args, **kwargs)
        
        
    
    
    def requires(self):
        return AvroToParquet(self.job_name, self.run_date, self.get_all , self.logger)
    
    def run(self):
        self.job_config = get_job_config(self.job_name)
        self.temptable=self.job_config['temptable']
        self.logger.info("configuration  %s"%self.job_config)
        self.parquetable=self.job_config['parquetable']
        
#        try: 
#            #self.logger.info("checking table  %s exist"%"{0}.{1}".format(self.database,self.temptable))
#            target = HiveTableTarget(table=self.temptable , database=self.database).exists()
#            if (target!=True): 
#                run_hive_cmd(texttable_schema)
#                self.logger.error("temp table does't exist")
#            self.logger.info("table  %s exist"%"{0}.{1}".format(self.database,self.temptable))
#            truncate_query="truncate table [database].[temptable]".replace('[database]',self.database).replace('[temptable]',self.temptable)
#            run_hive_cmd(truncate_query)
#            self.logger.info("table successfully  truncated")
#        except Exception as e:
#            self.logger.critical("Error as %s"%e)
#            return 0 
            
#####################load to temp table ##################################\           
#            
#        try:
#            hdfs_client = HdfsClient()
#            path=job_config['sqoop_output_dir']
#            hdfsfiles=hdfs_client.listdir(path)
#            for name in hdfsfiles:
#                name=name.rstrip('\n')
#                obj=re.search('\S+.*parquet',name)
#                if (obj):
#                    load_data_query="LOAD DATA INPATH '%s' INTO TABLE [database].[temptable];"%obj.group(0)
#                    loadquery=load_data_query.replace('[database]',self.database).replace('[temptable]',self.temptable)
#                    self.logger.info("loading parquet file %s to temp table"%obj.group(0))
#                    run_hive_cmd(loadquery)
#        except Exception as e:
#            self.logger.critical("hive error while loading file to table %s"%e)
#            return 0
        
        try:
            
            target = HiveTableTarget(table=self.temptable , database=self.database).exists()
            if target:
                job_config = get_job_config(self.job_name)
                if job_config['partitionedBy'] <> "False":
                    stdout=run_hive_cmd('LOAD DATA INPATH \'{0}\' INTO TABLE {2}.{1} PARTITION({4}=\"{3}\");'.format(job_config['parquet_output_dir'],self.temptable,self.database,self.run_date,str(job_config['partitionedBy'])))
                    self.logger.info('Ran Load Successfully...,Created New Partition')
                else:
                    stdout=run_hive_cmd('LOAD DATA INPATH \'{0}\' INTO TABLE {2}.{1};'.format(job_config['parquet_output_dir'],table_name,database_name))
                    self.logger.info('Ran Load Successfully...')
            else:
                self.logger.info('Table {0} in Database {1} Does not exist..'.format(table_name,database_name))
        except Exception as e:
            self.logger.critical("hive error while loading file to temp table %s"%e)
            return 0

#########################loading to final parquet table###################################
#        
#        try:
#            self.logger.info("setting hive orc paramter")
#            run_hive_cmd("set hive.mv.files.thread=0;")
#            
#            parquet_convesion_qry=self.job_config['parquet_casting']
#            final_insert_query="""insert into [database].[parquet_table]
#                                """
#            final_insert_query+=parquet_convesion_qry
#            final_insert_query=final_insert_query.replace('[database]',self.database).replace('[temptable]',self.temptable).replace('[parquet_table]' ,self.parquetable)
#            self.logger.info("loading to final parquet table  %s"%final_insert_query)            
#            run_hive_cmd(final_insert_query)
#        except Exception as e:
#            self.logger.critical("hive error while loading file to final parquet table %s"%e)
#            return 0
                    
        
        with self.output().open('w') as f:
            f.write('{word}\n'.format(word='ImportParTable_'))
    
    def output(self):
        return luigi.LocalTarget(path='target/ImportParTable_%s_%s.txt'%(self.job_name,self.run_date.strftime('%Y-%m-%d')))                          
        



class AvroToParquet(luigi.Task):
    job_name = luigi.Parameter()
    run_date = luigi.DateParameter(default = datetime.date.today()-datetime.timedelta(days=1))
    get_all = luigi.Parameter(default = 'yes')
    logger = luigi.Parameter(default ='')
    
    
    def requires(self):
        return SqoopImportTask(self.job_name, self.run_date, self.get_all ,self.logger)
    
    def run(self):
        self.job_config = get_job_config(self.job_name)
        config = luigi.configuration.get_config()
        avro_tools = config.get('avro', 'path-to-avro-tools')
        luigi_config = luigi.configuration.get_config()
        current_tag=self.job_name+'_'+self.run_date.strftime('%Y-%m-%d')
        
        ##################get schema from  hdfs avro file and copy to local system ###############        
        try:  
            commands = [luigi_config.get('hadoop','command'), 'jar']
            commands.append(avro_tools)
            commands.append('getschema')
            avropath=self.job_config['sqoop_output_dir']+'/part-m-00000.avro'
            self.logger.info("avro file  %s "%avropath)
            commands.append(avropath)
            local_schema_path='%s/%s.avsc'%(luigi_config.get('movoto', 'schemas-path'), current_tag)
            
            if  os.path.exists(local_schema_path):
                os.remove(local_schema_path)
                self.logger.info("deleted the file for rewriting")             
            
            self.logger.info("running command   %s "%commands)
            with open(local_schema_path, 'w') as filep:
                filep.write(subprocess.check_output(commands))   
            self.logger.info("writing schema file to local system is  completed with following commnad %s"%commands)
        except Exception as e:
                self.logger.critical("error %s"%e)
                return 0

        #######################from local system  copy to  hdfs ###############           
        try:
            hdfs_client = HdfsClient()
            avro_schema='%s/%s.avsc' % (self.job_config['sqoop_output_dir'], current_tag)
            self.logger.info("copying to hdfs filesys at %s" ,avro_schema)
            if (hdfs_client.exists(avro_schema)==1):
                hdfs_client.remove(avro_schema)
            hdfs_client.put(local_schema_path, avro_schema)     
            self.logger.info("copied at %s" ,avro_schema)
        except Exception as e:
            self.logger.critical("error %s"%(e))
            return 0
        
#############create parquet file format for loading###################
        
        try:
            hdfs_client = HdfsClient()
            path=self.job_config['sqoop_output_dir']
            hdfsfiles=hdfs_client.listdir(path)
            for name in hdfsfiles:
                name=name.rstrip('\n')
                obj=re.search('\S+.*avro',name)
                if (obj):
                    hadoop_command = [luigi_config.get('hadoop','command'), 'jar']
                    hadoop_command.append(luigi_config.get('avro', 'avro2parquet-path'))
                    hadoop_command.append(luigi_config.get('avro', 'avro2parquet-main'))
                    hadoop_command.append(luigi_config.get('avro', 'jvm-par'))       
                    #Path to Avro Schema File
                    hadoop_command.append(avro_schema)      
                    #Path to Avro Data File
                    hadoop_command.append(obj.group(0))
                    #Output Path
                    hadoop_command.append(self.job_config['parquet_output_dir'])
                    self.logger.info('AvroToParquetTask::run_task: Running command: %s' % (' '.join(hadoop_command)))
                    output = subprocess.check_output(hadoop_command)
                    self.logger.info('Task completed with output: %s' % output)
        except Exception as e:
            self.logger.critical("error %s"%(e))
            return 0    


        
        with self.output().open('w') as f:
            f.write('{word}\n'.format(word='AvroToParquet'))
    
    
    def output(self):
        return luigi.LocalTarget(path='target/AvroToParquet%s_%s.txt'%(self.job_name,self.run_date.strftime('%Y-%m-%d')))

        
        

        
        
        
        
class SqoopImportTask(luigi.Task):
    job_name = luigi.Parameter()
    run_date = luigi.DateParameter(default = datetime.date.today()-datetime.timedelta(days=1))
    get_all = luigi.Parameter(default = 'yes')
    logger = luigi.Parameter(default ='')
    #daydiff = luigi.Parameter(default = '10')
    
    
#    def __init__(self, *args, **kwargs):
#        super(SqoopImportTask, self).__init__(*args, **kwargs)
    
    def run(self):
        #get DB info
        #build parameters using config
        job_config = get_job_config(self.job_name)
        db_config = luigi_properties.DATABASES[job_config['db']]
        luigi_config = luigi.configuration.get_config()
        
        commands = []
        
        commands.append(luigi_config.get('sqoop', 'sqoop-path'))
        commands.append('import')

        if self.get_all == False:
	    commands.append(luigi_config.get('hadoop','parameter'))
        
        #commands.append('-fs local')
        
        #DB Driver info
        driver_class = luigi_properties.DRIVERS[db_config['driver']]['driver_class']
        
        commands.append('--driver')
        commands.append(driver_class)
        
        #DB connection string
        jdbc_driver = luigi_properties.DRIVERS[db_config['driver']]['jdbc_driver']
        connection_string = luigi_properties.DRIVERS[db_config['driver']]['connection_string'].format(jdbc_driver, db_config['host'], str(db_config['port']), db_config['name'])
        
        commands.append('--connect')
        commands.append(connection_string)
        
        #DB Credentials
        commands.append('--username')
        commands.append(db_config['username'])
        commands.append('--password')
        commands.append(db_config['password'])
        
        #DB Query String
        commands.append('--query')
        self.logger.info ("getall value %s"%self.get_all)
        if self.get_all == 'yes':
            self.logger.info("table query %s"%job_config['db_query'])
            commands.append(job_config['db_query'].replace('CURRENT_DATE',self.run_date.strftime('%Y-%m-%d')))
        else:
            commands.append(job_config['db_daily_query'].replace('$START_DATE', self.run_date.strftime('%Y-%m-%d')).replace('$END_DATE', (self.run_date + datetime.timedelta(1)).strftime('%Y-%m-%d')))
        
#        commands.append('--fields-terminated-by')
#        commands.append('\t')
        
        #Output file type
        if job_config['avro_transform'] == True:
            commands.append(luigi_properties.FILE_TYPES['avro'])
        else:
            commands.append(luigi_properties.FILE_TYPES['parquet'])
        
        #Data Output path
        commands.append('--target-dir')
        hdfs_client = HdfsClient()
        if (hdfs_client.exists(job_config['sqoop_output_dir'])) :
            hdfs_client.remove(job_config['sqoop_output_dir'])
            self.logger.info("removing hdfs path")
            
        commands.append(job_config['sqoop_output_dir'])
        #commands.append("/opt/bkfs_upload/logs/avrofiles")
        
        if self.get_all == 'yes':
            commands.append('-m')
            commands.append('1')
        else:
            commands.append('-m')
            commands.append('1')
        
        
#        commands.append('--split-by')
#        commands.append(job_config['partitionedBy'])
        
#        if self.get_all == 'yes' :
#            commands.append('--split-by')
#            #commands.append('mls_id')
#            commands.append(job_config['partitionedBy'])
            
        self.logger.debug('SqoopImportTask::run_task: Running command: \n%s' % (' '.join(commands)))
        
        
        
        #Run the command
        self.logger.info("sqoop command %s"%commands)
        try:
#            hdfs_client = HdfsClient()
#            self.logger.info("recreating folder to copy")
#            hdfs_client.mkdir("/data/LM/Avro/mls/public_record_assoc_temp")
            output = subprocess.check_output(commands)
        except Exception as e:
            self.logger.critical("error %s"%(e))
            return 0 
        
        
        self.logger.debug('SqoopImportTask::run_task: Command completed with output: %s' % (output))
        
        with self.output().open('w') as f:
            f.write('{word}\n'.format(word='SqoopImportTask'))
    
    def output(self):
        return luigi.LocalTarget(path='target/SqoopImportTask_%s_%s.txt'%(self.job_name,self.run_date.strftime('%Y-%m-%d')))


   
class TaskException(Exception):
    pass

if __name__ == "__main__":
    luigi.run()   
