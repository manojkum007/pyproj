# -*- coding: utf-8 -*-
"""
Created on Thu Mar 29 22:34:35 2018

@author: manoj
"""

ll=[10, 1, 10, 1, 10]
#ll=[4, 10, 10, 5, 10]
ll=[75, 26, 45, 72, 81, 47, 29, 97, 2, 75, 25, 82, 84, 17, 56, 32, 2,
    28, 37, 57, 39, 18]

lis=[]
for i in range(len(ll)):
    if i%2==0:
        lis.append(min(range(1,ll[i]+1)))
    else:
        lis.append(max(range(1,ll[i]+1)))

print lis
def sum_cal(ll):
    summer=0
    for i in range(1,len(ll),1):
        summer+=abs(ll[i]-ll[i-1])
    return summer



print sum_cal(lis)
        