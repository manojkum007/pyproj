# -*- coding: utf-8 -*-
"""
Created on Tue Jul 11 14:32:47 2017

@author: manoj
"""

class Person:
    def __init__(self, first, last):
        
    
    @property
    def Name(self):
        return self.firstname + " " + self.lastname

class Employee(Person):

    def __init__(self, first, last, staffnum):
        Person.__init__(self,first, last)
        self.staffnumber = staffnum

    def GetEmployee(self):
        return self.Name() + ", " +  self.staffnumber

#x = Person("Marge", "Simpson")
y = Employee("Homer", "Simpson", "1007")

#print(x.Name())

print y.Name()
print(y.GetEmployee())