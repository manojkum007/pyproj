# -*- coding: utf-8 -*-
"""
Created on Mon May 29 12:58:26 2017

@author: manoj
"""

import pandas as pd
import numpy as np

from collections import OrderedDict
from datetime import date

s = pd.Series([1,3,5,np.nan,6,8])
dates = pd.date_range('20130101', periods=6)

df = pd.DataFrame(np.random.randn(6,4), index=dates, columns=list('ABCD'))

#print df.dtypes
#print df.head()
#print df.tail(3)
#print df.index

#print df.columns
#
#print df.values


#print df.describe

#print df.T

#sales = [('Jones LLC', 150, 200, 50),
#         ('Alpha Co', 200, 210, 90),
#         ('Blue Inc', 140, 215, 95)]
#         

sales = [('tem_wynufkhXhkMdGKaNuxrxG','bounce',3),
('tem_wynufkhXhkMdGKaNuxrxG','click',88),
('tem_wynufkhXhkMdGKaNuxrxG','delay',2),
('tem_wynufkhXhkMdGKaNuxrxG','delivery',169),
('tem_wynufkhXhkMdGKaNuxrxG','generation_rejection',4),
('tem_wynufkhXhkMdGKaNuxrxG','injection',173),
('tem_wynufkhXhkMdGKaNuxrxG','open',160),
('tem_4KEZtcB4jqPf763bo9uHaC','bounce',13),
('tem_4KEZtcB4jqPf763bo9uHaC','click',1),
('tem_4KEZtcB4jqPf763bo9uHaC','delay',26),
('tem_4KEZtcB4jqPf763bo9uHaC','delivery',209),
('tem_4KEZtcB4jqPf763bo9uHaC','generation_rejection',4),
('tem_4KEZtcB4jqPf763bo9uHaC','injection',73)]


labels = ['template_id', 'type', 'typecount']
df = pd.DataFrame.from_records(sales, columns=labels)

newlabels=['template_id', 'deliverycount', 'openrate' ,'clickrate']

grouper= df.groupby('template_id')


userdict={}
subdict={}
#{'template_id':None, 'deliverycount':None, 'openrate':None ,'clickrate':None}


for name, group  in grouper: 
    for row in group.iterrows():
        #if row[1]['type']=='delivery':
            #userdict[row[1]['template_id']]=row[1]['typecount']
        subdict[row[1]['type']]=row[1]['typecount']
    userdict[row[1]['template_id']]=subdict
        
        #print row[1]['template_id']

#

for k,v in userdict.iteritems():
    userdict[k]['openrate']=userdict[k]['open']/float(userdict[k]['delivery'])
    userdict[k]['delayrate']=userdict[k]['delay']/float(userdict[k]['delivery'])
    userdict[k]['clickrate']=userdict[k]['click']/float(userdict[k]['delivery'])
    userdict[k]['bouncerate']=userdict[k]['bounce']/float(userdict[k]['delivery'])
    

#print userdict


##########################test data frame##########



sales = [(56,89,3),
(6,9,3),(556,893,113),(5,8,23),(60,19,13),(56,89,3),]



labels = ['ColA', 'ColB', 'colC']
df = pd.DataFrame.from_records(sales, columns=labels)



for i in labels:
    print i ,min(df[i]) ,max(df[i]) ,(len(df[i].unique())/float(df[i].count()))*100

