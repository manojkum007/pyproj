# -*- coding: utf-8 -*-
"""
Created on Sun Jul 30 12:00:55 2017

@author: manoj
"""








#class Employee:
#    age=0
#    def get_employee(self,name,salary):
#        self.name=name
#        self.salary=salary
#
#    def displayEmployee(self):
#       print "Name : ", self.name,  ", Salary: ", self.salary
#


#
#emp1 = Employee()
#
#print emp1.name
#emp2 = Employee()
#print emp1.__dict__
#print Employee.__dict__



#{'displayEmployee': 
#    <function displayEmployee at 0x7fc459d05230>,
#    '__module__': '__main__', 
#    'get_employee':
#        <function get_employee at 0x7fc459cf0e60>, 
#        'age': 0, '__doc__': None}
##emp1.age=10
#print "age" ,emp2.age
#emp1.get_employee("Nitin",5000)
#emp1.displayEmployee()



class Employee:
   empCount = 0
   def __init__(self, name, salary):
       self.name = name
       self.salary = salary
       Employee.empCount += 1
     
   def __add__(self, other):
       return Employee(self.name +other.name,self.salary +other.salary)
       
   def displayCount(self):
       print "Total Employee %d" % Employee.empCount

   def displayEmployee(self):
       print "Name : ", self.name,  ", Salary: ", self.salary


#
emp1 = Employee("Nanda", 2000)
emp2 = Employee("Nanda", 2000)
e=emp1+emp2
e.displayEmployee()

#emp2.displayCount()
#emp2.displayEmployee()
#






class Animal:
    def __init__(self,leg):
        self.legs=leg
    def eat(self):
        print" animal eats"
    def move(self):
        print" animal moves"

class Mammal:
    def __init__(self,habitat):
        self.habitat=habitat
    def move(self):
        print "Mammal move ",self.habitat

class Dog(Animal,Mammal):
    def __init__(self,leg,mtype):
        Animal.__init__(self,leg)
        Mammal.__init__(self,mtype)
        #super(Dog, self).__init__(leg)
    
    def move(self):
        d=Dog(5, "sea")
        Mammal.move(d)
    def bark(self):
        print " dog  has {0}  leg and  barks".format(self.legs)
        
 
 

#d=Dog(4,"habitat_land")
#d.move()     

class  snake(Animal):
    def move(self):
        print "sankes crawls"
        

s=snake()
s.move()
#
#
#d=Dog(4,"land")
#d.eat()
#d.bark()
#d.move()


#class Demo:
#    def __init__(self, a):
#        self.a=a
#    
#    def display(self):
#        d=Demo(25)
#        print "content" ,d.a
#    
#d=Demo(56)
#d.display()
        
