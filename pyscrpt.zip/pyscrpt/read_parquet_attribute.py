# -*- coding: utf-8 -*-
"""
Created on Wed Nov  9 13:00:00 2016

@author: manoj
"""

import parquet
import json

## assuming parquet file with two rows and three columns:
## foo bar baz
## 1   2   3
## 4   5   6
bgfile='/home/manoj/parquet/2016-10-27_145916-m-00000.snappy.parquet'
sample="/home/manoj/parquet/2016-10-06_000623-m-00000.snappy.parquet"
#
#with open(bgfile) as fo:
#   for row in parquet.DictReader(fo, columns=['id', 'address_id','url_type' ]):
#       print(json.dumps(row))
#      


with open(bgfile) as fo:
   for row in parquet.DictReader(fo, columns=["'visitorId'"]):
       print(json.dumps(row))
      
#with open("test.parquet") as fo:
#   # prints:
#   # 1,2
#   # 4,5
#   for row in parquet.reader(fo, columns=['foo', 'bar]):
#       print(",".join([str(r) for r in row]))