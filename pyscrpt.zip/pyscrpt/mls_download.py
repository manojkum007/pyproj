# -*- coding: utf-8 -*-
"""
Created on Mon Mar  7 18:16:12 2016

@author: manoj
"""
#python libraries
import csv
import logging
import re
import string
import urllib2
# import  requests
import datetime
from dateutil.relativedelta import relativedelta
import ast

#third-party libraries
# import usaddress
from lxml import etree
import psycopg2
import luigi
from luigi import postgres
from luigi import six

def get_config(section, name):
    luigi_config = luigi.configuration.get_config()
    return luigi_config.get(section, name)


tiger_host=get_config('localmls', 'db-host')
tiger_database=get_config('localmls', 'db-name')
tiger_user=get_config('localmls', 'db-user')
tiger_password=get_config('localmls', 'db-password')

logger = logging.getLogger('luigi-interface')

AUTH_TOKEN = 'c34z7xKwq8e'
DB_SCHEMA = 'mls_updates'

MLS_URL = 'http://www.terradatum.com/apis/movoto/movoto/mls-data-2.0.xml?authToken=%s'
LISTINGS_URL = 'http://www.terradatum.com/apis/movoto/movoto/property-data-1.0.csv?authToken=%s&mlsId=%s&fromDate=%s'
AGENTS_URL = 'http://www.terradatum.com/apis/movoto/movoto/agent-data-1.0.csv?authToken=%s&mlsId=%s&fromDate=%s'
OFFICES_URL = 'http://www.terradatum.com/apis/movoto/movoto/office-data-1.0.csv?authToken=%s&mlsId=%s&fromDate=%s'
row_mls=[]

def MlsGetid():
    response_mls = urllib2.urlopen(MLS_URL % (AUTH_TOKEN))
    doc = etree.parse(response_mls)
    root = doc.getroot()
    for MLS in root.findall('MLS'):
        rank = MLS.find('mlsId').text
        if (rank is not None):
          row_mls.append(rank)
    return row_mls


class MlsMonthlyDownload(luigi.Task):
    mls = luigi.Parameter()
    #Default the date to the first day of last month
    date = luigi.DateParameter(default=datetime.date.today() - relativedelta(months=1, day=1))
    
    def run(self):  
        result=MlsGetid()
        #result =['MLSPIN']
        #logger.warning( "url data %s"%result)
        yield [ {
                "listings": MlsListingsDownload(mls=mls, date=self.date)
                } for mls in result ]
        
        pass

    def requires(self):
        pass
#        conn = psycopg2.connect(host=tiger_host, dbname=tiger_database, user=tiger_user, password=tiger_password)
#        cur = conn.cursor()
        
        
    
    
    def output(self):
        pass



class MlsListingsDownload(luigi.Task):
    mls = luigi.Parameter()
    #Default the date to the first day of last month
    date = luigi.DateParameter(default=datetime.date.today() - relativedelta(months=1, day=1))
    
    def run(self):  
        url = LISTINGS_URL % (AUTH_TOKEN, self.mls, self.date.strftime('%m-%d-%Y'))
        response = urllib2.urlopen(url)
        #csv_reader = csv.reader(response)
        #logger.warning( "url data %s"%help(csv_reader))
        #logger.warning( "url data %s"%response.read())
        path="/home/manoj/scripts/python_scripts/mls_download/{0}_property_data1.csv".format(self.mls)
        urlFile=open(path ,'w+')
        urlFile.write(str(response.read()))
        urlFile.close()               
        pass

    
    def output(self):
        return luigi.postgres.PostgresTarget(
                                             host=tiger_host,
                                             database=tiger_database,
                                             user=tiger_user,
                                             password=tiger_password,
                                             table='table_updates',
                                             update_id='%s_listings_%s' % (self.mls, self.date.strftime('%Y%m%d')))