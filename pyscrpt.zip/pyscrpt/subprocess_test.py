# -*- coding: utf-8 -*-
"""
Created on Mon Sep 17 14:21:22 2018

@author: manoj
"""


import subprocess


fpath=mongopath+" -h "+mongohostname+" --port "+str(mongoport)+"  -u '"+username+"' -p '"+password+"' -d "+database+" -c "+collectioname +"  --type json '"+path+"' --jsonArray" 
            p = subprocess.Popen([fpath], stdout=subprocess.PIPE, stderr=subprocess.PIPE,shell=True)
            out, err = p.communicate()
            flag=1
            mongomess=err.split("\n")
            for i in mongomess:
                matchObj=re.match( r'(.*)error inserting documents', i)
                if  matchObj:      
                    flag=-1
                matchObj1=re.match( r'(.*)imported 1 document', i)
                if  matchObj1:      
                    flag=0                   
            if (flag==0):
                print "sucess"
                logger.info("loading successfull %s"%mongomess)
            else:
                print "error"
                logger.info("loading Failed %s"%mongomess)
                try:
                    copyfile(path, './%s/%s_%s_%s.json'%(og_errdir, fileprefix, mongoid[docindex], counter))
                except Exception as e:
                    logger.info("error in copying %s"%path)