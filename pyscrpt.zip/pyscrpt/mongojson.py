# -*- coding: utf-8 -*-
"""
Created on Tue Oct 25 14:33:17 2016

@author: manoj
"""

select CAST(id AS  VARCHAR(20)) AS id
 CAST(fips_code AS VARCHAR(5)) AS fips_code
CAST(apn AS VARCHAR(45)) as apn
CAST(address_id AS VARCHAR(36)) as address_id
bkfs_internal_pid as bkfs_internal_pid
est_value as est_value
est_value_high as est_value_high
est_value_low as est_value_low
confidence_score as confidence_score
land_use_code as land_use_code
building_area as building_area
CAST(main_building_area_indicator AS VARCHAR(2)) as main_building_area_indicator
CAST(building_area_1 AS VARCHAR(8)) as building_area_1
CAST(building_area_1_indicator AS VARCHAR(2)) as building_area_1_indicator
CAST(building_area_2 AS VARCHAR(8)) as building_area_2
CAST(building_area_2_indicator AS VARCHAR(2)) as building_area_2_indicator
CAST(building_area_3 AS VARCHAR(8)) as building_area_3
CAST(building_area_3_indicator AS VARCHAR(2)) as building_area_3_indicator
CAST(building_area_4 AS VARCHAR(8)) as building_area_4
CAST(building_area_4_indicator AS VARCHAR(2)) as building_area_4_indicator
CAST(building_area_5 AS VARCHAR(8)) as building_area_5
CAST(building_area_5_indicator AS VARCHAR(2)) as building_area_5_indicator
CAST(building_area_6 AS VARCHAR(8)) as building_area_6
CAST(building_area_6_indicator AS VARCHAR(2)) as building_area_6_indicator
CAST(building_area_7 AS VARCHAR(8)) as building_area_7
CAST(building_area_7_indicator AS VARCHAR(2)) as building_area_7_indicator
lot_size as lot_size
CAST(lot_size_unit AS VARCHAR(2)) as lot_size_unit
year_built as year_built
num_rooms as num_rooms
num_beds as num_beds
num_baths as num_baths
CAST(num_part_baths AS VARCHAR(2)) as num_part_baths
CAST(garage_type AS VARCHAR(1))  as garage_type
num_garages as num_garages
 CAST(assessment_src_file_date AS VARCHAR(50)) 
last_sale_date as last_sale_date
last_sale_price as last_sale_price
CAST(pool AS VARCHAR(1)) as pool
CAST(style AS VARCHAR(1)) as style
CAST(type_construction AS VARCHAR(1)) as type_construction
CAST(exterior_walls AS VARCHAR(1)) as exterior_walls
CAST(foundation AS VARCHAR(1)) as foundation
CAST(roof_cover AS VARCHAR(1)) as roof_cover
CAST(heating AS VARCHAR(1)) as heating
CAST(air_conditioning AS VARCHAR(1)) as air_conditioning
CAST(elevator AS VARCHAR(1)) as elevator
CAST(fireplace AS VARCHAR(1)) as fireplace
CAST(basement AS VARCHAR(1)) as basement
create_time as create_time
update_time as update_time
CAST(old_full_addr AS VARCHAR(200)) as old_full_addr
addr_change_time  as addr_change_time
CAST(property_id AS VARCHAR(36)) as property_id
CAST(url AS VARCHAR(200)) as url from public_record