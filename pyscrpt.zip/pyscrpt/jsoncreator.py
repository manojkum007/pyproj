# -*- coding: utf-8 -*-
"""
Created on Tue Dec 13 22:54:43 2016

@author: manoj
"""
import collections
import json
import pymssql
import itertools
import datetime
import math
import luigi


conn = pymssql.connect('192.168.120.139', 'sa', 'igen', 'AgentDirectory') 
page=100

coldict={    'Url': 0,
             'InActiveUrls': 1,
             'AgentCode': 2,
             'sequenceNumber': 3,
             'OGuserID': 4,
             'NovaId': 5,
             'IdType': 6,
             'AverageRating': 7,
             'ReviewCount': 8,
             'showProfilePage': 9,
             'showInDPP': 10,
             'IsShowDREName': 11,
             'IsShowMailingAddress': 12,
             'MovotoAgentSince': 13,
             'AgentSince': 14,
             'AgentType': 15,
             'AgentStatus': 16,
             'FirstName': 17,
             'MiddleName': 18,
             'LastName': 19,
             'DisplayPhone': 20,
             'HomePhone': 21,
             'OfficePhone': 22,
             'Altphone': 23,
             'CellPhone': 24,
             'Email': 25,
             'AltEmail': 26,
             'LinkedInProfile': 27,
             'FacebookProfile': 28,
             'TwitterProfile': 29,
             'Blog': 30,
             'Languages': 31,
             'Website': 32,
             'streetAddress': 33,
             'HomeCity': 34,
             'HomeZipCode': 35,
             'HomeState': 36,
             'HomeCityCode': 37,
             'Brokerage': 38,
             'BrokerageWebSite': 39,
             'LicenseNumber': 40,
             'LicenseState': 41,
             'ExpireDate': 42,
             'Score': 43,
             'mlsAssociationId': 44,
             'mlsDb': 45,
             'mlsAssociationName': 46,
             'MlsState': 47,
             'Gender': 48,
             'Biography': 49,
             'Spanish': 50,
             'Mandarin': 51,
             'Cantonese': 52,
             'Vietnamese': 53,
             'French': 54,
             'Tagalog': 55,
             'Korean': 56,
             'Portuguese': 57,
             'Russian': 58,
             'Italian': 59,
             'Hindi': 60,
             'German': 61,
             'Japanese': 62,
             'Hebrew': 63,
             'Polish': 64,
             'Arabic': 65,
             'English': 66,
             'PersonalInterests': 67,
             'Speciality': 68,
             'OtherSpeciality': 69,
             'AwardsAndRecognition': 70,
             'QuestionName': 71,
             'Comments': 72,
             'IsJointProfile': 73,
             'SpouseFirstName': 74,
             'IsClaimed': 75,
             'ClaimTime': 76,
             'Zip': 77,
             'StateCode': 78,
             'StateName': 79,
             'CityID': 80,
             'CityName': 81,
             'sitemapCityPropertyPageUrl': 82,
             'CountyID': 83,
             'CountyName': 84,
             'AgentImage': 85,
             'Representing Buyers': 86, 
             'Representing Sellers': 87, 
             'First-Time Buyers': 88, 
             'Short Sales': 89, 
             'Foreclosures': 90, 
             'Auctions': 91, 
             'Relocations': 92, 
             '1031 Exchanges': 93, 
             'Commercial Real Estate': 94, 
             'Rentals': 95, 
             'Rent-to-Owns': 96, 
             'Lease-to-Owns': 97, 
             'Timeshares': 98, 
             'Condos': 99, 
             'Luxury Properties': 100, 
             'Resorts and Second Homes': 101, 
             'Farms/Vineyards': 102, 
             'Horse Properties': 103, 
             'Senior Housing': 104, 
             'Estate Management': 105, 
             'Property Management': 106, 
             'Investment Properties': 107, 
             'Appraisals': 108,
             'QuestionId':109
             }
             
             
            
class parallizecreator(luigi.Task):
    def run(self):
        lis=[11121,22242,33363,44484,55605,66726,77847,88968,100089]
        yield luigi.build([jsonCreator(int(element) for element in lis], workers=2)
#        with self.output().open('w') as f:
#            f.write('{word}\n'.format(word='ImportParTable_'))
    
    def output(self):
        return luigi.file.LocalTarget(path='./logs/parallizecreator.txt') 
        


class jsonCreator(luigi.Task):
    minvalue=luigi.Parameter()
    def requires(self):
        pass
    def run(self):
        cursor = conn.cursor() 
        mongodblis=[]
        userdict,questansdict, mongodb=collections.OrderedDict(),collections.OrderedDict(),collections.OrderedDict()
        query="""select  Url,InActiveUrls, AgentCode, sequenceNumber, OGuserID, NovaId, IdType, AverageRating, ReviewCount, showProfilePage, showInDPP, IsShowDREName, IsShowMailingAddress, MovotoAgentSince, AgentSince, AgentType, AgentStatus, FirstName, MiddleName, LastName, DisplayPhone, HomePhone, OfficePhone, Altphone, CellPhone, Email, AltEmail, LinkedInProfile, FacebookProfile, TwitterProfile, Blog, Languages, Website, streetAddress, HomeCity, HomeZipCode, HomeState, HomeCityCode, Brokerage, BrokerageWebSite, LicenseNumber, LicenseState, ExpireDate, Score, mlsAssociationId, mlsDb, mlsAssociationName, MlsState, Gender, Biography, Spanish, Mandarin, Cantonese, Vietnamese, French, Tagalog, Korean, Portuguese, Russian, Italian, Hindi, German, Japanese, Hebrew, Polish, Arabic, English, PersonalInterests, Rentals, OtherSpeciality, AwardsAndRecognition,QuestionName, Comments, IsJointProfile, SpouseFirstName, IsClaimed, ClaimTime, Zip, StateCode, StateName, CityID, CityName, sitemapCityPropertyPageUrl, CountyID, CountyName, AgentImage,RepresentingBuyers,RepresentingSellers, FirstTimeBuyers, ShortSales, Foreclosures, Auctions, Relocations, 1031Exchanges, CommercialRealEstate, Rentals, RenttoOwns, LeasetoOwns, Timeshares,Condos, LuxuryProperties, ResortsandSecondHomes, FarmsVineyards, HorseProperties,SeniorHousing, EstateManagement, PropertyManagement, InvestmentProperties, Appraisals, QuestionId
                   from AgentDirectory.dbo.Temp_QueryResult_Latest   where  OGuserID>%s and OGuserID<= %s;"""%(self.minvalue,int(self.minvalue)+page) 
        
        cursor.execute(query)
        for row in cursor:
            uniqueuserid=row[coldict['OGuserID']]
            rowlength=len(row)
            agentsince=map(lambda t : t.strftime("%Y-%m-%d") if (type(t)==datetime.datetime) else t,[row[coldict['ExpireDate']]])
            agentsince=agentsince[0]
            qid=row[coldict['QuestionId']]
            qname=row[coldict['QuestionName']]
            ans=row[coldict['Comments']]
            questrow=(qname,ans)
            row=(row[0],row[1],row[2],row[3],row[4],row[5],row[6],float(row[7]),row[8],row[9],row[10],row[11],row[12],row[13],row[14],row[15],row[16],row[17],row[18],row[19],row[20],row[21],row[22],row[23],row[24],row[25],row[26],row[27],row[28],row[29],row[30],row[31],row[32],row[33],row[34],row[35],row[36],row[37],row[38],row[39],row[40],row[41],agentsince,row[43],row[44],row[45],row[46],row[47],row[48],row[49],row[50],row[51],row[52],row[53],row[54],row[55],row[56],row[57],row[58],row[59],row[60],row[61],row[62],row[63],row[64],row[65],row[66],row[67],row[68],row[69],row[70],row[109],row[109],row[73],row[74],row[75],row[76],row[77],row[78],row[79],row[80],row[81],row[82],row[83],row[84],row[85],row[86],row[87],row[88],row[89],row[90],row[91],row[92],row[93],row[94],row[94],row[95],row[96],row[97],row[98],row[99],row[100],row[101],row[102],row[103],row[104],row[105],row[106],row[107],row[108])
            if (userdict.get(uniqueuserid))==None:
                userdict[uniqueuserid]=[]
#                agentkeycount+=1
                userdict[uniqueuserid].append(row)
            else:
                userdict[uniqueuserid].append(row)
            
            if qid!=None:
                uid=uniqueuserid+qid
                if questansdict.get(uid)==None:
                    questansdict[uid]=questrow
            
            print "completed reading from table"
            
        for key,v in userdict.iteritems():
            d=collections.OrderedDict()
            darry=[[]] 
            for i in range(rowlength):
                darry.append([])
            for j in range(len(v)):
                for k in range(len(v[j])):            
                    darry[k].append(v[j][k])
            for ind in range(len(darry)):
                darry[ind]=list(set(darry[ind]))
            
            d["url"]=filter(None,darry[coldict['Url']])[0]
            mongodblis.append(d)
            jsonob=open('./luigireport/withspectresult13dec_%s.json'%self.minvalue,'w')
            mongodb=mongodblis
            json.dump(mongodb,jsonob, indent=4)
            jsonob.close()
        
        with self.output().open('w') as f:
            f.write('{word}\n'.format(word='ImportParTable_'))
            
    def output(self):
        return luigi.file.LocalTarget(path='./logs/creator_json_%s.txt'%(self.minvalue))   
            
            
            
                
                
                
                
            
            
        
        
        
        
        
        