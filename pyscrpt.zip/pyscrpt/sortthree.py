# -*- coding: utf-8 -*-
"""
Created on Sat Jan 13 09:41:11 2018

@author: manoj
"""


import unittest
import itertools
ll=[94,15,9]


def sortthree(ss):
    if ss[0]>ss[1]:
        ss[0],ss[1]=ss[1],ss[0]
    if ss[1]>ss[2]:
        ss[1],ss[2]=ss[2],ss[1]
    if ss[0]>ss[1]:
        ss[0],ss[1]=ss[1],ss[0]
    return ss






testlist=list(itertools.permutations([1,2,3]))

for i in testlist:
    print sortthree(list(i))
