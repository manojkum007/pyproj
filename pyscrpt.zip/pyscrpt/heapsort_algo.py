# -*- coding: utf-8 -*-
"""
Created on Wed Jun  6 21:48:06 2018

@author: manoj
"""


heaparr=[4,1,3,2,16,9,10,14,8,7]

def left(i):
    return 2*i+1
    

def right(i):
    return 2*i+2
    
    
def parent(i):
    return i/2
 
def swapele(first ,sec):
    heaparr[first], heaparr[sec]=  heaparr[sec], heaparr[first]
    
    
def heapsort(index,counter):
    #if (counter>=len(heaparr)):
    if (counter>=50):
        return 0
    else:
        leftindex= left(index)
        rightindex= right(index)
        if leftindex<len(heaparr):
            if (left(index)<len(heaparr) and heaparr[left(index)]>heaparr[index]):
                swapele(leftindex, index)
            print "left",index ,left(index) , "counter" ,counter 
            heapsort(left(index) , counter+1)
        
        if rightindex<len(heaparr):
            #print "right" ,index ,right(index),counter ,heaparr[right(index)],heaparr[index]
            if (right(index)<len(heaparr) and heaparr[right(index)]>heaparr[index]):
                swapele(rightindex, index)
            print "right" ,index ,right(index), "counter" ,counter 
            heapsort(right(index) , counter+1)
        

counter=0
heapsort(0,counter) 

print heaparr     


  
            
        
        