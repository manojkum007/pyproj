# -*- coding: utf-8 -*-
"""
Created on Sat Feb 13 00:13:11 2016

@author: manoj
"""

def cube(x):
    for i in x:
        yield i**3
        
lis=[1,2,5]
data=cube(lis)
data.next()
data.next()
data.next()`
try:
    print data.next()
except :
    print "someerror"